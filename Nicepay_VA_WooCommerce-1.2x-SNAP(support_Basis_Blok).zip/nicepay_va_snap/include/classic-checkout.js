jQuery(function($) {
    console.log('NICEPay classic checkout initialized');

    // Handler untuk perubahan bank
    $('#nicepay-bank-select').on('change', function() {
        var selectedBank = $(this).val();
        console.log('Selected bank:', selectedBank);

        $.ajax({
            url: nicepayData.ajax_url,
            type: 'POST',
            data: {
                action: 'set_nicepay_bank',
                bank_code: selectedBank,
                security: nicepayData.nonce
            },
            success: function(response) {
                console.log('Bank selection saved:', response);
            },
            error: function(error) {
                console.error('Error saving bank selection:', error);
            }
        });
    });

    // Validasi form submission
    $('form.checkout').on('submit', function() {
        var selectedBank = $('#nicepay-bank-select').val();
        if (selectedBank) {
            if (!$('input[name="nicepay_bank"]').length) {
                $(this).append('<input type="hidden" name="nicepay_bank" value="' + selectedBank + '">');
            } else {
                $('input[name="nicepay_bank"]').val(selectedBank);
            }
        }
    });
});