<?php
/**
 * Plugin Name: NICEPay Virtual Account SNAP Payment Gateway
 * Plugin URI: http://nicepay.co.id
 * Description: NICEPay Virtual Account SNAP Payment Gateway for WooCommerce
 * Version: 1.0.0
 * Author: codeNinja
 * Author URI: http://nicepay.co.id
 * Text Domain: nicepay-vasnap-gateway
 * WC requires at least: 5.0
 * WC tested up to: 7.x
 */
defined('ABSPATH') or exit;

// Make sure WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

// Initialize the plugin
add_action('plugins_loaded', 'initialize_nicepay_va_snap', 0);
// add_action('wp_ajax_set_nicepay_bank', array('WC_Gateway_NICEPay_SNAP', 'handle_set_nicepay_bank'));
// add_action('wp_ajax_nopriv_set_nicepay_bank', array('WC_Gateway_NICEPay_SNAP', 'handle_set_nicepay_bank'));


function initialize_nicepay_va_snap() {
    // Check if WooCommerce is active
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    // Load plugin textdomain
    load_plugin_textdomain('nicepay-vasnap-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');

    // Include the main gateway class
    require_once plugin_dir_path(__FILE__) . 'include/index-va.php';
    $gateway = new WC_Gateway_NICEPay_SNAP();
    $settings = get_option('woocommerce_nicepay_va_snap_settings', array());
    $checkout_mode = isset($settings['enable_blocks']) ? $settings['enable_blocks'] : 'classic';

    if ($checkout_mode === 'classic') {
        // Load classic checkout assets and handlers
        add_action('wp_enqueue_scripts', 'enqueue_nicepay_classic_scripts');
        add_action('wp_ajax_set_nicepay_bank', array($gateway, 'handle_set_nicepay_bank'));
        add_action('wp_ajax_nopriv_set_nicepay_bank', array($gateway, 'handle_set_nicepay_bank'));
    } else {
        // Load blocks checkout assets
        add_action('woocommerce_blocks_enqueue_checkout_block_scripts_before', 'enqueue_nicepay_vasnap_scripts');
    }
}

function add_nicepay_va_snap_gateway($methods) {
    $methods[] = 'WC_Gateway_NICEPay_SNAP';
    return $methods;
}
add_filter('woocommerce_payment_gateways', 'add_nicepay_va_snap_gateway');

function enqueue_nicepay_classic_scripts() {
    if (is_checkout()) {
        wp_enqueue_script(
            'nicepay-classic-checkout',
            plugins_url('include/classic-checkout.js', __FILE__),
            array('jquery'),
            '1.0.0',
            true
        );
        
        $gateway = new WC_Gateway_NICEPay_SNAP();
        wp_localize_script(
            'nicepay-classic-checkout',
            'nicepayClassicData',
            array(
                'banks' => $gateway->get_bank_list(),
                'ajax_url' => admin_url('admin-ajax.php')
            )
        );
    }
}

// Enqueue scripts for blocks
function enqueue_nicepay_vasnap_scripts() {
    wp_enqueue_script(
        'nicepay-vasnap-blocks-integration',
        plugins_url('include/blocks-integration.js', __FILE__),
        ['wc-blocks-registry', 'wp-element', 'jquery'],
        '1.0.0',
        true
    );

    wp_enqueue_style(
        'nicepay-vasnap-style',
        plugins_url('include/nicepay-vasnap.css', __FILE__),
        [],
        '1.0.0'
    );
    $gateway = new WC_Gateway_NICEPay_SNAP();
    wp_localize_script(
        'nicepay-vasnap-blocks-integration',
        'nicepayData',
        array(
            'banks' => $gateway->get_bank_list(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'pluginUrl' => plugins_url('', __FILE__)
        )
    );
}
add_action('woocommerce_blocks_enqueue_checkout_block_scripts_before', 'enqueue_nicepay_vasnap_scripts');
