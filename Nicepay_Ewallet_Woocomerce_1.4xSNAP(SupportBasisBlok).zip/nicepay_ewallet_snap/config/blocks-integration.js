const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { createElement, useState } = window.wp.element;

const NicepayEwalletComponent = () => {
    const [selectedMitra, setSelectedMitra] = useState('');
    
    // Gunakan mitra dari nicepayData.enabled_mitra
    const mitra = nicepayData?.enabled_mitra || [];
    console.log('Available mitra:', mitra);

    const handleMitraChange = (e) => {
        const selectedMitraCode = e.target.value;
        console.log('Mitra selected:', selectedMitraCode);
        setSelectedMitra(selectedMitraCode);
        saveMitraSelection(selectedMitraCode);
    };

    const saveMitraSelection = (mitraCode) => {
        console.log('Attempting to save mitra selection:', mitraCode);
        if (typeof jQuery !== 'undefined' && typeof nicepayData !== 'undefined') {
            jQuery.ajax({
                url: nicepayData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_mitra',
                    mitra_code: mitraCode,
                    nonce: nicepayData.nonce
                },
                success: function(response) {
                    console.log('Mitra selection saved:', response);
                    // Simpan ke session storage sebagai backup
                    sessionStorage.setItem('nicepay_selected_mitra', mitraCode);
                },
                error: function(error) {
                    console.error('Error saving mitra selection:', error);
                }
            });
        } else {
            console.error('jQuery or nicepayData is not available');
        }
    };

    // Jika tidak ada mitra yang aktif, jangan tampilkan komponen
    if (!Array.isArray(mitra) || mitra.length === 0) {
        console.log('No active mitra available');
        return null;
    }

    return createElement('div', { className: 'nicepay-ewallet-container' }, [
        createElement('div', { className: 'nicepay-ewallet-header' }, [
            createElement('img', { 
                src: nicepayData.pluginUrl + '/config/ewallet1.png', 
                alt: 'E-wallet Options', 
                className: 'nicepay-ewallet-image' 
            }),
        ]),
        createElement('div', { className: 'nicepay-ewallet-select' }, [
            createElement('label', { htmlFor: 'nicepay-ewallet-select' }, 'Pilih E-wallet:'),
            createElement('select',
                {
                    name: 'nicepay_mitra',
                    id: 'nicepay-ewallet-select',
                    onChange: handleMitraChange,
                    value: selectedMitra
                },
                [
                    createElement('option', { value: '' }, 'Pilih E-wallet'),
                    ...mitra.map(m => createElement('option', 
                        { 
                            value: m.value || m.code, 
                            key: m.value || m.code 
                        }, 
                        m.label || m.name
                    ))
                ]
            )
        ]),
        createElement('p', { className: 'nicepay-ewallet-instruction' }, 
            'Silakan pilih e-wallet untuk pembayaran Anda.'
        )
    ]);
};

registerPaymentMethod({
    name: "nicepay_ewallet_snap",
    label: "NICEPay E-wallet",
    content: createElement(NicepayEwalletComponent),
    edit: createElement(NicepayEwalletComponent),
    canMakePayment: () => true,
    ariaLabel: "NICEPay E-wallet payment method",
    supports: {
        features: ['products'],
    },
});