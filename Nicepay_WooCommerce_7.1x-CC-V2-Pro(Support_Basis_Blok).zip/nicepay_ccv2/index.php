<?php
/*
  Plugin Name: NICEPay Credit Card Payment Gateway
  Plugin URI: http://nicepay.co.id
  Description: NICEPay Plugin for WooCommerce to support payment via Credit Card
  Version: 6.1
  Author: NICEPay <codeNinja>
  Author URI: http://nicepay.co.id
*/

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('NICEPAY_CCV2_VERSION', '6.1');
define('NICEPAY_CCV2_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NICEPAY_CCV2_PLUGIN_URL', plugin_dir_url(__FILE__));

// Fungsi logging
function cc_error_log($message, $type = 'info') {
    $log_file = WP_CONTENT_DIR . '/debug.log';
    $timestamp = current_time('Y-m-d H:i:s');
    
    if (is_array($message) || is_object($message)) {
        $message = print_r($message, true);
    }
    
    $log_message = sprintf("[%s] CC %s: %s\n", $timestamp, strtoupper($type), $message);
    error_log($log_message, 3, $log_file);
}

// Inisialisasi plugin setelah semua plugin dimuat
add_action('plugins_loaded', 'woocommerce_nicepay_ccv2_init', 0);

function woocommerce_nicepay_ccv2_init() {
    cc_error_log('Initializing CC Payment Gateway plugin', 'init');
    
    // Pastikan WooCommerce ada
    if (!class_exists('WooCommerce')) {
        cc_error_log('WooCommerce is not installed or activated', 'error');
        return;
    }

    try {
        // Load main gateway class
        require_once(NICEPAY_CCV2_PLUGIN_PATH . 'config/ccv2.php');
        cc_error_log('Gateway class loaded successfully', 'debug');
        
        // Register gateway dan scripts
        add_filter('woocommerce_payment_gateways', 'add_nicepay_ccv2_gateway');
        
        // Register block support
        add_action('wp_enqueue_scripts', 'register_nicepay_cc_scripts');
        add_action('init', 'register_nicepay_ccv2_block_support');
        
        cc_error_log('Plugin initialized successfully', 'info');
        
    } catch (Exception $e) {
        cc_error_log('Failed to initialize plugin: ' . $e->getMessage(), 'error');
    }
}

/**
 * Add the Credit Card Gateway to WooCommerce
 */
function add_nicepay_ccv2_gateway($methods) {
    cc_error_log('Adding CC gateway to payment methods', 'debug');
    $methods[] = 'WC_Gateway_NICEPay_CCV2';
    return $methods;
}

function register_nicepay_cc_scripts() {
    if (!class_exists('WC_Gateway_NICEPay_CCV2') || !is_checkout()) {
        return;
    }

    try {
        $gateway = new WC_Gateway_NICEPay_CCV2();
        $checkout_mode = $gateway->get_option('enable_blocks', 'classic');
        
        // Enqueue CSS for both modes
        wp_enqueue_style(
            'nicepay-cc-style',
            NICEPAY_CCV2_PLUGIN_URL . 'config/ccv2.css',
            array(),
            NICEPAY_CCV2_VERSION
        );

        if ($checkout_mode === 'blocks') {
            // Blocks mode scripts
            wp_enqueue_script(
                'nicepay-cc-blocks-integration',
                NICEPAY_CCV2_PLUGIN_URL . 'config/block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'),
                NICEPAY_CCV2_VERSION,
                true
            );
            
            wp_localize_script(
                'nicepay-cc-blocks-integration',
                'ccData',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('nicepay-cc-nonce'),
                    'pluginUrl' => NICEPAY_CCV2_PLUGIN_URL,
                    'merchantId' => $gateway->get_option('iMid'),
                    'version' => NICEPAY_CCV2_VERSION
                )
            );
        } else {
            // Classic mode scripts
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_CCV2_PLUGIN_URL . 'config/classic-checkout.js',
                array('jquery'),
                NICEPAY_CCV2_VERSION,
                true
            );
            
            wp_localize_script(
                'nicepay-classic-checkout',
                'nicepayData',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'pluginUrl' => NICEPAY_CCV2_PLUGIN_URL,
                    'nonce' => wp_create_nonce('nicepay-ccv2-nonce'),
                    'merchantId' => $gateway->get_option('iMid'),
                    'version' => NICEPAY_CCV2_VERSION
                )
            );
        }
        
        cc_error_log('Scripts registered successfully for ' . $checkout_mode . ' mode', 'debug');
    } catch (Exception $e) {
        cc_error_log('Failed to register scripts: ' . $e->getMessage(), 'error');
    }
}


/**
 * Register Block Support for WooCommerce Blocks
 */
function register_nicepay_ccv2_block_support() {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        cc_error_log('WooCommerce Blocks not available', 'debug');
        return;
    }

    try {
        // Only register block support if blocks mode is enabled
        $gateway = new WC_Gateway_NICEPay_CCV2();
        if ($gateway->get_option('enable_blocks') === 'blocks') {
            // Add your block registration code here
            cc_error_log('Block support registered successfully', 'debug');
        }
    } catch (Exception $e) {
        cc_error_log('Failed to register block support: ' . $e->getMessage(), 'error');
    }
}
