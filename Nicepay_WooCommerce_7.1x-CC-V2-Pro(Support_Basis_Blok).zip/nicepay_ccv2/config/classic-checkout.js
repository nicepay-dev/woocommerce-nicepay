jQuery(function($) {
    console.log('NICEPay CC classic checkout initialized');

    function createCardInput() {
        if (!nicepayData) {
            console.error('NICEPay configuration is missing');
            return $('<div>').text('Payment configuration is not available');
        }

        const container = $('<div/>', {
            class: 'nicepay-ccv2-container'
        });

        
        const header = $('<div/>', {
            class: 'nicepay-ccv2-header'
        }).append(
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/card.png',
                alt: 'CC Logo',
                class: 'nicepay-ccv2-icon'
            })
        );

        // Credit card logos
        const cardLogos = $('<div/>', {
            class: 'nicepay-ccv2-logos'
        }).append(
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/visa.png',
                alt: 'Visa',
                class: 'card-logo'
            }),
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/mastercard.png',
                alt: 'Mastercard',
                class: 'card-logo'
            }),
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/jcb.png',
                alt: 'JCB',
                class: 'card-logo'
            }),
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/american.png',
                alt: 'AmericanExpress',
                class: 'card-logo'
            })
        );

        container.append(header, cardLogos);
        return container;
    }

    function initNicepayClassic() {
        const paymentMethod = $('input[name="payment_method"][value="nicepay_ccv2"]');
        if (paymentMethod.length) {
            // Remove existing container if any
            paymentMethod.closest('li').find('.nicepay-ccv2-container').remove();
            
            const cardInput = createCardInput();
            paymentMethod.closest('li').append(cardInput);
        }
    }

    // Place order handler
    $('form.checkout').on('checkout_place_order_nicepay_ccv2', function() {
        return true; // Selalu return true karena form input sudah dihilangkan
    });

    // Initialize on page load
    initNicepayClassic();

    // Reinitialize when checkout is updated
    $(document.body).on('updated_checkout payment_method_selected', function() {
        initNicepayClassic();
    });
});