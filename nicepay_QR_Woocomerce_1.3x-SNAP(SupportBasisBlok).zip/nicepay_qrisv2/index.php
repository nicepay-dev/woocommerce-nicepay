<?php
/*
  Plugin Name: NICEPay QRIS SNAP Payment Gateway
  Plugin URI: http://nicepay.co.id
  Description: NICEPay Plugin for WooCommerce to support payment via QRIS
  Version: 1.3
  Author: NICEPay <codeNinja>
  Author URI: http://nicepay.co.id
*/

if (!defined('ABSPATH')) {
    exit;
}

// Fungsi logging
function qris_error_log($message, $type = 'info') {
    $log_file = WP_CONTENT_DIR . '/debug.log';
    $timestamp = current_time('Y-m-d H:i:s');
    
    if (is_array($message) || is_object($message)) {
        $message = print_r($message, true);
    }
    
    $log_message = sprintf("[%s] QRIS %s: %s\n", $timestamp, strtoupper($type), $message);
    error_log($log_message, 3, $log_file);
}

// Inisialisasi plugin setelah semua plugin dimuat
add_action('plugins_loaded', 'woocommerce_nicepay_qrisv2_init', 0);

function woocommerce_nicepay_qrisv2_init() {
    qris_error_log('Initializing QRIS Payment Gateway plugin', 'init');
    
    // Pastikan WooCommerce ada
    if (!class_exists('WooCommerce')) {
        qris_error_log('WooCommerce is not installed or activated', 'error');
        return;
    }

    try {
        // Load main gateway class
        require_once(dirname(__FILE__) . '/assets/class-qris.php');
        qris_error_log('Gateway class loaded successfully', 'debug');
        
        // Register gateway
        add_filter('woocommerce_payment_gateways', 'add_nicepay_qrisv2_gateway');
        add_action('wp_enqueue_scripts', 'enqueue_nicepay_qris_scripts');
        
        qris_error_log('Plugin initialized successfully', 'info');
        
    } catch (Exception $e) {
        qris_error_log('Failed to initialize plugin: ' . $e->getMessage(), 'error');
    }
}

function add_nicepay_qrisv2_gateway($methods) {
    qris_error_log('Adding QRIS gateway to payment methods', 'debug');
    qris_error_log('Current payment methods: ' . print_r($methods, true), 'debug');
    
    $methods[] = 'WC_Gateway_NICEPay_QRISV2';
    
    qris_error_log('Updated payment methods: ' . print_r($methods, true), 'debug');
    return $methods;
}


function enqueue_nicepay_qris_scripts() {
    if (!is_checkout()) return;

    // Dapatkan mode checkout yang aktif
    $gateway = new WC_Gateway_NICEPay_QRISV2();
    $checkout_mode = $gateway->get_option('enable_blocks', 'classic');

    qris_error_log("Plugin base URL: " . plugins_url('', __FILE__), 'debug');
    qris_error_log("Assets URL: " . plugins_url('assets', __FILE__), 'debug');
    qris_error_log("Images URL: " . plugins_url('assets/images', __FILE__), 'debug');

    wp_enqueue_style(
        'nicepay-qris-style',
        plugins_url('assets/qris.css', __FILE__),
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'assets/qris.css')
    );

    
    if ($checkout_mode === 'classic') {
        wp_enqueue_script(
            'nicepay-qris-classic',
            plugins_url('assets/classic-checkout.js', __FILE__),
            array('jquery'),
            filemtime(plugin_dir_path(__FILE__) . 'assets/classic-checkout.js'),
            true
        );
    } else {
        wp_enqueue_script(
            'nicepay-qris-blocks',
            plugins_url('assets/block-integration.js', __FILE__),
            array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'),
            filemtime(plugin_dir_path(__FILE__) . 'assets/block-integration.js'),
            true
        );
    }

    // Localize script data
    $script_handle = ($checkout_mode === 'classic') ? 'nicepay-qris-classic' : 'nicepay-qris-blocks';
    wp_localize_script(
        $script_handle,
        'qrisData',
        array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nicepay-qris-nonce'),
            'pluginUrl' => plugins_url('', __FILE__),
            'assetsUrl' => plugins_url('assets', __FILE__),
            'imagesUrl' => plugins_url('images', __FILE__),
            'merchantId' => $gateway->get_option('iMid'),
            'shopId' => $gateway->get_option('shopId'),
            'mode' => $checkout_mode
        )
    );
}
