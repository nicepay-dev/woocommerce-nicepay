jQuery(function($) {
    console.log('NICEPay QRIS classic checkout initialized');
    console.log('Plugin URL:', qrisData.pluginUrl);
    console.log('Images URL:', qrisData.imagesUrl);

    function initQRISClassic() {
        const container = $('#nicepay-qris-payment-container');
        if (!container.length) return;

    
        container.empty();

        const paymentContent = $('<div/>', {
            class: 'nicepay-qris-wrapper'
        });

        const header = $('<div/>', {
            class: 'nicepay-qris-header'
        }).append(
            $('<img/>', {
                src: qrisData.imagesUrl + '/qrislogo1.png',
                alt: 'QRIS Logo',
                class: 'nicepay-qris-logo'
            }).css({  
                'maxWidth': '200px',
                'height': 'auto',
                'display': 'block',
                'margin': '0 auto'
            })
        );

            const description = $('<div/>', {
                class: 'nicepay-qris-description'
            }).append(
                $('<h3/>').text('Pembayaran QRIS'),
                $('<p/>').text('Pembayaran dapat dilakukan melalui aplikasi:'),
                $('<div/>', {
                    class: 'qris-apps-list'
                }).append(
                    $('<ul/>').append(
                        $('<li/>').text('DANA'),
                        $('<li/>').text('OVO'),
                        $('<li/>').text('GoPay'),
                        $('<li/>').text('ShopeePay'),
                        $('<li/>').text('LinkAja'),
                        $('<li/>').text('Mobile Banking')
                    )
                )
            );

            paymentContent.append(header, description);
            container.append(paymentContent);
        }
    

    $(document.body).on('updated_checkout', initQRISClassic);
    $(document).ready(initQRISClassic);
});