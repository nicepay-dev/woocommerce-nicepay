jQuery(document).ready(function($) {
    console.log('QRIS check status script loaded');
    
    $(document).on('click', '#check-payment', function(e) {
        e.preventDefault();
        console.log('Check payment button clicked');
        
        var button = $(this);
        var orderId = button.data('order');
        
        if (!orderId || !qrisAjax || !qrisAjax.ajaxurl) {
            console.error('Missing required data', {
                orderId: orderId,
                qrisAjax: qrisAjax
            });
            return;
        }
        
        button.prop('disabled', true)
              .text('Memeriksa status pembayaran...');
        
        // Debug info
        console.log('Sending request to:', qrisAjax.ajaxurl);
        console.log('Request data:', {
            action: 'check_qris_payment_status',
            order_id: orderId,
            nonce: qrisAjax.nonce
        });
        
        $.ajax({
            url: qrisAjax.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'check_qris_payment_status',
                order_id: orderId,
                nonce: qrisAjax.nonce
            },
            success: function(response) {
                console.log('AJAX Response:', response);
                
                if (response.success) {
                    handleSuccessResponse(response, button);
                } else {
                    handleErrorResponse(response, button);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                
                handleErrorResponse({
                    data: {
                        message: 'Terjadi kesalahan saat memeriksa status. Silakan coba lagi.'
                    }
                }, button);
            }
        });
    });
    
    function handleSuccessResponse(response, button) {
        if (response.data.status === 'paid') {
            $('#payment-status-result').html(
                '<div class="woocommerce-success">' +
                'Pembayaran berhasil! Halaman akan diperbarui...' +
                '</div>'
            );
            setTimeout(function() {
                window.location.reload();
            }, 2000);
        } else {
            $('#payment-status-result').html(
                '<div class="woocommerce-error">' +
                'Pembayaran belum diterima. Silakan coba lagi setelah melakukan pembayaran.' +
                '</div>'
            );
            button.prop('disabled', false)
                  .text('Periksa Status Pembayaran');
        }
    }
    
    function handleErrorResponse(response, button) {
        $('#payment-status-result').html(
            '<div class="woocommerce-error">' +
            (response.data.message || 'Terjadi kesalahan') +
            '</div>'
        );
        button.prop('disabled', false)
              .text('Periksa Status Pembayaran');
    }
});