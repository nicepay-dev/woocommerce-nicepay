<?php
class WC_Gateway_NICEPay_QRISV2 extends WC_Payment_Gateway {
    public function __construct() {
        qris_error_log('Initializing QRIS Payment Gateway', 'init');
        // plugin id
        $this->id = 'nicepay_qrisv2';
        // Payment Gateway title
        $this->method_title = 'NICEPay QRIS Payment Gateway';
        // true only in case of direct payment method, false in our case
        $this->has_fields = false;
        // redirect URL
        $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'WC_Gateway_NICEPay_QRISSNAP', home_url('/')));
        $this->method_description = __('Allows payments using NICEPay QRIS SNAP.', 'nicepay-qr-snap-gateway');

        $this->supports = [
            'products',
            'refunds',
        ];
        //Load settings
        $this->init_form_fields(); 
        $this->init_settings();

        // $this->api_endpoints = [
        //     'access_token' => 'https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b',
        //     'registration'    => 'https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-generate',
        //     'check_status_url' => 'https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-query',
        // ];
        $this->api_endpoints = $this->get_api_endpoints();

        if ($this->get_option('enable_blocks') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        // Define user set variables
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->iMid = $this->get_option('iMid');
        $this->XCLIENTKEY = $this->get_option('X-CLIENT-KEY');
        $this->mKey = $this->get_option('mKey');
        $this->privateKey = $this->get_option('privateKey');
        $this->SecretClient = $this->get_option('SecretClient');
        //---------------------------------------------//
        $this->reduceStock   = $this->get_option( 'reduceStock' );
        //---------------------------------------------//
        $this->shopeepay = $this->get_option('shopeepay');
        $this->shopId = $this->get_option('shopId');

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_qrisv2', array($this, 'handle_callback'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
        add_action('wp_ajax_check_qris_payment_status', array($this, 'ajax_check_payment_status'));
        add_action('wp_ajax_nopriv_check_qris_payment_status', array($this, 'ajax_check_payment_status'));
        add_action('woocommerce_thankyou', array($this, 'add_qris_payment_status'), 10, 1);
        

        /*add_action( 'template_redirect', 'wc_nicepay_redirect_after_purchase' );*/
    }
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }
    
        wp_enqueue_style(
            'nicepay-qris-style',
            plugins_url('assets/qris.css', dirname(__FILE__))
        );
    
        // Tambahkan inline CSS yang penting
        $inline_css = "
        .nicepay-qris-container {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .nicepay-qris-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .nicepay-qris-logo {
            max-width: 200px;
            height: auto;
        }
        .nicepay-qris-description {
            text-align: center;
        }
        .qris-apps-list ul {
            list-style: none;
            padding: 0;
            margin: 15px 0;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }
        .qris-apps-list li {
            background: #fff;
            padding: 8px 15px;
            border-radius: 20px;
            border: 1px solid #ddd;
        }
        .nicepay-qris-instructions {
            text-align: center;
            margin-top: 20px;
            font-weight: 500;
        }
    ";
    wp_add_inline_style('nicepay-qris-style', $inline_css);
        wp_enqueue_script(
            'nicepay-classic-checkout',
            $plugin_url . '/assets/classic-checkout.js',
            array('jquery'),
            '1.0.0',
            true
        );
    }
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }
    
        wp_enqueue_style(
            'nicepay-qris-style',
            plugins_url('assets/qris.css', dirname(__FILE__))
        );
    
        wp_enqueue_script(
            'nicepay-classic-checkout',
            plugins_url('assets/block-integration.js', dirname(__FILE__)),
            array('jquery'),
            '1.0.0',
            true
        );
    
        wp_localize_script(
            'nicepay-classic-checkout',
            'qrisData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => plugins_url('', dirname(__FILE__)),
                'nonce' => wp_create_nonce('nicepay-qris-nonce'),
                'merchantId' => $this->get_option('iMid'),
                'shopId' => $this->get_option('shopId')
            )
        );
    }
    // public function enqueue_qris_scripts() {
    //     if (is_wc_endpoint_url('order-received')) {
    //         wp_enqueue_script('jquery');
    //         wp_register_script(
    //             'qris-check-status', 
    //             plugins_url('checkstatus.js', __FILE__),
    //             array('jquery'), 
    //             time(),
    //             true
    //         );
    //         qris_error_log("Ajax URL: " . admin_url('admin-ajax.php'), 'debug');
    //         wp_localize_script(
    //             'qris-check-status', 
    //             'qrisAjax', 
    //             array(
    //                 'ajaxurl' => admin_url('admin-ajax.php'),
    //                 'nonce' => wp_create_nonce('check-qris-payment')
    //             )
    //         );
            
    //         wp_enqueue_script('qris-check-status');
    //     }
    // }

    private function get_api_endpoints() {
        $environment = $this->get_option('environment', 'sandbox');
        qris_error_log("Current environment setting: " . $environment, 'debug');

            $base_url = ($environment === 'production')  
                ? 'https://www.nicepay.co.id'
                : 'https://dev.nicepay.co.id';

                qris_error_log("Using base URL: " . $base_url, 'debug');
        
            return [
                'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
                'registration'     => $base_url . '/nicepay/api/v1.0/qr/qr-mpm-generate',
                'check_status_url' => $base_url . '/nicepay/api/v1.0/qr/qr-mpm-query',
            ];
        }
    public function add_qris_payment_status($order_id) {
        $order = wc_get_order($order_id);
        
        // Hanya tampilkan untuk pembayaran QRIS
        if ($order->get_payment_method() !== 'nicepay_qrisv2') {
            return;
        }
    
        echo '<section class="woocommerce-qris-status">';
        echo '<h2>Status Pembayaran QRIS</h2>';
        echo '<h3>Lakukan Check Status untuk konfirmasi pembayaran</h3>';
        echo '<div class="qris-status-wrapper">';
        echo '<div class="' . esc_attr($status_class) . '">' . esc_html($status_text) . '</div>';
        if ($order->get_status() === 'completed') {
            echo '<p><span class="dashicons dashicons-yes-alt"></span> Pembayaran berhasil diverifikasi</p>';
        } else {
            echo '<p><span class="dashicons dashicons-marker"></span> Menunggu pembayaran</p>';
        }
    echo '</div>';

    echo '<div class="action-container">';
        // Tombol check status
        if ($order->get_status() !== 'completed') {
            echo '<form method="post" class="qris-check-form">';
            wp_nonce_field('check_qris_status', 'qris_nonce');
            echo '<input type="hidden" name="check_qris_status" value="1">';
            echo '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">';
            echo '<button type="submit" 
                     class="button" 
                     style="background: #ff6b00; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px;">
                     Periksa Status Pembayaran
                  </button>';
            echo '</form>';
        }
        
        // Container untuk hasil status check
        echo '<div class="status-result">';
        if (isset($_POST['check_qris_status']) && 
        !get_transient('checking_status_' . $order_id) && 
        wp_verify_nonce($_POST['qris_nonce'], 'check_qris_status')) {
        
        // Set transient untuk menghindari multiple checks
        set_transient('checking_status_' . $order_id, true, 10);
        
        try {
            qris_error_log("==================== START CHECK STATUS ====================", 'debug');
            qris_error_log("Processing status check for order: " . $order_id, 'debug');
            
            $access_token = WC()->session->get('accessToken');
            qris_error_log("Access token from session: " . ($access_token ? substr($access_token, 0, 20) . "..." : "Not found"), 'debug');
            
            if (empty($access_token)) {
                $access_token = $order->get_meta('_nicepay_access_token');
                qris_error_log("Access token from order meta: " . ($access_token ? "Found" : "Not found"), 'debug');
            }
            
            if (empty($access_token)) {
                throw new Exception('Token akses tidak ditemukan. Silakan refresh halaman dan coba lagi.');
            }

            $reference_no = $order->get_meta('_nicepay_reference_no');
            $timestamp = $this->generate_timestamp();
            
            // Prepare request body dengan originalPartnerReferenceNo yang benar
            $body = [
                "originalReferenceNo" => $reference_no,
                "originalPartnerReferenceNo" => $order->get_order_number(), // Menggunakan order number asli
                "merchantId" => $this->XCLIENTKEY,
                "externalStoreId" => $this->shopId,
                "serviceCode" => "47",
                "additionalInfo" => new stdClass()
            ];
            
            qris_error_log("Request body prepared: " . json_encode($body), 'debug');
            
            $stringBody = json_encode($body);
            $hashbody = strtolower(hash("SHA256", $stringBody));
            
            $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $access_token . ":" . $hashbody . ":" . $timestamp;
            $bodyHasing = hash_hmac("sha512", $strigSign, $this->SecretClient, true);
            
            $args = array(
                'method' => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE' => base64_encode($bodyHasing),
                    'X-TIMESTAMP' => $timestamp,
                    'Authorization' => "Bearer " . $access_token,
                    'CHANNEL-ID' => $this->XCLIENTKEY . "01",
                    'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
                    'X-PARTNER-ID' => $this->XCLIENTKEY
                ),
                'body' => $stringBody
            );
            qris_error_log("Making request to: " . $this->api_endpoints['check_status_url'], 'debug');
            qris_error_log("Full request data: " . print_r($args, true), 'debug');
            
            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
            
            if (is_wp_error($response)) {
                qris_error_log("WP Error: " . $response->get_error_message(), 'error');
                throw new Exception($response->get_error_message());
            }
            $response_code = wp_remote_retrieve_response_code($response);
            $response_headers = wp_remote_retrieve_headers($response);
            $response_body = wp_remote_retrieve_body($response);
            
            qris_error_log("Response Code: " . $response_code, 'debug');
            qris_error_log("Response Headers: " . print_r($response_headers, true), 'debug');
            qris_error_log("Response Body: " . $response_body, 'debug');
            $result = json_decode(wp_remote_retrieve_body($response));
            
            if (isset($result->latestTransactionStatus)) {
                switch($result->latestTransactionStatus) {
                    case '00':
                        qris_error_log("Payment successful for order: " . $order_id, 'info');
                        echo '<div class="woocommerce-success">Pembayaran berhasil diverifikasi</div>';
                        
                        $order->add_order_note(
                            sprintf(
                                'QRIS Reference Number: %s (Payment Success)',
                                $reference_no
                            ),
                            false
                        );
                        $order->update_status('completed', 'Pembayaran QRIS berhasil.');
                        break;
                        echo '<script>setTimeout(function() { window.location.reload(); }, 2000);</script>';
                    case '03':
                        qris_error_log("Payment pending for order: " . $order_id, 'info');
                        echo '<div class="woocommerce-message">Menunggu Pembayaran</div>';
                        break;
                    default:
                    qris_error_log("Unknown status: " . $result->latestTransactionStatus, 'warning');
                        echo '<div class="woocommerce-error">Status pembayaran: ' . esc_html($result->responseMessage) . '</div>';
                }
            } else {
                throw new Exception($result->responseMessage ?? 'Gagal mendapatkan status pembayaran');
            }
            qris_error_log("==================== END CHECK STATUS ====================", 'debug');
        } catch (Exception $e) {
            echo '<div class="woocommerce-error">' . esc_html($e->getMessage()) . '</div>';
        }
        delete_transient('checking_status_' . $order_id);
    }
        
    echo '</div>'; 
    
    echo '</div>'; 
    echo '</div>'; 
    
    echo '</section>';
        
        
        echo '<style>
        .woocommerce-qris-status {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .woocommerce-success {
            padding: 1em;
            margin: 1em 0;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            border-radius: 4px;
        }
        .woocommerce-error {
            padding: 1em;
            margin: 1em 0;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            color: #a94442;
            border-radius: 4px;
        }
    </style>';
}
    // function add_content() {}
    function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Enable/Disable',
                'label' => 'Enable NICEPay',
                'type' => 'checkbox',
                'description' => '',
                'default' => 'yes',
            ),
            'title' => array(
                'title' =>'Title',
                'type' => 'text',
                'description' => '',
                'default' => 'Pembayaran dengan QRIS',
            ),
            'description' => array(
                'title' => 'Description',
                'type' => 'textarea',
                'description' => '',
                'default' => 'Sistem pembayaran menggunakan QRIS.',
            ),
            'enable_blocks' => array(
                'title'       => __('Checkout Mode', 'woocommerce'),
                'type'        => 'select',
                'description' => __('Select checkout mode. Block checkout is for modern WooCommerce checkout, while Classic is for traditional checkout.', 'woocommerce'),
                'default'     => 'blocks',
                'options'     => array(
                'classic' => __('Classic Checkout (Non-Blocks)', 'woocommerce'),
                'blocks'  => __('Block Checkout', 'woocommerce')
                )
                ),
            'environment' => array(
            'title'       => __('Environment', 'woocommerce'),
            'type'        => 'select',
            'desc_tip'    => true,
            'description' => __('Select the NICEPay environment.', 'woocommerce'),
            'default'     => 'sandbox',
            'options'     => array(
                'sandbox'    => __('Sandbox / Development', 'woocommerce'),
                'production' => __('Production', 'woocommerce'),
            ),
            ),
            'iMid' => array(
                'title' => 'MID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Merchant ID dari NICEPay</small>.',
                'default' => 'TNICEQR081',
            ),
            'X-CLIENT-KEY' => array(
                'title' => 'Merchant ID / Client ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Merchant ID dari NICEPay</small>.',
                'default' => 'TNICEQR081',
            ),
            'Chanel-ID' => array(
                'title' => 'Chanel ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Chanel ID dari NICEPay</small>.',
                'default' => 'TNICEQR081',
            ),
            'SecretClient' => array(
                'title' => 'Secret Client',
                'type' => 'text',
                'description' =>'<small>Isikan dengan Client Secret anda</small>.',
                'default' => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            'privateKey' => array(
                'title' => 'Private Key',
                'type' => 'text',
                'description' =>'<small>Isikan dengan Private Key dari NICEPay</small>.',
                'default' => 'MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAIafKi6hDyut+QypYTahjYuRa98D7alL6fhq0yJCrhn6rdGrcVZOtZL6d9dDqfsoCeBS5ydr3WwyyyiN7gtF2C4RIO3zWYIFNlZXKMDruybbwUUxmCRkGOOen7q+Nlz5aMk3b0YdAH07C+Hlm5dxoXH6yBBXGOs0bx/gnltFg7V/AgMBAAECgYAo65611801uMc4WxAqvAa7gvOoMZh/Woz/LvGIu34SdYl6b0OfOYOl7q6Y53920Z/W6TxMVlRS/EmWxTWzhYKFZV98Fwm4kOfo5FsIOapu257eDE7Qb9xGBisv06mvaqqtlb2GJYf4rFvl+9rVpR/a16XGrQcqyBL9/5cndtCxCQJBALvNTC340Wh8BqweNom5GCkh+H8UQSGJni1nMVER8mmg8B9CuBCyqKtg042FIjogVNq/sZKKC/DiDishOF5q0VMCQQC3gg5GrznZrD4B/Yp9Uf7JrhhXUKr6VEmqG8OXP2OUQ6y6bSTtmh9mWHxJF91zKfxtJGS+9QnCG7Yw8bEpOamlAkEAnDEQjKOGNmoAeqHeJgkFKSCRtc84pBX6sjRC9fQBMwyg6L7qqyiL040CJY92efVt3UjU/NVHPR4lPoWwhgY89QJBAJwH7XOUki/PEHpIxnSAP4/kg7XaVUa8XFZTfR8hOt5aHIf3Par5nTE8k5DixdyiGowCodbsKvvs7CD5oJVY/jECQQCuOs9qvZtK9UYHw3FWLbpWrEEIqLelLXJB1VXCl56NlkiWgyPfPgNtTzaMhgsATLZo9rL9DGqv1dhvU25eKTDW',
            ),
            'shopId' => array(
                'title' => 'QRIS Shop ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Shop ID dari NICEPay</small>',
                'default' => 'NICEPAY',
            ),
            'shopeepay' => array(
                'title' => 'Shopeepay QRIS',
                'type' => 'checkbox',
                'description' => '<small>Check to enable. Please confirm to NICEPay before changing this.</small>',
                'default' => 'yes',
            ),
            'reduceStock' => array(
                'title' => __('Reduce stock', 'woocommerce'),
                'type' => 'checkbox',
                'description' => __('<small>Check to enable.</small>', 'woocommerce'),
                'default' => 'no',
            ),
        );
    }

    public function admin_options() {
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';
    }

    function payment_fields() {
        if ($this->get_option('enable_blocks') === 'classic') {
            if (!empty($this->description)) {
                echo wp_kses_post($this->description);
            }
            
            echo '<div id="nicepay-qris-payment-container"></div>';
        }
    }

    // function payment_fields() {
        // if ($this->get_option('enable_blocks') === 'classic') {
            
            // error_log('Payment Fields Method Called');
            
            
            // if (!empty($this->description)) {
                // echo wp_kses_post($this->description);
            // }
            
            // $plugin_url = plugins_url('', dirname(__FILE__));
            // 
            // <div class="nicepay-qris-container">
            //     <div class="nicepay-qris-header">
            //         <img src="<?php echo esc_url($plugin_url . 'images/qris1.png');" 
//             <!-- //              alt="QRIS Logo"  -->
//             <!-- //              class="nicepay-qris-logo"> -->
//                 <!-- </div> -->
// <!--                 
//                 <div class="nicepay-qris-description">
//                     <h3>Pembayaran QRIS</h3>
//                     <p>Pembayaran dapat dilakukan melalui aplikasi:</p>
//                     <div class="qris-apps-list">
//                         <ul>
//                             <li>DANA</li>
//                             <li>OVO</li>
//                             <li>GoPay</li>
//                             <li>ShopeePay</li>
//                             <li>LinkAja</li>
//                             <li>Mobile Banking</li>
//                         </ul>
//                     </div>
//                 </div>
    
//                 <div class="nicepay-qris-instructions">
//                     <p>Silakan pilih "Place Order" untuk mendapatkan QR Code pembayaran</p>
//                 </div>
//             </div> -->
            
//         <!-- } -->
//     <!-- } -->
    

    public function validate_fields() {
        qris_error_log("Validating fields", 'debug');
        
        // Set default mitraCd 
        $mitraCd = isset($_POST['mitraCdQRISV2']) ? sanitize_text_field($_POST['mitraCdQRISV2']) : 'QSHP';
        
        qris_error_log("Setting mitraCd: " . $mitraCd, 'debug');
        WC()->session->set('mitraCd', $mitraCd);
        
        return true;
    }
    private function generate_timestamp() {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    function payment_list() {
        $payment = array(
            "QSHP" => array(
                "label" => "QRIS Shopeepay",
                "enabled" => $this->shopeepay,
            )
        );

        return $payment;
    }

    function receipt_page($order_id) {
        $order = wc_get_order($order_id);
        $qr_url = $order->get_meta('_nicepay_qr_url');
        
        qris_error_log("Displaying receipt page for order: " . $order_id, 'debug');
        qris_error_log("QR URL: " . $qr_url, 'debug');

        if (empty($qr_url)) {
            $qr_url = WC()->session->get('qr_url');
        }
    
        if (empty($qr_url)) {
            echo "<div class='woocommerce-error'>Error: QR Code not generated. Please try again.</div>";
            return;
        }
    
        echo "<div class='qris-payment-container'>";
        echo "<h2>QRIS Payment</h2>";
        
        // QR Code
        echo "<div class='qris-code'>";
        echo "<img src='" . esc_url($qr_url) . "' alt='QRIS Code' style='width:280px; height:280px;'>";
        echo "</div>";
        
        // Instructions
        echo "<div class='qris-instructions'>";
        echo "<p><strong>Silahkan scan QR Code di atas menggunakan aplikasi e-wallet atau m-banking yang mendukung QRIS</strong></p>";
        echo "<p><strong>Tekan Lanjutkan jika sudah melakukan pembayaran</strong></p>";
        echo "<p>QR Code akan kadaluarsa dalam: <span id='countdown'>5:00</span></p>";
        echo "</div>";
        
        // Download button
        echo "<div class='qris-actions'>";
        echo "<button onclick='window.location.href=\"" . esc_url($qr_url) . "\"' class='button download-qr'>";
        echo "<i class='fa fa-download'></i> Download QR";
        echo "</button>";
        echo "</div>";
    
        // Continue button
        echo "<div class='qris-continue'>";
        echo "<button onclick='window.location.href=\"" . esc_url($this->get_return_url($order)) . "\"' class='button continue-btn'>";
        echo "Lanjutkan";
        echo "</button>";
        echo "</div>";
    
        // Timer script
        echo "<script>
            function startTimer(duration, display) {
                var timer = duration, minutes, seconds;
                var interval = setInterval(function () {
                    minutes = parseInt(timer / 60, 10);
                    seconds = parseInt(timer % 60, 10);
    
                    minutes = minutes < 10 ? '0' + minutes : minutes;
                    seconds = seconds < 10 ? '0' + seconds : seconds;
    
                    display.textContent = minutes + ':' + seconds;
    
                    if (--timer < 0) {
                        clearInterval(interval);
                        window.location.href = '" . esc_js($this->get_return_url($order)) . "';
                    }
                }, 1000);
            }
    
            window.onload = function () {
                var fiveMinutes = 60 * 5,
                    display = document.querySelector('#countdown');
                startTimer(fiveMinutes, display);
            };
        </script>";
        // jQuery(document).ready(function($) {
        //     $('#check-payment').on('click', function(e) {
        //         e.preventDefault();
        //         var button = $(this);
        //         var orderId = button.data('order');
                
        //         button.prop('disabled', true);
        //         button.text('Memeriksa status pembayaran...');
                
        //         $.ajax({
        //             url: '" . admin_url('admin-ajax.php') . "',
        //             type: 'POST',
        //             data: {
        //                 action: 'check_qris_payment_status',
        //                 order_id: orderId,
        //                 nonce: '" . wp_create_nonce('check-qris-payment') . "'
        //             },
        //             success: function(response) {
        //             console.log('AJAX response:', response);
        //                 if(response.success) {
        //                     if(response.data.status === 'paid') {
        //                         $('#payment-status-result').html('<div class=\"woocommerce-success\">Pembayaran berhasil! Mengalihkan...</div>');
        //                         window.location.href = '" . esc_js($this->get_return_url($order)) . "';
        //                     } else {
        //                         $('#payment-status-result').html('<div class=\"woocommerce-error\">Pembayaran belum diterima. Silakan coba lagi setelah melakukan pembayaran.</div>');
        //                         button.prop('disabled', false);
        //                         button.text('Check Status');
        //                     }
        //                 } else {
        //                     $('#payment-status-result').html('<div class=\"woocommerce-error\">' + response.data.message + '</div>');
        //                     button.prop('disabled', false);
        //                     button.text('Check Status');
        //                 }
        //             },
        //             error: function() {
        //             console.error('AJAX error:', error);
        //                 $('#payment-status-result').html('<div class=\"woocommerce-error\">Terjadi kesalahan. Silakan coba lagi.</div>');
        //                 button.prop('disabled', false);
        //                 button.text('Check Status');
        //             }
        //         });
        //     });
        // });
    
        // Styles
        echo "<style>
            .qris-payment-container {
                max-width: 600px;
                margin: 0 auto;
                text-align: center;
                padding: 20px;
            }
            .qris-logo img {
                max-width: 200px;
                margin-bottom: 20px;
            }
            .qris-code {
                margin: 20px 0;
            }
            .qris-instructions {
                margin: 20px 0;
            }
            .qris-actions {
                margin: 20px 0;
            }
            .download-qr {
                background: #f8f9fa;
                border: 1px solid #ddd;
                padding: 10px 20px;
            }
            .continue-btn {
                background: #ff6b00;
                color: white;
                padding: 15px 30px;
                font-size: 18px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .continue-btn:hover {
                background: #ff8533;
            }
            #countdown {
                font-weight: bold;
                color: #ff6b00;
            }
            .woocommerce-success {
            padding: 1em;
            margin-bottom: 1em;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            border-radius: 4px;
        }
        .woocommerce-error {
            padding: 1em;
            margin-bottom: 1em;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            color: #a94442;
            border-radius: 4px;
        }
        </style>";
        echo "</div>";
    }

    function includes() {
        // Validation class payment gateway woocommerce
        if (!class_exists( 'NicepayLibQRISV2' )) {
            include_once "NicepayLibQRISV2/NicepayLibQRISV2.php";
        }
    }

    function konversi($nilai, $currency) {
        if ($currency == 'USD') {
            return $nilai*(int)13500;
        } else {
            return $nilai*(int)1;
        }
    }

    public function generate_nicepay_form($order_id) {


        global $woocommerce;

        $order = new WC_Order($order_id);
        $currency = $order->get_currency();
        $fees = $order->get_fees();
        $total_quantity = 0;

        if (sizeof($order->get_items()) > 0) {
            foreach ($order->get_items() as $item) {
                if (!$item['qty']) {
                    continue;
                }


                $item_name = $item->get_name();;
                $item_quantity = $item->get_quantity();
                $product_id = $item->get_product_id();
                $item_cost_non_discount = $item->get_subtotal();
                $item_cost_discounted = $item->get_total();;
                $item_url = get_permalink($product_id);

                $orderInfo[] = array(
                    'goods_name' => $this->nicepay_item_name($item_name),
                    'goods_detail' => $this->nicepay_item_name($item_name),
                    'goods_amt' => strval($this->konversi($item_cost_non_discount/$item_quantity, $currency)),
                    'goods_quantity' => strval($item_quantity),
                    'img_url' => "https://image.freepik.com/free-psd/simple-black-men-s-tee-mockup_53876-57893.jpg"
                );

                if (count($orderInfo) < 0) {
                    return false; // Abort - negative line
                }

                $total_quantity = $total_quantity + $item_quantity;
            }

            function clean($string) {
                $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

                return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
            }

            // Loop over $cart fees
            if(!empty($fees)) {
                foreach ( $fees as $fees_key => $fee ) {
                    $name = $fee['name'];
                    $total = $fee['total'];
                    if($total != 0){
                        $orderInfo[] = array(
                            'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                            'goods_name' => clean($name),
                            'goods_detail' => clean($name)." for ".$order_id,
                            'goods_amt' => wc_float_to_string($total),
                            'goods_quantity' => "1",
                            'goods_url' => "https://".$_SERVER['SERVER_NAME']
                        );
                    }
                    $total_quantity = $total_quantity + 1;
                }
            }

            //Shipping
            if($order->calculate_shipping() > 0){
                $orderInfo[] = array(
                    'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                    'goods_name' => "Shipping Fee",
                    'goods_detail' => $order->get_shipping_method(),
                    'goods_amt' => wc_float_to_string($order->calculate_shipping()),
                    'goods_quantity' => "1",
                    'goods_url' => "https://".$_SERVER['SERVER_NAME']
                );
                $total_quantity = $total_quantity + 1;
            }
            //Coupons
            $coupons = $order->get_coupon_codes();
            if(!empty($coupons)) {
                foreach ($coupons as $coupon_code) {
                    $coupon = new WC_Coupon($coupon_code);
                    $couponName = $coupon_code;

                    $orderInfo[] = array(
                        'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                        'goods_name' => "COUPON",
                        'goods_detail' => $couponName." ".$coupon->get_amount(),
                        'goods_quantity' => "1",
                        'goods_amt' => "-".$coupon->get_amount(),
                        'goods_url' => "https://".$_SERVER['SERVER_NAME']
                    );
                    $total_quantity = $total_quantity + 1;
                }
            }

            $cartData = array(
                'count' => count($orderInfo),
                'item' => $orderInfo
            );

        }

        //Order Total
        if($currency == 'USD'){
            $order_total = $this->get_order_total()*(int)13500;
        }else{
            $order_total = $this->get_order_total();
        }

        //Get current user
        $current_user = wp_get_current_user();

        //Get Address customer
        $billingFirstName = ($current_user->ID == 0) ? $order->get_billing_first_name() : get_user_meta($current_user->ID, "billing_first_name", true);
        $billingLastName = ($current_user->ID == 0) ? $order->get_billing_last_name() : get_user_meta($current_user->ID, "billing_last_name", true);
        $billingNm = $billingFirstName." ".$billingLastName;
        $billingPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
        $billingEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
        $billingAddr1 = ($current_user->ID == 0) ? $order->get_billing_address_1() : get_user_meta($current_user->ID, "billing_address_1", true);
        $billingAddr2 = ($current_user->ID == 0) ? $order->get_billing_address_2() : get_user_meta($current_user->ID, "billing_address_2", true);
        $billingAddr = $billingAddr1."-".$billingAddr2;
        $billingCity = ($current_user->ID == 0) ? $order->get_billing_city() : get_user_meta($current_user->ID, "billing_city", true);
        $billingState = WC()->countries->states[$order->get_billing_country()][$order->get_billing_state()];
        $billingPostCd = ($current_user->ID == 0) ? $order->get_billing_postcode() : get_user_meta($current_user->ID, "billing_postcode", true);
        $billingCountry = WC()->countries->countries[$order->get_billing_country()];

        $deliveryFirstName = $order->get_shipping_first_name();
        $deliveryLastName = $order->get_shipping_last_name();
        $deliveryNm = $deliveryFirstName." ".$deliveryLastName;
        $deliveryPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
        $deliveryEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
        $deliveryAddr1 = $order->get_shipping_address_1();
        $deliveryAddr2 = $order->get_shipping_address_2();
        $deliveryAddr = $deliveryAddr1." ".$deliveryAddr2;
        $deliveryCity = $order->get_billing_city();
        $deliveryState = WC()->countries->states[$order->get_shipping_country()][$order->get_shipping_state()];
        $deliveryPostCd = $order->get_shipping_postcode();
        $deliveryCountry = WC()->countries->countries[$order->get_shipping_country()];

        // Prepare Parameters
        $nicepay = new NicepayLibQRISV2();

        $dateNow        = date('Ymd');

        $nicepay->set('mKey', $this->mKey);
        $nicepay->set('privateKey', $this->privateKey);
        $nicepay->set('SecretClient', $this->SecretClient);
        $paymentExpiryDate   = date('Ymd', strtotime($dateNow . ' +1 day'));
        $paymentExpiryTime   = date('His', strtotime($dateNow . ' +1 hour'));
        $timeStamp = date("Ymdhis");
        date_default_timezone_set('Asia/Jakarta');
        $nicepay->set('X-TIMESTAMP', date('c'));
        $nicepay->set('timeStamp', $timeStamp);
        //$nicepay->set('instmntType', '2');
        //$nicepay->set('instmntMon', '1');
        // $nicepay->set('payValidDt', $paymentExpiryDate);
        // $nicepay->set('payValidTm', $paymentExpiryTime);
        $nicepay->set('iMid', $this->iMid);
        $nicepay->set('X-CLIENT-KEY', $this->XCLIENTKEY);
        // $nicepay->set('payMethod', '08');
        $nicepay->set('currency', 'IDR');
        $nicepay->set('amt', $order_total);
        $nicepay->set('referenceNo', $order_id);
        $nicepay->set('goodsNm', 'Payment of invoice No '.$order_id);
        $nicepay->set('dbProcessUrl', WC()->api_request_url('WC_Gateway_NICEPay_QRISV2'));
        $nicepay->set('description', 'Payment of invoice No '.$order_id);
        // $merchantToken = $nicepay->merchantToken();
        // $nicepay->set('merchantToken', $merchantToken);
        $nicepay->set('reqDt', date('Ymd'));
        $nicepay->set('reqTm', date('His'));
        $nicepay->set('mitraCd', WC()->session->get('mitraCd'));
        $nicepay->set('userIP', $nicepay->getUserIP());
        $nicepay->set('cartData', json_encode($cartData, JSON_UNESCAPED_SLASHES ));
        //$nicepay->set('sellers', json_encode($sellers, JSON_UNESCAPED_SLASHES ));
        $nicepay->set('billingNm', $billingNm);
        $nicepay->set('billingPhone', $billingPhone);
        $nicepay->set('billingEmail', $billingEmail);
        $nicepay->set('billingAddr', $billingAddr);
        $nicepay->set('billingCity', $billingCity);
        $nicepay->set('billingState', $billingState);
        $nicepay->set('billingPostCd', $billingPostCd);
        $nicepay->set('billingCountry', $billingCountry);
        // $nicepay->set('deliveryNm', $deliveryNm);
        // $nicepay->set('deliveryPhone', $deliveryPhone);
        // $nicepay->set('deliveryAddr', $deliveryAddr);
        // $nicepay->set('deliveryCity', $deliveryCity);
        // $nicepay->set('deliveryState', $deliveryState);
        // $nicepay->set('deliveryPostCd', $deliveryPostCd);
        // $nicepay->set('deliveryCountry', $deliveryCountry);
        $nicepay->set('shopId', $this->shopId);

        unset($nicepay->requestData['mKey']);

        // $validate = $nicepay->requestQRISV2();
        $validate = $nicepay->requestQRISV2();

        $X_CLIENT_KEY = $this->XCLIENTKEY;
        $requestToken = SNAPQRConfig::NICEPAY_ACCESSTOKEN;
        // date_default_timezone_set('Asia/Jakarta');
        // $X_TIMESTAMP = date('c');
        $stringToSign = $X_CLIENT_KEY."|".$nicepay->get('X-TIMESTAMP');
        $privatekey = "-----BEGIN RSA PRIVATE KEY-----" . "\r\n" .
        $this->privateKey . // string private key
        "\r\n" .
        "-----END RSA PRIVATE KEY-----";
        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);
        
        
        openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        
        openssl_pkey_free($pKey);
        $signature = base64_encode($binary_signature);
        // print_r($stringToSign);exit();
        $jsonData = array(
          "grantType" => "client_credentials",
        "additionalInfo" => ""
      );


        $jsonDataEncode = json_encode($jsonData);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $requestToken);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncode);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'X-SIGNATURE: '.base64_encode($binary_signature),
            'X-CLIENT-KEY: '.$X_CLIENT_KEY,
            'X-TIMESTAMP: '.$nicepay->get('X-TIMESTAMP')
        ));

        $output = curl_exec($ch);
        $data = json_decode($output);
        $accessToken = $data->accessToken;
        // print_r($data);exit();
        WC()->session->set('accessToken', $data->accessToken);

        $X_TIMESTAMP = $nicepay->get("X-TIMESTAMP");
        $timestamp = date('YmdHis');
        $CreateQR = SNAPQRConfig::NICEPAY_SNAP_CREATEQR;
        $authorization = "Bearer ".$accessToken;
        $channel = $X_CLIENT_KEY."01";
        $external = $timestamp.rand();
        $partner = $X_CLIENT_KEY;
        $amt = $nicepay->get("amt");
        $secretClient = 
        $this->SecretClient;
        // "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
        // $this->secretClient;
        // print_r($secretClient);exit();
        $additionalInfo = [
        //   "bankCd" => $nicepay->get("bankCd"),
          "goodsNm" => $nicepay->get("goodsNm"),
          "dbProcessUrl" => $nicepay->get("dbProcessUrl"),
        //   "payValidDt" => $nicepay->get("payValidDt"),
        //   "payValidTm" => $nicepay->get("payValidTm"),
          "billingNm" => $nicepay->get("billingNm"),
          "billingPhone" => $nicepay->get("billingPhone"),
          "billingEmail" => $nicepay->get("billingEmail"),
          "billingCity" => $nicepay->get("billingCity"),
          "billingState" => $nicepay->get("billingState"),
          "billingPostCd" => $nicepay->get("billingPostCd"),
          "billingCountry" => $nicepay->get("billingCountry"),
          "callBackUrl" => "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp",
          "mitraCd" => $nicepay->get("mitraCd"),
          "cartData" => $nicepay->get("cartData"),
          "msId" => "",
          "msFee" => "",
          "msFeeType" => "",
          "mbFee" => "",
          "mbFeeType" => ""
        ];
        // print_r($additionalInfo);exit();

        $TotalAmount = [
          "value"=> $nicepay->get("amt").".00",
          "currency" => $nicepay->get("currency")
        ];
        // print_r($TotalAmount);exit();

        $newBody = [
          "partnerReferenceNo" => "ncpy20221017161458",
          "amount" => $TotalAmount,
          "validityPeriod"=>"",
          "merchantId"=>$X_CLIENT_KEY,
          "storeId"=> $nicepay->get("shopId"),
          "additionalInfo" => $additionalInfo
        ];
        // print_r($newBody);exit();
        // print_r($nicepay);exit();
        // $data = $nicepay->requestVAV2();
        
        
        $stringBody = json_encode($newBody);
        
        $hashbody = strtolower(hash("SHA256", $stringBody));

        // print_r($CreateVA);exit();

        $strigSign = "POST:/api/v1.0/qr/qr-mpm-generate:".$accessToken.":".$hashbody.":".$X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
        // echo base64_encode($bodyHasing);exit();

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$CreateQR);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $stringBody);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-SIGNATURE: '.base64_encode($bodyHasing),
        'X-CLIENT-KEY: '.$X_CLIENT_KEY,
        'X-TIMESTAMP: '.$X_TIMESTAMP,
        'Authorization: '.$authorization,
        'CHANNEL-ID: '.$channel,
        'X-EXTERNAL-ID: '.$external,
        'X-PARTNER-ID: '.$X_CLIENT_KEY
    ));

  $output = curl_exec($ch);
  $response = json_decode($output);
//   $responseMessage = $data->responseMessage;
//   $trxId = $data->referenceNo;
//   $RefrenceNo = $data->partnerReferenceNo;
//   $QRurl = $data->qrUrl;
//   $goodsNm = $data->additionalInfo->goodsNm;
//   $billingNm = $data->additionalInfo->billingNm;
//   $bankCd = $data->virtualAccountData->additionalInfo->bankCd;
//   $tXidVA = $data->virtualAccountData->additionalInfo->tXidVA;
//   $goodsNm = $data->virtualAccountData->additionalInfo->goodsNm;
//   $vacctValidDt = $data->virtualAccountData->additionalInfo->vacctValidDt;
//   $vacctValidTm = $data->virtualAccountData->additionalInfo->vacctValidTm;
//   print_r($response);exit();


        // Send Data
        // $registResponse = $nicepay->requestQRISV2();

        // Response from NICEPAY
        if (isset($response->responseCode) && $response->responseCode == "2004700") {
            //Set Session
            WC()->session->set('tXid', $response->referenceNo); //from response
            WC()->session->set('referenceNo', $response->partnerReferenceNo); //from response
            // WC()->session->set('payMethod', $registResponse->payMethod); //from response
            WC()->session->set('amt', $nicepay->get("amt")); //from response
            WC()->session->set('billingNm', $billingNm);
            // WC()->session->set('mitraCd', $response->mitraCd); //from response
            // WC()->session->set('transDt', $registResponse->transDt); //from response
            // WC()->session->set('description', $registResponse->description); //from response
            // WC()->session->set('paymentExpDt', $registResponse->paymentExpDt); //from response
            // WC()->session->set('validityPeriod', $response->validityPeriod); //from response
            WC()->session->set('qrContent', $response->qrContent); //from response
            WC()->session->set('qrUrl', $response->qrUrl); //from response

            WC()->cart->empty_cart();

            $order->add_order_note(__('Menunggu pembayaran melalui NICEPay Payment Gateway dengan id transaksi '.$response->referenceNo, 'woocommerce'));
            $order->add_order_note(__('QRContent:  '.$response->qrContent, 'woocommerce'));
            $order->add_order_note(__('QR Image URL:  '.$response->qrUrl, 'woocommerce'));

            //REDUCE WC Stock
            if ( property_exists($this,'reduceStock') && $this->reduceStock == 'yes' ) {
                wc_reduce_stock_levels($order);
            }

            // REDIRECT Continue Button
            $callBackUrl = $order->get_checkout_order_received_url() ;
            $qrisLogo = plugins_url('/qrislogo1.png', __FILE__);
            // print_r($qrisLogo);exit();
            echo "<script>
                    function startTimer(duration, display) {
                        var timer = duration, minutes, seconds;
                        setInterval(function () {
                            minutes = parseInt(timer / 60, 10);
                            seconds = parseInt(timer % 60, 10);
                    
                            minutes = minutes < 10 ? \"0\" + minutes : minutes;
                            seconds = seconds < 10 ? \"0\" + seconds : seconds;
                    
                            display.textContent = minutes + \":\" + seconds;
                    
                            if (--timer < 0) {
                                timer = duration;
                            }
                        }, 1000);
                    }
                    
                    window.onload = function () {
                        var fiveMinutes = 60 * 5,
                            display = document.querySelector('#time');
                        startTimer(fiveMinutes, display);
                    };
                
                </script>";
            echo "<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">";

            echo "<style>
                  .qrdetails{
                      align-content: center;
                      text-align: center;
                  }
                  .qrdetailsimage{
                    display: flex;
                      justify-content: center;
                  }
                  .continue-btn{
                  width: 10em;  
                  height: 3em;
                  font-size: 30px;
                  color: white !important;
                  background-color: orange !important;
                  }
                  .continue-btn:hover{
                  color: white !important;
                  background-color: darkorange !important;
                  }
                  </style>";

            echo "
                <ul class=\"order_details\">
                        <li class=\"qrdetails\">
                        <h4><strong>Silahkan Scan QRIS berikut menggunakan Applikasi pembayaran yang mendukung QRIS.</strong></h4>
                        </li>
                        
                        <li class=\"qrdetailsimage\">
                        <img src=\"$qrisLogo\" alt=\"QRIS Logo\">
                        </li>

                        <li class=\"qrdetailsimage\">
                        <img src=\"$response->qrUrl\" alt=\"QRIS Image\" width=\"280px\" height=\"280px\">
                        </li>
                        
                        <li class=\"qrdetails\">
                        <button onClick=\"window . location = '$response->qrUrl';\" class=\"btn\"> <i class=\"fa fa-download\"></i> Download QR</button>

                        <strong>QR hanya valid dalam <strong><p id='time'>5 Menit</p></strong>Tekan tombol Continue jika sudah melakukan pembayaran.</strong>
                        <p><small>Halaman ini akan otomatis redirect dalam 5 menit.</small></p>
                        </li>
                        
                        <li class=\"qrdetailsimage\">
                            <button onClick=\"window.location='$callBackUrl';\" class=\"continue-btn\">Continue</button>
                        </li>
                        <br>
                </ul>";

            header("Refresh: 300; Location:".$callBackUrl);

        } elseif(isset($data->responseCode)) {
            // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
            // In this sample, we echo error message
            // header("Location: "."http://example.com/checkout.php");
            echo "<pre>";
            echo "result code: ".$response->responseCode."\n";
            echo "result message: ".$response->responseMessage."\n";
            // echo "requestUrl: ".$registResponse->data->requestURL."\n";
            echo "</pre>";
        } else {
            // Timeout, you can redirect back to checkout page or echo error message.
            // In this sample, we echo error message
            // header("Location: "."http://example.com/checkout.php");
            echo "<pre>Registration Connection Timeout. Please Try again.</pre>";
        }
    }

    public function add_description_payment_success($orderdata) {
        $order = new WC_Order($orderdata);
        if ($order->get_payment_method() == 'nicepay_qrisv2') {
        $nicepay = new NicepayLibQRISV2();

        // Set checkStatus Token For Inquiry
        $X_CLIENT_KEY = $this->XCLIENTKEY;
        $shopId = $this->shopId;
        $accessToken = WC()->session->get('accessToken');
        $CheckStts = SNAPQRConfig::NICEPAY_SNAP_INQUIRY;
        $timestamp = date('YmdHis');
        // print_r($accessToken);exit();
        date_default_timezone_set('Asia/Jakarta');
        $nicepay->set('X-TIMESTAMP', date('c'));
        $X_TIMESTAMP = $nicepay->get("X-TIMESTAMP");
        $authorization = "Bearer ".$accessToken;
        $channel = $X_CLIENT_KEY."01";
        $external = $timestamp.rand();
        $partner = $X_CLIENT_KEY;
        $amt = $nicepay->get("amt");
        $tXid = WC()->session->get('tXid');
        $referenceno = WC()->session->get('referenceNo');
        $secretClient = 
        $this->SecretClient;

        $additonalInfo = new \stdClass();
        $bodyInqu = [
            "originalReferenceNo" => $tXid,
          "originalPartnerReferenceNo" => $referenceno,
        //   "payValidDt" => $nicepay->get("payValidDt"),
        //   "payValidTm" => $nicepay->get("payValidTm"),
          "merchantId" => $X_CLIENT_KEY,
          "externalStoreId" => $shopId,
          "serviceCode" => "51",
          "additionalInfo" =>$additonalInfo
        ];
        // print_r($bodyInqu);exit();

        // $Validate = $nicepay->checkPaymentStatus($X_TIMESTAMP, $X_CLIENT_KEY, $tXid, $referenceno);

        $StringBody = json_encode($bodyInqu);
        
        $hashbody = strtolower(hash("SHA256", $StringBody));

       

        $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:".$accessToken.":".$hashbody.":".$X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$CheckStts);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $StringBody);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-SIGNATURE: '.base64_encode($bodyHasing),
        'X-CLIENT-KEY: '.$X_CLIENT_KEY,
        'X-TIMESTAMP: '.$X_TIMESTAMP,
        'Authorization: '.$authorization,
        'CHANNEL-ID: '.$channel,
        'X-EXTERNAL-ID: '.$external,
        'X-PARTNER-ID: '.$X_CLIENT_KEY
    ));

          $output = curl_exec($ch);
          $paymentStatus = json_decode($output);
        


            if($paymentStatus->latestTransactionStatus == '00'){
                echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                echo '<table border="0" cellpadding="10">';
                echo '<tr><td><strong>Status</strong></td><td>'.ucfirst($paymentStatus->responseMessage).'</td></tr>';
                echo '<tr><td><strong>Reference Code</strong></td><td>'.WC()->session->get('referenceNo').'</td></tr>';
                echo '<tr><td><strong>Billing Name</strong></td><td>'.WC()->session->get('billingNm').'</td></tr>';
                echo '<tr><td><strong>Transaction Amount</strong></td><td>'.WC()->session->get('amt').'</td></tr>';
                echo '<tr><td><strong>Transaction Date</strong></td><td>'.$paymentStatus->paidTime.'</td></tr>';
                echo '</table>';
            } elseif($paymentStatus->latestTransactionStatus != '00') {
                echo '<h1 id="h2thanks">Your Transaction has not been processed.</h1>';
                echo '<h1 style="color: red;"><strong>Status: '.ucfirst($paymentStatus->latestTransactionStatus).'</strong></h1><br>';
            } else {
                echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                echo '<table border="0" cellpadding="10">';
                echo '<tr><td><strong>Timeout To Nicepay, Please Try Again.</strong></td></tr>';
                echo '</table>';
            }
        }
    }

    //Add details to Processing Order email
    public function np_add_payment_email_detail($orderdata, $sent_to_admin, $plain_text, $email){
        $order = new WC_Order($orderdata);
        if ($order->get_payment_method() == 'nicepay_qrisv2') {
            if ( $email->id == 'customer_processing_order' ) {
                echo '<h2 class="email-upsell-title">We Have Received Your Payment!</h2>';
            }
        }
    }

    //Change Email Subject for Processing Email
    public function np_change_subject_payment_email_detail($formated_subject, $orderdata){
        $order = new WC_Order($orderdata);
        if ($order->get_payment_method() == 'nicepay_qrisv2') {
            $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
            $subject = sprintf( 'Hi %s, Thank you for your payment on %s', $order->billing_first_name, $blogname );
            return $subject;
        }
    }

    public function modify_fee_html_for_taxes( $cart_fee_html, $fees ) {

        if ( 'incl' === get_option( 'woocommerce_tax_display_cart' ) && isset( $fees->tax ) && $fees->tax > 0 && in_array( $fees->name, $this->fees_added, true ) ) {
            $cart_fee_html .= '<small class="includes_tax">' . sprintf( __( '(includes %s Tax)', 'checkout-fees-for-woocommerce' ), wc_price( $fees->tax ) ) . '</small>'; // phpcs:ignore
        }
        return $cart_fee_html;
    }

    private function get_access_token() {
        qris_error_log("Getting access token", 'debug');
        
        try {
            $X_CLIENT_KEY = $this->XCLIENTKEY;
            $timestamp = $this->generate_timestamp();
            $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;
            qris_error_log("X_CLIENT_KEY: " . $X_CLIENT_KEY, 'debug');
            qris_error_log("Timestamp: " . $timestamp, 'debug');
            qris_error_log("StringToSign: " . $stringToSign, 'debug');

            $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
                 $this->get_option('privateKey') .
                "\r\n-----END RSA PRIVATE KEY-----";
                qris_error_log("Private Key Structure: " . substr($privatekey, 0, 100) . "...", 'debug');
            $binary_signature = "";
            $pKey = openssl_pkey_get_private($privatekey);
            
            if ($pKey === false) {
                $error = openssl_error_string();
                qris_error_log("Failed to get private key. OpenSSL Error: " . $error, 'error');
                throw new Exception("Invalid private key: " . $error);
            }
            
            $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        
            if ($sign_result === false) {
                $error = openssl_error_string();
                qris_error_log("Failed to create signature. OpenSSL Error: " . $error, 'error');
                throw new Exception("Failed to create signature: " . $error);
            }
            
            $signature = base64_encode($binary_signature);
            qris_error_log("Generated Signature: " . $signature, 'debug');
            
            // Prepare request data
            $jsonData = array(
                "grantType" => "client_credentials"
            );
            
            $jsonDataEncode = json_encode($jsonData);
            qris_error_log("Request Body JSON: " . $jsonDataEncode, 'debug');
            
            // Prepare request
            $requestToken = $this->api_endpoints['access_token'];
            qris_error_log("Request URL: " . $requestToken, 'debug');
            
            $args = array(
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE'  => $signature,
                    'X-CLIENT-KEY' => $X_CLIENT_KEY,
                    'X-TIMESTAMP'  => $timestamp
                ),
                'body'    => $jsonDataEncode,
            );
    
            qris_error_log("Full Request Headers: " . print_r($args['headers'], true), 'debug');
            qris_error_log("Full Request Body: " . print_r($args['body'], true), 'debug');
            
            // Send request
            $response = wp_remote_post($requestToken, $args);
            
            if (is_wp_error($response)) {
                qris_error_log("Error in get_access_token: " . $response->get_error_message(), 'error');
                throw new Exception($response->get_error_message());
            }
            
            qris_error_log("Response Code: " . wp_remote_retrieve_response_code($response), 'debug');
            qris_error_log("Response Headers: " . print_r(wp_remote_retrieve_headers($response), true), 'debug');
            
            $body = json_decode(wp_remote_retrieve_body($response));
            qris_error_log("Access token response: " . json_encode($body), 'debug');
            
            if (!isset($body->accessToken)) {
                qris_error_log("Invalid access token response: " . json_encode($body), 'error');
                throw new Exception(__('Invalid access token response', 'nicepay-qris-gateway'));
            }
            
            qris_error_log("Successfully obtained access token", 'info');
            WC()->session->set('accessToken', $body->accessToken);
            
            return $body->accessToken;
            
        } catch (Exception $e) {
            qris_error_log("Failed to get access token: " . $e->getMessage(), 'error');
            throw $e;
        }
    }

    public function process_payment($order_id) {
        qris_error_log("Starting process_payment for order $order_id", 'info');
        
        $checkout_mode = $this->get_option('enable_blocks', 'classic');
        qris_error_log("Checkout mode: " . $checkout_mode, 'debug');
        
        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }


    
    public function process_classic_payment($order_id) {
        qris_error_log("Starting payment process for order: $order_id", 'info');
        
        try {
            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception("Invalid order ID");
            }

            
            WC()->session->set('mitraCd', 'QSHP');
            
            // Get access token
            qris_error_log("Requesting access token", 'debug');
            $access_token = $this->get_access_token();
            
            if (!$access_token) {
                throw new Exception("Failed to obtain access token");
            }
            
            // Prepare payment data
            $payment_data = $this->prepare_payment_data($order);
            qris_error_log("Payment data prepared: " . json_encode($payment_data), 'debug');
            
            // Create QRIS request
            $result = $this->create_qris_request($payment_data, $access_token, $order);
            qris_error_log("QRIS response received: " . json_encode($result), 'debug');
            
            if (!isset($result->responseCode) || $result->responseCode !== "2004700") {
                throw new Exception($result->responseMessage ?? "Failed to create QRIS");
            }
            
            // Save transaction data
            $this->save_transaction_data($order, $result);
            WC()->session->set('qr_url', $result->qrUrl);
            WC()->session->set('qr_content', $result->qrContent);
            
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
            
        } catch (Exception $e) {
            qris_error_log("Payment process failed: " . $e->getMessage(), 'error');
            wc_add_notice($e->getMessage(), 'error');
            return array('result' => 'failure');
        }
    }
    public function process_blocks_payment($order_id) {
        qris_error_log("Starting payment process for order: $order_id", 'info');
        
        try {
            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception("Invalid order ID");
            }

            
            WC()->session->set('mitraCd', 'QSHP');
            
            // Get access token
            qris_error_log("Requesting access token", 'debug');
            $access_token = $this->get_access_token();
            
            if (!$access_token) {
                throw new Exception("Failed to obtain access token");
            }
            
            // Prepare payment data
            $payment_data = $this->prepare_payment_data($order);
            qris_error_log("Payment data prepared: " . json_encode($payment_data), 'debug');
            
            // Create QRIS request
            $result = $this->create_qris_request($payment_data, $access_token, $order);
            qris_error_log("QRIS response received: " . json_encode($result), 'debug');
            
            if (!isset($result->responseCode) || $result->responseCode !== "2004700") {
                throw new Exception($result->responseMessage ?? "Failed to create QRIS");
            }
            
            // Save transaction data
            $this->save_transaction_data($order, $result);
            WC()->session->set('qr_url', $result->qrUrl);
            WC()->session->set('qr_content', $result->qrContent);
            
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
            
        } catch (Exception $e) {
            qris_error_log("Payment process failed: " . $e->getMessage(), 'error');
            wc_add_notice($e->getMessage(), 'error');
            return array('result' => 'failure');
        }
    }
    private function get_callback_url() {
        return WC()->api_request_url('WC_Gateway_NICEPay_QRISV2');
    }
    private function get_cart_data($order) {
        $items = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $items[] = [
                "goods_name" => $item->get_name(),
                "goods_detail" => $product->get_short_description() ?: $item->get_name(),
                "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
                "goods_quantity" => (string)$item->get_quantity()
            ];
        }
        
        return json_encode([
            "count" => count($items),
            "item" => $items
        ], JSON_UNESCAPED_SLASHES);
    }

    private function prepare_payment_data($order) {
        qris_error_log("Preparing payment data for order: " . $order->get_id(), 'debug');

    try {
        // Prepare cart data
        $cart_items = array();
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $cart_items[] = array(
                "img_url" => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: "http://placeholder.com/image.jpg",
                "goods_name" => $item->get_name(),
                "goods_detail" => $product->get_short_description() ?: $item->get_name(),
                "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
                "goods_quantity" => (string)$item->get_quantity()
            );
        }

        $cart_data = array(
            "count" => count($cart_items),
            "item" => $cart_items
        );

        // Prepare request data structure
        $payment_data = [
            "partnerReferenceNo" =>  $order->get_order_number(),
            "amount" => [
                "value" => number_format($order->get_total(), 2, '.', ''),
                "currency" => $order->get_currency()
            ],
            "merchantId" => $this->get_option('X-CLIENT-KEY'),
            "storeId" => $this->get_option('shopId'),
            "validityPeriod" => '',
            "additionalInfo" => [
                "goodsNm" => "Payment for Order #" . $order->get_id(),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $order->get_billing_phone(),
                "billingEmail" => $order->get_billing_email(),
                "billingAddr" => $order->get_billing_address_1(),
                "billingCity" => $order->get_billing_city(),
                "billingState" => WC()->countries->states[$order->get_billing_country()][$order->get_billing_state()],
                "billingPostCd" => $order->get_billing_postcode(),
                "billingCountry" => WC()->countries->countries[$order->get_billing_country()],
                "callBackUrl" => $this->get_return_url($order),
                "dbProcessUrl" => WC()->api_request_url($this->id),
                "userIP" => $this->get_user_ip(),
                "cartData" => json_encode($cart_data, JSON_UNESCAPED_SLASHES),
                "mitraCd" => WC()->session->get('mitraCd', 'QSHP')
            ]
        ];

        qris_error_log("Payment data prepared: " . json_encode($payment_data), 'debug');
        return $payment_data;

    } catch (Exception $e) {
        qris_error_log("Error preparing payment data: " . $e->getMessage(), 'error');
        throw $e;
    }
}



    private function save_transaction_data($order, $result) {
        try {
            qris_error_log("Saving transaction data for order: " . $order->get_id(), 'debug');
            qris_error_log("Data to save: " . print_r($result, true), 'debug');
            $order->update_meta_data('_nicepay_reference_no', $result->referenceNo);
            $order->update_meta_data('_nicepay_qr_url', $result->qrUrl);
            $order->update_meta_data('_nicepay_qr_content', $result->qrContent);

            WC()->session->set('qr_url', $result->qrUrl);
             WC()->session->set('qr_content', $result->qrContent);
             $order->add_order_note(
                sprintf(
                    'QRIS Reference Number: %s (QR Created)',
                    $result->referenceNo
                ),
                false // private note
            );
            $order->save();
            qris_error_log("Transaction data saved successfully", 'debug');
        } catch (Exception $e) {
            qris_error_log("Error saving transaction data: " . $e->getMessage(), 'error');
            throw $e;
        }
    }
    

    private function create_qris_request($data, $access_token, $order) {
        qris_error_log("Starting QRIS request for order " . $order->get_id(), 'debug');

    try {
        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('SecretClient');
        $X_TIMESTAMP = $this->generate_timestamp();
        $timestamp = date('YmdHis');
        
        qris_error_log("Starting QRIS request with data: " . json_encode($data), 'debug');
        
        $stringBody = json_encode($data, JSON_UNESCAPED_SLASHES);
        $hashbody = strtolower(hash("SHA256", $stringBody));
        
        qris_error_log("Request body hash: " . $hashbody, 'debug');
        
        $strigSign = "POST:/api/v1.0/qr/qr-mpm-generate:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
        
        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type'   => 'application/json',
                'X-SIGNATURE'    => base64_encode($bodyHasing),
                'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                'X-TIMESTAMP'    => $X_TIMESTAMP,
                'Authorization'  => "Bearer " . $access_token,
                'CHANNEL-ID'     => $X_CLIENT_KEY . "01",
                'X-EXTERNAL-ID'  => $timestamp . rand(1000, 9999),
                'X-PARTNER-ID'   => $X_CLIENT_KEY
            ),
            'body'    => $stringBody,
        );
        
        qris_error_log("Making request to QRIS API", 'debug');
        qris_error_log("Request headers: " . json_encode($args['headers']), 'debug');
        qris_error_log("Request body: " . $args['body'], 'debug');
        
        $response = wp_remote_post($this->api_endpoints['registration'], $args);
        
        if (is_wp_error($response)) {
            throw new Exception("QRIS request failed: " . $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        qris_error_log("QRIS API Response Code: " . $response_code, 'debug');
        qris_error_log("QRIS API Response Body: " . $response_body, 'debug');
        
        $result = json_decode($response_body);
        
        if (!$result || !isset($result->responseCode) || $result->responseCode !== '2004700') {
            qris_error_log("Invalid API response: " . print_r($result, true), 'error');
            throw new Exception($result->responseMessage ?? "Failed to create QRIS");
        }

        $this->save_transaction_data($order, $result);
        
        return $result;
        
    } catch (Exception $e) {
        qris_error_log("Error in create_qris_request: " . $e->getMessage(), 'error');
        throw $e;
    }
}
    private function get_user_ip() {
    $ip = '';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
    }
    
    public function ajax_check_payment_status() {
        qris_error_log("Starting payment status check", 'debug');
        
        try {
            // 1. Validasi dan Persiapan Data
            if (!check_ajax_referer('check-qris-payment', 'security', false)) {
                throw new Exception('Invalid security token');
            }
            
            $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
            qris_error_log("Checking status for order ID: " . $order_id, 'debug');
            
            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception('Order tidak ditemukan');
            }
    
            $accessToken = WC()->session->get('accessToken');
            if (empty($accessToken)) {
                throw new Exception('Sesi tidak valid');
            }
    
            // 2. Persiapan Request ke NicePay
            $bodyInqu = array(
                "originalReferenceNo" => $order->get_meta('_nicepay_reference_no'),
                "originalPartnerReferenceNo" => "Order-" . $order->get_id() . "-" . $order->get_meta('_nicepay_timestamp'),
                "merchantId" => $this->XCLIENTKEY,
                "externalStoreId" => $this->shopId,
                "serviceCode" => "47",
                "additionalInfo" => new stdClass()
            );
    
            // 3. Persiapan Headers dan Signature
            $X_TIMESTAMP = $this->generate_timestamp();
            $stringBody = json_encode($bodyInqu);
            $hashbody = strtolower(hash("SHA256", $stringBody));
            
            $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $accessToken . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $this->SecretClient, true);
            
            $args = array(
                'method' => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE' => base64_encode($bodyHasing),
                    'X-CLIENT-KEY' => $this->XCLIENTKEY,
                    'X-TIMESTAMP' => $X_TIMESTAMP,
                    'Authorization' => "Bearer " . $accessToken,
                    'CHANNEL-ID' => $this->XCLIENTKEY . "01",
                    'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
                    'X-PARTNER-ID' => $this->XCLIENTKEY
                ),
                'body' => $stringBody
            );
    
            // 4. Kirim Request ke NicePay
            qris_error_log("Making request to NicePay with body: " . $stringBody, 'debug');
            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
            
            if (is_wp_error($response)) {
                throw new Exception("Request failed: " . $response->get_error_message());
            }
    
            $result = json_decode(wp_remote_retrieve_body($response));
            
            if (!$result) {
                throw new Exception("Invalid response from server");
            }
    
            // 5. Proses Response dan Update Status
            $status = $result->latestTransactionStatus;
            $message = '';
            
            switch($status) {
                case '00':
                    $order->update_status('completed', 'Pembayaran QRIS berhasil.');
                    $message = 'Pembayaran berhasil diverifikasi';
                    break;
                case '03':
                    $order->update_status('pending', 'Menunggu pembayaran QRIS.');
                    $message = 'Menunggu pembayaran';
                    break;
                case '04':
                    $order->update_status('refunded', 'Pembayaran QRIS direfund.');
                    $message = 'Pembayaran telah direfund';
                    break;
                case '05':
                    $order->update_status('cancelled', 'Pembayaran QRIS dibatalkan.');
                    $message = 'Pembayaran dibatalkan';
                    break;
                case '06':
                    $order->update_status('failed', 'Pembayaran QRIS gagal.');
                    $message = 'Pembayaran gagal';
                    break;
                default:
                    $message = 'Status tidak dikenal';
            }
    
            // 6. Kirim Response ke Frontend
            wp_send_json_success(array(
                'transactionStatus' => $status,
                'message' => $message,
                'paidTime' => $result->paidTime ?? null,
                'amount' => $result->amount ?? null,
                'additionalInfo' => $result->additionalInfo ?? null
            ));
    
        } catch (Exception $e) {
            qris_error_log("Error: " . $e->getMessage(), 'error');
            wp_send_json_error(array('message' => $e->getMessage()));
        }
        wp_die();
    }
    private function check_payment_status_direct($order_id, $reference_no, $accessToken) {
        qris_error_log("Starting payment status check for Order ID: {$order_id}", 'debug');
        qris_error_log("Reference No: {$reference_no}", 'debug');

        try {
            // Validasi access token
            if (empty($access_token)) {
                qris_error_log("Access token is empty", 'error');
                throw new Exception('Access token tidak valid');
            }
    
            qris_error_log("Using access token: " . $access_token, 'debug');
            
            $timestamp = $this->generate_timestamp();
            
            // Prepare body
            $stringBody = json_encode([
                "originalReferenceNo" => $reference_no,
                "originalPartnerReferenceNo" => $order_id,
                "merchantId" => $this->XCLIENTKEY,
                "externalStoreId" => $this->shopId,
                "serviceCode" => "47",
                "additionalInfo" => new stdClass()
            ]);
    
            // Generate signature
            $hashbody = strtolower(hash("SHA256", $stringBody));
            $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $access_token . ":" . $hashbody . ":" . $timestamp;
            $signature = hash_hmac("sha512", $strigSign, $this->SecretClient, true);
    
            // Prepare request args
            $args = array(
                'method' => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE' => base64_encode($signature),
                    'X-TIMESTAMP' => $timestamp,
                    'Authorization' => 'Bearer ' . $access_token,
                    'CHANNEL-ID' => $this->XCLIENTKEY . "01",
                    'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
                    'X-PARTNER-ID' => $this->XCLIENTKEY
                ),
                'body' => $stringBody,
            );
    
            // Log request details
            qris_error_log("URL: " . $this->api_endpoints['check_status_url'], 'debug');
            qris_error_log("Full request: " . print_r($args, true), 'debug');
            qris_error_log("Body: " . $stringBody, 'debug');
    
            // Send request
            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
    
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                qris_error_log("WP Error in request: {$error_message}", 'error');
                throw new Exception($error_message);
            }
    
            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            
            qris_error_log("Response code: {$response_code}", 'debug');
            qris_error_log("Response body: {$response_body}", 'debug');
    
            // Handle 401 specifically
            if ($response_code === 401) {
                qris_error_log("Authentication failed. Token might be expired.", 'error');
                throw new Exception("Token autentikasi tidak valid atau kadaluarsa");
            }
    
            $result = json_decode($response_body);
            if (!$result) {
                throw new Exception("Failed to decode response: " . json_last_error_msg());
            }
    
            return $result;
    
        } catch (Exception $e) {
            qris_error_log("Error in check_payment_status_direct: " . $e->getMessage(), 'error');
            throw $e;
        }
    }
    // private function check_payment_status($bodyInqu, $accessToken) {
    //     qris_error_log("Starting payment status check with data: " . json_encode($bodyInqu), 'debug');
    //     $X_TIMESTAMP = $this->generate_timestamp();
    //     $stringBody = json_encode($bodyInqu);
    //     $hashbody = strtolower(hash("SHA256", $stringBody));
    //     qris_error_log("Request body hash: " . $hashbody, 'debug');
        
    //     $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $accessToken . ":" . $hashbody . ":" . $X_TIMESTAMP;
    //     $bodyHasing = hash_hmac("sha512", $strigSign, $this->SecretClient, true);
    //     qris_error_log("Generated signature for status check", 'debug');
    
    //     $headers = array(
    //         'Content-Type' => 'application/json',
    //         'X-SIGNATURE' => base64_encode($bodyHasing),
    //         'X-CLIENT-KEY' => $this->XCLIENTKEY,
    //         'X-TIMESTAMP' => $X_TIMESTAMP,
    //         'Authorization' => "Bearer " . $accessToken,
    //         'CHANNEL-ID' => $this->XCLIENTKEY . "01",
    //         'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
    //         'X-PARTNER-ID' => $this->XCLIENTKEY
    //     );

    //     $args = array(
    //         'method' => 'POST',
    //         'timeout' => 45,
    //         'headers' => $headers,
    //         'body' => $stringBody
    //     );
    //     qris_error_log("Making status check request to: " . $this->api_endpoints['check_status_url'], 'debug');
    //     qris_error_log("Request headers: " . json_encode($headers), 'debug');
    //     qris_error_log("Request body: " . $stringBody, 'debug');
    
    //     $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
    //     if (is_wp_error($response)) {
    //         qris_error_log("Status check request failed: " . $response->get_error_message(), 'error');
    //         throw new Exception($response->get_error_message());
    //     }

        
    //     $response_code = wp_remote_retrieve_response_code($response);
    //     $response_body = wp_remote_retrieve_body($response);
        
    //     qris_error_log("Status check response code: " . $response_code, 'debug');
    //     qris_error_log("Status check response body: " . $response_body, 'debug');

    //     $result = json_decode($response_body);

    //     if (json_last_error() !== JSON_ERROR_NONE) {
    //         qris_error_log("Failed to decode response JSON: " . json_last_error_msg(), 'error');
    //         throw new Exception("Invalid JSON response from server");
    //     }

    //     qris_error_log("Payment status check completed successfully", 'info');
    //     return $result;
    // }

  
}
?>