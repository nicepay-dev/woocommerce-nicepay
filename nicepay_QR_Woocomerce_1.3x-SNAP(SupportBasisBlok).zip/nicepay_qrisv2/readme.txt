Plugin Name: NICEPay QRIS SNAP
Plugin URI: http://nicepay.co.id
Description: QRIS Payment Method
API Version: 1
Author: NICEPay
Author URI: http://nicepay.co.id
------

Fixing update :

------
1.x Create Plugin QRIS SNAP
2.x Update block basis checkout woocomerce
3.x Update mode checkout & environment

-------