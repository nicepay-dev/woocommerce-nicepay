<?php
/**
 * Plugin Name: NICEPay Ewallet SNAP Payment Gateway
 * Plugin URI: http://nicepay.co.id
 * Description: NICEPay Ewallet SNAP Payment Gateway for WooCommerce
 * Version: 1.3.0
 * Author: codeNinja
 * Author URI: http://nicepay.co.id
 * Text Domain: nicepay-ewallet-snap
 * WC requires at least: 5.0
 * WC tested up to: 7.x
 */
defined('ABSPATH') or exit;

// Make sure WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

function enqueue_nicepay_ewallet_blocks() {
    if (!is_checkout()) {
        return;
    }

    wp_enqueue_script(
        'nicepay-ewallet-blocks-integration',
        plugins_url('config/blocks-integration.js', __FILE__),
        ['wc-blocks-registry', 'wp-element', 'jquery'],
        filemtime(plugin_dir_path(__FILE__) . 'config/blocks-integration.js'),
        true
    );

    wp_enqueue_style(
        'nicepay-ewallet-style',
        plugins_url('config/ewalletsnap.css', __FILE__),
        [],
        filemtime(plugin_dir_path(__FILE__) . 'config/ewalletsnap.css')
    );

    $gateway = new WC_Gateway_Ewallet_NICEPay_SNAP();
    wp_localize_script(
        'nicepay-ewallet-blocks-integration',
        'nicepayData',
        array(
            'enabled_mitra' => $gateway->get_ewallet_options(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nicepay-ewallet-snap-nonce'),
            'pluginUrl' => plugins_url('', __FILE__)
        )
    );
}

function enqueue_nicepay_ewallet_classic() {
    if (!is_checkout()) {
        return;
    }

    wp_enqueue_script(
        'nicepay-classic-checkout',
        plugins_url('config/classic-checkout.js', __FILE__),
        array('jquery'),
        filemtime(plugin_dir_path(__FILE__) . 'config/classic-checkout.js'),
        true
    );

    $gateway = new WC_Gateway_Ewallet_NICEPay_SNAP();
    wp_localize_script(
        'nicepay-classic-checkout',
        'nicepayData',
        array(
            'enabled_mitra' => $gateway->get_ewallet_options(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nicepay-ewallet-snap-nonce'),
            'pluginUrl' => plugins_url('', __FILE__)
        )
    );
}

// Initialize the plugin
function initialize_nicepay_ewallet_snap() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    require_once plugin_dir_path(__FILE__) . 'config/ewallet-snap.php';
    $gateway = new WC_Gateway_Ewallet_NICEPay_SNAP();
    
    // Get settings
    $settings = get_option('woocommerce_nicepay_ewallet_snap_settings', array());
    $checkout_mode = isset($settings['enable_blocks']) ? $settings['enable_blocks'] : 'classic';

    // Register AJAX handlers - using the existing handler name from the class
    add_action('wp_ajax_set_nicepay_mitra', array($gateway, 'handle_set_nicepay_mitra'));
    add_action('wp_ajax_nopriv_set_nicepay_mitra', array($gateway, 'handle_set_nicepay_mitra'));

    // Enqueue scripts based on checkout mode
    if ($checkout_mode === 'blocks') {
        add_action('woocommerce_blocks_enqueue_checkout_block_scripts_before', 'enqueue_nicepay_ewallet_blocks');
    } else {
        add_action('wp_enqueue_scripts', 'enqueue_nicepay_ewallet_classic');
    }
}

function add_nicepay_ewallet_snap_gateway($methods) {
    $methods[] = 'WC_Gateway_Ewallet_NICEPay_SNAP';
    return $methods;
}

// Register hooks
add_action('plugins_loaded', 'initialize_nicepay_ewallet_snap', 0);
add_filter('woocommerce_payment_gateways', 'add_nicepay_ewallet_snap_gateway');