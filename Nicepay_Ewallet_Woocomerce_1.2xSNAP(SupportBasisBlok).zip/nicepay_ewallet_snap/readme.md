<!-- 29 Januari 2025 -->
- Create Plugin Ewallet SNAP
- Fixing environment
- Fixing flag checkout mode 