<?php
if (!defined('ABSPATH')) {
    exit;
}
class WC_Gateway_Ewallet_NICEPay_SNAP extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'nicepay_ewallet_snap';
        $this->icon               = apply_filters('woocommerce_nicepay_ewallet_snap_icon', '');
        $this->has_fields         = false;
        $this->method_title       = __('NICEPay Ewallet SNAP', 'nicepay-ewallet-snap-gateway');
        $this->method_description = __('Allows payments using NICEPay Ewallet SNAP.', 'nicepay-ewallet-snap-gateway');

        $this->supports = [
            'products',
            'refunds',
        ];
        // $this->api_endpoints = [
        //     'access_token' => 'https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b',
        //     'registration'    => 'https://dev.nicepay.co.id/nicepay/api/v1.0/debit/payment-host-to-host',
        //     'check_status_url' => 'https://dev.nicepay.co.id/nicepay/api/v1.0/debit/status',
        // ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        $this->register_scheduled_hooks();
        $this->environment  = $this->get_option('environment', 'sandbox');

        $this->api_endpoints = $this->get_api_endpoints();
        add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));

        if ($this->get_option('enable_blocks') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }
        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');

        add_action('wp_ajax_set_nicepay_mitra', array($this, 'handle_set_nicepay_mitra'));
        add_action('wp_ajax_nopriv_set_nicepay_mitra', array($this, 'handle_set_nicepay_mitra'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        // add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        // add_action('init', array($this, 'add_endpoint'));
        add_action('woocommerce_api_nicepay_linkaja_process', array($this, 'process_linkaja_payment'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'handle_return_url'));
        add_action('woocommerce_api_wc_gateway_nicepay_snap', array($this, 'handle_callback'));

        error_log("NICEPay gateway initialized");
}

public function enqueue_classic_mode() {
    if (!is_checkout()) {
        return;
    }

    ?>
    <style>
        .nicepay-ewallet-container {
            margin: 15px 0;
            padding: 15px;
            background: #f8f8f8;
            border-radius: 4px;
        }
        .nicepay-ewallet-header {
            margin-bottom: 15px;
            text-align: center;
            padding: 10px 0;
        }
        .nicepay-ewallet-icon {
            max-height: 150px;
            width: auto;
            display: inline-block;
            margin: 10px 0;
        }
        .nicepay-ewallet-select {
            margin: 10px 0;
        }
        .nicepay-ewallet-select label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .nicepay-ewallet-logos {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px; /* Spacing antar logo */
        margin-bottom: 20px;
        }
        .nicepay-ewallet-logos img {
        height: 30px; /* Ukuran untuk logo individu */
        width: auto;
        }
        .nicepay-ewallet-select select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
    <?php

    // Enqueue JS
    wp_enqueue_script(
        'nicepay-classic-checkout',
        plugins_url('config/classic-checkout.js', dirname(__FILE__)),
        array('jquery'),
        '1.0.0',
        true
    );

    // Localize script
    wp_localize_script(
        'nicepay-classic-checkout',
        'nicepayData',
        array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'pluginUrl' => plugins_url('', dirname(__FILE__)),
            'enabled_mitra' => $this->get_ewallet_options(),
            'nonce' => wp_create_nonce('nicepay-ewallet-snap-nonce')
        )
    );
}
public function enqueue_blocks_mode() {
    // Enqueue CSS
    wp_enqueue_style(
        'nicepay-ewallet-style',
        plugins_url('config/ewalletsnap.css', dirname(__FILE__))
    );

    // Register blocks script
    wp_register_script(
        'nicepay-blocks-integration',
        plugins_url('config/blocks-integration.js', dirname(__FILE__)),
        array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
        filemtime(plugin_dir_path(dirname(__FILE__)) . '/config/blocks-integration.js'),
        true
    );

    // Localize script
    wp_localize_script(
        'nicepay-blocks-integration',
        'nicepayData',
        array(
            'enabled_mitra' => $this->get_ewallet_options(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nicepay-ewallet-snap-nonce'),
            'pluginUrl' => plugins_url('', dirname(__FILE__))
        )
    );

    // Enqueue blocks script
    wp_enqueue_script('nicepay-blocks-integration');
}
// public function add_endpoint() {
//     add_rewrite_endpoint('wc-api', EP_ALL);
//     }
public function update_api_endpoints() {
    $this->environment = $this->get_option('environment', 'sandbox');
    $this->api_endpoints = $this->get_api_endpoints();
}
private function get_api_endpoints() {
    $environment = $this->get_option('environment', 'sandbox');
    error_log ("Current environment setting: " . $environment);

    $base_url = ($environment === 'production')  
            ? 'https://www.nicepay.co.id'
            : 'https://dev.nicepay.co.id';
    
        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/debit/payment-host-to-host',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/debit/status',
        ];
    }

public function init_form_fields() {
    $this->form_fields = array(
        'enabled' => array(
            'title'   => __('Enable/Disable', 'woocommerce'),
            'type'    => 'checkbox',
            'label'   => __('Enable NICEPay Payment', 'woocommerce'),
            'default' => 'no'
        ),
        'title' => array(
            'title'       => __('Title', 'woocommerce'),
            'type'        => 'text',
            'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
            'default'     => __('NICEPay', 'woocommerce'),
            'desc_tip'    => true,
        ),
        'description' => array(
            'title'       => __('Description', 'woocommerce'),
            'type'        => 'textarea',
            'description' => __('This controls the description which the user sees during checkout.', 'woocommerce'),
            'default'     => __('Pay with NICEPay', 'woocommerce'),
            'desc_tip'    => true,
        ),
        'enable_blocks' => array(
            'title'       => __('Checkout Mode', 'woocommerce'),
            'type'        => 'select',
            'description' => __('Select checkout mode. Block checkout is for modern WooCommerce checkout, while Classic is for traditional checkout.', 'woocommerce'),
            'default'     => 'classic',
            'options'     => array(
            'classic' => __('Classic Checkout / Element Checkout (Non-Blocks)', 'woocommerce'),
            'blocks'  => __('Block Checkout', 'woocommerce')
            )
        ),
        'environment' => array(
            'title'       => __('Environment', 'woocommerce'),
            'type'        => 'select',
            'desc_tip'    => true,
            'description' => __('Select the NICEPay environment.', 'woocommerce'),
            'default'     => 'sandbox',
            'options'     => array(
                'sandbox'    => __('Sandbox / Development', 'woocommerce'),
                'production' => __('Production', 'woocommerce'),
            ),
        ),
        'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPay</small>.', 'woocommerce'),
                'default' => 'IONPAYTEST',
            ),
        'CHANNEL-ID' => array(
                'title' => __('Channel ID', 'woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Channel ID dari NICEPay</small>.', 'woocommerce'),
                'default' => 'IONPAYTEST01',
            ),
        'client_secret' => array(
            'title'       => __('Client Key', 'woocommerce'),
            'type'        => 'text',
            'description' => __('Enter your NICEPay Client Key.', 'woocommerce'),
            'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            'desc_tip'    => true,
        ),
        'merchant_key' => array(
            'title'       => __('Merchant Key', 'woocommerce'),
            'type'        => 'text',
            'description' => __('Enter your NICEPay Merchant Key.', 'woocommerce'),
            'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R',
        ),
        'private_key' => array(
            'title'       => __('Private Key', 'woocommerce'),
            'type'        => 'textarea',
            'description' => __('Enter your NICEPay Private Key.', 'woocommerce'),
            'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
            'desc_tip'    => true,
        ),
        'mitra_options' => array(
            'title'       => __('E-wallet Options', 'woocommerce'),
            'type'        => 'title',
            'description' => __('Select which e-wallets you want to enable.', 'woocommerce'),
        ),
        'enable_ovo' => array(
            'title'   => __('OVO', 'woocommerce'),
            'type'    => 'checkbox',
            'label'   => __('Enable OVO Payment', 'woocommerce'),
            'default' => 'yes'
        ),
        'enable_dana' => array(
            'title'   => __('DANA', 'woocommerce'),
            'type'    => 'checkbox',
            'label'   => __('Enable DANA Payment', 'woocommerce'),
            'default' => 'yes'
        ),
        'enable_linkaja' => array(
            'title'   => __('LinkAja', 'woocommerce'),
            'type'    => 'checkbox',
            'label'   => __('Enable LinkAja Payment', 'woocommerce'),
            'default' => 'yes'
        ),
        'enable_shopeepay' => array(
            'title'   => __('ShopeePay', 'woocommerce'),
            'type'    => 'checkbox',
            'label'   => __('Enable ShopeePay Payment', 'woocommerce'),
            'default' => 'yes'
        ),
    );
}

public function get_ewallet_options() {
    $available_options = array();

    if ($this->get_option('enable_ovo') === 'yes') {
        $available_options[] = array('value' => 'OVOE', 'label' => 'OVO');
    }
    if ($this->get_option('enable_dana') === 'yes') {
        $available_options[] = array('value' => 'DANA', 'label' => 'DANA');
    }
    if ($this->get_option('enable_linkaja') === 'yes') {
        $available_options[] = array('value' => 'LINK', 'label' => 'LINK AJA');
    }
    if ($this->get_option('enable_shopeepay') === 'yes') {
        $available_options[] = array('value' => 'ESHP', 'label' => 'ShopeePay');
    }

    error_log("Available e-wallet options: " . print_r($available_options, true));
    return $available_options;
}
    public function handle_set_nicepay_mitra() {
    check_ajax_referer('nicepay-ewallet-snap-nonce', 'nonce');
    
    if (!isset($_POST['mitra_code'])) {
        wp_send_json_error('Mitra not specified');
    }

    $mitra = sanitize_text_field($_POST['mitra_code']);
    WC()->session->set('nicepay_selected_mitra', $mitra);
    
    wp_send_json_success('Mitra selection saved');
}
    public function is_available() {
    $is_available = ('yes' === $this->enabled);

    if ($is_available) {
        $available_mitra = $this->get_ewallet_options();
        if (empty($available_mitra)) {
            error_log('No e-wallet options are enabled');
            return false;
        }
    }
    
    if (WC()->cart && WC()->cart->needs_shipping()) {
        $is_available = $is_available && $this->supports_shipping_country(WC()->customer->get_shipping_country());
    }

    return $is_available;
}

    private function supports_shipping_country($country) {
    $supported_countries = array('ID'); 
    return in_array($country, $supported_countries);
}

public function payment_fields() {
    if ($this->get_option('enable_blocks') === 'classic') {
        if ($this->description) {
            echo wpautop(wptexturize($this->description));
        }
        
        $selected_mitra = WC()->session->get('nicepay_selected_mitra');
        
        ?>
        <div class="nicepay-ewallet-container">
            <!-- Logo container -->
            <div class="nicepay-ewallet-header">
            <div class="nicepay-ewallet-logos">
            <img src="<?php echo plugins_url('config/ewallet1.png', dirname(__FILE__)); ?>" 
                 alt="E-wallet Logo" 
                 class="nicepay-ewallet-icon">
        </div>
    </div>
            
            <!-- Selector container -->
            <div class="nicepay-ewallet-select">
                <label for="nicepay-ewallet-select">Pilih E-wallet:</label>
                <select name="nicepay_mitra" id="nicepay-ewallet-select">
                    <option value="">Pilih E-wallet</option>
                    <?php foreach ($this->get_ewallet_options() as $mitra): ?>
                        <option value="<?php echo esc_attr($mitra['value']); ?>" 
                                <?php selected($selected_mitra, $mitra['value']); ?>>
                            <?php echo esc_html($mitra['label']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <?php
    }
}

public function process_payment($order_id) {
    $checkout_mode = $this->get_option('enable_blocks', 'classic');
    
    if ($checkout_mode === 'classic') {
        return $this->process_classic_payment($order_id);
    } else {
        return $this->process_blocks_payment($order_id);
    }
}

public function process_blocks_payment($order_id) {
    error_log("Starting process_blocks_payment for order $order_id");
    error_log("POST data received: " . print_r($_POST, true));
    error_log("Session data: " . print_r(WC()->session->get_session_data(), true));
    $order = wc_get_order($order_id);
    $selected_mitra = WC()->session->get('nicepay_selected_mitra');
    error_log("Selected mitra from session: " . $selected_mitra);

    if (empty($selected_mitra)) {
        wc_add_notice(__('Please select an e-wallet payment method.', 'nicepay-ewallet-snap-gateway'), 'error');
        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }

    try {
        $access_token = $this->get_access_token();
        $ewallet_data = $this->create_registration($order, $access_token);
        
        if (!isset($ewallet_data['responseCode'])) {
            throw new Exception(__('Invalid response from payment gateway', 'nicepay-ewallet-snap-gateway'));
        }
        error_log("E-wallet registration response: " . print_r($ewallet_data, true));

        if ($ewallet_data['responseCode'] === '2005400' && $ewallet_data['responseMessage'] === 'Successful') {
            // Simpan data response ke order meta
            $order->update_meta_data('_nicepay_reference_no', $ewallet_data['referenceNo']);
            $order->update_meta_data('_nicepay_partner_reference_no', $ewallet_data['partnerReferenceNo']);
            $order->update_meta_data('_nicepay_mitra', $selected_mitra);
            $order->save();

            // Empty cart
            WC()->cart->empty_cart();
            
            // Return success with redirect URL
            if ($selected_mitra === 'OVOE') {
                // Untuk OVO, check status setelah mendapat response sukses
                error_log("Checking payment status for OVO payment...");
                $status_response = $this->check_payment_status($order, $ewallet_data['referenceNo']);
                error_log("Status check response: " . print_r($status_response, true));

                // Update order status berdasarkan response check status
                $this->update_order_status($order, $status_response);

                return array(
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                );
            } elseif ($selected_mitra === 'LINK' && isset($ewallet_data['additionalInfo']['redirectToken'])) {
                error_log("Processing LinkAja payment...");
                
                // Ensure correct URL format
                $redirectUrl = $ewallet_data['webRedirectUrl'] . "?Message=" . $ewallet_data['additionalInfo']['redirectToken'];
                error_log("LinkAja Redirect URL: " . $redirectUrl);
                // $redirectToken = $ewallet_data['additionalInfo']['redirectToken'];
                
                $order->update_status('pending', sprintf(
                    __('Menunggu pembayaran %s', 'nicepay-ewallet-snap-gateway'),
                    $selected_mitra
                ));
                
                // Save minimal required data
                $order->update_meta_data('_nicepay_reference_no', $ewallet_data['referenceNo']);
                $order->update_meta_data('_nicepay_partner_reference_no', $ewallet_data['partnerReferenceNo']);
                $order->update_meta_data('_nicepay_mitra', $selected_mitra);
                $order->save();
                WC()->cart->empty_cart();

                return array(
                    'result' => 'success',
                    'redirect' => $redirectUrl
                );
            } elseif (isset($ewallet_data['webRedirectUrl'])) {
                // Untuk DANA, Shopee Pay
                $order->update_meta_data('_nicepay_redirect_url', $ewallet_data['webRedirectUrl']);
                $order->update_status('pending', sprintf(
                    __('Menunggu pembayaran %s', 'nicepay-ewallet-snap-gateway'),
                    $selected_mitra
                ));
                $order->save();

                add_action('woocommerce_thankyou_' . $this->id, function($order_id) {
                    $order = wc_get_order($order_id);
                    if (!$order || $order->get_status() !== 'pending') {
                        return;
                    }

                    $reference_no = $order->get_meta('_nicepay_reference_no');
                    $mitra = $order->get_meta('_nicepay_mitra');

                    if (!empty($reference_no) && $mitra !== 'OVOE') {
                        error_log("Checking payment status for order {$order_id} after redirect");
                        try {
                            $status_response = $this->check_payment_status($order, $reference_no);
                            $this->update_order_status($order, $status_response);
                        } catch (Exception $e) {
                            error_log("Error checking payment status: " . $e->getMessage());
                        }
                    }
                });

                return array(
                    'result' => 'success',
                    'redirect' => $ewallet_data['webRedirectUrl']
                );
            }
        }
        
        // Jika response code tidak sesuai
        throw new Exception(sprintf(
            __('Payment gateway error: %s', 'nicepay-ewallet-snap-gateway'),
            $ewallet_data['responseMessage'] ?? 'Unknown error'
        ));

    } catch (Exception $e) {
        wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
        error_log("Payment error in process_payment: " . $e->getMessage());
        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }
}

public function process_classic_payment($order_id) {
    error_log("Starting process_classic_payment for order $order_id");
    error_log("POST data received: " . print_r($_POST, true));
    error_log("Session data: " . print_r(WC()->session->get_session_data(), true));
    $order = wc_get_order($order_id);
    $selected_mitra = sanitize_text_field($_POST['nicepay_mitra'] ?? '');

    if (empty($selected_mitra)) {
        wc_add_notice(__('Please select an e-wallet payment method.', 'nicepay-ewallet-snap-gateway'), 'error');
        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }
    WC()->session->set('nicepay_selected_mitra', $selected_mitra);

    try {
        $access_token = $this->get_access_token();
        $ewallet_data = $this->create_registration($order, $access_token);
        
        if (!isset($ewallet_data['responseCode'])) {
            throw new Exception(__('Invalid response from payment gateway', 'nicepay-ewallet-snap-gateway'));
        }
        error_log("E-wallet registration response: " . print_r($ewallet_data, true));

        if ($ewallet_data['responseCode'] === '2005400' && $ewallet_data['responseMessage'] === 'Successful') {
            // Simpan data response ke order meta
            $order->update_meta_data('_nicepay_reference_no', $ewallet_data['referenceNo']);
            $order->update_meta_data('_nicepay_partner_reference_no', $ewallet_data['partnerReferenceNo']);
            $order->update_meta_data('_nicepay_mitra', $selected_mitra);
            $order->save();

            // Empty cart
            WC()->cart->empty_cart();
            
            // Return success with redirect URL
            if ($selected_mitra === 'OVOE') {
                // Untuk OVO, check status setelah mendapat response sukses
                error_log("Checking payment status for OVO payment...");
                $status_response = $this->check_payment_status($order, $ewallet_data['referenceNo']);
                error_log("Status check response: " . print_r($status_response, true));

                // Update order status berdasarkan response check status
                $this->update_order_status($order, $status_response);

                return array(
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                );
            } elseif ($selected_mitra === 'LINK' && isset($ewallet_data['additionalInfo']['redirectToken'])) {
                error_log("Processing LinkAja payment...");
                
                // Ensure correct URL format
                $redirectUrl = $ewallet_data['webRedirectUrl'] . "?Message=" . $ewallet_data['additionalInfo']['redirectToken'];
                error_log("LinkAja Redirect URL: " . $redirectUrl);
                // $redirectToken = $ewallet_data['additionalInfo']['redirectToken'];
                
                $order->update_status('pending', sprintf(
                    __('Menunggu pembayaran %s', 'nicepay-ewallet-snap-gateway'),
                    $selected_mitra
                ));
                
                // Save minimal required data
                $order->update_meta_data('_nicepay_reference_no', $ewallet_data['referenceNo']);
                $order->update_meta_data('_nicepay_partner_reference_no', $ewallet_data['partnerReferenceNo']);
                $order->update_meta_data('_nicepay_mitra', $selected_mitra);
                $order->save();
                WC()->cart->empty_cart();

                return array(
                    'result' => 'success',
                    'redirect' => $redirectUrl
                );
            } elseif (isset($ewallet_data['webRedirectUrl'])) {
                // Untuk DANA, Shopee Pay
                $order->update_meta_data('_nicepay_redirect_url', $ewallet_data['webRedirectUrl']);
                $order->update_status('pending', sprintf(
                    __('Menunggu pembayaran %s', 'nicepay-ewallet-snap-gateway'),
                    $selected_mitra
                ));
                $order->save();

                add_action('woocommerce_thankyou_' . $this->id, function($order_id) {
                    $order = wc_get_order($order_id);
                    if (!$order || $order->get_status() !== 'pending') {
                        return;
                    }

                    $reference_no = $order->get_meta('_nicepay_reference_no');
                    $mitra = $order->get_meta('_nicepay_mitra');

                    if (!empty($reference_no) && $mitra !== 'OVOE') {
                        error_log("Checking payment status for order {$order_id} after redirect");
                        try {
                            $status_response = $this->check_payment_status($order, $reference_no);
                            $this->update_order_status($order, $status_response);
                        } catch (Exception $e) {
                            error_log("Error checking payment status: " . $e->getMessage());
                        }
                    }
                });

                return array(
                    'result' => 'success',
                    'redirect' => $ewallet_data['webRedirectUrl']
                );
            }
        }
        
        // Jika response code tidak sesuai
        throw new Exception(sprintf(
            __('Payment gateway error: %s', 'nicepay-ewallet-snap-gateway'),
            $ewallet_data['responseMessage'] ?? 'Unknown error'
        ));

    } catch (Exception $e) {
        wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
        error_log("Payment error in process_payment: " . $e->getMessage());
        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }
}
public function process_linkaja_payment() {
    if (!isset($_GET['url']) || !isset($_GET['token'])) {
        wp_die('Invalid request');
    }

    $url = sanitize_text_field($_GET['url']);
    $token = sanitize_text_field($_GET['token']);

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Processing LinkAja Payment</title>
        <style>
            body { 
                font-family: Arial, sans-serif;
                text-align: center;
                padding: 20px;
                background: #f5f5f5;
                margin: 0;
            }
            .container {
                max-width: 500px;
                margin: 40px auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .spinner {
                display: inline-block;
                width: 50px;
                height: 50px;
                margin: 20px auto;
                border: 4px solid #f3f3f3;
                border-top: 4px solid #ff0000;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            h2 {
                color: #333;
                margin-bottom: 20px;
            }
            p {
                color: #666;
                margin: 15px 0;
            }
            button {
                background: #ff0000;
                color: white;
                border: none;
                padding: 12px 25px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin-top: 20px;
            }
            button:hover {
                background: #e60000;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Menghubungkan ke LinkAja</h2>
            <div class="spinner"></div>
            <p>Mohon tunggu, Anda akan diarahkan ke halaman pembayaran LinkAja...</p>
            <form id="linkaja_form" method="POST" action="<?php echo esc_url($url); ?>">
                <input type="hidden" name="redirectToken" value="<?php echo esc_attr($token); ?>">
            </form>
            <script>
                // Submit form setelah semua konten dimuat
                window.onload = function() {
                    setTimeout(function() {
                        document.getElementById('linkaja_form').submit();
                    }, 1000);
                };
            </script>
            <noscript>
                <p>Jika Anda tidak dialihkan secara otomatis, silakan klik tombol di bawah ini:</p>
                <button type="submit" form="linkaja_form">Lanjutkan ke LinkAja</button>
            </noscript>
        </div>
    </body>
    </html>
    <?php
    exit;
}
        


private function generate_formatted_timestamp() {
    $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
    return $date->format('Y-m-d\TH:i:sP');
}
private function get_access_token() {
    error_log("Starting get_access_token process");

    $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
    $timestamp = $this->generate_formatted_timestamp();
    $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;

    error_log("X_CLIENT_KEY: " . $X_CLIENT_KEY);
    error_log("Timestamp: " . $timestamp);
    error_log("StringToSign: " . $stringToSign);
    
    $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
        $this->get_option('private_key') . "\r\n" .
        "-----END RSA PRIVATE KEY-----";
        // error_log("Private Key: " . $privatekey);
        error_log("Private Key Structure: " . substr($privatekey, 0, 100) . "...");
    $binary_signature = "";
    $pKey = openssl_pkey_get_private($privatekey);
    
    if ($pKey === false) {
        $error = openssl_error_string();
        error_log("Failed to get private key. OpenSSL Error: " . $error);
        throw new Exception("Invalid private key: " . $error);
    }
    
    $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
    
    if ($sign_result === false) {
        $error = openssl_error_string();
        error_log("Failed to create signature. OpenSSL Error: " . $error);
        throw new Exception("Failed to create signature: " . $error);
    }
    
    $signature = base64_encode($binary_signature);
    error_log("Generated Signature: " . $signature);
    
    $jsonData = array(
        "grantType" => "client_credentials",
    );
    
    $jsonDataEncode = json_encode($jsonData);
    error_log("Request Body JSON: " . $jsonDataEncode);
    
    $requestToken = $this->api_endpoints['access_token'];
    error_log("Request URL: " . $requestToken);
    
    $args = array(
        'method'  => 'POST',
        'timeout' => 45,
        'headers' => array(
            'Content-Type' => 'application/json',
            'X-SIGNATURE'  => $signature,
            'X-CLIENT-KEY' => $X_CLIENT_KEY,
            'X-TIMESTAMP'  => $timestamp
        ),
        'body'    => $jsonDataEncode,
    );

    error_log("Full Request Headers: " . print_r($args['headers'], true));
    error_log("Full Request Body: " . print_r($args['body'], true));
    
    $response = wp_remote_post($requestToken, $args);
    
    
    if (is_wp_error($response)) {
        error_log("Error in get_access_token: " . $response->get_error_message());
        throw new Exception($response->get_error_message());
    }
    error_log("Response Code: " . wp_remote_retrieve_response_code($response));
    error_log("Response Headers: " . print_r(wp_remote_retrieve_headers($response), true));
    
    
    $body = json_decode(wp_remote_retrieve_body($response));
    error_log("Access token response: " . json_encode($body));
    
    if (!isset($body->accessToken)) {
        error_log("Invalid access token response: " . json_encode($body));
        throw new Exception(__('Invalid access token response', 'nicepay-vasnap-gateway'));
    }
    
    error_log("Successfully obtained access token");
    WC()->session->set('accessToken', $body->responseCode);
    
    return $body->accessToken;
}

private function create_registration($order, $access_token) {
    error_log("Starting create_registration for order " . $order->get_id());

    $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
    $secretClient = $this->get_option('client_secret');
    $X_TIMESTAMP = $this->generate_formatted_timestamp();
    $timestamp = date('YmdHis');
    $channel = $this->get_option('CHANNEL-ID');
    $external = $timestamp . rand(1000, 9999);
    error_log("secret client: " . $secretClient);
    $selected_mitra = WC()->session->get('nicepay_selected_mitra', '');
    error_log("Selected mitra: " . $selected_mitra);
    if (empty($selected_mitra)) {
        throw new Exception(__('No e-wallet selected. Please choose an e-wallet payment method.', 'nicepay-ewallet-snap-gateway'));
    }

    $cart_items = array();
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        $cart_items[] = array(
            "img_url" => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: "http://placeholder.com/image.jpg",
            "goods_name" => $item->get_name(),
            "goods_detail" => $product->get_short_description() ?: $item->get_name(),
            "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
            "goods_quantity" => (string)$item->get_quantity()
        );
    }
    $cart_data = array(
        "count" => (string)count($cart_items),
        "item" => $cart_items
    );
    $cart_data_json = json_encode($cart_data, JSON_UNESCAPED_SLASHES);
    error_log("Cart Data JSON: " . $cart_data_json);

    $newBody = [
        "partnerReferenceNo" => $order->get_id(),
        "merchantId" => $X_CLIENT_KEY,
        "subMerchantId" => "",
        "externalStoreId" => "",
        "validUpTo" => date('Y-m-d\TH:i:s\Z', strtotime('+1 day')),
        "pointOfInitiation" => "MOBILE_APP",
        "amount" => [
            "value" => number_format($order->get_total(), 2, '.', ''),
            "currency" => $order->get_currency()
        ],
        "urlParam" => [
            [
                "url" => home_url('/wc-api/wc_gateway_nicepay_snap'),
                "type" => "PAY_NOTIFY",
                "isDeeplink" => "Y" 
            ],
            [
                "url" => $this->get_return_url($order),
                "type" => "PAY_RETURN",
                "isDeeplink" => "Y" 
            ]
        ],
        "additionalInfo" => [
            "mitraCd" => $selected_mitra,
            "goodsNm" => $this->get_order_items_names($order),
            "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            "billingPhone" => $order->get_billing_phone(),
            "customerEmail" => $order->get_billing_email(), 
            "cartData" => $cart_data_json, 
            "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_snap'),
            "callBackUrl" => $this->get_return_url($order),
            "msId" => ""
        ]
    ];
    error_log("Request body structure: " . print_r($newBody, true));
    error_log("Cart Data (encoded): " . json_encode($cart_data));

    $stringBody = json_encode($newBody, JSON_UNESCAPED_SLASHES);;
    $hashbody = strtolower(hash("SHA256", $stringBody));

    $strigSign = "POST:/api/v1.0/debit/payment-host-to-host:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
    $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

    $args = array(
        'method'  => 'POST',
        'timeout' => 45,
        'headers' => array(
            'Content-Type'   => 'application/json',
            'X-SIGNATURE'    => base64_encode($bodyHasing),
            'X-CLIENT-KEY'   => $X_CLIENT_KEY,
            'X-TIMESTAMP'    => $X_TIMESTAMP,
            'Authorization'  => "Bearer " . $access_token,
            'CHANNEL-ID'     => $channel,
            'X-EXTERNAL-ID'  => $external,
            'X-PARTNER-ID'   => $X_CLIENT_KEY
        ),
        'body'    => $stringBody,
    );

    error_log("Request body for create_registration: " . $stringBody);
    error_log("Request headers for create_registration: " . print_r($args['headers'], true));

    $response = wp_remote_post($this->api_endpoints['registration'], $args);

    if (is_wp_error($response)) {
        error_log("Error in create_registration: " . $response->get_error_message());
        throw new Exception($response->get_error_message());
    }

    $response_body = json_decode(wp_remote_retrieve_body($response), true);
    error_log("Create registration response: " . json_encode($response_body));

    if (!isset($response_body['responseCode']) || $response_body['responseCode'] !== '2005400') {
        throw new Exception(__('Failed to create registration: ' . 
            ($response_body['responseMessage'] ?? 'Unknown error'), 'nicepay-ewallet-snap-gateway'));
    } 

    return $response_body;
}
    private function get_cart_data($order) {
    $cart_data = [
        "count" => $order->get_item_count(),
        "item" => []
    ];
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        $cart_data["item"][] = [
            "img_url" => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
            "goods_name" => $item->get_name(),
            "goods_detail" => $product->get_short_description(),
            "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
            "goods_quantity" => $item->get_quantity()
        ];
    }

    return $cart_data;
    }

    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    private function check_payment_status($order, $reference_no) {
        error_log("Starting check_payment_status for reference_no: " . $reference_no);
    
        try {
            $access_token = $this->get_access_token();
            
            $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
            $secretClient = $this->get_option('client_secret');
            $X_TIMESTAMP = $this->generate_formatted_timestamp();
            $timestamp = date('YmdHis');
            $channel = $this->get_option('CHANNEL-ID');
            $external = $timestamp . rand(1000, 9999);
    
            $newBody = [
                "merchantId" => $X_CLIENT_KEY,
                "subMerchantId" => "",
                "originalPartnerReferenceNo" => $order->get_meta('_nicepay_partner_reference_no'),
                "originalReferenceNo" => $reference_no,
                "serviceCode" => "54",
                "transactionDate" => date('Y-m-d\TH:i:sP'), 
                "externalStoreId" => "",
                "amount" => [
                    "value" => number_format($order->get_total(), 2, '.', ''),
                    "currency" => $order->get_currency()
                ],
                "additionalInfo" => (object)[]
            ];
    
            $stringBody = json_encode($newBody, JSON_UNESCAPED_SLASHES);
            $hashbody = strtolower(hash("SHA256", $stringBody));
    
            error_log("Check status request body: " . $stringBody);
    
            $strigSign = "POST:/api/v1.0/debit/status:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
    
            $args = array(
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type'   => 'application/json',
                    'X-SIGNATURE'    => base64_encode($bodyHasing),
                    'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                    'X-TIMESTAMP'    => $X_TIMESTAMP,
                    'Authorization'  => "Bearer " . $access_token,
                    'CHANNEL-ID'     => $channel,
                    'X-EXTERNAL-ID'  => $external,
                    'X-PARTNER-ID'   => $X_CLIENT_KEY
                ),
                'body'    => $stringBody,
            );
    
            error_log("Check status request headers: " . print_r($args['headers'], true));
    
            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
    
            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }
    
            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            error_log("Check status response: " . json_encode($response_body));
    
            return $this->update_order_status($order, $response_body);
    
        } catch (Exception $e) {
            error_log("Error checking payment status: " . $e->getMessage());
            throw $e;
        }
    }

    private function update_order_status($order, $status_response) {
        if (!isset($status_response['responseCode'])) {
            error_log("Invalid status response: missing responseCode");
            return false;
        }
    
        // Pastikan response sukses dan ada latestTransactionStatus
        if ($status_response['responseCode'] === '2005500' && isset($status_response['latestTransactionStatus'])) {
            $transaction_status = $status_response['latestTransactionStatus'];
            $status_desc = $status_response['transactionStatusDesc'] ?? '';
    
            error_log("Updating order status. Latest Transaction Status: " . $transaction_status);
            error_log("Transaction Status Description: " . $status_desc);
    
            switch ($transaction_status) {
                case '00': // Success
                    $order->payment_complete();
                    $order->add_order_note(sprintf(
                        __('Payment successful via NICEPay. Reference: %s. Status: %s', 'nicepay-ewallet-snap-gateway'),
                        $status_response['originalReferenceNo'],
                        $status_desc
                    ));
                    return true;
    
                case '03': // Pending
                    $order->update_status('pending', sprintf(
                        __('Payment pending. Status: %s', 'nicepay-ewallet-snap-gateway'),
                        $status_desc
                    ));
                    return true;
    
                case '04': // Refund
                    $order->update_status('refunded', sprintf(
                        __('Payment refunded. Status: %s', 'nicepay-ewallet-snap-gateway'),
                        $status_desc
                    ));
                    return true;
    
                case '06': // Failed
                    $order->update_status('failed', sprintf(
                        __('Payment failed. Status: %s', 'nicepay-ewallet-snap-gateway'),
                        $status_desc
                    ));
                    return false;
    
                default:
                    error_log("Unknown transaction status code: " . $transaction_status);
                    $order->add_order_note(sprintf(
                        __('Unknown payment status received (%s). Status description: %s', 'nicepay-ewallet-snap-gateway'),
                        $transaction_status,
                        $status_desc
                    ));
                    return false;
            }
        } else {
            error_log("Invalid or unsuccessful status response: " . print_r($status_response, true));
            return false;
        }
    }
    public function check_scheduled_payment_status($order_id) {
        error_log("Running scheduled payment status check for order: " . $order_id);
        
        $order = wc_get_order($order_id);
        if (!$order) {
            error_log("Order not found: " . $order_id);
            return;
        }
    
        $reference_no = $order->get_meta('_nicepay_reference_no');
        if (empty($reference_no)) {
            error_log("No reference number found for order: " . $order_id);
            return;
        }
    
        try {
            $check_status_result = $this->check_payment_status($order, $reference_no);
            error_log("Scheduled payment status check result: " . ($check_status_result ? 'success' : 'pending/failed'));
            
            // If payment is still pending, schedule another check
            if (!$check_status_result && $order->get_status() === 'pending') {
                wp_schedule_single_event(time() + 300, 'check_nicepay_payment_status', array($order_id));
            }
        } catch (Exception $e) {
            error_log("Error in scheduled payment status check: " . $e->getMessage());
        }
    }
    
    // Register the scheduled action hook
    public function register_scheduled_hooks() {
        add_action('check_nicepay_payment_status', array($this, 'check_scheduled_payment_status'));
    }

    public function handle_return_url($order_id) {
        $order = wc_get_order($order_id);
        if (!$order || $order->get_status() !== 'pending') {
            return;
        }
    
        $reference_no = $order->get_meta('_nicepay_reference_no');
        $mitra = $order->get_meta('_nicepay_mitra');
    
        if (!empty($reference_no) && $mitra !== 'OVOE') {
            error_log("Checking payment status for order {$order_id} after redirect");
            try {
                $status_response = $this->check_payment_status($order, $reference_no);
                $this->update_order_status($order, $status_response);
            } catch (Exception $e) {
                error_log("Error checking payment status: " . $e->getMessage());
            }
        }
    }


}