=== NICEPay Payment Gateway for WooCommerce ===
Contributors: nicepay
Tags: woocommerce, payment, nicepay, checkout, redirect
Requires at least: 5.8
Tested up to: 7.0
Stable tag: 1.0.0
Requires PHP: 7.4
Requires Plugins: woocommerce
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

NICEPay payment gateway for WooCommerce with a single checkout option. Customers choose their payment method on the NICEPay payment page.

== Description ==

NICEPay for WooCommerce provides **one checkout payment method**: **Continue to Payment**.

After customers complete checkout, they are redirected to NICEPay to choose from the payment methods enabled for your merchant account (Credit Card, Virtual Account, QRIS, E-Wallet, CVS, Payloan, and more).

**Key features:**

* Single checkout gateway — All Payment Method (payMethod 00)
* WooCommerce Blocks checkout support
* Centralized admin page: **WooCommerce → NICEPay Payment Gateway**
* Payment notification validation (status, referenceNo, txId, merchantToken)
* Payment status verification via NICEPay inquiry API
* Activity logs in the **NICEPay Logs** menu
* Indonesian checkout labels for local stores

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/nicepay-payment-gateway`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Open **WooCommerce → NICEPay Payment Gateway**.
4. Configure Environment, Host, and advanced settings as needed.
5. Click **Configure** for **Continue to Payment**, then enter your **Merchant ID** and **Merchant Key** from the NICEPay dashboard.
6. Test payments in Sandbox before going to production.

== Frequently Asked Questions ==

= How do I get a Merchant ID and Merchant Key? =

Register in the NICEPay Merchant Dashboard and request API credentials (iMid / Merchant ID and Merchant Key).

= Does this support WooCommerce Blocks checkout? =

Yes. This plugin is built for WooCommerce Blocks checkout.

= Do customers choose VA, QRIS, or E-Wallet on the WooCommerce checkout page? =

No. Customers only see **Continue to Payment** on WooCommerce checkout, then choose their method on the NICEPay payment page.

= Where can I report bugs or request features? =

Contact **integration@nicepay.co.id** or open an issue in the plugin GitHub repository.

== Screenshots ==

1. NICEPay settings page in WooCommerce admin.
2. Checkout with the Continue to Payment option.
3. Payment method icons on checkout.

== Changelog ==

= 1.0.0 =
* Initial release — NICEPay All Payment Method (single checkout redirect)
* Gateway `nicepay_all` — redirect to NICEPay payment page (Direct V2, payMethod 00)
* Centralized admin: environment, host, debug, order status, credential configuration
* WooCommerce Blocks checkout UI with payment method icons
* Notification callback with validation for status, referenceNo, txId, and merchantToken (SHA256)
* Inquiry API to confirm payment before updating order status
* Log channel `all` in NICEPay Logs

== Upgrade Notice ==

= 1.0.0 =
Initial release of the NICEPay All Payment Method plugin for WooCommerce.
