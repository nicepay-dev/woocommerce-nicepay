<?php
/**
 * Plugin Name: NICEPay Payment Gateway for WooCommerce
 * Plugin URI: https://github.com/yourusername/nicepay-woocommerce
 * Description: WooCommerce payment gateway NICEPay — satu pintu checkout (All Payment Method). Pelanggan memilih metode pembayaran di halaman NICEPay.
 * Version: 1.0.0
 * Author: Nicepay
 * Author URI: https://github.com/yourusername
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: nicepay-payment-gateway
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Tested up to: 7.0
 * WC requires at least: 5.0
 * WC tested up to: 9.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'NICEPAY_PLUGIN_URL' ) ) {
	define( 'NICEPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
define( 'NICEPAY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NICEPAY_GATEWAY_ID', 'nicepay_all' );

if ( ! defined( 'NICEPAY_WC_VERSION' ) ) {
	if ( ! function_exists( 'get_file_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$nicepay_plugin_data = get_file_data(
		__FILE__,
		array( 'Version' => 'Version' ),
		'plugin'
	);
	define( 'NICEPAY_WC_VERSION', ! empty( $nicepay_plugin_data['Version'] ) ? $nicepay_plugin_data['Version'] : '1.0.0' );
}

require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-nicepay.php';
require_once NICEPAY_PLUGIN_PATH . 'includes/class-nicepay-log-manager.php';

add_action(
	'before_woocommerce_init',
	static function () {
		if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			return;
		}
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
);

/**
 * @param string $message Log message.
 * @param string $type    Log level.
 * @param string $channel Log channel.
 */
function nicepay_log( $message, $type = 'info', $channel = 'all' ) {
	if ( class_exists( 'NICEPay_Log_Manager' ) ) {
		NICEPay_Log_Manager::instance( $channel )->log( $message, $type );
	} elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( "NICEPay {$channel} {$type}: {$message}" );
	}
}

/**
 * Load gateway class files once.
 */
function nicepay_include_gateway_files() {
	static $loaded = false;
	if ( $loaded ) {
		return;
	}

	ob_start();
	$includes = NICEPAY_PLUGIN_PATH . 'includes/';
	include_once $includes . 'class-nicepay-gateway-base.php';
	include_once $includes . 'gateways/class-wc-gateway-nicepay-all.php';
	$stray = ob_get_clean();

	if ( is_string( $stray ) && '' !== $stray ) {
		nicepay_log( 'Output liar saat load gateway files dibuang (len=' . strlen( $stray ) . ')', 'error', 'all' );
	}

	$loaded = true;
}

function nicepay_is_wc_store_api_request() {
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only URI sniff for Store API buffer.
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	return ( false !== strpos( $uri, '/wp-json/wc/store/' ) )
		|| ( false !== strpos( $uri, 'rest_route=/wc/store/' ) );
}

function nicepay_store_api_buffer_start() {
	if ( nicepay_is_wc_store_api_request() ) {
		ob_start();
		nicepay_store_api_buffer_mark_active( true );
	}
}
add_action( 'plugins_loaded', 'nicepay_store_api_buffer_start', 0 );

/**
 * @param bool|null $active Whether buffer is active.
 * @return bool
 */
function nicepay_store_api_buffer_mark_active( $active = null ) {
	static $is_active = false;
	if ( null === $active ) {
		return $is_active;
	}
	$is_active = (bool) $active;
	return $is_active;
}

/**
 * @param mixed            $response Response.
 * @param WP_REST_Server   $server   Server.
 * @param WP_REST_Request  $request  Request.
 * @return mixed
 */
function nicepay_store_api_buffer_end( $response, $server, $request ) {
	unset( $server );
	$route = ( $request && method_exists( $request, 'get_route' ) ) ? $request->get_route() : '';
	if ( strpos( $route, '/wc/store/' ) === false || ! nicepay_store_api_buffer_mark_active( null ) ) {
		return $response;
	}
	if ( ob_get_level() > 0 ) {
		$stray = ob_get_clean();
		if ( is_string( $stray ) && '' !== $stray ) {
			nicepay_log( 'Output liar Store API dibuang (len=' . strlen( $stray ) . ')', 'error', 'all' );
		}
	}
	nicepay_store_api_buffer_mark_active( false );
	return $response;
}
add_filter( 'rest_post_dispatch', 'nicepay_store_api_buffer_end', PHP_INT_MAX, 3 );

/**
 * @param array $methods Gateway classes.
 * @return array
 */
function nicepay_add_payment_gateway_classes( $methods ) {
	nicepay_include_gateway_files();
	$methods[] = 'Nicepay_Gateway_All';
	return $methods;
}
add_filter( 'woocommerce_payment_gateways', 'nicepay_add_payment_gateway_classes' );

function nicepay_init_woocommerce_gateway_integration() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}
	add_action( 'wp_enqueue_scripts', 'nicepay_enqueue_payment_assets' );
	nicepay_include_gateway_files();
}
add_action( 'plugins_loaded', 'nicepay_init_woocommerce_gateway_integration', 20 );

function nicepay_bootstrap_gateway_defaults() {
	if ( ! function_exists( 'WC' ) ) {
		return;
	}
	nicepay_set_gateway_enabled( NICEPAY_GATEWAY_ID, true );
}
add_action( 'woocommerce_init', 'nicepay_bootstrap_gateway_defaults', 5 );

register_activation_hook(
	__FILE__,
	static function () {
		nicepay_set_gateway_enabled( NICEPAY_GATEWAY_ID, true );
	}
);

/**
 * @return array<string, string>
 */
function nicepay_get_gateway_settings_urls() {
	$base = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' );
	return array(
		NICEPAY_GATEWAY_ID => $base . NICEPAY_GATEWAY_ID,
	);
}

function nicepay_register_wc_submenu() {
	add_submenu_page(
		'woocommerce',
		__( 'NICEPay Payment Gateway', 'nicepay-payment-gateway' ),
		__( 'NICEPay Payment Gateway', 'nicepay-payment-gateway' ),
		'manage_woocommerce',
		'nicepay-wc-payment-methods',
		'nicepay_render_wc_payment_methods_page'
	);
}
add_action( 'admin_menu', 'nicepay_register_wc_submenu', 99 );

/**
 * Sanitize yes/no option values.
 *
 * @param mixed $value Raw value.
 * @return string
 */

function nicepay_sanitize_yes_no( $value ) {
	return ( 'yes' === $value || 1 === $value || '1' === $value || true === $value ) ? 'yes' : 'no';
}

function nicepay_handle_advanced_settings_save() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	if ( ! isset( $_POST['submit'], $_POST['nicepay_nonce'] ) ) {
		return;
	}
	check_admin_referer( 'nicepay_settings_save', 'nicepay_nonce' );
	if ( ! class_exists( 'WC_Nicepay_Admin' ) ) {
		return;
	}
	WC_Nicepay_Admin::instance()->save_settings_from_request();
	wp_safe_redirect( admin_url( 'admin.php?page=nicepay-wc-payment-methods&settings_saved=1' ) );
	exit;
}
add_action( 'load-woocommerce_page_nicepay-wc-payment-methods', 'nicepay_handle_advanced_settings_save', 5 );

/**
 * @return array<string, WC_Payment_Gateway>
 */
function nicepay_get_wc_payment_gateways() {
	if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
		return array();
	}
	return WC()->payment_gateways()->payment_gateways();
}

/**
 * @param string $gateway_id Gateway ID.
 * @return array<string, mixed>
 */
function nicepay_get_gateway_settings_array( $gateway_id ) {
	$option_key = 'woocommerce_' . $gateway_id . '_settings';
	$settings   = get_option( $option_key, null );
	if ( is_array( $settings ) ) {
		return $settings;
	}
	$gateways = nicepay_get_wc_payment_gateways();
	if ( isset( $gateways[ $gateway_id ] ) ) {
		$gateways[ $gateway_id ]->init_settings();
		return is_array( $gateways[ $gateway_id ]->settings ) ? $gateways[ $gateway_id ]->settings : array();
	}
	return array( 'enabled' => 'no' );
}

/**
 * @param string $gateway_id Gateway ID.
 * @param bool   $enabled    Enabled flag.
 * @return bool
 */
function nicepay_set_gateway_enabled( $gateway_id, $enabled ) {
	if ( ! array_key_exists( $gateway_id, nicepay_get_gateway_settings_urls() ) ) {
		return false;
	}
	$settings            = nicepay_get_gateway_settings_array( $gateway_id );
	$settings['enabled'] = $enabled ? 'yes' : 'no';
	update_option( 'woocommerce_' . $gateway_id . '_settings', $settings );
	$gateways = nicepay_get_wc_payment_gateways();
	if ( isset( $gateways[ $gateway_id ] ) ) {
		$gateways[ $gateway_id ]->settings = $settings;
		$gateways[ $gateway_id ]->enabled  = $settings['enabled'];
	}
	return true;
}

/**
 * @param string $gateway_id Gateway ID.
 * @return bool
 */
function nicepay_is_gateway_enabled( $gateway_id ) {
	$settings = nicepay_get_gateway_settings_array( $gateway_id );
	$enabled  = isset( $settings['enabled'] ) ? $settings['enabled'] : 'no';
	if ( function_exists( 'wc_string_to_bool' ) ) {
		return wc_string_to_bool( $enabled );
	}
	return 'yes' === $enabled;
}

/**
 * @return array<string, string>
 */
function nicepay_get_checkout_i18n_strings() {
	return array(
		'all_caption'     => __( 'Kartu Kredit, QRIS, E-Wallet, Virtual Account, CVS, dan lainnya.', 'nicepay-payment-gateway' ),
		'all_redirect'    => __( 'Anda akan diarahkan ke halaman pembayaran.', 'nicepay-payment-gateway' ),
		'alt_credit_card' => __( 'Kartu Kredit', 'nicepay-payment-gateway' ),
		'alt_qris'        => __( 'Pembayaran QRIS', 'nicepay-payment-gateway' ),
		'alt_ewallet'     => __( 'E-Wallet', 'nicepay-payment-gateway' ),
		'alt_virtual_account' => __( 'Virtual Account', 'nicepay-payment-gateway' ),
		'alt_cvs'         => __( 'CVS', 'nicepay-payment-gateway' ),
	);
}

/**
 * @param string $gateway_id  Gateway ID.
 * @param string $saved_title Saved title.
 * @return string
 */
function nicepay_get_checkout_gateway_title( $gateway_id, $saved_title = '' ) {
	$default = __( 'Lanjutkan Pembayaran', 'nicepay-payment-gateway' );
	$legacy  = array(
		'NICEPay All Payment Method' => $default,
		'NICEPAY All Payment Method' => $default,
	);
	$saved_title = is_string( $saved_title ) ? trim( $saved_title ) : '';
	if ( '' !== $saved_title && isset( $legacy[ $saved_title ] ) ) {
		return $legacy[ $saved_title ];
	}
	if ( '' !== $saved_title ) {
		return $saved_title;
	}
	return $default;
}

/**
 * @param string $title      Gateway title.
 * @param string $gateway_id Gateway ID.
 * @return string
 */
function nicepay_filter_checkout_gateway_title( $title, $gateway_id ) {
	if ( NICEPAY_GATEWAY_ID !== $gateway_id ) {
		return $title;
	}
	if ( ! is_checkout() && ! wp_doing_ajax() ) {
		return $title;
	}
	return nicepay_get_checkout_gateway_title( $gateway_id, $title );
}
add_filter( 'woocommerce_gateway_title', 'nicepay_filter_checkout_gateway_title', 10, 2 );

function nicepay_handle_gateway_status_toggle() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
	if ( 'nicepay-wc-payment-methods' !== $page ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$toggle     = isset( $_GET['nicepay_toggle'] ) ? sanitize_text_field( wp_unslash( $_GET['nicepay_toggle'] ) ) : '';
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$gateway_id = isset( $_GET['gateway'] ) ? sanitize_text_field( wp_unslash( $_GET['gateway'] ) ) : '';
	if ( ! $toggle || NICEPAY_GATEWAY_ID !== $gateway_id ) {
		return;
	}
	if ( ! in_array( $toggle, array( 'enable', 'disable' ), true ) ) {
		return;
	}
	check_admin_referer( 'nicepay_toggle_gateway_' . $gateway_id );
	$saved = nicepay_set_gateway_enabled( $gateway_id, 'enable' === $toggle );
	wp_safe_redirect(
		admin_url(
			'admin.php?page=nicepay-wc-payment-methods&' . ( $saved ? 'updated=1' : 'update_error=1' )
		)
	);
	exit;
}
add_action( 'load-woocommerce_page_nicepay-wc-payment-methods', 'nicepay_handle_gateway_status_toggle' );

function nicepay_register_gateway_settings_field_filters() {
	add_filter( 'woocommerce_settings_api_form_fields_' . NICEPAY_GATEWAY_ID, 'nicepay_remove_enabled_setting_field' );
}
add_action( 'woocommerce_init', 'nicepay_register_gateway_settings_field_filters' );

/**
 * @param array<string, array<string, mixed>> $fields Form fields.
 * @return array<string, array<string, mixed>>
 */
function nicepay_remove_enabled_setting_field( $fields ) {
	unset( $fields['enabled'] );
	return $fields;
}

/**
 * @return string[]
 */
function nicepay_get_managed_gateway_ids() {
	return array( NICEPAY_GATEWAY_ID );
}

function nicepay_exclude_gateways_from_wc_payments_settings_list() {
	if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
		return;
	}
	unset( WC()->payment_gateways()->payment_gateways[ NICEPAY_GATEWAY_ID ] );
}
add_action( 'woocommerce_admin_field_payment_gateways', 'nicepay_exclude_gateways_from_wc_payments_settings_list', 1 );

/**
 * @param mixed           $response Response.
 * @param WP_REST_Server  $server   Server.
 * @param WP_REST_Request $request  Request.
 * @return mixed
 */
function nicepay_filter_wc_admin_payment_providers_response( $response, $server, $request ) {
	unset( $server );
	if ( ! $request instanceof WP_REST_Request ) {
		return $response;
	}
	if ( '/wc-admin/settings/payments/providers' !== (string) $request->get_route() ) {
		return $response;
	}
	if ( ! $response instanceof WP_REST_Response ) {
		return $response;
	}
	$data = $response->get_data();
	if ( ! is_array( $data ) || empty( $data['providers'] ) || ! is_array( $data['providers'] ) ) {
		return $response;
	}
	$data['providers'] = array_values(
		array_filter(
			$data['providers'],
			static function ( $provider ) {
				$id = is_array( $provider ) && isset( $provider['id'] ) ? (string) $provider['id'] : '';
				return NICEPAY_GATEWAY_ID !== $id;
			}
		)
	);
	$response->set_data( $data );
	return $response;
}
add_filter( 'rest_post_dispatch', 'nicepay_filter_wc_admin_payment_providers_response', 10, 3 );

function nicepay_render_wc_payment_methods_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['settings_saved'] ) && '1' === $_GET['settings_saved'] ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved successfully.', 'nicepay-payment-gateway' ) . '</p></div>';
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['updated'] ) && '1' === $_GET['updated'] ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Payment method status updated.', 'nicepay-payment-gateway' ) . '</p></div>';
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['update_error'] ) && '1' === $_GET['update_error'] ) {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Could not update payment method status. Please try again.', 'nicepay-payment-gateway' ) . '</p></div>';
	}

	echo '<div class="wrap nicepay-gateway-admin">';
	if ( class_exists( 'WC_Nicepay_Admin' ) ) {
		WC_Nicepay_Admin::instance()->render_page_header();
		WC_Nicepay_Admin::instance()->render_advanced_settings_form();
	}

	$settings_url = nicepay_get_gateway_settings_urls()[ NICEPAY_GATEWAY_ID ];
	$is_enabled   = nicepay_is_gateway_enabled( NICEPAY_GATEWAY_ID );

	echo '<h2 class="title">' . esc_html__( 'Payment Method', 'nicepay-payment-gateway' ) . '</h2>';
	echo '<p>' . esc_html__( 'Checkout menggunakan satu pintu: pelanggan memilih metode pembayaran (Kartu Kredit, VA, QRIS, E-Wallet, CVS, dll.) di halaman NICEPay.', 'nicepay-payment-gateway' ) . '</p>';
	echo '<style>
		.nicepay-methods-table .nicepay-status-badge{display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:600;}
		.nicepay-methods-table .nicepay-status-enabled{background:#d1fae5;color:#065f46;}
		.nicepay-methods-table .nicepay-status-disabled{background:#f3f4f6;color:#6b7280;}
		.nicepay-methods-table tr.nicepay-row-enabled{background:#f0fdf4;}
	</style>';
	echo '<table class="widefat striped nicepay-methods-table" style="max-width:860px;"><thead><tr><th>' . esc_html__( 'Method', 'nicepay-payment-gateway' ) . '</th><th>' . esc_html__( 'Status', 'nicepay-payment-gateway' ) . '</th><th>' . esc_html__( 'Action', 'nicepay-payment-gateway' ) . '</th></tr></thead><tbody>';

	$status_html = $is_enabled
		? '<span class="nicepay-status-badge nicepay-status-enabled">' . esc_html__( 'Enabled', 'nicepay-payment-gateway' ) . '</span>'
		: '<span class="nicepay-status-badge nicepay-status-disabled">' . esc_html__( 'Disabled', 'nicepay-payment-gateway' ) . '</span>';

	echo '<tr class="' . ( $is_enabled ? 'nicepay-row-enabled' : '' ) . '">';
	echo '<td><strong>' . esc_html__( 'Lanjutkan Pembayaran', 'nicepay-payment-gateway' ) . '</strong></td>';
	echo '<td>' . wp_kses_post( $status_html ) . '</td>';
	echo '<td><a class="button button-primary" href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Configure', 'nicepay-payment-gateway' ) . '</a></td>';
	echo '</tr></tbody></table>';

	if ( class_exists( 'WC_Nicepay_Admin' ) ) {
		WC_Nicepay_Admin::instance()->render_footer_help();
	}
	echo '</div>';
}

function nicepay_enqueue_all_payment_assets() {
	if ( ! class_exists( 'Nicepay_Gateway_All' ) || ! nicepay_is_gateway_enabled( NICEPAY_GATEWAY_ID ) ) {
		return;
	}

	$all_gateway        = new Nicepay_Gateway_All();
	$file_all_blocks_js = NICEPAY_PLUGIN_PATH . 'assets/js/all-block-integration.js';
	$file_all_css       = NICEPAY_PLUGIN_PATH . 'assets/css/all.css';

	wp_enqueue_style(
		'nicepay-all-style',
		NICEPAY_PLUGIN_URL . 'assets/css/all.css',
		array(),
		file_exists( $file_all_css ) ? filemtime( $file_all_css ) : NICEPAY_WC_VERSION
	);
	wp_enqueue_script(
		'nicepay-all-blocks',
		NICEPAY_PLUGIN_URL . 'assets/js/all-block-integration.js',
		array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry' ),
		filemtime( $file_all_blocks_js ),
		true
	);
	wp_localize_script(
		'nicepay-all-blocks',
		'nicepayAllData',
		array_merge(
			nicepay_get_checkout_i18n_strings(),
			array(
				'ajax_url'    => admin_url( 'admin-ajax.php' ),
				'security'    => wp_create_nonce( 'nicepay-all-nonce' ),
				'pluginUrl'   => NICEPAY_PLUGIN_URL,
				'title'       => nicepay_get_checkout_gateway_title( NICEPAY_GATEWAY_ID, $all_gateway->get_option( 'title' ) ),
				'isAll'       => true,
				'methodIcons' => $all_gateway->get_checkout_method_icons(),
			)
		)
	);
}

function nicepay_enqueue_payment_assets() {
	if ( ! is_checkout() ) {
		return;
	}
	nicepay_enqueue_all_payment_assets();
}

add_action( 'admin_menu', 'nicepay_register_log_menu' );
function nicepay_register_log_menu() {
	add_menu_page(
		__( 'NICEPay Logs', 'nicepay-payment-gateway' ),
		__( 'NICEPay Logs', 'nicepay-payment-gateway' ),
		'manage_options',
		'nicepay-logs',
		'nicepay_logs_main_page_callback',
		'dashicons-clipboard',
		56
	);
}

function nicepay_logs_main_page_callback() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$log_manager = NICEPay_Log_Manager::instance( 'all' );

	echo '<div class="wrap"><h1>' . esc_html__( 'NICEPay Logs', 'nicepay-payment-gateway' ) . '</h1>';
	echo '<p><a href="' . esc_url( $log_manager->get_log_file_url() ) . '" class="button button-primary" download>' . esc_html__( 'Download Today\'s Log', 'nicepay-payment-gateway' ) . '</a> ';
	echo '<a href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?page=nicepay-logs&clear=true' ), 'nicepay_clear_log_all' ) ) . '" class="button">' . esc_html__( 'Clear Today\'s Log', 'nicepay-payment-gateway' ) . '</a></p>';

	$logs = $log_manager->get_logs();
	if ( empty( $logs ) ) {
		echo '<p>' . esc_html__( 'No logs found.', 'nicepay-payment-gateway' ) . '</p>';
	} else {
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Time', 'nicepay-payment-gateway' ) . '</th><th>' . esc_html__( 'Type', 'nicepay-payment-gateway' ) . '</th><th>' . esc_html__( 'Message', 'nicepay-payment-gateway' ) . '</th></tr></thead><tbody>';
		foreach ( $logs as $log ) {
			echo '<tr><td>' . esc_html( $log['time'] ) . '</td><td>' . esc_html( ucfirst( $log['type'] ) ) . '</td><td>' . esc_html( $log['message'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	$files = $log_manager->get_log_files();
	if ( ! empty( $files ) ) {
		echo '<h3>' . esc_html__( 'Previous Logs', 'nicepay-payment-gateway' ) . '</h3><ul>';
		foreach ( $files as $file ) {
			if ( $file === $log_manager->get_today_log_filename() ) {
				continue;
			}
			echo '<li><a href="' . esc_url( $log_manager->get_log_file_url( $file ) ) . '" download>' . esc_html( $file ) . '</a></li>';
		}
		echo '</ul>';
	}
	echo '</div>';
}

add_action(
	'admin_init',
	static function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page  = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$clear = isset( $_GET['clear'] ) ? sanitize_text_field( wp_unslash( $_GET['clear'] ) ) : '';
		if ( 'nicepay-logs' !== $page || 'true' !== $clear ) {
			return;
		}
		check_admin_referer( 'nicepay_clear_log_all' );
		NICEPay_Log_Manager::instance( 'all' )->clear_logs();
		wp_safe_redirect( admin_url( 'admin.php?page=nicepay-logs' ) );
		exit;
	}
);
