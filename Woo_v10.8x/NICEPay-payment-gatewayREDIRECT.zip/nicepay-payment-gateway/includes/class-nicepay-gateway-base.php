<?php
/**
 * Base class for NICEPay WooCommerce payment gateways.
 *
 * @package Nicepay_Payment_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\Internal\Admin\Settings\Utils as SettingsUtils;

/**
 * Shared behavior for all NICEPay gateways (settings URL for WC 10+ Payments UI).
 */
abstract class Nicepay_Gateway_Base extends WC_Payment_Gateway {

	/**
	 * Log channel name for nicepay_log().
	 *
	 * @return string
	 */
	protected function get_log_channel() {
		return 'all';
	}

	/**
	 * Global WooCommerce order status after successful payment.
	 *
	 * @return string
	 */
	protected function get_payment_status_setting() {
		return strtolower( get_option( 'status_order', 'processing' ) );
	}

	/**
	 * Parse NICEPay server-to-server notification body.
	 *
	 * @return array<string, mixed>
	 */
	protected function parse_notification_payload() {
		$raw_post = file_get_contents( 'php://input' );
		nicepay_log( 'Raw input: ' . $raw_post, 'info', $this->get_log_channel() );

		$data = json_decode( $raw_post, true );
		if ( ! is_array( $data ) ) {
			parse_str( $raw_post, $data );
		}
		if ( empty( $data ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- NICEPay server-to-server notification callback.
			$data = $_POST;
		}

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Resolve WooCommerce order ID from NICEPay referenceNo.
	 *
	 * @param string $reference_no NICEPay reference number.
	 * @return int
	 */
	protected function get_order_id_from_reference( $reference_no ) {
		$parts = explode( '-', trim( (string) $reference_no ) );
		return absint( $parts[0] );
	}

	/**
	 * Apply paid status to order from notification / inquiry data.
	 *
	 * @param int                  $order_id Order ID.
	 * @param array<string, mixed> $data     Payment data.
	 * @param string               $note     Order note.
	 * @return bool
	 */
	protected function apply_paid_status_from_notification( $order_id, $data, $note = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}

		if ( $order->is_paid() ) {
			nicepay_log( 'Order already paid: ' . $order_id, 'info', $this->get_log_channel() );
			return true;
		}

		$saved_txid = $order->get_meta( '_nicepay_tXid' );
		if ( ! empty( $data['tXid'] ) && ! empty( $saved_txid ) && (string) $data['tXid'] !== (string) $saved_txid ) {
			nicepay_log(
				'tXid mismatch for order ' . $order_id . ' (saved=' . $saved_txid . ', callback=' . $data['tXid'] . ')',
				'error',
				$this->get_log_channel()
			);
			return false;
		}

		if ( empty( $note ) ) {
			$note = __( 'Payment completed via NICEPay.', 'nicepay-payment-gateway' );
		}

		$payment_status = $this->get_payment_status_setting();
		if ( 'completed' === $payment_status ) {
			$order->update_status( 'completed', $note );
		} else {
			$order->update_status( 'processing', $note );
		}

		$order->set_date_paid( time() );
		$order->update_meta_data( '_nicepay_status', 'Success' );
		$order->update_meta_data( '_nicepay_status_code', '00' );
		$order->update_meta_data( '_nicepay_paid_amount', $data['amt'] ?? $order->get_total() );
		$order->update_meta_data( '_nicepay_currency', $data['currency'] ?? 'IDR' );

		$trans_dt = $data['transDt'] ?? '';
		$trans_tm = $data['transTm'] ?? '';
		if ( $trans_dt || $trans_tm ) {
			$order->update_meta_data( '_nicepay_transaction_datetime', $trans_dt . $trans_tm );
		}

		if ( ! empty( $data['tXid'] ) ) {
			$order->update_meta_data( '_nicepay_tXid', $data['tXid'] );
		}

		$order->save();

		nicepay_log( 'Order status updated to paid for order ' . $order_id, 'info', $this->get_log_channel() );

		return true;
	}

	/**
	 * Normalize amount string from NICEPay notification (IDR).
	 *
	 * @param mixed $amt Amount value.
	 * @return string
	 */
	protected function normalize_notification_amt( $amt ) {
		$amt = trim( (string) $amt );
		if ( '' === $amt ) {
			return '';
		}

		if ( is_numeric( $amt ) ) {
			return (string) (int) round( (float) $amt );
		}

		return $amt;
	}

	/**
	 * merchantToken dari payload notifikasi NICEPay (nilai asli yang dikirim server).
	 *
	 * @param array<string, mixed> $data Notification payload.
	 * @return string
	 */
	protected function get_notification_merchant_token_from_payload( $data ) {
		foreach ( array( 'merchantToken', 'merchant_token', 'MerchantToken' ) as $key ) {
			if ( isset( $data[ $key ] ) && '' !== trim( (string) $data[ $key ] ) ) {
				return strtolower( trim( (string) $data[ $key ] ) );
			}
		}
		return '';
	}

	/**
	 * iMid dari notifikasi (prioritas payload NICEPay, fallback ke pengaturan gateway).
	 *
	 * @param array<string, mixed> $data Notification payload.
	 * @return string
	 */
	protected function get_notification_imid( $data ) {
		if ( ! empty( $data['iMid'] ) ) {
			return trim( (string) $data['iMid'] );
		}
		return trim( (string) $this->get_option( 'X-CLIENT-KEY' ) );
	}

	/**
	 * txId persis dari payload notifikasi untuk perhitungan merchantToken.
	 *
	 * @param array<string, mixed> $data Notification payload.
	 * @return string
	 */
	protected function get_notification_txid_for_token( $data ) {
		foreach ( array( 'txId', 'tXid', 'txid', 'TXid' ) as $key ) {
			if ( isset( $data[ $key ] ) && '' !== trim( (string) $data[ $key ] ) ) {
				return trim( (string) $data[ $key ] );
			}
		}
		return '';
	}

	/**
	 * Amount candidates for merchantToken hash (handles "18870" vs "18870.00").
	 *
	 * @param array<string, mixed> $data  Notification payload.
	 * @param WC_Order|null        $order Optional order for saved txn amount.
	 * @return string[]
	 */
	protected function get_notification_amt_candidates( $data, $order = null ) {
		$sources = array( $data['amt'] ?? '' );
		if ( $order instanceof WC_Order ) {
			$sources[] = $order->get_meta( '_nicepay_txn_amt' );
			$sources[] = $order->get_total();
		}

		$candidates = array();
		foreach ( $sources as $source ) {
			$raw = trim( (string) $source );
			if ( '' === $raw ) {
				continue;
			}
			$candidates[] = $raw;
			if ( is_numeric( $raw ) ) {
				$candidates[] = (string) (int) round( (float) $raw );
				$candidates[] = number_format( (float) $raw, 2, '.', '' );
				if ( function_exists( 'wc_format_decimal' ) ) {
					$candidates[] = wc_format_decimal( $raw, wc_get_price_decimals() );
				}
			}
		}

		return array_values( array_unique( array_filter( $candidates ) ) );
	}

	/**
	 * Build merchantToken for Notification API Checkout.
	 *
	 * Formula: SHA256( iMid + txId + amt + merchantKey )
	 *
	 * @param string $i_mid        Merchant ID.
	 * @param string $tx_id        Transaction ID.
	 * @param string $amt          Amount.
	 * @param string $merchant_key Merchant key.
	 * @return string
	 */
	protected function build_notification_merchant_token( $i_mid, $tx_id, $amt, $merchant_key ) {
		return hash( 'sha256', (string) $i_mid . (string) $tx_id . (string) $amt . (string) $merchant_key );
	}

	/**
	 * Verify merchantToken: nilai dari NICEPay harus sama dengan hash yang dihitung ulang.
	 *
	 * Formula: SHA256( iMid + txId + amt + merchantKey )
	 *
	 * @param array<string, mixed> $data  Notification payload.
	 * @param WC_Order|null        $order Order (untuk kandidat amt tersimpan).
	 * @return true|WP_Error
	 */
	protected function validate_notification_merchant_token( $data, $order = null ) {
		$channel = $this->get_log_channel();

		$received = $this->get_notification_merchant_token_from_payload( $data );
		if ( '' === $received ) {
			nicepay_log( 'Notification rejected: merchantToken not sent by NICEPay', 'error', $channel );
			return new WP_Error(
				'missing_merchant_token',
				__( 'Notification rejected: merchantToken not sent by NICEPay.', 'nicepay-payment-gateway' )
			);
		}

		$i_mid        = $this->get_notification_imid( $data );
		$merchant_key = trim( (string) $this->get_option( 'merchant_key' ) );
		$tx_id        = $this->get_notification_txid_for_token( $data );

		if ( '' === $i_mid || '' === $merchant_key || '' === $tx_id ) {
			nicepay_log( 'Notification rejected: incomplete data for merchantToken verification', 'error', $channel );
			return new WP_Error(
				'invalid_merchant_token_context',
				__( 'Notification rejected: incomplete data for merchantToken verification.', 'nicepay-payment-gateway' )
			);
		}

		$configured_imid = trim( (string) $this->get_option( 'X-CLIENT-KEY' ) );
		if ( '' !== $configured_imid && $i_mid !== $configured_imid ) {
			nicepay_log( 'Notification rejected: iMid mismatch (callback=' . $i_mid . ', configured=' . $configured_imid . ')', 'error', $channel );
			return new WP_Error(
				'invalid_imid',
				__( 'Notification rejected: invalid iMid.', 'nicepay-payment-gateway' )
			);
		}

		$amt_candidates = $this->get_notification_amt_candidates( $data, $order );
		if ( empty( $amt_candidates ) ) {
			nicepay_log( 'Notification rejected: missing amt for merchantToken verification', 'error', $channel );
			return new WP_Error(
				'missing_amt',
				__( 'Notification rejected: missing amt.', 'nicepay-payment-gateway' )
			);
		}

		foreach ( $amt_candidates as $amt ) {
			$expected = strtolower( $this->build_notification_merchant_token( $i_mid, $tx_id, $amt, $merchant_key ) );
			if ( hash_equals( $expected, $received ) ) {
				nicepay_log(
					'Notification merchantToken match (iMid=' . $i_mid . ', txId=' . $tx_id . ', amt=' . $amt . ')',
					'info',
					$channel
				);
				return true;
			}
		}

		$expected_sample = strtolower(
			$this->build_notification_merchant_token( $i_mid, $tx_id, $amt_candidates[0], $merchant_key )
		);
		nicepay_log(
			'Notification rejected: merchantToken mismatch (received=' . $received . ', expected=' . $expected_sample . ', iMid=' . $i_mid . ', txId=' . $tx_id . ', amt=' . $amt_candidates[0] . ')',
			'error',
			$channel
		);

		return new WP_Error(
			'invalid_merchant_token',
			__( 'Notification rejected: merchantToken does not match NICEPay signature.', 'nicepay-payment-gateway' )
		);
	}

	/**
	 * Validasi payload notifikasi Direct V2 sebelum inquiry API.
	 *
	 * @param WC_Order              $order Order WooCommerce.
	 * @param array<string, mixed>  $data  Data callback NICEPay.
	 * @param bool                  $require_callback_status Require callback status === '0'.
	 * @return true|WP_Error
	 */
	protected function validate_notification_payload( $order, $data, $require_callback_status = true ) {
		$order_id = $order->get_id();
		$channel  = $this->get_log_channel();

		if ( $order->get_payment_method() !== $this->id ) {
			nicepay_log( 'Notification rejected: payment method mismatch for order ' . $order_id, 'error', $channel );
			return new WP_Error( 'invalid_payment_method', __( 'Notification rejected: invalid payment method.', 'nicepay-payment-gateway' ) );
		}

		if ( $require_callback_status ) {
			if ( ! isset( $data['status'] ) || (string) $data['status'] !== '0' ) {
				$status = isset( $data['status'] ) ? (string) $data['status'] : 'missing';
				nicepay_log( 'Notification rejected: invalid status (' . $status . ') for order ' . $order_id, 'error', $channel );
				return new WP_Error( 'invalid_status', __( 'Notification rejected: invalid status.', 'nicepay-payment-gateway' ) );
			}
		}

		$callback_ref = trim( (string) ( $data['referenceNo'] ?? '' ) );
		$saved_ref    = trim( (string) $order->get_meta( '_nicepay_reference_no' ) );
		$expected_ref = '' !== $saved_ref ? $saved_ref : (string) $order_id;

		if ( '' === $callback_ref || $callback_ref !== $expected_ref ) {
			nicepay_log(
				'Notification rejected: referenceNo mismatch for order ' . $order_id . ' (expected=' . $expected_ref . ', callback=' . $callback_ref . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_reference', __( 'Notification rejected: invalid referenceNo.', 'nicepay-payment-gateway' ) );
		}

		$callback_txid = $this->get_notification_txid( $data );
		$saved_txid    = trim( (string) $order->get_meta( '_nicepay_tXid' ) );

		if ( '' === $callback_txid || '' === $saved_txid || $callback_txid !== $saved_txid ) {
			nicepay_log(
				'Notification rejected: tXid mismatch for order ' . $order_id . ' (expected=' . $saved_txid . ', callback=' . $callback_txid . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_txid', __( 'Notification rejected: invalid tXid.', 'nicepay-payment-gateway' ) );
		}

		$token_validation = $this->validate_notification_merchant_token( $data, $order );
		if ( is_wp_error( $token_validation ) ) {
			return $token_validation;
		}

		return true;
	}

	/**
	 * Normalize transaction ID from Direct V2 / return URL payload.
	 *
	 * @param array<string, mixed> $data Callback data.
	 * @return string
	 */
	protected function get_notification_txid( $data ) {
		return $this->get_notification_txid_for_token( $data );
	}

	/**
	 * Validasi payload notifikasi SNAP sebelum inquiry API.
	 *
	 * @param WC_Order              $order Order WooCommerce.
	 * @param array<string, mixed>  $data  Data callback NICEPay SNAP.
	 * @return true|WP_Error
	 */
	protected function validate_snap_notification_payload( $order, $data ) {
		$order_id = $order->get_id();
		$channel  = $this->get_log_channel();

		if ( $order->get_payment_method() !== $this->id ) {
			nicepay_log( 'SNAP notification rejected: payment method mismatch for order ' . $order_id, 'error', $channel );
			return new WP_Error( 'invalid_payment_method', __( 'Notification rejected: invalid payment method.', 'nicepay-payment-gateway' ) );
		}

		$callback_ref = trim(
			(string) (
				$data['originalPartnerReferenceNo']
				?? $data['trxId']
				?? ''
			)
		);
		$saved_ref    = trim( (string) $order->get_meta( '_nicepay_reference_no' ) );
		$expected_ref = '' !== $saved_ref ? $saved_ref : (string) $order_id;

		if ( '' === $callback_ref || $callback_ref !== $expected_ref ) {
			nicepay_log(
				'SNAP notification rejected: reference mismatch for order ' . $order_id . ' (expected=' . $expected_ref . ', callback=' . $callback_ref . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_reference', __( 'Notification rejected: invalid reference.', 'nicepay-payment-gateway' ) );
		}

		$callback_txid = trim(
			(string) (
				$data['originalReferenceNo']
				?? $data['paymentRequestId']
				?? ''
			)
		);
		$saved_txid    = trim( (string) $order->get_meta( '_nicepay_tXid' ) );

		if ( '' === $callback_txid || '' === $saved_txid || $callback_txid !== $saved_txid ) {
			nicepay_log(
				'SNAP notification rejected: tXid mismatch for order ' . $order_id . ' (expected=' . $saved_txid . ', callback=' . $callback_txid . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_txid', __( 'Notification rejected: invalid tXid.', 'nicepay-payment-gateway' ) );
		}

		return true;
	}

	/**
	 * Handle Direct V2 dbProcessUrl notification from NICEPay.
	 */
	protected function handle_direct_v2_notification() {
		nicepay_log( 'NICEPay callback received. Starting processing...', 'info', $this->get_log_channel() );
		status_header( 200 );

		$data = $this->parse_notification_payload();
		nicepay_log( 'Processed callback data: ' . wp_json_encode( $data ), 'info', $this->get_log_channel() );

		if ( empty( $data['referenceNo'] ) ) {
			nicepay_log( 'Missing referenceNo in callback', 'error', $this->get_log_channel() );
			wp_send_json_error( 'Invalid callback', 400 );
		}

		$order_id = $this->get_order_id_from_reference( $data['referenceNo'] );
		$order    = wc_get_order( $order_id );

		if ( ! $order ) {
			nicepay_log( 'Order not found for referenceNo: ' . $order_id, 'error', $this->get_log_channel() );
			wp_send_json_error( 'Order not found', 404 );
		}

		$validation = $this->validate_notification_payload( $order, $data );
		if ( is_wp_error( $validation ) ) {
			wp_send_json_error(
				array(
					'message' => $validation->get_error_message(),
				),
				400
			);
		}

		nicepay_log( 'Order found: ' . $order_id . ' — verifying via inquiry API', 'info', $this->get_log_channel() );
		$this->check_payment_status_directv2( $order_id, $data );

		wp_send_json( array( 'status' => 'received' ), 200 );
		exit;
	}

	/**
	 * Verify payment via NICEPay inquiry API. Override in gateway class.
	 *
	 * @param int                  $order_id Order ID.
	 * @param array<string, mixed> $data     Callback data.
	 */
	protected function check_payment_status_directv2( $order_id, $data ) {
		// Implemented in concrete gateway classes.
	}

	/**
	 * Settings page URL (classic section — works even when the main Payments list is React-only).
	 *
	 * @return string
	 */
	public function get_settings_url() {
		return SettingsUtils::wc_payments_settings_url(
			null,
			array(
				'section' => $this->id,
			)
		);
	}
}
