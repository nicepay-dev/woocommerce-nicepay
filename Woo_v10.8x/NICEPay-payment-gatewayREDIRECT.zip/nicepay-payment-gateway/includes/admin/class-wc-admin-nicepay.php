<?php

/**
 * NICEPay Admin — global settings rendered on WooCommerce > NICEPay Payment Gateway.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Admin class uses Nicepay prefix in filename.
class WC_Nicepay_Admin
{
    /**
     * @var WC_Nicepay_Admin|null
     */
    private static $instance = null;

    /**
     * @return WC_Nicepay_Admin
     */
    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('admin_init', array($this, 'redirect_legacy_settings_page'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
    }

    /**
     * Redirect old top-level menu URL to the unified settings page.
     */
    public function redirect_legacy_settings_page()
    {
        if (!is_admin()) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect guard.
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        if ('nicepay-settings' === $page) {
            wp_safe_redirect(admin_url('admin.php?page=nicepay-wc-payment-methods'));
            exit;
        }
    }

    /**
     * Initialize admin settings
     */
    public function admin_init()
    {
        register_setting('nicepay_settings', 'nicepay_debug_mode', array(
            'sanitize_callback' => 'nicepay_sanitize_yes_no',
        ));
        register_setting('nicepay_settings', 'nicepay_reduce_stock', array(
            'sanitize_callback' => 'nicepay_sanitize_yes_no',
        ));
        register_setting('nicepay_settings', 'nicepay_environment', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_host', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
    }

    /**
     * Enqueue admin scripts
     *
     * @param string $hook Current admin page hook.
     */
    public function admin_scripts($hook)
    {
        if ('woocommerce_page_nicepay-wc-payment-methods' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'nicepay-admin-style',
            plugins_url('assets/css/admin.css', dirname(dirname(__FILE__))),
            array(),
            defined('NICEPAY_WC_VERSION') ? NICEPAY_WC_VERSION : '1.0.0'
        );
    }

    /**
     * Save global NICEPay settings from POST request.
     */
    public function save_settings_from_request()
    {
        check_admin_referer('nicepay_settings_save', 'nicepay_nonce');

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified; fields sanitized below.
        $post = wp_unslash($_POST);

        $debug_mode   = isset($post['nicepay_debug_mode']) ? 'yes' : 'no';
        $reduce_stock = isset($post['nicepay_reduce_stock']) ? 'yes' : 'no';

        $environment = isset($post['nicepay_environment']) ? sanitize_text_field($post['nicepay_environment']) : 'sandbox';
        $host        = isset($post['nicepay_host']) ? sanitize_text_field($post['nicepay_host']) : 'cloud';
        $status      = isset($post['status_order']) ? sanitize_text_field($post['status_order']) : 'Processing';

        update_option('nicepay_debug_mode', $debug_mode);
        update_option('nicepay_reduce_stock', $reduce_stock);
        update_option('nicepay_environment', $environment);
        update_option('nicepay_host', $host);
        update_option('status_order', $status);
    }

    /**
     * Render page header block.
     */
    public function render_page_header()
    {
        ?>
        <div class="nicepay-header">
            <div class="nicepay-logo">
                <img src="<?php echo esc_url(plugins_url('assets/images/logo-nicepay.jpg', dirname(dirname(__FILE__)))); ?>" alt="NICEPay" />
            </div>
            <div class="nicepay-info">
                <h1><?php esc_html_e('NICEPay Payment Gateway', 'nicepay-payment-gateway'); ?></h1>
                <p class="nicepay-version">
                    <?php esc_html_e('Version', 'nicepay-payment-gateway'); ?>
                    <?php echo esc_html(defined('NICEPAY_WC_VERSION') ? NICEPAY_WC_VERSION : '1.0.0'); ?>
                </p>
            </div>
        </div>

        <div class="nicepay-description">
            <p><?php esc_html_e('Configure your NICEPay environment here. Merchant credentials are set via Configure for Lanjutkan Pembayaran below.', 'nicepay-payment-gateway'); ?></p>

            <?php if (!$this->check_credentials()) : ?>
                <div class="notice notice-warning inline">
                    <p>
                        <strong><?php esc_html_e('Credentials not configured!', 'nicepay-payment-gateway'); ?></strong>
                        <?php esc_html_e('Please configure Merchant ID and Merchant Key via Configure.', 'nicepay-payment-gateway'); ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render advanced settings form.
     */
    public function render_advanced_settings_form()
    {
        $debug_mode   = get_option('nicepay_debug_mode', 'no');
        $reduce_stock = get_option('nicepay_reduce_stock', 'no');
        $host         = get_option('nicepay_host', 'cloud');
        $status       = get_option('status_order', 'Processing');
        $environment  = get_option('nicepay_environment', 'sandbox');
        ?>
        <form method="post" action="">
            <?php wp_nonce_field('nicepay_settings_save', 'nicepay_nonce'); ?>

            <h2 class="title"><?php esc_html_e('Advanced Settings', 'nicepay-payment-gateway'); ?></h2>

            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_environment"><?php esc_html_e('Environment', 'nicepay-payment-gateway'); ?></label>
                        </th>
                        <td>
                            <select name="nicepay_environment" id="nicepay_environment">
                                <option value="sandbox" <?php selected($environment, 'sandbox'); ?>><?php esc_html_e('Sandbox', 'nicepay-payment-gateway'); ?></option>
                                <option value="production" <?php selected($environment, 'production'); ?>><?php esc_html_e('Production', 'nicepay-payment-gateway'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Select the NICEPay environment.', 'nicepay-payment-gateway'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_host"><?php esc_html_e('Host', 'nicepay-payment-gateway'); ?></label>
                        </th>
                        <td>
                            <select name="nicepay_host" id="nicepay_host">
                                <option value="cloud" <?php selected($host, 'cloud'); ?>><?php esc_html_e('Cloud', 'nicepay-payment-gateway'); ?></option>
                                <option value="premise" <?php selected($host, 'premise'); ?>><?php esc_html_e('Premise', 'nicepay-payment-gateway'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Select the NICEPay host.', 'nicepay-payment-gateway'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_debug_mode"><?php esc_html_e('Debug Mode', 'nicepay-payment-gateway'); ?></label>
                        </th>
                        <td>
                            <label for="nicepay_debug_mode">
                                <input type="checkbox" id="nicepay_debug_mode" name="nicepay_debug_mode" value="yes" <?php checked($debug_mode, 'yes'); ?> />
                                <?php esc_html_e('Enable debug mode (logging)', 'nicepay-payment-gateway'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Log debug messages for troubleshooting. Only enable when needed.', 'nicepay-payment-gateway'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="status_order"><?php esc_html_e('Status', 'nicepay-payment-gateway'); ?></label>
                        </th>
                        <td>
                            <select name="status_order" id="status_order">
                                <option value="Completed" <?php selected($status, 'Completed'); ?>><?php esc_html_e('Completed', 'nicepay-payment-gateway'); ?></option>
                                <option value="Processing" <?php selected($status, 'Processing'); ?>><?php esc_html_e('Processing', 'nicepay-payment-gateway'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Automatic Status after Payment.', 'nicepay-payment-gateway'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_reduce_stock"><?php esc_html_e('Reduce Stock', 'nicepay-payment-gateway'); ?></label>
                        </th>
                        <td>
                            <label for="nicepay_reduce_stock">
                                <input type="checkbox" id="nicepay_reduce_stock" name="nicepay_reduce_stock" value="yes" <?php checked($reduce_stock, 'yes'); ?> />
                                <?php esc_html_e('Reduce stock levels when order is placed', 'nicepay-payment-gateway'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Reduce stock when payment is initiated rather than when completed.', 'nicepay-payment-gateway'); ?></p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <?php submit_button(__('Save Changes', 'nicepay-payment-gateway')); ?>
        </form>
        <?php
    }

    /**
     * Render footer help block.
     */
    public function render_footer_help()
    {
        ?>
        <div class="nicepay-footer">
            <h3><?php esc_html_e('Need Help?', 'nicepay-payment-gateway'); ?></h3>
            <p><?php esc_html_e('For technical support or questions about NICEPay integration:', 'nicepay-payment-gateway'); ?></p>
            <ul>
                <li><a href="https://docs.nicepay.co.id" target="_blank" rel="noopener noreferrer"><?php esc_html_e('NICEPay Documentation', 'nicepay-payment-gateway'); ?></a></li>
                <li><a href="mailto:technical.support@nicepay.co.id"><?php esc_html_e('Technical Support', 'nicepay-payment-gateway'); ?></a></li>
            </ul>
        </div>
        <?php
    }

    /**
     * Check if credentials are configured
     *
     * @return bool
     */
    private function check_credentials()
    {
        $all_settings = get_option( 'woocommerce_nicepay_all_settings', array() );
        return ! empty( $all_settings['X-CLIENT-KEY'] ) && ! empty( $all_settings['merchant_key'] );
    }
}

WC_Nicepay_Admin::instance();
