(function () {

    console.log("Loading NICEPay All Payment Method Plugin");



    document.addEventListener('DOMContentLoaded', function () {

        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {

            console.log('Initializing All Payment Method');

            initNicepayAll();

        } else {

            console.error('Required dependencies not available for All Payment Method');

        }

    });



    function initNicepayAll() {

        if (window.nicepay_all_registered === true) {

            return;

        }



        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;

        const { createElement, Fragment } = window.wp.element;



        const data = window.nicepayAllData || {};

        const label = data.title || 'NICEPay All Payment Method';

        const iconsBase = (data.pluginUrl || '') + '/assets/images/';

        const methodIcons = data.methodIcons || [

            { file: 'ccL.png', alt: 'Credit Card' },

            { file: 'qrL.png', alt: 'QRIS' },

            { file: 'ewalletL.png', alt: 'E-Wallet' },

            { file: 'vaL.png', alt: 'Virtual Account' },

            { file: 'cvsL.png', alt: 'CVS' },

        ];



        const NicepayAllComponent = () => {

            return createElement(Fragment, null,

                createElement('div', { className: 'nicepay-all-container' },

                    createElement('div', { className: 'nicepay-all-header' },

                        createElement('div', { className: 'nicepay-all-icons' },

                            methodIcons.map(function (icon) {

                                return createElement('img', {

                                    key: icon.file,

                                    src: iconsBase + icon.file,

                                    alt: icon.alt || '',

                                    className: 'nicepay-all-icon',

                                    onError: function (e) {

                                        e.target.style.display = 'none';

                                    }

                                });

                            })

                        )

                    ),

                    createElement('p', { className: 'nicepay-all-methods-caption' },

                        'Credit Card, QRIS, E-Wallet, and more.'

                    ),

                    createElement('p', null,

                        'You will be directed to the payment page.'

                    )

                )

            );

        };



        registerPaymentMethod({

            name: 'nicepay_all',

            label: label,

            content: createElement(NicepayAllComponent),

            edit: createElement(NicepayAllComponent),

            canMakePayment: () => true,

            ariaLabel: 'NICEPay All Payment Method',

            supports: { features: ['products'] }

        });



        window.nicepay_all_registered = true;

        console.log('All Payment Method registered');

    }

})();

