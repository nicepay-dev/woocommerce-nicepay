jQuery(function ($) {
    console.log('NICEPay Ewallet classic checkout initialized');

    const nicepayData = window.nicepayEwalletClassicData || {};

    const config = {
        paymentMethod: 'nicepay_ewallet',
        storageKey: 'nicepay_selected_mitra'
    };

    function showError(message) {
        let container = $('.nicepay-ewallet-container');
        if (!container.length) {
            container = $('li.payment_method_' + config.paymentMethod);
        }
        let errorDiv = container.find('.nicepay-ewallet-error');
        if (!errorDiv.length) {
            errorDiv = $('<div/>', {
                class: 'nicepay-ewallet-error',
                style: 'color:red;margin-top:10px;'
            }).appendTo(container);
        }
        errorDiv.text(message).show();
        setTimeout(function () { errorDiv.fadeOut(); }, 5000);
    }

    function clearError() {
        $('.nicepay-ewallet-error').stop(true, true).hide().text('');
    }

    function normalizeAjaxResponse(res, xhr) {
        if (res && typeof res === 'object') {
            return res;
        }

        // Be tolerant: some WordPress stacks can return string body.
        if (typeof res === 'string') {
            try {
                return JSON.parse(res);
            } catch (e) {
                if (res.indexOf('"success":true') !== -1) {
                    return { success: true, data: res };
                }
            }
        }

        if (xhr && typeof xhr.responseText === 'string') {
            try {
                return JSON.parse(xhr.responseText);
            } catch (e) {
                if (xhr.responseText.indexOf('"success":true') !== -1) {
                    return { success: true, data: xhr.responseText };
                }
            }
        }

        return { success: false, data: 'Invalid AJAX response format' };
    }

    function saveMitra(selectedMitra) {
        if (!selectedMitra) return;
        if (!nicepayData.ajax_url || !nicepayData.nonce) {
            console.error('Missing ewallet AJAX config:', nicepayData);
            showError('Konfigurasi e-wallet belum siap. Refresh halaman lalu coba lagi.');
            return;
        }

        const select = $('#nicepay_mitra').prop('disabled', true);

        $.post(nicepayData.ajax_url, {
            action: 'set_nicepay_mitra',
            mitra_code: selectedMitra,
            nonce: nicepayData.nonce
        }).done(function (res) {
            const parsed = normalizeAjaxResponse(res);
            if (parsed.success) {
                sessionStorage.setItem(config.storageKey, selectedMitra);
                clearError();
                console.log('Ewallet mitra saved:', parsed.data);
            } else {
                console.error('Failed to save mitra:', parsed.data);
                showError(parsed.data || 'Gagal menyimpan pilihan e-wallet');
            }
        }).fail(function (xhr, status, error) {
            const parsed = normalizeAjaxResponse(null, xhr);
            if (parsed.success) {
                sessionStorage.setItem(config.storageKey, selectedMitra);
                clearError();
                console.log('Ewallet mitra saved (from xhr.responseText):', parsed.data);
                return;
            }

            console.error('AJAX error saving mitra:', error);
            showError('Gagal menyimpan pilihan e-wallet');
        }).always(function () {
            select.prop('disabled', false);
        });
    }

    function initClassic() {
        console.log('Initializing ewallet classic mode');

        const methodInput = $('input[name="payment_method"][value="' + config.paymentMethod + '"]');
        if (!methodInput.length) {
            console.log('Ewallet payment method not found:', config.paymentMethod);
            return;
        }

        // Restore saved mitra jika ada
        const saved = sessionStorage.getItem(config.storageKey);
        if (saved) {
            console.log('Restoring saved ewallet mitra:', saved);
            $('#nicepay_mitra').val(saved).trigger('change');
        }

        // Event handler untuk perubahan dropdown
        $('#nicepay_mitra').off('change.nicepayEwallet').on('change.nicepayEwallet', function () {
            const val = $(this).val();
            console.log('Ewallet mitra selected:', val);
            if (val) {
                saveMitra(val);
            } else {
                sessionStorage.removeItem(config.storageKey);
            }
        });
    }

    // Validasi sebelum submit untuk metode nicepay_ewallet
    $('form.checkout').on('checkout_place_order_' + config.paymentMethod, function () {
        console.log('Validating ewallet before checkout');
        const selected = $('#nicepay_mitra').val();
        console.log('Selected ewallet mitra on submit:', selected);

        if (!selected) {
            showError('Silakan pilih e-wallet untuk pembayaran');
            if ($('#nicepay_mitra').length) {
                $('html, body').animate({
                    scrollTop: $('#nicepay_mitra').offset().top - 100
                }, 500);
            }
            return false;
        }

        // Pastikan nilai dikirim via POST
        $('input[name="nicepay_mitra"]').remove();
        $('<input>', {
            type: 'hidden',
            name: 'nicepay_mitra',
            value: selected
        }).appendTo('form.checkout');

        console.log('Ewallet checkout validation passed');
        return true;
    });

    // Init saat halaman ready
    initClassic();

    // Reinit tiap checkout di-refresh / payment method diganti
    $(document.body).on('updated_checkout payment_method_selected', function () {
        initClassic();
    });
});