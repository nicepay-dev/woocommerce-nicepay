<?php
if (!defined('ABSPATH')) exit;
class Nicepay_Gateway_Payloan extends Nicepay_Gateway_Base {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;
    private static $thankyou_displayed = array();
    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_payloan';
        $this->method_title       = __('NICEPAY Payloan', 'nicepay-payment-gateway-for-woocommerce');
        $this->has_fields         = false;
        $this->icon               = apply_filters( 'nicepay_gateway_payloan_icon', '' );
        $this->method_description = __('Allows payments using NICEPAY Payloan like akulaku, indodana, and kredivo.', 'nicepay-payment-gateway-for-woocommerce');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        
        // $this->api_endpoints = $this->get_api_endpoints();

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set
        $this->api_endpoints = $this->get_api_endpoints();
        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_payloan', array($this, 'handle_callback'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-payloan-container {
                margin: 12px 0;
                padding: 12px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-payloan-header {
                margin-bottom: 8px;
                text-align: left;
                padding: 4px 0;
            }
            .nicepay-payloan-image,
            .nicepay-payloan-icon {
                display: block;
                max-width: 140px;
                width: auto;
                height: auto;
                margin: 0;
            }
            .nicepay-payloan-select {
                margin: 10px 0;
            }
            .nicepay-payloan-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-payloan-logos {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                gap: 15px;
                margin-bottom: 12px;
            }
            .nicepay-payloan-logos img {
                height: 30px;
                width: auto;
            }
            .nicepay-payloan-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-payloan-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/payloan-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-classic-checkout',
            'nicepayData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'enabled_mitra' => $this->get_payloan_options(),
                'nonce' => wp_create_nonce('nicepay-payloan-nonce')
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');
        $this->init_form_fields();
        $this->init_settings();
    
        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-payloan-style',
            NICEPAY_PLUGIN_URL . '/assets/css/payloan.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-payloan-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-payloan-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/payloan-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-payloan-blocks-integration',
            'nicepaypayloanData',
            array(
                'enabled_mitra' => $this->get_payloan_options(),
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('nicepay-payloan-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'ispayloan' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        
        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/debit/payment-host-to-host',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/debit/status',
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'paymentDirectV2'       => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }
        /**
         * Get global payment status setting dari admin panel
         */

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPAY Payloan Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'no'
            ),
            'title' => array(
                'title'       => __('Title', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __('NICEPAY Payloan', 'nicepay-payment-gateway-for-woocommerce'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __('Pay with payloan via NICEPAY (akulaku, indodana, kredivo)', 'nicepay-payment-gateway-for-woocommerce'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-payment-gateway-for-woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'IONPAYTEST',
            ),
            // 'CHANNEL-ID' => array(
            //     'title' => __('Channel ID', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type' => 'text',
            //     'description' => __('<small>Isikan dengan Channel ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
            //     'default' => '',
            // ),
            // 'client_secret' => array(
            //     'title'       => __('Client Key', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type'        => 'text',
            //     'description' => __('Enter your NICEPAY Client Key.', 'nicepay-payment-gateway-for-woocommerce'),
            //     //'default'     => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            // 'private_key' => array(
            //     'title'       => __('Private Key', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type'        => 'textarea',
            //     'description' => __('Enter your NICEPAY Private Key.', 'nicepay-payment-gateway-for-woocommerce'),
            //     //'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'mitra_options' => array(
                'title'       => __('payloan Options', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'title',
                'description' => __('Select which payloans you want to enable.', 'nicepay-payment-gateway-for-woocommerce'),
            ),
            'enable_akulaku' => array(
                'title'   => __('Akulaku', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable Akulaku Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
            'enable_indodana' => array(
                'title'   => __('Indodana', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable Indodana Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
            'enable_kredivo' => array(
                'title'   => __('Kredivo', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable Kredivo Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
        );
    }

    public function payment_fields()
{
    echo '<div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">';
    echo '<img src="' . esc_url(NICEPAY_PLUGIN_URL . '/assets/images/ccL.png') . '" alt="Payloan" style="height: 24px; width: auto;">';
    
    if (!empty($this->description)) {
        echo '<span>' . wp_kses_post($this->description) . '</span>';
    }
    echo '</div>';
    
    $payloan_options = $this->get_payloan_options();
    
    if (!empty($payloan_options)) {
        echo '<div class="nicepay-payloan-container">';
        echo '<div class="nicepay-payloan-select">';
        echo '<label for="nicepay_mitra">' . __('Select Payloan Provider:', 'nicepay-payment-gateway-for-woocommerce') . '</label>';
        echo '<select name="nicepay_mitra" id="nicepay_mitra" required>';
        echo '<option value="">' . __('-- Choose Provider --', 'nicepay-payment-gateway-for-woocommerce') . '</option>';
        
        foreach ($payloan_options as $option) {
            $selected = (WC()->session && WC()->session->get('nicepay_selected_payloan_mitra') === $option['value']) ? 'selected' : '';
            echo '<option value="' . esc_attr($option['value']) . '" ' . $selected . '>' . esc_html(ucfirst($option['label'])) . '</option>';
        }
        
         echo '</select>';
        echo '</div>';
        echo '</div>';
    } else {
        echo '<p class="woocommerce-error">' . __('No payloan providers available. Please contact support.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
    }
}

    /**
     * Get available payloan options
     */
    public function get_payloan_options() {
        $available_options = array();

        if ($this->get_option('enable_akulaku') === 'yes') {
            $available_options[] = array('value' => 'AKLP', 'label' => 'AKULAKU');
        }
        if ($this->get_option('enable_indodana') === 'yes') {
            $available_options[] = array('value' => 'IDNA', 'label' => 'INDODANA');
        }
        if ($this->get_option('enable_kredivo') === 'yes') {
            $available_options[] = array('value' => 'KDVI', 'label' => 'KREDIVO');
        }
        return $available_options;
    }

    /**
     * Handle the Ajax request to set the selected mitra
     */
    public function set_nicepay_payloan_mitra() {
        nicepay_log("AJAX set_nicepay_payloan_mitra called", 'info', 'payloan');
    
    check_ajax_referer('nicepay-payloan-nonce', 'nonce');
    
    if (!isset($_POST['mitra_code'])) {
        nicepay_log("Mitra code not provided", 'error', 'payloan');
        wp_send_json_error('Mitra not specified');
    }

    $mitra = sanitize_text_field( wp_unslash( $_POST['mitra_code'] ) );
    WC()->session->set('nicepay_selected_payloan_mitra', $mitra);
    
    nicepay_log("Mitra saved to session: " . $mitra, 'info', 'payloan');
    
    wp_send_json_success('Mitra selection saved: ' . $mitra);
}

    public function is_available() {
        $is_available = ('yes' === $this->enabled);
        if ('yes' !== $this->enabled) {
            return false;
        }

        if ($is_available) {
            $available_mitra = $this->get_payloan_options();
            if (empty($available_mitra)) {
                return false;
            }
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment payloan for order $order_id", 'info', 'payloan');

        return $this->process_blocks_payment($order_id);
    }

    /**
     * Process payment for classic checkout
     */
    public function process_classic_payment($order_id) {
        nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'payloan');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'payloan');
        $order->save();

        $selected_mitra = WC()->session->get( 'nicepay_selected_payloan_mitra' );
        if ( empty( $selected_mitra ) && isset( $_POST['nicepay_mitra'] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified by WooCommerce checkout.
            $selected_mitra = sanitize_text_field( wp_unslash( $_POST['nicepay_mitra'] ) );
        }
        if ( ! empty( $selected_mitra ) ) {
            WC()->session->set( 'nicepay_selected_payloan_mitra', $selected_mitra );
        }
        nicepay_log("Selected mitra from POST/session: " . $selected_mitra, 'info', 'payloan');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an payloan payment method.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        $order->update_meta_data('_nicepay_mitra_code', $selected_mitra);
        $order->save();

        try {
            $payloanRegis_data = $this->process_directV2($order_id);
            if (!is_array($payloanRegis_data) || !isset($payloanRegis_data['resultCd']) || $payloanRegis_data['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create payloan transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($payloanRegis_data['resultMsg'] ?? 'Unknown error'));
            }

            $paymentUrl = $this->process_paymentV2($order_id, $payloanRegis_data);
            if (!is_string($paymentUrl) || $paymentUrl === '') {
                throw new Exception(__('Invalid payment redirect URL.', 'nicepay-payment-gateway-for-woocommerce'));
            }

            WC()->cart->empty_cart();

            return array(
                'result'   => 'success',
                'redirect' => $paymentUrl,
            );
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log('Payment error in process_classic_payment: ' . $e->getMessage(), 'error', 'payloan');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order $order_id", 'info', 'payloan');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'payloan');
        $order->save();

        $selected_mitra = WC()->session->get( 'nicepay_selected_payloan_mitra' );
        if ( empty( $selected_mitra ) && isset( $_POST['nicepay_mitra'] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified by WooCommerce checkout.
            $selected_mitra = sanitize_text_field( wp_unslash( $_POST['nicepay_mitra'] ) );
        }
        if ( ! empty( $selected_mitra ) ) {
            WC()->session->set( 'nicepay_selected_payloan_mitra', $selected_mitra );
        }
        nicepay_log("Selected mitra from POST/session: " . $selected_mitra, 'info', 'payloan');

        if (empty($selected_mitra)) {
        wc_add_notice(__('Please select a payloan payment method.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }
        $order->update_meta_data('_nicepay_mitra_code', $selected_mitra);
        $order->save();

        try {
            $payloanRegis_data = $this->process_directV2($order_id);

            if (!is_array($payloanRegis_data) || !isset($payloanRegis_data['resultCd']) || $payloanRegis_data['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create payloan transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($payloanRegis_data['resultMsg'] ?? 'Unknown error'));
            }

            $paymentUrl = $this->process_paymentV2($order_id, $payloanRegis_data);
            if (!is_string($paymentUrl) || $paymentUrl === '') {
                throw new Exception(__('Invalid payment redirect URL.', 'nicepay-payment-gateway-for-woocommerce'));
            }

            WC()->cart->empty_cart();

            return array(
                'result'   => 'success',
                'redirect' => $paymentUrl,
            );
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log('Payment error in process_blocks_payment: ' . $e->getMessage(), 'error', 'payloan');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'payloan');

        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $reqDt = date('Ymd');
            $reqTm = date('His');

            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int) $order->get_total();
            // $amount = 100000;
            $referenceNo = $order->get_id();
            $mitraCd = WC()->session->get('nicepay_selected_payloan_mitra', '');

            if (empty($mitraCd)) {
                throw new Exception(__('No payloan selected. Please choose a payloan payment method.', 'nicepay-payment-gateway-for-woocommerce'));
            }

            // Generate merchant token
            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);
            $cart_data = $this->prepare_cart_data($order);
            $sellers_data = [[
                "sellersId" => "STORE",
                "sellersNm" => "STORESHOP",
                "sellersUrl" => "http://nicestore.store/product/beanie/",
                "sellersEmail" => "sellers@test.com",
                "sellersAddress" => [
                    "sellerNm" => "STORESHOP",
                    "sellerLastNm" => "STORESHOP",
                    "sellerAddr" => "Jln. Kasablanka Kav 88",
                    "sellerCity" => "Jakarta",
                    "sellerPostCd" => "14350",
                    "sellerPhone" => "082111111111",
                    "sellerCountry" => "ID"
                ]
            ]];

            // Request body lengkap
            $requestBody = [
                "timeStamp" => $timestamp,
                "iMid" => $iMid,
                "payMethod" => "06",
                "currency" => "IDR",
                "mitraCd" => $mitraCd,
                "amt" => (string) $amount,
                "referenceNo" => $referenceNo,
                "goodsNm" => $this->get_order_items_names($order),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $order->get_billing_phone(),
                // "billingPhone" => "081234567890",
                "billingEmail" => $order->get_billing_email(),
                "billingAddr" => $order->get_billing_address_1(),
                "billingCity" => $order->get_billing_city(),
                "billingState" => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "deliveryNm" => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
                "deliveryPhone" => $order->get_billing_phone(),
                // "deliveryPhone" => "081234567890",
                "deliveryAddr" => $order->get_shipping_address_1() ?: $order->get_billing_address_1(),
                "deliveryCity" => $order->get_shipping_city() ?: $order->get_billing_city(),
                "deliveryState" => $order->get_shipping_state() ?: $order->get_billing_state(),
                "deliveryPostCd" => $order->get_shipping_postcode() ?: $order->get_billing_postcode(),
                "deliveryCountry" => $order->get_shipping_country() ?: $order->get_billing_country(),
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_payloan'),
                "vat" => "",
                "fee" => "",
                "notaxAmt" => "",
                "description" => "Testing API payloan - " . get_bloginfo('name'),
                "merchantToken" => $merchantToken,
                "reqDt" => $reqDt,
                "reqTm" => $reqTm,
                "reqDomain" => $_SERVER['HTTP_HOST'],
                "reqServerIP" => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
                "reqClientVer" => "",
                "userIP" => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "userSessionID" => session_id(),
                "userAgent" => $_SERVER['HTTP_USER_AGENT'] ?? '',
                "userLanguage" => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
                "cartData" => $cart_data,
                "sellers" => json_encode($sellers_data, JSON_UNESCAPED_SLASHES),
                "instmntType" => "1",
                "instmntMon" => "1",
                "recurrOpt" => "0",
                "bankCd" => "",
                "vacctValidDt" => "",
                "vacctValidTm" => "",
                "merFixAcctId" => "",
                "payValidDt" => date('Ymd', strtotime('+1 day')),
                "payValidTm" => "235959"
            ];

            $args = [
                'method' => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("Payloan Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'payloan');
            nicepay_log("Payloan Request Body: " . json_encode($requestBody, JSON_UNESCAPED_SLASHES), 'info', 'payloan');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("Payloan Response: " . json_encode($response_body), 'info', 'payloan');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create payloan transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($response_body['resultMsg'] ?? 'Unknown error'));
            }

            // translators: 1: reference number, 2: transaction ID, 3: transaction amount.
            $order->add_order_note( sprintf(
                __( "NICEPay Payloan. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s\nTransaction Amount: %3\$s", 'nicepay-payment-gateway-for-woocommerce' ),
                $response_body['referenceNo'],
                $response_body['tXid'],
                $response_body['amt']
            ) );

             // Save important meta
            $order->update_meta_data('_nicepay_tXid', $response_body['tXid'] ?? '');
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo'] ?? '');
            $order->save();
            
            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'payloan');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }

        return $response_body;
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => "http://merchant.com/cellphones/iphone5s_64g",
                //get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => "http://merchant.com/cellphones/iphone5s_64g",
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => "http://merchant.com/cellphones/iphone5s_64g",
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    public function process_paymentV2($order_id, $response_regis) {
        nicepay_log("Starting process_paymentV2", 'info', 'payloan');
        try {
            $order = wc_get_order($order_id);
            $timestamp     = date('YmdHis');
            $iMid          = $this->get_option('X-CLIENT-KEY');
            $merchantKey   = $this->get_option('merchant_key');
            $amount        = (int) $order->get_total();
            $referenceNo   = $response_regis['referenceNo'];

            if($response_regis['mitraCd'] === 'IDNA'){
                $callBackUrl = $this->get_return_url($order);
            } else {
                $callBackUrl = $this->get_return_url($order);
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            $paymentUrl = $this->api_endpoints['paymentDirectV2'] . '?' . http_build_query([
                'timeStamp'     => $timestamp,
                'tXid'          => $response_regis['tXid'],
                'merchantToken' => $merchantToken,
                'callBackUrl'   => $callBackUrl,
            ]);

            nicepay_log("Redirecting user to: " . $paymentUrl, 'info', 'payloan');

            return $paymentUrl;
        } catch (Exception $e) {
            nicepay_log('Payment error in process_paymentV2: ' . $e->getMessage(), 'error', 'payloan');
            throw $e;
        }
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_callback() {
        nicepay_log('NICEPay callback received. Starting processing...', 'info', 'payloan');
        status_header(200);

        $decoded_post = $this->parse_notification_payload();

        if (empty($decoded_post) && !empty($_GET)) {
            $decoded_post = wp_unslash($_GET);
            nicepay_log('Using GET parameters for payloan callback', 'info', 'payloan');
        }

        nicepay_log('Processed callback data: ' . wp_json_encode($decoded_post), 'info', 'payloan');

        $headers   = function_exists('getallheaders') ? getallheaders() : array();
        $signature = is_array($headers) ? ($headers['X-SIGNATURE'] ?? null) : null;

        // Redirect dari halaman pembayaran NICEPay (user browser).
        if (isset($decoded_post['resultCd']) && empty($signature) && empty($decoded_post['merchantToken'])) {
            nicepay_log('Handle redirect from payment page', 'info', 'payloan');

            if (empty($decoded_post['referenceNo'])) {
                wp_die('Invalid callback', 'Invalid Callback', array('response' => 400));
            }

            $order_id = $this->get_order_id_from_reference($decoded_post['referenceNo']);
            $order    = wc_get_order($order_id);

            if (!$order) {
                nicepay_log('Order not found for referenceNo: ' . $decoded_post['referenceNo'], 'error', 'payloan');
                wp_die('Order not found', 'Order Not Found', array('response' => 404));
            }

            if ($decoded_post['resultCd'] === '0000') {
                $validation = $this->validate_notification_payload($order, $decoded_post, false);
                if (is_wp_error($validation)) {
                    nicepay_log('Payloan return validation failed: ' . $validation->get_error_message(), 'error', 'payloan');
                } else {
                    $this->check_payment_status_directv2($order_id, $decoded_post);
                }
            } else {
                $order->update_status('failed', 'Payment failed: ' . ($decoded_post['resultMsg'] ?? 'Unknown error'));
                $order->update_meta_data('_nicepay_error_message', $decoded_post['resultMsg'] ?? 'Unknown error');
                $order->save();
            }

            wp_safe_redirect($this->get_return_url($order));
            exit;
        }

        // Notifikasi server Direct V2 (dbProcessUrl).
        if (!empty($decoded_post['merchantToken']) && !empty($decoded_post['referenceNo'])) {
            if (empty($decoded_post['referenceNo'])) {
                wp_send_json_error('Invalid callback', 400);
            }

            $order_id = $this->get_order_id_from_reference($decoded_post['referenceNo']);
            $order    = wc_get_order($order_id);

            if (!$order) {
                nicepay_log('Order not found for referenceNo: ' . $order_id, 'error', 'payloan');
                wp_send_json_error('Order not found', 404);
            }

            $validation = $this->validate_notification_payload($order, $decoded_post);
            if (is_wp_error($validation)) {
                wp_send_json_error(
                    array(
                        'message' => $validation->get_error_message(),
                    ),
                    400
                );
            }

            nicepay_log('Order found: ' . $order_id . ' — verifying via inquiry API', 'info', 'payloan');
            $this->check_payment_status_directv2($order_id, $decoded_post);

            wp_send_json(array('status' => 'received'), 200);
            exit;
        }

        nicepay_log('No matching callback condition, returning 200', 'info', 'payloan');
        status_header(200);
        exit;
    }

    /**
    * Check payment status with NICEPAY
    */
    protected function check_payment_status_directv2($order_id, $decoded_post) {
        nicepay_log("(Direct V2) Starting check_payment_status_directv2 for reference_no: " . $decoded_post['referenceNo'] , 'info', 'payloan');
        
        $order = wc_get_order($order_id);

        if (!$order) {
        nicepay_log("Order not found: " . $order_id, 'error', 'payloan');
        return false;
    }

    // ✅ Cek apakah order sudah dibayar sebelumnya
    if ($order->is_paid()) {
        nicepay_log("Order already paid: " . $order_id, 'info', 'payloan');
        return true;
    }

        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $tXid = $decoded_post['tXid'];
        $referenceNo = $decoded_post['referenceNo'];
        $amount = $decoded_post['amt'];
        $merchantKey = $this->get_option('merchant_key');

        if (empty($tXid) || empty($referenceNo) || empty($amount)) {
        nicepay_log("Missing required parameters for status check", 'error', 'payloan');
        return false;
    }
        nicepay_log("Status check params - tXid: $tXid, refNo: $referenceNo, amt: $amount", 'info', 'payloan');

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("Payloan Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'payloan');
        nicepay_log("Payloan Request Body: " . json_encode($requestBody), 'info', 'payloan');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
        nicepay_log("HTTP Request failed: " . $response->get_error_message(), 'error', 'payloan');
        return false;
    }

         $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("Status check response: " . json_encode($response_body), 'info', 'payloan');

        if (!isset($response_body['resultCd'])) {
        nicepay_log("Invalid response from status check", 'error', 'payloan');
        return false;
        }

        if ($response_body['resultCd'] === '0000' && isset($response_body['status'])) {
        
        if ($response_body['status'] == '0') {
            // ✅ Payment SUCCESS
            nicepay_log("Payment successful for order: " . $order_id, 'info', 'payloan');
            
            $payment_status = $this->get_payment_status_setting();
            
            // ✅ Update meta SEBELUM mengubah status
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency'] ?? 'IDR');
            $order->update_meta_data('_nicepay_transaction_datetime', ($response_body['transDt'] ?? '') . ($response_body['transTm'] ?? ''));
            
            if ($payment_status === 'completed') {
                $order->payment_complete($tXid);
                $order->update_status('completed', __('Payloan payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce'));
            } else {
                $order->payment_complete($tXid);
                $order->update_status('processing', __('Payloan payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce'));
            }
            
            $order->save();

            nicepay_log('Order payment completed and meta updated for order ' . $order_id, 'info', 'payloan');
            return true;
            
        } else if ($response_body['status'] == '3') {
            // ✅ Payment PENDING
            nicepay_log("Payment pending for order: " . $order_id, 'info', 'payloan');
            $order->update_status('on-hold', __('Payloan payment is pending.', 'nicepay-payment-gateway-for-woocommerce'));
            $order->update_meta_data('_nicepay_status', 'Pending');
            $order->save();
            return false;
            
        } else if ($response_body['status'] == '8') {
            // ✅ Payment FAILED
            nicepay_log("Payment failed for order: " . $order_id, 'error', 'payloan');
            $order->update_status('failed', __('Payloan payment failed: ' . ($response_body['resultMsg'] ?? 'Unknown error'), 'nicepay-payment-gateway-for-woocommerce'));
            $order->update_meta_data('_nicepay_status', 'Failed');
            $order->update_meta_data('_nicepay_error_message', $response_body['resultMsg'] ?? 'Unknown error');
            $order->save();
            return false;
        }
    } else {
        nicepay_log("Status check failed: " . ($response_body['resultMsg'] ?? 'Unknown error'), 'error', 'payloan');
        $order->update_meta_data('_nicepay_error_message', $response_body['resultMsg'] ?? 'Unknown error');
        $order->save();
        return false;
    }
    
    return false;
}

    /**
     * Handle return URL after payment
     */
    public function thankyou_page($order_id) {
    if (isset(self::$thankyou_displayed[$order_id])) {
        nicepay_log("Thank you page already displayed for order: " . $order_id, 'info', 'payloan');
        return;
    }
    self::$thankyou_displayed[$order_id] = true;
    nicepay_log("Starting thankyou_page" .$order_id,'info','payloan');
    $order = wc_get_order($order_id);
    
     if (!$order) {
        nicepay_log("Order not found: " . $order_id, 'error', 'payloan');
        return;
    }

     if ($order->get_payment_method() !== $this->id) {
        nicepay_log("Payment method mismatch for order: " . $order_id, 'info', 'payloan');
        return;
    }
    
    // Get transaction data
    $txid = $order->get_meta('_nicepay_tXid');
    $reference_no = $order->get_meta('_nicepay_reference_no');
    $amount = $order->get_meta('_nicepay_paid_amount');
    $status = $order->get_meta('_nicepay_status');
    $status_code = $order->get_meta('_nicepay_status_code');
    $payment_method = $order->get_meta('_nicepay_payment_method');
    $transaction_date = $order->get_meta('_nicepay_transaction_datetime');
    
    if (empty($amount)) {
        $amount = $order->get_total();
    }
    // Check apakah pembayaran sukses atau gagal
    $is_success = ($status === 'Success' || $status_code === '00' || $order->is_paid());
    
    // Format tanggal
    if ($transaction_date) {
        $date = DateTime::createFromFormat('YmdHis', $transaction_date);
        $formatted_date = $date ? $date->format('d M Y, H:i:s') : date('d M Y, H:i:s');
    } else {
        $formatted_date = date('d M Y, H:i:s');
    }
    
    // Payment method name
   $payment_method_name = 'Payloan';
    $mitra_code = $order->get_meta('_nicepay_mitra_code');
    if ($mitra_code === 'KDVI') {
        $payment_method_name = 'Kredivo';
    } elseif ($mitra_code === 'AKLP') {
        $payment_method_name = 'Akulaku';
    } elseif ($mitra_code === 'IDNA') {
        $payment_method_name = 'Indodana';
    }
    ?>
    <style>
        .nicepay-thankyou-container {
            max-width: 800px;
            margin: 30px auto;
            padding: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nicepay-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
            margin-bottom: 30px;
        }
        
        .nicepay-logo {
            background: #00b4d8;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 18px;
        }
        
        .nicepay-status-badge {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .nicepay-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            position: relative;
        }
        
        .nicepay-icon.success {
            background: #4ade80;
        }
        
        .nicepay-icon.success::after {
            content: "✓";
            color: white;
            font-size: 32px;
            font-weight: bold;
        }
        
        .nicepay-icon.failed {
            background: #ef4444;
        }
        
        .nicepay-icon.failed::before,
        .nicepay-icon.failed::after {
            content: "";
            position: absolute;
            width: 30px;
            height: 3px;
            background: white;
            border-radius: 2px;
        }
        
        .nicepay-icon.failed::before {
            transform: rotate(45deg);
        }
        
        .nicepay-icon.failed::after {
            transform: rotate(-45deg);
        }
        
        .nicepay-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }
        
        .nicepay-amount {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .nicepay-amount.success {
            color: #00b4d8;
        }
        
        .nicepay-amount.failed {
            color: #ef4444;
        }
        
        .nicepay-date {
            color: #666;
            font-size: 14px;
        }
        
        .nicepay-error-msg {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
            padding: 12px 16px;
            border-radius: 6px;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .nicepay-detail-section {
            margin-top: 30px;
        }
        
        .nicepay-detail-header {
            color: #666;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .nicepay-detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .nicepay-detail-row:last-child {
            border-bottom: none;
        }
        
        .nicepay-label {
            color: #666;
            font-size: 14px;
        }
        
        .nicepay-value {
            color: #333;
            font-weight: 500;
            text-align: right;
            font-size: 14px;
        }
        
        .nicepay-payment-icon {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .nicepay-visa-badge {
            background: #1a1f71;
            color: white;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .nicepay-footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            color: #999;
            font-size: 12px;
        }
    </style>
    
    <div class="nicepay-thankyou-container">
        <!-- Header -->
        <div class="nicepay-header">
            <div class="nicepay-logo">NICEPAY</div>
            <div style="color: #666;">🌐 Bahasa Indonesia</div>
        </div>
        
        <!-- Status Badge -->
        <div class="nicepay-status-badge">
            <div class="nicepay-icon <?php echo $is_success ? 'success' : 'failed'; ?>"></div>
            <h2 class="nicepay-title">
                <?php echo $is_success ? 'Pembayaran Sukses!' : 'Pembayaran Gagal!'; ?>
            </h2>
            <div class="nicepay-amount <?php echo $is_success ? 'success' : 'failed'; ?>">
                Rp<?php echo number_format($amount ?: $order->get_total(), 0, ',', '.'); ?>
            </div>
            
            <?php if (!$is_success): ?>
            <div class="nicepay-error-msg">
                <?php 
                $error_msg = $order->get_meta('_nicepay_error_message');
                echo $error_msg ? esc_html($error_msg) : 'Transaksi gagal diproses. Silakan coba lagi atau hubungi customer service.';
                ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="nicepay-footer">
            Powered by <strong>NICEPAY</strong>
        </div>
    </div>
    <?php
}
}