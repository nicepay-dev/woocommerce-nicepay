<?php
if (!defined('ABSPATH')) exit;

/**
 * NICEPay "All Payment Method" gateway.
 *
 * Memakai skema redirect yang sama dengan Credit Card (redirect/v2/registration),
 * namun dengan payMethod = "00" sehingga halaman pembayaran NICEPay menampilkan
 * SEMUA metode pembayaran yang aktif (CC, Virtual Account, CVS, E-Wallet, Payloan,
 * QRIS, dll). Pelanggan memilih metode di halaman NICEPay.
 */
class Nicepay_Gateway_All extends Nicepay_Gateway_Base {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;
    private static $thankyou_displayed = array();

    public function __construct() {
        $this->id                 = 'nicepay_all';
        $this->icon               = apply_filters('nicepay_gateway_all_icon', '');
        $this->has_fields         = false;
        $this->method_title       = __('NICEPay All Payment Method', 'nicepay-payment-gateway-for-woocommerce');
        $this->method_description = __('Allows payments using all available NICEPay payment methods (Credit Card, Virtual Account, E-Wallet, QRIS, etc.) via a single redirect page.', 'nicepay-payment-gateway-for-woocommerce');

        $this->supports = [
            'products',
            'refunds',
        ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment  = get_option('nicepay_environment', 'sandbox');
        $this->host         = get_option('nicepay_host', 'premise');

        $this->api_endpoints = $this->get_api_endpoints();

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_nicepay_return', array($this, 'handle_return_url'));
        add_action('woocommerce_api_wc_gateway_nicepay_all', array($this, 'handle_notification'));
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');

        wp_enqueue_style(
            'nicepay-all-style',
            NICEPAY_PLUGIN_URL . '/assets/css/all.css',
            [],
            $version
        );

        if (!wp_script_is('nicepay-all-blocks-integration', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-all-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/all-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        wp_localize_script(
            'nicepay-all-blocks-integration',
            'nicepayAllData',
            array(
                'ajax_url'  => admin_url('admin-ajax.php'),
                'security'  => wp_create_nonce('nicepay-all-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'title'     => $this->title ?: __('NICEPay All Payment Method', 'nicepay-payment-gateway-for-woocommerce'),
                'isAll'     => true,
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment   = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() {
        $isProduction = $this->environment === 'production';
        $isCloud      = $this->host === 'cloud';

        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }

        return [
            'registrationRedirectV2'    => $base_url . '/nicepay/redirect/v2/registration',
            'paymentDirectV2'           => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url . '/nicepay/direct/v2/inquiry',
        ];
    }

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPay All Payment Method', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'no',
            ),
            'title' => array(
                'title'       => __('Title', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __('NICEPay All Payment Method', 'nicepay-payment-gateway-for-woocommerce'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __('Choose your preferred payment method (Credit Card, Virtual Account, E-Wallet, QRIS, and more) on the secure NICEPay page.', 'nicepay-payment-gateway-for-woocommerce'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title'       => __('Merchant ID', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => 'TESTMPGS05',
            ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
        );
    }

    public function get_checkout_method_icons() {
        return array(
            array( 'file' => 'ccL.png', 'alt' => __( 'Credit Card', 'nicepay-payment-gateway-for-woocommerce' ) ),
            array( 'file' => 'qrL.png', 'alt' => __( 'QRIS', 'nicepay-payment-gateway-for-woocommerce' ) ),
            array( 'file' => 'ewalletL.png', 'alt' => __( 'E-Wallet', 'nicepay-payment-gateway-for-woocommerce' ) ),
            array( 'file' => 'vaL.png', 'alt' => __( 'Virtual Account', 'nicepay-payment-gateway-for-woocommerce' ) ),
            array( 'file' => 'cvsL.png', 'alt' => __( 'CVS', 'nicepay-payment-gateway-for-woocommerce' ) ),
        );
    }

    private function render_checkout_method_icons() {
        echo '<div class="nicepay-all-icons">';
        foreach ( $this->get_checkout_method_icons() as $icon ) {
            echo '<img src="' . esc_url( NICEPAY_PLUGIN_URL . '/assets/images/' . $icon['file'] ) . '" alt="' . esc_attr( $icon['alt'] ) . '" class="nicepay-all-icon" />';
        }
        echo '</div>';
    }

    public function payment_fields() {
        echo '<div class="nicepay-all-container">';
        echo '<div class="nicepay-all-header">';
        $this->render_checkout_method_icons();
        echo '</div>';
        echo '<p class="nicepay-all-methods-caption">' . esc_html__('Credit Card, QRIS, E-Wallet, and more.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';

        if (!empty($this->description)) {
            echo '<p>' . wp_kses_post($this->description) . '</p>';
        }

        echo '</div>';
    }

    /**
     * Process the payment (entry point for both classic & blocks checkout)
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment all for order $order_id", 'info', 'all');

        return $this->process_blocks_payment($order_id);
    }

    /**
     * Process payment: register transaksi ke NICEPay lalu arahkan ke halaman order-pay
     * internal (same-origin) yang kompatibel dengan WooCommerce Blocks. Forward ke NICEPay
     * dilakukan dari receipt_page().
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order " . $order_id, 'info', 'all');

        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'all');
        $order->save();

        try {
            $paymentUrl = $this->process_redirectV2($order_id);
            if (!is_string($paymentUrl) || $paymentUrl === '') {
                $err = (is_array($paymentUrl) && !empty($paymentUrl['resultMsg'])) ? $paymentUrl['resultMsg'] : 'Unknown error';
                throw new Exception(__('Failed to create transaction: ', 'nicepay-payment-gateway-for-woocommerce') . $err);
            }

            $result = [
                'result'   => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            ];
            nicepay_log("process_blocks_payment RETURN: " . wp_json_encode($result) . " | nicepay_url=" . $paymentUrl, 'info', 'all');

            return $result;
        } catch (Exception $e) {
            nicepay_log("Payment error in process_blocks_payment: " . $e->getMessage(), 'error', 'all');
            throw $e;
        }
    }

    /**
     * Register transaksi ke NICEPay (redirect/v2). payMethod "00" = semua metode aktif.
     *
     * @return string|array URL pembayaran NICEPay jika sukses, atau array error.
     */
    public function process_redirectV2($order_id) {
        nicepay_log("Starting process_redirectV2 for order $order_id", 'info', 'all');
        try {
            $order = wc_get_order($order_id);

            $timestamp   = date('YmdHis');
            $iMid        = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount      = (string) $order->get_total();
            $referenceNo = $order->get_id();
            $return_url  = add_query_arg(array(
                'wc-api'   => 'nicepay_return',
                'order_id' => $order->get_id(),
                'key'      => $order->get_order_key(),
            ), home_url('/'));

            nicepay_log("Return URL (for user): " . $return_url, 'info', 'all');

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            $cart_data = $this->prepare_cart_data($order);

            $sellers = [[
                "sellersId"      => "SEL123",
                "sellersNm"      => "WooCommerce Seller",
                "sellersEmail"   => get_option('admin_email'),
                "sellersAddress" => [
                    "sellerNm"      => "Woo",
                    "sellerLastNm"  => "Commerce",
                    "sellerAddr"    => "Merchant Address",
                    "sellerCity"    => "Jakarta",
                    "sellerPostCd"  => "12345",
                    "sellerPhone"   => "08123456789",
                    "sellerCountry" => "Indonesia",
                ],
            ]];

            $requestBody = [
                "timeStamp"       => $timestamp,
                "iMid"            => $iMid,
                "payMethod"       => "00", // 00 = tampilkan semua metode pembayaran
                "currency"        => "IDR",
                "amt"             => $amount,
                "referenceNo"     => $referenceNo,
                "merchantToken"   => $merchantToken,
                "reqDt"           => date('Ymd'),
                "reqTm"           => date('His'),
                "goodsNm"         => $order->get_formatted_billing_full_name(),
                "billingNm"       => $order->get_formatted_billing_full_name(),
                "billingPhone"    => $order->get_billing_phone(),
                "billingEmail"    => $order->get_billing_email(),
                "billingAddr"     => $order->get_billing_address_1(),
                "billingCity"     => $order->get_billing_city(),
                "billingState"    => $order->get_billing_state(),
                "billingCountry"  => $order->get_billing_country(),
                "billingPostCd"   => $order->get_billing_postcode(),
                "description"     => "Payment for WooCommerce order #{$order_id}",
                "callBackUrl"     => $return_url,
                "dbProcessUrl"    => home_url('/wc-api/wc_gateway_nicepay_all'),
                "userIP"          => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "cartData"        => $cart_data,
                "sellers"         => json_encode($sellers, JSON_UNESCAPED_SLASHES),
                "deliveryNm"      => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
                "deliveryPhone"   => $order->get_billing_phone(),
                "deliveryAddr"    => $order->get_shipping_address_1(),
                "deliveryCity"    => $order->get_shipping_city(),
                "deliveryState"   => $order->get_shipping_state(),
                "deliveryCountry" => $order->get_shipping_country(),
                "deliveryPostCd"  => $order->get_shipping_postcode(),
                "mitraCd"         => "",
                "recurrOpt"       => "",
                "userLanguage"    => "en",
                "userAgent"       => $_SERVER['HTTP_USER_AGENT'] ?? 'nicepay-payment-gateway-for-woocommerce',
            ];

            $args = [
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'body'    => json_encode($requestBody, JSON_UNESCAPED_SLASHES),
            ];

            nicepay_log("Request to " . $this->api_endpoints['registrationRedirectV2'], 'info', 'all');
            nicepay_log("Request Body: " . json_encode($requestBody), 'info', 'all');

            $response = wp_remote_post($this->api_endpoints['registrationRedirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("Response: " . json_encode($response_body), 'info', 'all');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($response_body['resultMsg'] ?? 'Unknown error'));
            }

            if (!isset($response_body['paymentURL'])) {
                throw new Exception(__('Failed to create transaction: payment URL missing.', 'nicepay-payment-gateway-for-woocommerce'));
            }

            nicepay_log("Final callBackUrl sent to NICEPay: " . $return_url, 'info', 'all');

            // translators: 1: reference number, 2: transaction ID, 3: transaction amount.
            $order->add_order_note(sprintf(
                __("NICEPay All Payment Method. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s\nTransaction Amount: %3\$s", 'nicepay-payment-gateway-for-woocommerce'),
                $response_body['referenceNo'],
                $response_body['tXid'],
                $response_body['amt']
            ));

            $paymentUrl = $response_body['paymentURL'] . '?' . http_build_query([
                'tXid' => $response_body['tXid'],
            ]);

            $order->update_meta_data('_nicepay_tXid', $response_body['tXid']);
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo']);
            $order->update_meta_data('_nicepay_txn_amt', $response_body['amt']);
            $order->update_meta_data('_nicepay_payment_url', $paymentUrl);
            $order->save();

            nicepay_log("paymentUrl: " . $paymentUrl, 'info', 'all');

            return $paymentUrl;

        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_redirectV2: " . $e->getMessage(), 'error', 'all');
            return [
                'resultCd'  => '9999',
                'resultMsg' => $e->getMessage(),
            ];
        }
    }

    /**
     * Build cartData payload for NICEPay.
     */
    private function prepare_cart_data($order) {
        $cart_items       = array();
        $calculated_total = 0;
        $order_total      = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($order->get_items() as $item) {
            $product    = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', ''));

            $cart_items[] = array(
                'goods_id'           => $product ? ($product->get_sku() ?: $product->get_id()) : 'ITEM',
                'goods_detail'       => $product ? substr(strip_tags($product->get_description()), 0, 50) : '',
                'goods_name'         => $item->get_name(),
                'goods_amt'          => (string) $unit_price,
                'goods_type'         => $product ? $product->get_type() : 'simple',
                'goods_url'          => $product ? get_permalink($product->get_id()) : '',
                'goods_quantity'     => $item->get_quantity(),
                'goods_sellers_id'   => 'STORE',
                'goods_sellers_name' => get_bloginfo('name'),
            );
            $calculated_total += ($unit_price * $item->get_quantity());
        }

        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[]    = array(
                'goods_id'           => 'SHIPPING',
                'goods_detail'       => 'Delivery Fee',
                'goods_name'         => 'Shipping Cost',
                'goods_amt'          => (string) $shipping_amount,
                'goods_type'         => 'shipping',
                'goods_url'          => '',
                'goods_quantity'     => 1,
                'goods_sellers_id'   => 'STORE',
                'goods_sellers_name' => get_bloginfo('name'),
            );
            $calculated_total += $shipping_amount;
        }

        $tax_difference = $order_total - $calculated_total;
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id'           => 'TAX',
                'goods_detail'       => 'Tax',
                'goods_name'         => 'Tax',
                'goods_amt'          => (string) $tax_difference,
                'goods_type'         => 'tax',
                'goods_url'          => '',
                'goods_quantity'     => 1,
                'goods_sellers_id'   => 'STORE',
                'goods_sellers_name' => get_bloginfo('name'),
            );
        }

        return json_encode(array(
            'count' => count($cart_items),
            'item'  => $cart_items,
        ));
    }

    /**
     * Halaman receipt (order-pay): forward pelanggan ke halaman pembayaran NICEPay.
     */
    public function receipt_page($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $payment_url = $order->get_meta('_nicepay_payment_url');
        if (empty($payment_url)) {
            nicepay_log("receipt_page: _nicepay_payment_url kosong untuk order {$order_id}", 'error', 'all');
            echo '<p>' . esc_html__('Payment link is not available. Please contact support.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
            return;
        }

        nicepay_log("receipt_page: forwarding order {$order_id} ke NICEPay: {$payment_url}", 'info', 'all');

        $payment_url_js = esc_url_raw($payment_url);
        ?>
        <div class="nicepay-all-redirect" style="text-align:center; padding:24px 12px;">
            <p style="font-size:15px; margin-bottom:8px;">
                <?php esc_html_e('Redirecting you to the secure NICEPay payment page...', 'nicepay-payment-gateway-for-woocommerce'); ?>
            </p>
            <p style="color:#666; font-size:13px;">
                <?php
                printf(
                    /* translators: %s: manual payment link */
                    esc_html__('If you are not redirected automatically, %s.', 'nicepay-payment-gateway-for-woocommerce'),
                    '<a href="' . esc_url($payment_url) . '">' . esc_html__('click here to continue', 'nicepay-payment-gateway-for-woocommerce') . '</a>'
                );
                ?>
            </p>
        </div>
        <script type="text/javascript">
            window.location.href = <?php echo wp_json_encode($payment_url_js); ?>;
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_attr($payment_url); ?>">
        </noscript>
        <?php
    }

    /**
     * Return URL handler (pelanggan kembali dari NICEPay) → arahkan ke halaman order received.
     */
    public function handle_return_url() {
        try {
            $order_id = isset($_GET['order_id']) ? sanitize_text_field(wp_unslash($_GET['order_id'])) : '';
            $key      = isset($_GET['key']) ? sanitize_text_field(wp_unslash($_GET['key'])) : '';

            if (!$order_id || !$key) {
                wp_redirect(home_url());
                exit;
            }

            $order = wc_get_order($order_id);
            if (!$order || $order->get_order_key() !== $key) {
                wp_redirect(home_url());
                exit;
            }

            // Hanya tangani order milik gateway ini; selain itu biarkan handler lain.
            if ($order->get_payment_method() !== $this->id) {
                return;
            }

            nicepay_log("Return URL accessed - Order ID: {$order_id}", 'info', 'all');

            wp_redirect($order->get_checkout_order_received_url());
            exit;
        } catch (Exception $e) {
            nicepay_log("Return URL error: " . $e->getMessage(), 'error', 'all');
            wp_redirect(home_url());
            exit;
        }
    }


    /**
     * Handle server-to-server notification (dbProcessUrl) dari NICEPay — All Payment Method.
     */
    public function handle_notification() {
        nicepay_log( 'NICEPay All callback received. Starting processing...', 'info', 'all' );
        status_header( 200 );

        $raw_post = file_get_contents( 'php://input' );
        nicepay_log( 'Raw input: ' . $raw_post, 'info', 'all' );

        $decoded_post = json_decode( $raw_post, true );
        if ( ! is_array( $decoded_post ) ) {
            parse_str( $raw_post, $decoded_post );
        }
        if ( empty( $decoded_post ) ) {
            $decoded_post = $_POST;
        }

        nicepay_log( 'Processed callback data: ' . wp_json_encode( $decoded_post ), 'info', 'all' );

        if ( empty( $decoded_post['referenceNo'] ) ) {
            nicepay_log( 'Missing referenceNo in callback', 'error', 'all' );
            wp_send_json_error( 'Invalid callback', 400 );
        }

        $reference_no = trim( (string) $decoded_post['referenceNo'] );
        $parts        = explode( '-', $reference_no );
        $order_id     = absint( $parts[0] );
        $order        = wc_get_order( $order_id );

        if ( ! $order ) {
            nicepay_log( 'Order not found for referenceNo: ' . $order_id, 'error', 'all' );
            wp_send_json_error( 'Order not found', 404 );
        }

        $validation = $this->validate_notification_payload( $order, $decoded_post );
        if ( is_wp_error( $validation ) ) {
            wp_send_json_error(
                array(
                    'message' => $validation->get_error_message(),
                ),
                400
            );
        }

        nicepay_log( 'Order found: ' . $order_id . ' — verifying via inquiry API', 'info', 'all' );
        $this->check_payment_status_directv2( $order_id, $decoded_post );

        wp_send_json( array( 'status' => 'received' ), 200 );
        exit;
    }

    /**
     * Label metode pembayaran aktual dari kode payMethod NICEPay.
     *
     * @param string $code Kode payMethod.
     * @return string
     */
    private function get_paymethod_label( $code ) {
        $map = array(
            '00' => 'All Payment Method',
            '01' => 'CC',
            '02' => 'VA',
            '03' => 'CVS',
            '04' => 'Direct Debit',
            '05' => 'E-Wallet',
            '06' => 'Payloan',
            '07' => 'Payout',
            '08' => 'QRIS',
        );

        $normalized = str_pad( preg_replace( '/\D/', '', (string) $code ), 2, '0', STR_PAD_LEFT );

        return isset( $map[ $normalized ] ) ? $map[ $normalized ] : $normalized;
    }

    /**
     * Detail pembayaran berdasarkan payMethod (dari notifikasi / inquiry NICEPay).
     *
     * @param array<string, mixed> $data Data transaksi.
     * @return string
     */
    private function get_payment_detail_from_notification( array $data ) {
        $pay_method = str_pad( preg_replace( '/\D/', '', (string) ( $data['payMethod'] ?? '' ) ), 2, '0', STR_PAD_LEFT );

        switch ( $pay_method ) {
            case '01':
                return ! empty( $data['cardNo'] ) ? (string) $data['cardNo'] : '-';

            case '02':
                return ! empty( $data['vacctNo'] ) ? (string) $data['vacctNo'] : '-';

            case '03':
                return ! empty( $data['payNo'] ) ? (string) $data['payNo'] : '-';

            case '04':
                if ( ! empty( $data['dbAcctNo'] ) ) {
                    return (string) $data['dbAcctNo'];
                }
                if ( ! empty( $data['accountNo'] ) ) {
                    return (string) $data['accountNo'];
                }
                return '-';

            case '05':
                $parts = array();
                if ( ! empty( $data['mitraCd'] ) ) {
                    $parts[] = (string) $data['mitraCd'];
                }
                if ( ! empty( $data['billingNm'] ) ) {
                    $parts[] = (string) $data['billingNm'];
                }
                return ! empty( $parts ) ? implode( ' - ', $parts ) : '-';

            case '06':
                return ! empty( $data['mitraCd'] ) ? (string) $data['mitraCd'] : '-';

            case '07':
                if ( ! empty( $data['vacctNo'] ) ) {
                    return (string) $data['vacctNo'];
                }
                if ( ! empty( $data['payNo'] ) ) {
                    return (string) $data['payNo'];
                }
                return '-';

            case '08':
                if ( ! empty( $data['qrContent'] ) ) {
                    return (string) $data['qrContent'];
                }
                if ( ! empty( $data['mitraCd'] ) ) {
                    return (string) $data['mitraCd'];
                }
                return '-';

            default:
                return '-';
        }
    }

    /**
     * Format tanggal & waktu transaksi NICEPay (transDt + transTm).
     *
     * @param string $trans_dt Format Ymd.
     * @param string $trans_tm Format His.
     * @return string
     */
    private function format_transaction_datetime( $trans_dt, $trans_tm ) {
        $trans_dt = preg_replace( '/\D/', '', (string) $trans_dt );
        $trans_tm = str_pad( preg_replace( '/\D/', '', (string) $trans_tm ), 6, '0', STR_PAD_LEFT );

        if ( 8 !== strlen( $trans_dt ) ) {
            return trim( $trans_dt . ' ' . $trans_tm );
        }

        $datetime = DateTime::createFromFormat( 'Ymd His', $trans_dt . ' ' . $trans_tm );
        if ( ! $datetime ) {
            return $trans_dt . ' / ' . $trans_tm;
        }

        $timestamp = $datetime->getTimestamp();

        return wp_date( 'j F Y', $timestamp ) . ' / ' . wp_date( 'H:i:s', $timestamp );
    }

    /**
     * Susun order note detail setelah pembayaran sukses (All Payment Method).
     *
     * @param WC_Order               $order Order.
     * @param array<string, mixed>   $data  Data notifikasi / inquiry NICEPay.
     * @return string
     */
    private function build_success_order_note( $order, array $data ) {
        $pay_method_code = str_pad( preg_replace( '/\D/', '', (string) ( $data['payMethod'] ?? '' ) ), 2, '0', STR_PAD_LEFT );
        $payment_label   = $this->get_paymethod_label( $pay_method_code );
        $detail          = $this->get_payment_detail_from_notification( $data );
        $txid            = (string) ( $data['tXid'] ?? $data['txid'] ?? $order->get_meta( '_nicepay_tXid' ) );
        $trans_dt        = $data['transDt'] ?? '';
        $trans_tm        = $data['transTm'] ?? '';
        $amount          = $data['amt'] ?? $order->get_total();
        $reference_no = ! empty( $data['referenceNo'] )
            ? (string) $data['referenceNo']
            : (string) ( $order->get_meta( '_nicepay_reference_no' ) ?: $order->get_id() );

        $lines = array(
            __( 'Pembayaran Sukses', 'nicepay-payment-gateway-for-woocommerce' ),
            '',
            sprintf(
                /* translators: %s: payment method label (CC, VA, QRIS, etc.) */
                __( 'Payment : %s', 'nicepay-payment-gateway-for-woocommerce' ),
                $payment_label
            ),
            sprintf(
                /* translators: %s: payment detail (masked card, VA number, payment number, etc.) */
                __( 'Detail : %s', 'nicepay-payment-gateway-for-woocommerce' ),
                $detail
            ),
            '',
            sprintf(
                /* translators: %s: NICEPay transaction ID */
                __( 'Txid : %s', 'nicepay-payment-gateway-for-woocommerce' ),
                $txid
            ),
            sprintf(
                /* translators: %s: formatted transaction date and time */
                __( 'Tgl & time Transaksi : %s', 'nicepay-payment-gateway-for-woocommerce' ),
                $this->format_transaction_datetime( $trans_dt, $trans_tm )
            ),
            sprintf(
                /* translators: %s: formatted payment amount */
                __( 'Nominal Amount : %s', 'nicepay-payment-gateway-for-woocommerce' ),
                number_format( (float) $amount, 0, ',', '.' )
            ),
            sprintf(
                /* translators: %s: merchant order / reference number */
                __( 'Order Number : %s', 'nicepay-payment-gateway-for-woocommerce' ),
                $reference_no
            ),
        );

        return implode( "\n", $lines );
    }

    /**
     * Verifikasi status pembayaran ke NICEPay (inquiry) dan update status order.
     */
    protected function check_payment_status_directv2( $order_id, $data ) {
        nicepay_log( 'Starting check_payment_status_directv2 for order ' . $order_id, 'info', 'all' );

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $timestamp   = date( 'YmdHis' );
        $iMid        = $this->get_option( 'X-CLIENT-KEY' );
        $tXid        = $data['tXid'] ?? $order->get_meta( '_nicepay_tXid' );
        $referenceNo = $data['referenceNo'] ?? $order->get_meta( '_nicepay_reference_no' );
        $amount      = $data['amt'] ?? $order->get_meta( '_nicepay_txn_amt' );
        $merchantKey = $this->get_option( 'merchant_key' );

        $merchantToken = hash( 'sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey );

        $requestBody = array(
            'timeStamp'     => $timestamp,
            'iMid'          => $iMid,
            'tXid'          => $tXid,
            'referenceNo'   => $referenceNo,
            'amt'           => $amount,
            'merchantToken' => $merchantToken,
        );

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => wp_json_encode( $requestBody ),
        );

        nicepay_log( 'Inquiry Request to ' . $this->api_endpoints['check_status_url_directv2'], 'info', 'all' );
        nicepay_log( 'Inquiry Request Body: ' . wp_json_encode( $requestBody ), 'info', 'all' );

        $response = wp_remote_post( $this->api_endpoints['check_status_url_directv2'], $args );

        if ( is_wp_error( $response ) ) {
            nicepay_log( 'HTTP Request failed: ' . $response->get_error_message(), 'error', 'all' );
            return;
        }

        $response_body = json_decode( wp_remote_retrieve_body( $response ), true );
        nicepay_log( 'Inquiry Response: ' . wp_json_encode( $response_body ), 'info', 'all' );

        if ( ! isset( $response_body['resultCd'] ) || '0000' !== $response_body['resultCd'] ) {
            nicepay_log( 'Inquiry failed: ' . ( $response_body['resultMsg'] ?? 'Unknown error' ), 'error', 'all' );
            return;
        }

        if ( isset( $response_body['status'] ) && (string) $response_body['status'] === '0' ) {
            if ( $order->is_paid() ) {
                nicepay_log( 'Order already paid: ' . $order_id, 'info', 'all' );
                return;
            }

            $txn_data       = array_merge( (array) $response_body, (array) $data );
            $payment_status = $this->get_payment_status_setting();
            $note           = $this->build_success_order_note( $order, $txn_data );
            $payment_detail = $this->get_payment_detail_from_notification( $txn_data );

            if ( 'completed' === $payment_status ) {
                $order->update_status( 'completed', $note );
            } else {
                $order->update_status( 'processing', $note );
            }

            $order->set_date_paid( time() );
            $order->update_meta_data( '_nicepay_status', 'Success' );
            $order->update_meta_data( '_nicepay_status_code', '00' );
            $order->update_meta_data( '_nicepay_paid_amount', $response_body['amt'] ?? $order->get_total() );
            $order->update_meta_data( '_nicepay_currency', $response_body['currency'] ?? 'IDR' );
            $order->update_meta_data(
                '_nicepay_transaction_datetime',
                ( $response_body['transDt'] ?? '' ) . ( $response_body['transTm'] ?? '' )
            );
            if ( ! empty( $txn_data['payMethod'] ) ) {
                $order->update_meta_data( '_nicepay_actual_pay_method', (string) $txn_data['payMethod'] );
            }
            if ( '-' !== $payment_detail ) {
                $order->update_meta_data( '_nicepay_payment_detail', $payment_detail );
            }
            $order->save();

            nicepay_log( 'Order status updated from inquiry for order ' . $order_id, 'info', 'all' );
        }
    }

    /**
     * Thank-you page summary.
     */
    public function thankyou_page($order_id) {
        if (isset(self::$thankyou_displayed[$order_id])) {
            return;
        }
        self::$thankyou_displayed[$order_id] = true;

        $order = wc_get_order($order_id);
        if (!$order || $order->get_payment_method() !== $this->id) {
            return;
        }

        $amount     = $order->get_meta('_nicepay_paid_amount');
        $status     = $order->get_meta('_nicepay_status');
        $statusCode = $order->get_meta('_nicepay_status_code');
        $is_success = ($status === 'Success' || $statusCode === '00' || $order->is_paid());
        ?>
        <div class="nicepay-thankyou-container" style="max-width:800px;margin:30px auto;padding:30px;background:#fff;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1);">
            <div style="text-align:center;">
                <h2 style="font-size:24px;font-weight:600;color:#333;margin-bottom:10px;">
                    <?php echo $is_success ? esc_html__('Payment Successful!', 'nicepay-payment-gateway-for-woocommerce') : esc_html__('Payment Pending / Failed', 'nicepay-payment-gateway-for-woocommerce'); ?>
                </h2>
                <div style="font-size:32px;font-weight:700;color:<?php echo $is_success ? '#00b4d8' : '#ef4444'; ?>;">
                    Rp<?php echo esc_html(number_format($amount ?: $order->get_total(), 0, ',', '.')); ?>
                </div>
                <p style="margin-top:20px;font-size:25px;">
                    <a href="<?php echo esc_url( 'https://template.nicepay.co.id/' ); ?>" target="_blank" rel="noopener noreferrer" style="color:#0073aa;text-decoration:underline;font-weight:600;">
                        <?php esc_html_e( 'NICEPay Payment Guide', 'nicepay-payment-gateway-for-woocommerce' ); ?>
                    </a>
                </p>
            </div>
            <div style="margin-top:30px;padding-top:20px;border-top:1px solid #e0e0e0;text-align:center;color:#999;font-size:12px;">
                Powered by <strong>NICEPAY</strong>
            </div>
        </div>
        <?php
    }
}
