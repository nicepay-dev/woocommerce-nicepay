<?php
if (!defined('ABSPATH')) exit;
class Nicepay_Gateway_Cvs extends Nicepay_Gateway_Base {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;
    private static $thankyou_displayed = array();
    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_cvs';
        $this->icon               = apply_filters( 'nicepay_gateway_cvs_icon', '' );
        $this->has_fields         = false;
        $this->method_title       = __('NICEPAY CVS', 'nicepay-payment-gateway-for-woocommerce');
        $this->method_description = __('Allows payments using NICEPAY Cvs like Indomaret and Alfamart.', 'nicepay-payment-gateway-for-woocommerce');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        
        // $this->api_endpoints = $this->get_api_endpoints();

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        $this->api_endpoints = $this->get_api_endpoints();
        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_cvs', array($this, 'handle_callback'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-cvs-container {
                margin: 12px 0;
                padding: 12px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-cvs-header {
                margin-bottom: 8px;
                text-align: left;
                padding: 4px 0;
            }
            .nicepay-cvs-image,
            .nicepay-cvs-icon {
                display: block;
                max-width: 140px;
                width: auto;
                height: auto;
                margin: 0;
            }
            .nicepay-cvs-select {
                margin: 10px 0;
            }
            .nicepay-cvs-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-cvs-logos {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                gap: 15px;
                margin-bottom: 12px;
            }
            .nicepay-cvs-logos img {
                height: 30px;
                width: auto;
            }
            .nicepay-cvs-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-cvs-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/cvs-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-classic-checkout',
            'nicepayCvsData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'enabled_mitra' => $this->get_cvs_options(),
                'nonce' => wp_create_nonce('nicepay-cvs-nonce')
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');

        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-cvs-style',
            NICEPAY_PLUGIN_URL . '/assets/css/cvs.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-cvs-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-cvs-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/cvs-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-cvs-blocks-integration',
            'nicepayCvsData',
            array(
                'enabled_mitra' => $this->get_cvs_options(),
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('nicepay-cvs-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'iscvs' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        nicepay_log('API Endpoints configured - Base URL: ' . $base_url, 'info', 'cvs');
        nicepay_log('Environment: ' . $this->environment . ' | Host: ' . $this->host, 'info', 'cvs');
        return [
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }
    /**
    * Get global payment status setting dari admin panel
    */

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPAY Cvs Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'no'
            ),
            'title' => array(
                'title'       => __('Title', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __('NICEPAY Cvs', 'nicepay-payment-gateway-for-woocommerce'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __('Pay with Cvs via NICEPAY (Indomart, Alfamart)', 'nicepay-payment-gateway-for-woocommerce'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-payment-gateway-for-woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'CVSNORMAL0',
            ),
            // 'CHANNEL-ID' => array(
            //     'title' => __('Channel ID', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type' => 'text',
            //     'description' => __('<small>Isikan dengan Channel ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
            //     'default' => '',
            // ),
            // 'client_secret' => array(
            //     'title'       => __('Client Key', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type'        => 'text',
            //     'description' => __('Enter your NICEPAY Client Key.', 'nicepay-payment-gateway-for-woocommerce'),
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            // 'private_key' => array(
            //     'title'       => __('Private Key', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type'        => 'textarea',
            //     'description' => __('Enter your NICEPAY Private Key.', 'nicepay-payment-gateway-for-woocommerce'),
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'mitra_options' => array(
                'title'       => __('Cvs Options', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'title',
                'description' => __('Select which Cvss you want to enable.', 'nicepay-payment-gateway-for-woocommerce'),
            ),
            'enable_indo' => array(
                'title'   => __('Indomart', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable Indomart Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
            'enable_alfa' => array(
                'title'   => __('Alfamart', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable Alfamart Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
        );
    }

    /**
     * Get available Cvs options
     */
    public function get_cvs_options() {
        $available_options = array();

        if ($this->get_option('enable_indo') === 'yes') {
            $available_options[] = array('value' => 'INDO', 'label' => 'Indomart');
        }
        if ($this->get_option('enable_alfa') === 'yes') {
            $available_options[] = array('value' => 'ALMA', 'label' => 'Alfamart');
        }
        return $available_options;
    }

    /**
     * Handle the Ajax request to set the selected mitra
     */
    public function set_nicepay_cvs_mitra() {
        check_ajax_referer('nicepay-cvs-nonce', 'nonce');
        
        if (!isset($_POST['mitra_code'])) {
            wp_send_json_error('Mitra not specified');
        }

        $mitra = sanitize_text_field( wp_unslash( $_POST['mitra_code'] ) );
        WC()->session->set('nicepay_selected_cvs_mitra', $mitra);
        
        wp_send_json_success('Mitra selection saved');
    }

    public function is_available() {
         $is_available = ('yes' === $this->enabled);

    if (!$is_available) {
        return false;
    }

        if ($is_available) {
            $available_mitra = $this->get_cvs_options();
            if (empty($available_mitra)) {
                return false;
            }
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    /**
     * Output payment fields
     */
   public function payment_fields()
{
     if (!empty($this->description)) {
        echo '<div class="payment-method-description">';
        echo wp_kses_post($this->description);
        echo '</div>';
    }
    $cvs_options = $this->get_cvs_options();

    if (!empty($cvs_options)) {
        echo '<div class="nicepay-cvs-container">';
        
        // Tampilkan logos CVS
        echo '<div class="nicepay-cvs-logos">';
        echo '<img src="' . esc_url(NICEPAY_PLUGIN_URL . '/assets/images/cvs-logo.png') . '" alt="Indomaret" style="height: 40px; width: auto; margin: 0 10px;">';
        // echo '<img src="' . esc_url(NICEPAY_PLUGIN_URL . '/assets/images/alfamart.png') . '" alt="Alfamart" style="height: 40px; width: auto; margin: 0 10px;">';
        echo '</div>';
        
        echo '<div class="nicepay-cvs-select">';
        echo '<label for="nicepay-cvs-select">' . __('Pilih Cvs:', 'nicepay-payment-gateway-for-woocommerce') . ' <span class="required">*</span></label>';
        echo '<select name="nicepay_cvs_mitra" id="nicepay-cvs-select" class="wc-enhanced-select" required>';
        echo '<option value="">' . __('-- Pilih Cvs --', 'nicepay-payment-gateway-for-woocommerce') . '</option>';
        
        foreach ($cvs_options as $option) {
            echo '<option value="' . esc_attr($option['value']) . '">' . esc_html($option['label']) . '</option>';
        }
        
        echo '</select>';
        echo '</div>';
        
        // Error container
        echo '<div class="nicepay-cvs-error" style="display: none; color: red; margin-top: 10px;"></div>';
        
        echo '</div>'; // Close nicepay-cvs-container
    } else {
        echo '<p>' . __('Tidak ada opsi CVS tersedia. Silakan hubungi administrator.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
    }
}
    
    // Tampilkan dropdown untuk memilih mitra CVS
    // $cvs_options = $this->get_cvs_options();
    
    //  if (!empty($cvs_options)) {
    //     echo '<div class="nicepay-cvs-container">';
    //     echo '<div class="nicepay-cvs-select">';
    //     echo '<label for="nicepay_cvs_mitra">' . __('Select Convenience Store:', 'nicepay-payment-gateway-for-woocommerce') . ' <span class="required">*</span></label>';
    //     echo '<select name="nicepay_cvs_mitra" id="nicepay_cvs_mitra" class="wc-enhanced-select" required>';
    //     echo '<option value="">' . __('-- Choose Store --', 'nicepay-payment-gateway-for-woocommerce') . '</option>';
        
    //     foreach ($cvs_options as $option) {
    //         echo '<option value="' . esc_attr($option['value']) . '">' . esc_html($option['label']) . '</option>';
    //     }
        
    //     echo '</select>';
    //     echo '</div>';
    //     echo '</div>';
    // } else {
    //     echo '<p>' . __('No CVS options available. Please contact administrator.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
    // }



    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment cvs for order $order_id", 'info', 'cvs');

        return $this->process_blocks_payment($order_id);
    }

    /**
     * Process payment for classic checkout
     */
    public function process_classic_payment($order_id) {
        nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'cvs');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'cvs');
        $order->save();

        $selected_mitra = WC()->session->get('nicepay_selected_cvs_mitra');
        nicepay_log("Selected mitra from session: " . $selected_mitra, 'info', 'cvs');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an Cvs payment method.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        try {
            $cvs_data = $this->process_directV2($order_id);
            if (!is_array($cvs_data) || !isset($cvs_data['resultCd']) || $cvs_data['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create CVS transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($cvs_data['resultMsg'] ?? 'Unknown error'));
            }
            $this->handle_cvs_creation_response($order_id, $cvs_data);
            nicepay_log('end handle_cvs_creation_response', 'info', 'cvs');
            return array(
                'result'   => 'success',
                'redirect' => $this->get_return_url($order),
            );
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log('Payment error in process_classic_payment: ' . $e->getMessage(), 'error', 'cvs');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order $order_id", 'info', 'cvs');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'cvs');
        $order->save();

        $selected_mitra = WC()->session->get('nicepay_selected_cvs_mitra');
        nicepay_log("Selected mitra from session: " . $selected_mitra, 'info', 'cvs');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an Cvs payment method.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        try {
            $cvs_data = $this->process_directV2($order_id);
            if (!is_array($cvs_data) || !isset($cvs_data['resultCd']) || $cvs_data['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create CVS transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($cvs_data['resultMsg'] ?? 'Unknown error'));
            }
            $this->handle_cvs_creation_response($order_id, $cvs_data);
            nicepay_log('end handle_cvs_creation_response', 'info', 'cvs');
            return array(
                'result'   => 'success',
                'redirect' => $this->get_return_url($order),
            );
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log('Payment error in process_blocks_payment: ' . $e->getMessage(), 'error', 'cvs');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'cvs');
        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int)$order->get_total();
            $referenceNo = $order->get_id();
            $mitraCd = WC()->session->get('nicepay_selected_cvs_mitra', '');

            if (empty($mitraCd)) {
                throw new Exception(__('No CVS selected. Please choose a CVS payment method.', 'nicepay-payment-gateway-for-woocommerce'));
            }
            
            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);
            $cart_data = $this->prepare_cart_data($order);
            $requestBody = [
                "timeStamp" => $timestamp,
                "iMid" => $iMid,
                "payMethod" => "03",
                "currency" => "IDR",
                "amt" => $amount,
                "referenceNo" => $referenceNo,
                "merchantToken" => $merchantToken,
                "mitraCd" => $mitraCd,
                "goodsNm" => $this->get_order_items_names($order),
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_cvs'),
                "description" => "Testing API CVS - " . get_bloginfo('name'),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $order->get_billing_phone(),
                "billingEmail" => $order->get_billing_email(),
                "billingAddr" => $order->get_billing_address_1(),
                "billingCity" => $order->get_billing_city(),
                "billingState" => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "userIP" => $_SERVER['REMOTE_ADDR'],
                "cartData" => $cart_data,
                "payValidDt" => date('Ymd', strtotime('+1 day')),
                "payValidTm" => "235959"
            ];

            $args = [
                'method' => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("CVS Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'cvs');
            nicepay_log("CVS Request Body: " . json_encode($requestBody), 'info', 'cvs');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("CVS Response: " . json_encode($response_body), 'info', 'cvs');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create CVS transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($response_body['resultMsg'] ?? 'Unknown error'));
            }

            $order->update_meta_data('_nicepay_cvs_number', $response_body['payNo']);
            $order->update_meta_data('_nicepay_cvs_expiry', $response_body['payValidDt'] . ' ' . $response_body['payValidTm']);
            $order->update_meta_data('_nicepay_tXid', $response_body['tXid']);
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo']);
            $order->save();

        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'cvs');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        return $response_body;
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    private function handle_cvs_creation_response($order_id, $data) {
        nicepay_log("Starting handle_cvs_creation_response for order " . $order_id, 'info', 'cvs');
        nicepay_log("payNo: " . $data['payNo'], 'info', 'cvs');
        
        if (isset($data['payNo'])) {
            $order = wc_get_order($order_id);
            $refno = $data['referenceNo'];
            $tXid = $data['tXid'];
            $amount = $data['amt'];
            $payNo = $data['payNo'];
            $mitraCd = $data['mitraCd'];
            $payValidDt = $data['payValidDt'];
            $payValidTm = $data['payValidTm'];
            $expiry_dt = DateTime::createFromFormat('YmdHis', $payValidDt . $payValidTm);
            if ($expiry_dt) {
                $expiry = $expiry_dt->format('Y-m-d H:i:s');
            } else {
                $expiry = $payValidDt . ' ' . $payValidTm; // fallback jika parsing gagal
            }

            $status_note = sprintf(
                __('Awaiting NICEPay payment', 'nicepay-payment-gateway-for-woocommerce'),
                $payNo,
                $tXid
            );

            $order->update_status('on-hold', $status_note);
            // translators: 1: reference number, 2: transaction ID, 3: amount, 4: payment number, 5: store name, 6: valid until.
            $order->add_order_note( sprintf(
                __( "NICEPay payment number created. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s\nTransaction Amount: %3\$s\nPayment Number: %4\$s\nConvenience Store: %5\$s\nPayment Valid Time: %6\$s", 'nicepay-payment-gateway-for-woocommerce' ),
                $refno,
                $tXid,
                $amount,
                $payNo,
                $this->get_cvs_mitra_name($mitraCd),
                $expiry
            ) );

            WC()->session->set('nicepay_cvs_number', $data['payNo']);

            if ($this->get_option('reduceStock') === 'yes' && !$order->get_meta('_stock_reduced', true)) {
                wc_reduce_stock_levels($order->get_id());
                $order->update_meta_data('_stock_reduced', 'yes');
                $order->save();
            }
        } else {
            throw new Exception(__('Failed to create CVS No', 'nicepay-payment-gateway-for-woocommerce'));
        }
    }

    public function get_cvs_mitra_name($mitra_code)
    {
        $mitras = $this->get_cvs_mitra_list();
        foreach ($mitras as $mitra) {
            if ($mitra['code'] === $mitra_code) {
                return $mitra['name'];
            }
        }
        return $mitra_code;
    }

    public function get_cvs_mitra_list()
    {
        return [
            ['code' => 'ALMA', 'name' => 'Alfamart'],
            ['code' => 'INDO', 'name' => 'Indomart']
        ];
    }

    public function thankyou_page($order_id) {
        nicepay_log("Starting thankyou_page" .$order_id,'info','cvs');
        if (isset(self::$thankyou_displayed[$order_id])) {
        nicepay_log("Thank you page already displayed for order: " . $order_id, 'info', 'cvs');
        return;
        }
        self::$thankyou_displayed[$order_id] = true;
        $order = wc_get_order($order_id);
        if ($order && $order->get_payment_method() === $this->id) {
            $cvs_number = $order->get_meta('_nicepay_cvs_number');
            $expiry_date = $order->get_meta('_nicepay_cvs_expiry');
            $payment_status = $order->get_status();

            $is_paid = in_array($payment_status, ['processing', 'completed']);

            nicepay_log("cvs_number: " . $cvs_number,'info','cvs');
            nicepay_log("payment_status: " . $payment_status,'info','cvs');
            nicepay_log("is_paid: " . ($is_paid ? 'YES' : 'NO'),'info','cvs');
            
        ?>
                <script>
                    function copyToClipboard(elementId) {
                        var copyText = document.getElementById(elementId);

                        // Pilih teks
                        var range = document.createRange();
                        range.selectNode(copyText);
                        window.getSelection().removeAllRanges();
                        window.getSelection().addRange(range);

                        // Salin teks
                        try {
                            document.execCommand('copy');
                            // Tampilkan notifikasi berhasil disalin
                            var tooltip = document.getElementById("copyTooltip");
                            tooltip.innerHTML = "Copied!";
                            setTimeout(function() {
                                tooltip.innerHTML = "Click to copy";
                            }, 1500);
                        } catch (err) {
                            console.error('Failed to copy text: ', err);
                        }

                        // Hapus seleksi
                        window.getSelection().removeAllRanges();
                    }
                </script>
                <style>
                    .nicepay-cvs-copy {
                        position: relative;
                        display: inline-block;
                        cursor: pointer;
                        padding: 5px 10px;
                        background-color: #f8f9fa;
                        border-radius: 4px;
                        border: 1px solid #ddd;
                        font-weight: bold;
                    }

                    .nicepay-cvs-copy .tooltip {
                        visibility: hidden;
                        width: 100px;
                        background-color: #555;
                        color: #fff;
                        text-align: center;
                        border-radius: 4px;
                        padding: 5px;
                        position: absolute;
                        z-index: 1;
                        bottom: 125%;
                        left: 50%;
                        margin-left: -50px;
                        opacity: 0;
                        transition: opacity 0.3s;
                        font-size: 12px;
                        font-weight: normal;
                    }

                    .nicepay-cvs-copy:hover .tooltip {
                        visibility: visible;
                        opacity: 1;
                    }
                </style>
<?php
                echo '<div class="woocommerce-order-payment-details">';
                echo '<h2>' . __('Payment Instructions', 'nicepay-payment-gateway-for-woocommerce') . '</h2>';
                

                 if ($is_paid) {
                echo '<p><strong>' . __('Payment Status:', 'nicepay-payment-gateway-for-woocommerce') . '</strong> ';
                echo '<span class="payment-status-icon status-paid">✅</span>';
                echo '<span class="status-paid">' . $this->get_payment_status_description($payment_status) . '</span>';
                echo '</p>';
            } else {
                echo '<p><strong>' . __('Payment Status:', 'nicepay-payment-gateway-for-woocommerce') . '</strong> ';
                echo '<span class="payment-status-icon status-unpaid">❌</span>';
                echo '<span class="status-unpaid">' . $this->get_payment_status_description($payment_status) . '</span>';
                echo '</p>';
            }
               // translators: %s: formatted order total amount.
               echo '<p>' . sprintf(
                __('Please transfer %s to the following Payment Number details:', 'nicepay-payment-gateway-for-woocommerce'),
                wc_price($order->get_total())
            ) . '</p>';
            
            echo '<ul>';
                    echo '<li><strong>' . __('Payment Number:', 'nicepay-payment-gateway-for-woocommerce') . '</strong> ';
                    echo '<span class="nicepay-cvs-copy" onclick="copyToClipboard(\'cvs-number\')">';
                    echo '<span id="cvs-number">' . esc_html($cvs_number) . '</span>';
                    echo '<span class="tooltip" id="copyTooltip">Click to copy</span>';
                    echo '</span></li>';
                    echo '<li><strong>' . __('Amount:', 'nicepay-payment-gateway-for-woocommerce') . '</strong> ' . wc_price($order->get_total()) . '</li>';
                    if ($expiry_date) {
                        $formatted_expiry = $this->format_expiry_date($expiry_date);
                        echo '<li><strong>' . __('Expiry Date:', 'nicepay-payment-gateway-for-woocommerce') . '</strong> ' . esc_html($formatted_expiry) . '</li>';
                    }
                    echo '</ul>';

            // translators: %s: URL to payment guide.
            echo '<p>' . sprintf(
                __('For detailed payment instructions, please visit <a href="%s" target="_blank">NICEPay Payment Guide</a>.', 'nicepay-payment-gateway-for-woocommerce'),
                'https://template.nicepay.co.id/'
            ) . '</p>';

            // Pesan tambahan sesuai status
            if ($is_paid) {
                echo '<p style="color: #28a745; font-weight: bold;">' . __('✅ Thank you for your payment. Your transaction has been completed successfully!', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
            } else {
                echo '<p>' . __('Please complete the payment before the Payment number expires. After payment is completed, it may take a few moments for the system to confirm your payment.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
            }

            echo '</div>';
            $order->save();
        
    }
}

    private function get_payment_status_description($status)
    {
        switch ($status) {
            case 'pending':
                return __('Pending payment', 'nicepay-payment-gateway-for-woocommerce');
            case 'on-hold':
                return __('Awaiting payment confirmation', 'nicepay-payment-gateway-for-woocommerce');
            case 'processing':
                return __('Payment received, processing order', 'nicepay-payment-gateway-for-woocommerce');
            case 'completed':
                return __('Payment completed', 'nicepay-payment-gateway-for-woocommerce');
            case 'cancelled':
                return __('Order cancelled', 'nicepay-payment-gateway-for-woocommerce');
            case 'failed':
                return __('Payment failed', 'nicepay-payment-gateway-for-woocommerce');
            default:
                return ucfirst($status);
        }
    }

    private function format_expiry_date($expiry_date)
    {
        $datetime = DateTime::createFromFormat('Ymd His', $expiry_date);
        if ($datetime) {
            return $datetime->format('d F Y H:i:s');
        }
        return $expiry_date;
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_callback()
    {
        nicepay_log('=== NICEPAY CVS CALLBACK RECEIVED ===', 'info', 'cvs');
        status_header(200);

        $decoded_post = $this->parse_notification_payload();
        nicepay_log('Final processed callback data: ' . wp_json_encode($decoded_post), 'info', 'cvs');

        if (empty($decoded_post['referenceNo'])) {
            nicepay_log('Missing referenceNo in callback', 'error', 'cvs');
            wp_send_json_error('Invalid callback', 400);
        }

        $order_id = $this->get_order_id_from_reference($decoded_post['referenceNo']);
        $order    = wc_get_order($order_id);

        if (!$order) {
            nicepay_log('Order not found for referenceNo: ' . $order_id, 'error', 'cvs');
            wp_send_json_error('Order not found', 404);
        }

        $validation = $this->validate_notification_payload($order, $decoded_post);
        if (is_wp_error($validation)) {
            wp_send_json_error(
                array(
                    'message' => $validation->get_error_message(),
                ),
                400
            );
        }

        nicepay_log('Order found: ' . $order_id . ' — verifying via inquiry API', 'info', 'cvs');
        $this->check_payment_status_directv2($order_id, $decoded_post);

        nicepay_log('=== CALLBACK PROCESSING COMPLETED ===', 'info', 'cvs');
        wp_send_json(array('status' => 'received'), 200);
        exit;
    }  
    
    protected function check_payment_status_directv2($order_id,$decoded_post)
    {
        nicepay_log('=== STARTING PAYMENT STATUS CHECK (DirectV2) ===', 'info', 'cvs');
        nicepay_log('Order ID: ' . $order_id, 'info', 'cvs');

        $order = wc_get_order($order_id);
        if (!$order) {
            nicepay_log('Order not found: ' . $order_id, 'error', 'cvs');
            return false;
        }

        if ($order->is_paid()) {
            nicepay_log('Order already paid: ' . $order_id, 'info', 'cvs');
            return true;
        }

        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $tXid = $decoded_post['tXid'];
        $referenceNo = $decoded_post['referenceNo'];
        $amount = $decoded_post['amt'];
        $merchantKey = $this->get_option('merchant_key');

        nicepay_log('Preparing inquiry request:', 'info', 'cvs');
        nicepay_log('- Timestamp: ' . $timestamp, 'info', 'cvs');
        nicepay_log('- Merchant ID (iMid): ' . $iMid, 'info', 'cvs');
        nicepay_log('- Transaction ID (tXid): ' . $tXid, 'info', 'cvs');
        nicepay_log('- Reference No: ' . $referenceNo, 'info', 'cvs');
        nicepay_log('- Amount: ' . $amount, 'info', 'cvs');

        nicepay_log($iMid . $tXid . $referenceNo . $amount);

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

       nicepay_log('cvs Request to ' . $this->api_endpoints['check_status_url_directv2'], 'info', 'cvs');
        nicepay_log('cvs Request Body: ' . json_encode($requestBody), 'info', 'cvs');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            throw new Exception("HTTP Request failed: " . $response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
         nicepay_log("=== INQUIRY RESPONSE ===", 'info', 'cvs');
        nicepay_log('cvs Response: ' . json_encode($response_body), 'info', 'cvs');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            nicepay_log("ERROR: resultCd not found in response", 'error', 'cvs');
            throw new Exception(__('Failed to create CVS transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($response_body['resultMsg'] ?? 'Unknown error'));
        }

        if($response_body['status'] == '0') {
            nicepay_log("=== PAYMENT CONFIRMED - UPDATING ORDER ===", 'info', 'cvs');
           $payment_status = $this->get_payment_status_setting();
            nicepay_log("Target order status: " . $payment_status, 'info', 'cvs');
            
            $old_status = $order->get_status();
            nicepay_log("Current order status BEFORE update: " . $old_status, 'info', 'cvs');
            
             if ($payment_status === 'completed') {
            $order->update_status('completed', __('CVS payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce'));
                } else {
            $order->update_status('processing', __('CVS payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce'));
                }
            $order->set_date_paid(current_time('timestamp', true));
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency']);
            $order->update_meta_data('_nicepay_transaction_datetime', $response_body['transDt'] . $response_body['transTm']);
            $order->save();

            nicepay_log('Order status updated to: ' . $payment_status . ' for order ' . $order_id, 'info', 'cvs');
        }
    }
}