<?php

/**
 * NICEPay Admin — global settings rendered on WooCommerce > NICEPay Payment Gateway.
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Admin class uses Nicepay prefix in filename.
class WC_Nicepay_Admin
{
    /**
     * @var WC_Nicepay_Admin|null
     */
    private static $instance = null;

    /**
     * @return WC_Nicepay_Admin
     */
    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('admin_init', array($this, 'redirect_legacy_settings_page'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
    }

    /**
     * Redirect old top-level menu URL to the unified settings page.
     */
    public function redirect_legacy_settings_page()
    {
        if (!is_admin()) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect guard.
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        if ('nicepay-settings' === $page) {
            wp_safe_redirect(admin_url('admin.php?page=nicepay-wc-payment-methods'));
            exit;
        }
    }

    /**
     * Initialize admin settings
     */
    public function admin_init()
    {
        register_setting('nicepay_settings', 'nicepay_enable_va', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_enable_cc', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_enable_ewallet', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_enable_cvs', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_enable_payloan', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_enable_qris', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_debug_mode', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_reduce_stock', array(
            'sanitize_callback' => 'absint',
        ));
        register_setting('nicepay_settings', 'nicepay_environment', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_host', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_merchant_id', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_client_secret', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_channel_id', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_merchant_key', array(
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting('nicepay_settings', 'nicepay_private_key', array(
            'sanitize_callback' => 'sanitize_textarea_field',
        ));
    }

    /**
     * Enqueue admin scripts
     *
     * @param string $hook Current admin page hook.
     */
    public function admin_scripts($hook)
    {
        if ('woocommerce_page_nicepay-wc-payment-methods' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'nicepay-admin-style',
            plugins_url('assets/css/admin.css', dirname(dirname(__FILE__))),
            array(),
            defined('NICEPAY_WC_VERSION') ? NICEPAY_WC_VERSION : '1.0.0'
        );
    }

    /**
     * Save global NICEPay settings from POST request.
     */
    public function save_settings_from_request()
    {
        check_admin_referer('nicepay_settings_save', 'nicepay_nonce');

        $post = wp_unslash($_POST);

        $va_enabled      = isset($post['nicepay_enable_va']) ? 'yes' : 'no';
        $cc_enabled      = isset($post['nicepay_enable_cc']) ? 'yes' : 'no';
        $ewallet_enabled = isset($post['nicepay_enable_ewallet']) ? 'yes' : 'no';
        $cvs_enabled     = isset($post['nicepay_enable_cvs']) ? 'yes' : 'no';
        $payloan_enabled = isset($post['nicepay_enable_payloan']) ? 'yes' : 'no';
        $qris_enabled    = isset($post['nicepay_enable_qris']) ? 'yes' : 'no';
        $debug_mode      = isset($post['nicepay_debug_mode']) ? 'yes' : 'no';
        $reduce_stock    = isset($post['nicepay_reduce_stock']) ? 'yes' : 'no';

        $environment   = isset($post['nicepay_environment']) ? sanitize_text_field($post['nicepay_environment']) : 'sandbox';
        $host          = isset($post['nicepay_host']) ? sanitize_text_field($post['nicepay_host']) : 'cloud';
        $status        = isset($post['status_order']) ? sanitize_text_field($post['status_order']) : 'Processing';
        $merchant_id   = isset($post['nicepay_merchant_id']) ? sanitize_text_field($post['nicepay_merchant_id']) : '';
        $client_secret = isset($post['nicepay_client_secret']) ? sanitize_text_field($post['nicepay_client_secret']) : '';
        $channel_id    = isset($post['nicepay_channel_id']) ? sanitize_text_field($post['nicepay_channel_id']) : '';
        $merchant_key  = isset($post['nicepay_merchant_key']) ? sanitize_text_field($post['nicepay_merchant_key']) : '';
        $private_key   = isset($post['nicepay_private_key']) ? sanitize_textarea_field($post['nicepay_private_key']) : '';

        update_option('nicepay_enable_va', $va_enabled);
        update_option('nicepay_enable_cc', $cc_enabled);
        update_option('nicepay_enable_ewallet', $ewallet_enabled);
        update_option('nicepay_enable_cvs', $cvs_enabled);
        update_option('nicepay_enable_payloan', $payloan_enabled);
        update_option('nicepay_enable_qris', $qris_enabled);
        update_option('nicepay_debug_mode', $debug_mode);
        update_option('nicepay_reduce_stock', $reduce_stock);
        update_option('nicepay_environment', $environment);
        update_option('nicepay_host', $host);
        update_option('status_order', $status);
        update_option('nicepay_merchant_id', $merchant_id);
        update_option('nicepay_client_secret', $client_secret);
        update_option('nicepay_channel_id', $channel_id);
        update_option('nicepay_merchant_key', $merchant_key);
        update_option('nicepay_private_key', $private_key);
    }

    /**
     * Render page header block.
     */
    public function render_page_header()
    {
        ?>
        <div class="nicepay-header">
            <div class="nicepay-logo">
                <img src="<?php echo esc_url(plugins_url('assets/images/logo-nicepay.jpg', dirname(dirname(__FILE__)))); ?>" alt="NICEPay" />
            </div>
            <div class="nicepay-info">
                <h1><?php esc_html_e('NICEPay Payment Gateway', 'nicepay-payment-gateway-for-woocommerce'); ?></h1>
                <p class="nicepay-version">
                    <?php esc_html_e('Version', 'nicepay-payment-gateway-for-woocommerce'); ?>
                    <?php echo esc_html(defined('NICEPAY_WC_VERSION') ? NICEPAY_WC_VERSION : '1.0.0'); ?>
                </p>
            </div>
        </div>

        <div class="nicepay-description">
            <p><?php esc_html_e('Configure your NICEPay payment environment and manage payment methods from this page.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>

            <?php if (!$this->check_credentials()) : ?>
                <div class="notice notice-warning inline">
                    <p>
                        <strong><?php esc_html_e('Credentials not configured!', 'nicepay-payment-gateway-for-woocommerce'); ?></strong>
                        <?php esc_html_e('Please configure your merchant credentials using Configure for each payment method below, or via', 'nicepay-payment-gateway-for-woocommerce'); ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout')); ?>"><?php esc_html_e('WooCommerce > Settings > Payments', 'nicepay-payment-gateway-for-woocommerce'); ?></a>.
                    </p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render advanced settings form.
     */
    public function render_advanced_settings_form()
    {
        $debug_mode   = get_option('nicepay_debug_mode', 'no');
        $reduce_stock = get_option('nicepay_reduce_stock', 'no');
        $host         = get_option('nicepay_host', 'cloud');
        $status       = get_option('status_order', 'Processing');
        $environment  = get_option('nicepay_environment', 'sandbox');
        ?>
        <form method="post" action="">
            <?php wp_nonce_field('nicepay_settings_save', 'nicepay_nonce'); ?>

            <h2 class="title"><?php esc_html_e('Advanced Settings', 'nicepay-payment-gateway-for-woocommerce'); ?></h2>

            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_environment"><?php esc_html_e('Environment', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                        </th>
                        <td>
                            <select name="nicepay_environment" id="nicepay_environment">
                                <option value="sandbox" <?php selected($environment, 'sandbox'); ?>><?php esc_html_e('Sandbox', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                <option value="production" <?php selected($environment, 'production'); ?>><?php esc_html_e('Production', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Select the NICEPay environment.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_host"><?php esc_html_e('Host', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                        </th>
                        <td>
                            <select name="nicepay_host" id="nicepay_host">
                                <option value="cloud" <?php selected($host, 'cloud'); ?>><?php esc_html_e('Cloud', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                <option value="premise" <?php selected($host, 'premise'); ?>><?php esc_html_e('Premise', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Select the NICEPay host.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_debug_mode"><?php esc_html_e('Debug Mode', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                        </th>
                        <td>
                            <label for="nicepay_debug_mode">
                                <input type="checkbox" id="nicepay_debug_mode" name="nicepay_debug_mode" value="yes" <?php checked($debug_mode, 'yes'); ?> />
                                <?php esc_html_e('Enable debug mode (logging)', 'nicepay-payment-gateway-for-woocommerce'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Log debug messages for troubleshooting. Only enable when needed.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="status_order"><?php esc_html_e('Status', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                        </th>
                        <td>
                            <select name="status_order" id="status_order">
                                <option value="Completed" <?php selected($status, 'Completed'); ?>><?php esc_html_e('Completed', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                <option value="Processing" <?php selected($status, 'Processing'); ?>><?php esc_html_e('Processing', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Automatic Status after Payment.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="nicepay_reduce_stock"><?php esc_html_e('Reduce Stock', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                        </th>
                        <td>
                            <label for="nicepay_reduce_stock">
                                <input type="checkbox" id="nicepay_reduce_stock" name="nicepay_reduce_stock" value="yes" <?php checked($reduce_stock, 'yes'); ?> />
                                <?php esc_html_e('Reduce stock levels when order is placed', 'nicepay-payment-gateway-for-woocommerce'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Reduce stock when payment is initiated rather than when completed.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <?php submit_button(__('Save Changes', 'nicepay-payment-gateway-for-woocommerce')); ?>
        </form>
        <?php
    }

    /**
     * Render footer help block.
     */
    public function render_footer_help()
    {
        ?>
        <div class="nicepay-footer">
            <h3><?php esc_html_e('Need Help?', 'nicepay-payment-gateway-for-woocommerce'); ?></h3>
            <p><?php esc_html_e('For technical support or questions about NICEPay integration:', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
            <ul>
                <li><a href="https://docs.nicepay.co.id" target="_blank" rel="noopener noreferrer"><?php esc_html_e('NICEPay Documentation', 'nicepay-payment-gateway-for-woocommerce'); ?></a></li>
                <li><a href="mailto:technical.support@nicepay.co.id"><?php esc_html_e('Technical Support', 'nicepay-payment-gateway-for-woocommerce'); ?></a></li>
            </ul>
        </div>
        <?php
    }

    /**
     * Check if credentials are configured
     *
     * @return bool
     */
    private function check_credentials()
    {
        $va_settings      = get_option('woocommerce_nicepay_va_snap_settings', array());
        $cc_settings      = get_option('woocommerce_nicepay_cc_settings', array());
        $ewallet_settings = get_option('woocommerce_nicepay_ewallet_settings', array());
        $cvs_settings     = get_option('woocommerce_nicepay_cvs_settings', array());
        $payloan_settings = get_option('woocommerce_nicepay_payloan_settings', array());
        $qris_settings    = get_option('woocommerce_nicepay_qris_settings', array());
        $all_settings     = get_option('woocommerce_nicepay_all_settings', array());

        $checks = array(
            !empty($va_settings['merchant_id']) && !empty($va_settings['merchant_key']),
            !empty($cc_settings['merchant_id']) && !empty($cc_settings['merchant_key']),
            !empty($ewallet_settings['merchant_id']) && !empty($ewallet_settings['merchant_key']),
            !empty($cvs_settings['merchant_id']) && !empty($cvs_settings['merchant_key']),
            !empty($payloan_settings['merchant_id']) && !empty($payloan_settings['merchant_key']),
            !empty($qris_settings['merchant_id']) && !empty($qris_settings['merchant_key']),
            !empty($all_settings['merchant_id']) && !empty($all_settings['merchant_key']),
        );

        foreach ($checks as $configured) {
            if ($configured) {
                return true;
            }
        }

        return false;
    }
}

WC_Nicepay_Admin::instance();
