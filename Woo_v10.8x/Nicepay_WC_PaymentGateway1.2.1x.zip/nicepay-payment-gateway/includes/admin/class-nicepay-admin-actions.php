<?php
if (!defined('ABSPATH')) exit;

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Admin actions helper class.
class NICEPay_Admin_Actions {

    private static $baseUrl = 'https://dev.nicepay.co.id';

    public static function process($operation, $params) {
        switch ($operation) {
            case 'va':
                return self::call_api('/nicepay/api/v1.0/transfer-va/delete-va', $params);

            case 'qris':
                return self::call_api('/nicepay/api/v1.0/qr/qr-mpm-refund', $params);

            case 'ewallet':
                return self::call_api('/nicepay/api/v1.0/debit/refund', $params);

            case 'payout':
                $payout_action = isset( $params['payout_action'] ) ? sanitize_text_field( wp_unslash( $params['payout_action'] ) ) : '';
                if ( empty( $payout_action ) ) {
                    return array( 'error' => 'Missing payout_action' );
                }

                if ($payout_action === 'approve') {
                    return self::call_api('/nicepay/api/v1.0/transfer/inquiry', $params);
                }
                if ($payout_action === 'reject') {
                    return self::call_api('/nicepay/api/v1.0/transfer/reject', $params);
                }
                if ($payout_action === 'cancel') {
                    return self::call_api('/nicepay/api/v1.0/transfer/cancel', $params);
                }

                return ['error' => 'Invalid payout_action'];
            default:
                return ['error' => 'Invalid operation'];
        }
    }

    private static function call_api($endpoint, $params) {
        $url = self::$baseUrl . $endpoint;
        $response = wp_remote_post($url, [
            'headers' => [
                'Content-Type' => 'application/json'
                // Add Authorization if needed
            ],
            'body' => json_encode($params),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        return json_decode(wp_remote_retrieve_body($response), true);
    }
}