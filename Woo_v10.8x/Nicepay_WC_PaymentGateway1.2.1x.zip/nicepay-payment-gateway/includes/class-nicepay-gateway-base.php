<?php
/**
 * Base class for NICEPay WooCommerce payment gateways.
 *
 * @package Nicepay_Payment_Gateway_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\Internal\Admin\Settings\Utils as SettingsUtils;

/**
 * Shared behavior for all NICEPay gateways (settings URL for WC 10+ Payments UI).
 */
abstract class Nicepay_Gateway_Base extends WC_Payment_Gateway {

	/**
	 * Log channel name for nicepay_log().
	 *
	 * @return string
	 */
	protected function get_log_channel() {
		$map = array(
			'nicepay_qris'    => 'qris',
			'nicepay_va_snap' => 'va',
			'nicepay_ewallet' => 'ewallet',
			'nicepay_cvs'     => 'cvs',
			'nicepay_payloan' => 'payloan',
			'nicepay_cc'      => 'cc',
			'nicepay_all'     => 'all',
		);

		return isset( $map[ $this->id ] ) ? $map[ $this->id ] : 'va';
	}

	/**
	 * Global WooCommerce order status after successful payment.
	 *
	 * @return string
	 */
	protected function get_payment_status_setting() {
		return strtolower( get_option( 'status_order', 'processing' ) );
	}

	/**
	 * Parse NICEPay server-to-server notification body.
	 *
	 * @return array<string, mixed>
	 */
	protected function parse_notification_payload() {
		$raw_post = file_get_contents( 'php://input' );
		nicepay_log( 'Raw input: ' . $raw_post, 'info', $this->get_log_channel() );

		$data = json_decode( $raw_post, true );
		if ( ! is_array( $data ) ) {
			parse_str( $raw_post, $data );
		}
		if ( empty( $data ) ) {
			$data = $_POST;
		}

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Resolve WooCommerce order ID from NICEPay referenceNo.
	 *
	 * @param string $reference_no NICEPay reference number.
	 * @return int
	 */
	protected function get_order_id_from_reference( $reference_no ) {
		$parts = explode( '-', trim( (string) $reference_no ) );
		return absint( $parts[0] );
	}

	/**
	 * Apply paid status to order from notification / inquiry data.
	 *
	 * @param int                  $order_id Order ID.
	 * @param array<string, mixed> $data     Payment data.
	 * @param string               $note     Order note.
	 * @return bool
	 */
	protected function apply_paid_status_from_notification( $order_id, $data, $note = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}

		if ( $order->is_paid() ) {
			nicepay_log( 'Order already paid: ' . $order_id, 'info', $this->get_log_channel() );
			return true;
		}

		$saved_txid = $order->get_meta( '_nicepay_tXid' );
		if ( ! empty( $data['tXid'] ) && ! empty( $saved_txid ) && (string) $data['tXid'] !== (string) $saved_txid ) {
			nicepay_log(
				'tXid mismatch for order ' . $order_id . ' (saved=' . $saved_txid . ', callback=' . $data['tXid'] . ')',
				'error',
				$this->get_log_channel()
			);
			return false;
		}

		if ( empty( $note ) ) {
			$note = __( 'Payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce' );
		}

		$payment_status = $this->get_payment_status_setting();
		if ( 'completed' === $payment_status ) {
			$order->update_status( 'completed', $note );
		} else {
			$order->update_status( 'processing', $note );
		}

		$order->set_date_paid( time() );
		$order->update_meta_data( '_nicepay_status', 'Success' );
		$order->update_meta_data( '_nicepay_status_code', '00' );
		$order->update_meta_data( '_nicepay_paid_amount', $data['amt'] ?? $order->get_total() );
		$order->update_meta_data( '_nicepay_currency', $data['currency'] ?? 'IDR' );

		$trans_dt = $data['transDt'] ?? '';
		$trans_tm = $data['transTm'] ?? '';
		if ( $trans_dt || $trans_tm ) {
			$order->update_meta_data( '_nicepay_transaction_datetime', $trans_dt . $trans_tm );
		}

		if ( ! empty( $data['tXid'] ) ) {
			$order->update_meta_data( '_nicepay_tXid', $data['tXid'] );
		}

		$order->save();

		nicepay_log( 'Order status updated to paid for order ' . $order_id, 'info', $this->get_log_channel() );

		return true;
	}

	/**
	 * Validasi payload notifikasi Direct V2 sebelum inquiry API.
	 *
	 * @param WC_Order              $order Order WooCommerce.
	 * @param array<string, mixed>  $data  Data callback NICEPay.
	 * @param bool                  $require_callback_status Require callback status === '0'.
	 * @return true|WP_Error
	 */
	protected function validate_notification_payload( $order, $data, $require_callback_status = true ) {
		$order_id = $order->get_id();
		$channel  = $this->get_log_channel();

		if ( $order->get_payment_method() !== $this->id ) {
			nicepay_log( 'Notification rejected: payment method mismatch for order ' . $order_id, 'error', $channel );
			return new WP_Error( 'invalid_payment_method', __( 'Notification rejected: invalid payment method.', 'nicepay-payment-gateway-for-woocommerce' ) );
		}

		if ( $require_callback_status ) {
			if ( ! isset( $data['status'] ) || (string) $data['status'] !== '0' ) {
				$status = isset( $data['status'] ) ? (string) $data['status'] : 'missing';
				nicepay_log( 'Notification rejected: invalid status (' . $status . ') for order ' . $order_id, 'error', $channel );
				return new WP_Error( 'invalid_status', __( 'Notification rejected: invalid status.', 'nicepay-payment-gateway-for-woocommerce' ) );
			}
		}

		$callback_ref = trim( (string) ( $data['referenceNo'] ?? '' ) );
		$saved_ref    = trim( (string) $order->get_meta( '_nicepay_reference_no' ) );
		$expected_ref = '' !== $saved_ref ? $saved_ref : (string) $order_id;

		if ( '' === $callback_ref || $callback_ref !== $expected_ref ) {
			nicepay_log(
				'Notification rejected: referenceNo mismatch for order ' . $order_id . ' (expected=' . $expected_ref . ', callback=' . $callback_ref . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_reference', __( 'Notification rejected: invalid referenceNo.', 'nicepay-payment-gateway-for-woocommerce' ) );
		}

		$callback_txid = $this->get_notification_txid( $data );
		$saved_txid    = trim( (string) $order->get_meta( '_nicepay_tXid' ) );

		if ( '' === $callback_txid || '' === $saved_txid || $callback_txid !== $saved_txid ) {
			nicepay_log(
				'Notification rejected: tXid mismatch for order ' . $order_id . ' (expected=' . $saved_txid . ', callback=' . $callback_txid . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_txid', __( 'Notification rejected: invalid tXid.', 'nicepay-payment-gateway-for-woocommerce' ) );
		}

		return true;
	}

	/**
	 * Normalize transaction ID from Direct V2 / return URL payload.
	 *
	 * @param array<string, mixed> $data Callback data.
	 * @return string
	 */
	protected function get_notification_txid( $data ) {
		return trim(
			(string) (
				$data['tXid']
				?? $data['txId']
				?? $data['txid']
				?? $data['TXid']
				?? ''
			)
		);
	}

	/**
	 * Validasi payload notifikasi SNAP sebelum inquiry API.
	 *
	 * @param WC_Order              $order Order WooCommerce.
	 * @param array<string, mixed>  $data  Data callback NICEPay SNAP.
	 * @return true|WP_Error
	 */
	protected function validate_snap_notification_payload( $order, $data ) {
		$order_id = $order->get_id();
		$channel  = $this->get_log_channel();

		if ( $order->get_payment_method() !== $this->id ) {
			nicepay_log( 'SNAP notification rejected: payment method mismatch for order ' . $order_id, 'error', $channel );
			return new WP_Error( 'invalid_payment_method', __( 'Notification rejected: invalid payment method.', 'nicepay-payment-gateway-for-woocommerce' ) );
		}

		$callback_ref = trim(
			(string) (
				$data['originalPartnerReferenceNo']
				?? $data['trxId']
				?? ''
			)
		);
		$saved_ref    = trim( (string) $order->get_meta( '_nicepay_reference_no' ) );
		$expected_ref = '' !== $saved_ref ? $saved_ref : (string) $order_id;

		if ( '' === $callback_ref || $callback_ref !== $expected_ref ) {
			nicepay_log(
				'SNAP notification rejected: reference mismatch for order ' . $order_id . ' (expected=' . $expected_ref . ', callback=' . $callback_ref . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_reference', __( 'Notification rejected: invalid reference.', 'nicepay-payment-gateway-for-woocommerce' ) );
		}

		$callback_txid = trim(
			(string) (
				$data['originalReferenceNo']
				?? $data['paymentRequestId']
				?? ''
			)
		);
		$saved_txid    = trim( (string) $order->get_meta( '_nicepay_tXid' ) );

		if ( '' === $callback_txid || '' === $saved_txid || $callback_txid !== $saved_txid ) {
			nicepay_log(
				'SNAP notification rejected: tXid mismatch for order ' . $order_id . ' (expected=' . $saved_txid . ', callback=' . $callback_txid . ')',
				'error',
				$channel
			);
			return new WP_Error( 'invalid_txid', __( 'Notification rejected: invalid tXid.', 'nicepay-payment-gateway-for-woocommerce' ) );
		}

		return true;
	}

	/**
	 * Handle Direct V2 dbProcessUrl notification from NICEPay.
	 */
	protected function handle_direct_v2_notification() {
		nicepay_log( 'NICEPay callback received. Starting processing...', 'info', $this->get_log_channel() );
		status_header( 200 );

		$data = $this->parse_notification_payload();
		nicepay_log( 'Processed callback data: ' . wp_json_encode( $data ), 'info', $this->get_log_channel() );

		if ( empty( $data['referenceNo'] ) ) {
			nicepay_log( 'Missing referenceNo in callback', 'error', $this->get_log_channel() );
			wp_send_json_error( 'Invalid callback', 400 );
		}

		$order_id = $this->get_order_id_from_reference( $data['referenceNo'] );
		$order    = wc_get_order( $order_id );

		if ( ! $order ) {
			nicepay_log( 'Order not found for referenceNo: ' . $order_id, 'error', $this->get_log_channel() );
			wp_send_json_error( 'Order not found', 404 );
		}

		$validation = $this->validate_notification_payload( $order, $data );
		if ( is_wp_error( $validation ) ) {
			wp_send_json_error(
				array(
					'message' => $validation->get_error_message(),
				),
				400
			);
		}

		nicepay_log( 'Order found: ' . $order_id . ' — verifying via inquiry API', 'info', $this->get_log_channel() );
		$this->check_payment_status_directv2( $order_id, $data );

		wp_send_json( array( 'status' => 'received' ), 200 );
		exit;
	}

	/**
	 * Verify payment via NICEPay inquiry API. Override in gateway class.
	 *
	 * @param int                  $order_id Order ID.
	 * @param array<string, mixed> $data     Callback data.
	 */
	protected function check_payment_status_directv2( $order_id, $data ) {
		// Implemented in concrete gateway classes.
	}

	/**
	 * Settings page URL (classic section — works even when the main Payments list is React-only).
	 *
	 * @return string
	 */
	public function get_settings_url() {
		return SettingsUtils::wc_payments_settings_url(
			null,
			array(
				'section' => $this->id,
			)
		);
	}
}
