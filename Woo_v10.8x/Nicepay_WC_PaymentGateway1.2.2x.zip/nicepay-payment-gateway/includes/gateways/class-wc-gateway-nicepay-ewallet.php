﻿<?php
if (!defined('ABSPATH')) exit;
class Nicepay_Gateway_Ewallet extends Nicepay_Gateway_Base {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;

    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_ewallet';
        $this->method_title       = __('NICEPAY E-wallet', 'nicepay-payment-gateway-for-woocommerce');
        $this->has_fields         = false;
        $this->icon               = apply_filters( 'nicepay_gateway_ewallet_icon', '' );
        $this->method_description = __('Allows payments using NICEPAY E-wallet like OVO, DANA, LinkAja, and ShopeePay.', 'nicepay-payment-gateway-for-woocommerce');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        //$this->register_scheduled_hooks();
        
        // $this->api_endpoints = $this->get_api_endpoints();

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set
        $this->api_endpoints = $this->get_api_endpoints();
        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_ewallet', array($this, 'handle_callback'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'handle_return_url'));
        add_action('woocommerce_api_nicepay_linkaja_process', array($this, 'process_linkaja_payment'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-ewallet-container {
                margin: 12px 0;
                padding: 12px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-ewallet-header {
                margin-bottom: 8px;
                text-align: center;
                padding: 4px 0;
            }
            .nicepay-ewallet-image,
            .nicepay-ewallet-icon {
                display: block;
                max-width: 140px;
                width: auto;
                height: auto;
                margin: 0 auto;
            }
            .nicepay-ewallet-select {
                margin: 10px 0;
            }
            .nicepay-ewallet-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-ewallet-logos {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                gap: 15px;
                margin-bottom: 12px;
            }
            .nicepay-ewallet-logos img {
                height: 30px;
                width: auto;
            }
            .nicepay-ewallet-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-ewallet-classic-checkout', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-ewallet-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/ewallet-classic-checkout.js',
                array('jquery'),
                date('YmdHis'),
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-ewallet-classic-checkout',
            'nicepayEwalletClassicData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'enabled_mitra' => $this->get_ewallet_options(),
                'nonce' => wp_create_nonce('nicepay-ewallet-nonce')
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');
        $this->init_form_fields();
        $this->init_settings();
    
        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-ewallet-style',
            NICEPAY_PLUGIN_URL . '/assets/css/ewallet.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-ewallet-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/ewallet-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-ewallet-blocks-integration',
            'nicepayEwalletData',
            array(
                'enabled_mitra' => $this->get_ewallet_options(),
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('nicepay-ewallet-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'isEwallet' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        
        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/debit/payment-host-to-host',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/debit/status',
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'paymentDirectV2'       => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'title' => array(
                'title'       => __('Title', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __( 'NICEPay E-Wallet', 'nicepay-payment-gateway-for-woocommerce' ),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __( 'Bayar dengan e-wallet melalui NICEPay (OVO, DANA, LinkAja, ShopeePay).', 'nicepay-payment-gateway-for-woocommerce' ),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-payment-gateway-for-woocommerce'),
                'type' => 'text',
                'description' => '<small>' . __('Isikan dengan Merchant ID dari NICEPAY.', 'nicepay-payment-gateway-for-woocommerce') . '</small>',
                'default' => 'TNICEEW051',
            ),
            'CHANNEL-ID' => array(
                'title' => __('Channel ID', 'nicepay-payment-gateway-for-woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Channel ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'TNICEEW05101',
                //'default' => '',
            ),
            'client_secret' => array(
                'title'       => __('Client Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Client Key.', 'nicepay-payment-gateway-for-woocommerce'),
                //'default'     => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
                'default'     => '',
                'desc_tip'    => true,
            ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            'private_key' => array(
                'title'       => __('Private Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'textarea',
                'description' => __('Enter your NICEPAY Private Key.', 'nicepay-payment-gateway-for-woocommerce'),
                //'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
                'default'     => '',
                'desc_tip'    => true,
            ),
            'mitra_options' => array(
                'title'       => __('E-wallet Options', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'title',
                'description' => __('Select which e-wallets you want to enable.', 'nicepay-payment-gateway-for-woocommerce'),
            ),
            'enable_ovo' => array(
                'title'   => __('OVO', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable OVO Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
            'enable_dana' => array(
                'title'   => __('DANA', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable DANA Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
            'enable_linkaja' => array(
                'title'   => __('LinkAja', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable LinkAja Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
            'enable_shopeepay' => array(
                'title'   => __('ShopeePay', 'nicepay-payment-gateway-for-woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable ShopeePay Payment', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'yes'
            ),
        );
    }

    /**
     * Get available e-wallet options
     */
    public function get_ewallet_options() {
        $available_options = array();

        if ($this->get_option('enable_ovo') === 'yes') {
            $available_options[] = array('value' => 'OVOE', 'label' => 'OVO');
        }
        if ($this->get_option('enable_dana') === 'yes') {
            $available_options[] = array('value' => 'DANA', 'label' => 'DANA');
        }
        if ($this->get_option('enable_linkaja') === 'yes') {
            $available_options[] = array('value' => 'LINK', 'label' => 'LINK AJA');
        }
        if ($this->get_option('enable_shopeepay') === 'yes') {
            $available_options[] = array('value' => 'ESHP', 'label' => 'ShopeePay');
        }
        return $available_options;
    }

    /**
     * Handle the Ajax request to set the selected mitra
     */
    public function set_nicepay_mitra() {
        nicepay_log('AJAX set_nicepay_mitra called', 'info', 'ewallet');

        check_ajax_referer('nicepay-ewallet-nonce', 'nonce');
        
        $mitra = '';
        if ( isset( $_POST['mitra_code'] ) && '' !== (string) $_POST['mitra_code'] ) {
            $mitra = sanitize_text_field( wp_unslash( $_POST['mitra_code'] ) );
        } elseif ( isset( $_POST['mitra'] ) && '' !== (string) $_POST['mitra'] ) {
            $mitra = sanitize_text_field( wp_unslash( $_POST['mitra'] ) );
        }
        if ( '' === $mitra ) {
            nicepay_log('Mitra code not provided in AJAX', 'error', 'ewallet');
            wp_send_json_error('Mitra not specified');
        }
        WC()->session->set('nicepay_selected_mitra', $mitra);
        
        nicepay_log('Mitra saved to session via AJAX: ' . $mitra, 'info', 'ewallet');

        wp_send_json_success('Mitra selection saved: ' . $mitra);
    }

    public function is_available() {
        $is_available = ('yes' === $this->enabled);
        if ('yes' !== $this->enabled) {
            return false;
        }

        if ($is_available) {
            $available_mitra = $this->get_ewallet_options();
            if (empty($available_mitra)) {
                return false;
            }
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    /**
     * Output payment fields
     */
   public function payment_fields()
{
    $i18n = function_exists( 'nicepay_get_checkout_i18n_strings' ) ? nicepay_get_checkout_i18n_strings() : array();
    echo '<div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">';
    echo '<img src="' . esc_url( NICEPAY_PLUGIN_URL . '/assets/images/ewalletL.png' ) . '" alt="' . esc_attr( $i18n['alt_ewallet'] ?? __( 'E-Wallet', 'nicepay-payment-gateway-for-woocommerce' ) ) . '" style="height: 24px; width: auto;">';
    if ( ! empty( $this->description ) ) {
        echo '<span>' . wp_kses_post( $this->description ) . '</span>';
    }
    echo '</div>';
    
    $available_mitras = $this->get_ewallet_options();
        
        if (!empty($available_mitras)) {
            echo '<div class="nicepay-ewallet-container">';
            echo '<div class="nicepay-ewallet-select">';
            echo '<label for="nicepay_mitra">' . esc_html( $i18n['select_ewallet'] ?? __( 'Pilih E-wallet:', 'nicepay-payment-gateway-for-woocommerce' ) ) . ' <span class="required">*</span></label>';
            echo '<select name="nicepay_mitra" id="nicepay_mitra" class="input-text" required>';
            echo '<option value="">' . esc_html( $i18n['select_ewallet_placeholder'] ?? __( 'Pilih E-wallet', 'nicepay-payment-gateway-for-woocommerce' ) ) . '</option>';
            
            foreach ($available_mitras as $mitra) {
                echo '<option value="' . esc_attr($mitra['value']) . '">' . esc_html($mitra['label']) . '</option>';
            }
            
            echo '</select>';
            echo '</div>';
            echo '<p class="nicepay-ewallet-instruction">' . esc_html( $i18n['select_ewallet_instruction'] ?? __( 'Silakan pilih e-wallet untuk pembayaran Anda.', 'nicepay-payment-gateway-for-woocommerce' ) ) . '</p>';

             // 🔥 TAMBAHAN: Field nomor HP untuk OVO (hidden by default)
            echo '<div class="nicepay-ovo-phone-field" id="nicepay_ovo_phone_container" style="display:none; margin-top: 15px;">';
            echo '<label for="nicepay_ovo_phone">' . __('Nomor HP OVO:', 'nicepay-payment-gateway-for-woocommerce') . ' <span class="required">*</span></label>';
            echo '<input type="tel" name="nicepay_ovo_phone" id="nicepay_ovo_phone" class="input-text" placeholder="08xxxxxxxxxx" pattern="[0-9]{10,13}" />';
            echo '<small style="display:block; margin-top:5px; color:#666;">' . __('Masukkan nomor HP yang terdaftar di OVO (contoh: 08123456789)', 'nicepay-payment-gateway-for-woocommerce') . '</small>';
            echo '</div>';
            
            // Tampilkan logo mitra
            echo '<div class="nicepay-ewallet-logos">';
            foreach ($available_mitras as $mitra) {
                $logo_file = strtolower($mitra['label']);
                $logo_file = str_replace(' ', '', $logo_file); // Hilangkan spasi untuk nama file
                echo '<img src="' . esc_url(NICEPAY_PLUGIN_URL . '/assets/images/' . $logo_file . '.svg') . '" alt="' . esc_attr($mitra['label']) . '">';
            }
            echo '</div>';
            
            echo '</div>';

             // 🔥 TAMBAHAN: JavaScript untuk show/hide field nomor HP
            ?>
            <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('#nicepay_mitra').on('change', function() {
                    var selectedMitra = $(this).val();
                    var ovoPhoneContainer = $('#nicepay_ovo_phone_container');
                    var ovoPhoneInput = $('#nicepay_ovo_phone');
                    
                    if (selectedMitra === 'OVOE') {
                        ovoPhoneContainer.slideDown();
                        ovoPhoneInput.prop('required', true);
                    } else {
                        ovoPhoneContainer.slideUp();
                        ovoPhoneInput.prop('required', false);
                        ovoPhoneInput.val(''); // Clear value
                    }
                });
            });
            </script>
            <?php
        }
}
    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment Ewallet for order $order_id", 'info', 'ewallet');

        return $this->process_blocks_payment($order_id);
    }

    /**
     * Process payment for classic checkout
     */
    public function process_classic_payment($order_id) {
        nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'ewallet');
        
        $order = wc_get_order($order_id);
        if (!$order) {
            nicepay_log("Order not found in process_classic_payment: " . $order_id, 'error', 'ewallet');
            wc_add_notice(__('Order not found.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        $order->update_meta_data('_nicepay_payment_method', 'ewallet');
        $order->save();

        $selected_mitra = WC()->session->get( 'nicepay_selected_mitra' );
        if ( empty( $selected_mitra ) && isset( $_POST['nicepay_mitra'] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified by WooCommerce checkout.
            $selected_mitra = sanitize_text_field( wp_unslash( $_POST['nicepay_mitra'] ) );
        }
        nicepay_log("Selected mitra from POST in classic payment: " . $selected_mitra, 'info', 'ewallet');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an e-wallet payment method.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
            nicepay_log('No e-wallet selected in classic payment', 'error', 'ewallet');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        // Validasi dan simpan nomor HP untuk OVO
        if ($selected_mitra === 'OVOE') {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified by WooCommerce checkout.
            $ovo_phone = isset( $_POST['nicepay_ovo_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['nicepay_ovo_phone'] ) ) : '';
            nicepay_log("OVO phone from POST: " . $ovo_phone, 'info', 'ewallet');
            
            if (empty($ovo_phone)) {
                wc_add_notice(__('Nomor HP OVO wajib diisi.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
            
            // Validasi format nomor HP (harus 08xxx atau 628xxx, 10-13 digit)
            if (!preg_match('/^(08|628)[0-9]{8,11}$/', $ovo_phone)) {
                wc_add_notice(__('Format nomor HP OVO tidak valid. Gunakan format: 08xxxxxxxxxx', 'nicepay-payment-gateway-for-woocommerce'), 'error');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
            
            // Simpan nomor HP OVO ke session
            WC()->session->set('nicepay_ovo_phone', $ovo_phone);
            nicepay_log("OVO phone number saved to session: " . $ovo_phone, 'info', 'ewallet');
        }
        
        // Simpan mitra ke session untuk proses Direct V2
        WC()->session->set('nicepay_selected_mitra', $selected_mitra);
        nicepay_log("Mitra saved to session in classic payment: " . $selected_mitra, 'info', 'ewallet');

        // Tentukan mode: SNAP (client_secret + private_key) atau Direct V2
        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            nicepay_log("(SNAP) classic payment flow detected for order " . $order_id, 'info', 'ewallet');

            try {
                $access_token = $this->get_access_token();
                $ewallet_data = $this->create_registration($order, $access_token);
                
                if (!isset($ewallet_data['responseCode'])) {
                    throw new Exception(__('Invalid response from payment gateway', 'nicepay-payment-gateway-for-woocommerce'));
                }
                nicepay_log("E-wallet registration response (classic SNAP): " . json_encode($ewallet_data), 'info', 'ewallet');

                if ($ewallet_data['responseCode'] === '2005400' && $ewallet_data['responseMessage'] === 'Successful') {
                    // translators: 1: reference number, 2: transaction ID.
                    $order->add_order_note( sprintf(
                        __( "NICEPay E-Wallet. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s", 'nicepay-payment-gateway-for-woocommerce' ),
                        $ewallet_data['partnerReferenceNo'],
                        $ewallet_data['referenceNo']
                    ) );

                    $order->update_meta_data('_nicepay_tXid', $ewallet_data['referenceNo']);
                    $order->update_meta_data('_nicepay_reference_no', $ewallet_data['partnerReferenceNo']);
                    $order->update_meta_data('_nicepay_mitra', $selected_mitra);
                    $order->save();
                    
                    if ($selected_mitra === 'OVOE') {
                        nicepay_log("Checking payment status for OVO payment (classic SNAP)...", 'info', 'ewallet');
                        $status_response = $this->check_payment_status($order, $ewallet_data['partnerReferenceNo']);
                        nicepay_log("Status check response (classic SNAP): " . json_encode($status_response), 'info', 'ewallet');
                        $this->update_order_status($order, $status_response);

                        return array(
                            'result' => 'success',
                            'redirect' => $this->get_return_url($order)
                        );
                    } elseif ($selected_mitra === 'LINK' && isset($ewallet_data['additionalInfo']['redirectToken'])) {
                        nicepay_log("Processing LinkAja payment (classic SNAP)...", 'info', 'ewallet');
                        $redirectUrl = $ewallet_data['webRedirectUrl'] . "?Message=" . $ewallet_data['additionalInfo']['redirectToken'];
                        nicepay_log("LinkAja Redirect URL (classic SNAP): " . $redirectUrl, 'info', 'ewallet');

                        $order->update_status('pending', sprintf(
                            // translators: %s: e-wallet provider name.
                            __('Menunggu pembayaran %s', 'nicepay-payment-gateway-for-woocommerce'),
                            $selected_mitra
                        ));

                        return array(
                            'result' => 'success',
                            'redirect' => $redirectUrl
                        );
                    } elseif (isset($ewallet_data['webRedirectUrl'])) {
                        nicepay_log("E-wallet webRedirectUrl (classic SNAP): " . $ewallet_data['webRedirectUrl'], 'info', 'ewallet');
                        $order->update_meta_data('_nicepay_redirect_url', $ewallet_data['webRedirectUrl']);
                        $order->update_status('pending', sprintf(
                            // translators: %s: e-wallet provider name.
                            __('Menunggu pembayaran %s', 'nicepay-payment-gateway-for-woocommerce'),
                            $selected_mitra
                        ));
                        $order->save();

                        return array(
                            'result' => 'success',
                            'redirect' => $ewallet_data['webRedirectUrl']
                        );
                    }
                }

                WC()->cart->empty_cart();
                throw new Exception(sprintf(
                    // translators: %s: error message from payment gateway.
                    __('Payment gateway error: %s', 'nicepay-payment-gateway-for-woocommerce'),
                    $ewallet_data['responseMessage'] ?? 'Unknown error'
                ));
            } catch (Exception $e) {
                wc_add_notice(
                    // translators: %s: error message.
                    sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in classic SNAP payment: " . $e->getMessage(), 'error', 'ewallet');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        } else {
            // Direct V2 flow untuk classic checkout
            nicepay_log("(Direct V2) classic payment flow detected for order " . $order_id, 'info', 'ewallet');

            try {
                $ewallet_data = $this->process_directV2($order_id);

                if (!isset($ewallet_data['resultCd']) || $ewallet_data['resultCd'] !== '0000') {
                    throw new Exception(sprintf(
                        // translators: %s: error message from payment gateway.
                        __('Failed to create eWallet transaction: %s', 'nicepay-payment-gateway-for-woocommerce'),
                        $ewallet_data['resultMsg'] ?? 'Unknown error'
                    ));
                }

                nicepay_log("(Direct V2) E-wallet registration response (classic): " . json_encode($ewallet_data), 'info', 'ewallet');

                $paymentUrl = $this->process_paymentV2($order_id, $ewallet_data);

                WC()->cart->empty_cart();

                return array(
                    'result'   => 'success',
                    'redirect' => $paymentUrl,
                );
            } catch (Exception $e) {
                wc_add_notice(
                    // translators: %s: error message.
                    sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in classic Direct V2 payment: " . $e->getMessage(), 'error', 'ewallet');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order $order_id", 'info', 'ewallet');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'ewallet');
        $order->save();

        $selected_mitra = WC()->session->get('nicepay_selected_mitra');
        nicepay_log("Selected mitra from session: " . $selected_mitra, 'info', 'ewallet');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an e-wallet payment method.', 'nicepay-payment-gateway-for-woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            try {
                $access_token = $this->get_access_token();
                $ewallet_data = $this->create_registration($order, $access_token);
                
                if (!isset($ewallet_data['responseCode'])) {
                    throw new Exception(__('Invalid response from payment gateway', 'nicepay-payment-gateway-for-woocommerce'));
                }
                nicepay_log("E-wallet registration response: " . $ewallet_data, 'info', 'ewallet');

                if ($ewallet_data['responseCode'] === '2005400' && $ewallet_data['responseMessage'] === 'Successful') {
                    
                    // translators: 1: reference number, 2: transaction ID.
                    $order->add_order_note( sprintf(
                        __( "NICEPay E-Wallet. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s", 'nicepay-payment-gateway-for-woocommerce' ),
                        $ewallet_data['partnerReferenceNo'],
                        $ewallet_data['referenceNo']
                    ) );

                    // Simpan data response ke order meta
                    $order->update_meta_data('_nicepay_tXid', $ewallet_data['referenceNo']);
                    $order->update_meta_data('_nicepay_reference_no', $ewallet_data['partnerReferenceNo']);
                    $order->update_meta_data('_nicepay_mitra', $selected_mitra);
                    $order->save();
                    
                    // Return success with redirect URL
                    if ($selected_mitra === 'OVOE') {
                        // Untuk OVO, check status setelah mendapat response sukses
                        nicepay_log("Checking payment status for OVO payment...", 'info', 'ewallet');
                        $status_response = $this->check_payment_status($order, $ewallet_data['partnerReferenceNo']);
                        nicepay_log("Status check response: " . $status_response, 'info', 'ewallet');

                        // Update order status berdasarkan response check status
                        $this->update_order_status($order, $status_response);

                        return array(
                            'result' => 'success',
                            'redirect' => $this->get_return_url($order)
                        );
                    } elseif ($selected_mitra === 'LINK' && isset($ewallet_data['additionalInfo']['redirectToken'])) {
                        nicepay_log("Processing LinkAja payment...", 'info', 'ewallet');
                        
                        // Ensure correct URL format
                        $redirectUrl = $ewallet_data['webRedirectUrl'] . "?Message=" . $ewallet_data['additionalInfo']['redirectToken'];
                        nicepay_log("LinkAja Redirect URL: " . $redirectUrl, 'info', 'ewallet');
                        
                        $order->update_status('pending', sprintf(
                            // translators: %s: e-wallet provider name.
                            __('Menunggu pembayaran %s', 'nicepay-payment-gateway-for-woocommerce'),
                            $selected_mitra
                        ));

                        return array(
                            'result' => 'success',
                            'redirect' => $redirectUrl
                        );
                    } elseif (isset($ewallet_data['webRedirectUrl'])) {
                        // Untuk DANA, Shopee Pay
                        nicepay_log("E-wallet webRedirectUrl: " . $ewallet_data['webRedirectUrl'], 'info', 'ewallet');
                        $order->update_meta_data('_nicepay_redirect_url', $ewallet_data['webRedirectUrl']);
                        $order->update_status('pending', sprintf(
                            // translators: %s: e-wallet provider name.
                            __('Menunggu pembayaran %s', 'nicepay-payment-gateway-for-woocommerce'),
                            $selected_mitra
                        ));
                        $order->save();

                        return array(
                            'result' => 'success',
                            'redirect' => $ewallet_data['webRedirectUrl']
                        );
                    }
                }
                
                WC()->cart->empty_cart();
                throw new Exception(sprintf(
                    // translators: %s: error message from payment gateway.
                    __('Payment gateway error: %s', 'nicepay-payment-gateway-for-woocommerce'),
                    $ewallet_data['responseMessage'] ?? 'Unknown error'
                ));

            } catch (Exception $e) {
            wc_add_notice(
                // translators: %s: error message.
                sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                'error'
            );
                nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'ewallet');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        } else {
            try {
                $ewallet_data = $this->process_directV2($order_id);

                if (!isset($ewallet_data['resultCd']) || $ewallet_data['resultCd'] !== '0000') {
                    throw new Exception(sprintf(
                        // translators: %s: error message from payment gateway.
                        __('Failed to create eWallet transaction: %s', 'nicepay-payment-gateway-for-woocommerce'),
                        $ewallet_data['resultMsg'] ?? 'Unknown error'
                    ));                
                }
                nicepay_log("(Direct V2) E-wallet registration response: " . json_encode($ewallet_data), 'info', 'ewallet');
                
                $paymentUrl = $this->process_paymentV2($order_id,$ewallet_data);
                WC()->cart->empty_cart();

                return [
                    'result'   => 'success',
                    'redirect' => $paymentUrl,
                ];
            } catch (Exception $e) {
                wc_add_notice(
                    // translators: %s: error message.
                    sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'ewallet');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    /**
     * Process LinkAja payment with redirect
     */
    public function process_linkaja_payment() {
        if (!isset($_GET['url']) || !isset($_GET['token'])) {
            wp_die('Invalid request');
        }

        $url = sanitize_text_field($_GET['url']);
        $token = sanitize_text_field($_GET['token']);

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Processing LinkAja Payment</title>
            <style>
                body { 
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding: 20px;
                    background: #f5f5f5;
                    margin: 0;
                }
                .container {
                    max-width: 500px;
                    margin: 40px auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                .spinner {
                    display: inline-block;
                    width: 50px;
                    height: 50px;
                    margin: 20px auto;
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid #ff0000;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                h2 {
                    color: #333;
                    margin-bottom: 20px;
                }
                p {
                    color: #666;
                    margin: 15px 0;
                }
                button {
                    background: #ff0000;
                    color: white;
                    border: none;
                    padding: 12px 25px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 16px;
                    margin-top: 20px;
                }
                button:hover {
                    background: #e60000;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Menghubungkan ke LinkAja</h2>
                <div class="spinner"></div>
                <p>Mohon tunggu, Anda akan diarahkan ke halaman pembayaran LinkAja...</p>
                <form id="linkaja_form" method="POST" action="<?php echo esc_url($url); ?>">
                    <input type="hidden" name="redirectToken" value="<?php echo esc_attr($token); ?>">
                </form>
                <script>
                    // Submit form setelah semua konten dimuat
                    window.onload = function() {
                        setTimeout(function() {
                            document.getElementById('linkaja_form').submit();
                        }, 1000);
                    };
                </script>
                <noscript>
                    <p>Jika Anda tidak dialihkan secara otomatis, silakan klik tombol di bawah ini:</p>
                    <button type="submit" form="linkaja_form">Lanjutkan ke LinkAja</button>
                </noscript>
            </div>
        </body>
        </html>
        <?php
        exit;
    }

    /**
     * Get access token from NICEPAY
     */
    private function get_access_token() {
        nicepay_log("Starting get_access_token process", 'info', 'ewallet');

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $timestamp = $this->generate_formatted_timestamp();
        $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;

        nicepay_log("X_CLIENT_KEY: " . $X_CLIENT_KEY, 'info', 'ewallet');
        nicepay_log("Timestamp: " . $timestamp, 'info', 'ewallet');
        nicepay_log("StringToSign: " . $stringToSign, 'info', 'ewallet');
        
        $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
            $this->get_option('private_key') . "\r\n" .
            "-----END RSA PRIVATE KEY-----";
        
        nicepay_log("Private Key Structure: " . substr($privatekey, 0, 100) . "...", 'info', 'ewallet');
        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);
        
        if ($pKey === false) {
            $error = openssl_error_string();
            nicepay_log("Failed to get private key. OpenSSL Error: " . $error, 'error', 'ewallet');
            throw new Exception("Invalid private key: " . $error);
        }
        
        $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        
        if ($sign_result === false) {
            $error = openssl_error_string();
            nicepay_log("Failed to create signature. OpenSSL Error: " . $error, 'error', 'ewallet');
            throw new Exception("Failed to create signature: " . $error);
        }
        
        $signature = base64_encode($binary_signature);
        nicepay_log("Generated Signature: " . $signature, 'info', 'ewallet');
        
        $jsonData = array(
            "grantType" => "client_credentials"
        );
        
        $jsonDataEncode = json_encode($jsonData);
        nicepay_log("Request Body JSON: " . $jsonDataEncode, 'info', 'ewallet');
        
        $requestToken = $this->api_endpoints['access_token'];
        nicepay_log("Request URL: " . $requestToken, 'info', 'ewallet');
        
        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SIGNATURE'  => $signature,
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP'  => $timestamp
            ),
            'body'    => $jsonDataEncode,
        );

        nicepay_log("url access_token: " . $this->api_endpoints['access_token'], 'info', 'ewallet');
        nicepay_log("Request headers for get_access_token: " . json_encode($args['headers']), 'info', 'ewallet');
        nicepay_log("Request body for get_access_token: " . json_encode($jsonDataEncode), 'info', 'ewallet');
        
        $response = wp_remote_post($requestToken, $args);
        
        if (is_wp_error($response)) {
            nicepay_log("Error in get_access_token: " . $response->get_error_message(), 'error', 'ewallet');
            throw new Exception($response->get_error_message());
        }
         
        $body = json_decode(wp_remote_retrieve_body($response));
        nicepay_log("Access token response: " . json_encode($body), 'info', 'ewallet');
        
        if (!isset($body->accessToken)) {
            nicepay_log("Invalid access token response: " . json_encode($body), 'info', 'ewallet');
            throw new Exception(__('Invalid access token response', 'nicepay-payment-gateway-for-woocommerce'));
        }
        
        nicepay_log("Successfully obtained access token", 'info', 'ewallet');
        WC()->session->set('accessToken', $body->accessToken);
        
        return $body->accessToken;
    }

    /**
     * Create payment registration with NICEPAY
     */
    private function create_registration($order, $access_token) {
        nicepay_log("Starting create_registration for order " . $order->get_id(), 'info', 'ewallet');

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $timestamp = date('YmdHis');
        $channel = $this->get_option('CHANNEL-ID');
        $external = $timestamp . rand(1000, 9999);
        $original_phone = $order->get_billing_phone();
        $beneficiaryPhone = preg_replace('/^\+62/', '0', $original_phone);
        $selected_mitra = WC()->session->get('nicepay_selected_mitra', '');

        nicepay_log("Selected mitra: " . $selected_mitra, 'info', 'ewallet');

        if (empty($selected_mitra)) {
            throw new Exception(__('No e-wallet selected. Please choose an e-wallet payment method.', 'nicepay-payment-gateway-for-woocommerce'));
        }

        // 🔥 TAMBAHAN: Gunakan nomor HP OVO dari session jika ada
    if ($selected_mitra === 'OVOE') {
        $ovo_phone = WC()->session->get('nicepay_ovo_phone', '');
        if (!empty($ovo_phone)) {
            $beneficiaryPhone = $ovo_phone;
            nicepay_log("Using OVO phone number from session: " . $beneficiaryPhone, 'info', 'ewallet');
        }
    }

        $cart_data = (string) $this->prepare_cart_data($order);
        $newBody = [
            "partnerReferenceNo" => $order->get_id(),
            "merchantId" => $X_CLIENT_KEY,
            "subMerchantId" => "",
            "externalStoreId" => "",
            "validUpTo" => "",
            "pointOfInitiation" => "MOBILE_APP",
            "amount" => [
                "value" => number_format($order->get_total(), 2, '.', ''),
                "currency" => $order->get_currency()
            ],
            "urlParams" => [
                [
                    "url" => home_url('/wc-api/wc_gateway_nicepay_ewallet'),
                    "type" => "PAY_NOTIFY",
                    "isDeeplink" => "Y" 
                ],
                [
                    "url" => $this->get_return_url($order),
                    "type" => "PAY_RETURN",
                    "isDeeplink" => "Y" 
                ]
            ],
            "additionalInfo" => [
                "mitraCd" => $selected_mitra,
                "goodsNm" => $this->get_order_items_names($order),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $beneficiaryPhone,
                "customerEmail" => $order->get_billing_email(), 
                "cartData" => $cart_data, 
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_ewallet'),
                "callBackUrl" => $this->get_return_url($order),
                "msId" => ""
            ]
        ];
        nicepay_log("Request body structure: " . $newBody, 'info', 'ewallet');

        $stringBody = json_encode($newBody, JSON_UNESCAPED_SLASHES);;
        $hashbody = strtolower(hash("SHA256", $stringBody));

        $strigSign = "POST:/api/v1.0/debit/payment-host-to-host:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type'   => 'application/json',
                'X-SIGNATURE'    => base64_encode($bodyHasing),
                'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                'X-TIMESTAMP'    => $X_TIMESTAMP,
                'Authorization'  => "Bearer " . $access_token,
                'CHANNEL-ID'     => $channel,
                'X-EXTERNAL-ID'  => $external,
                'X-PARTNER-ID'   => $X_CLIENT_KEY
            ),
            'body'    => $stringBody,
        );
        $headerBodyEwallet = json_encode($args['headers']);

        nicepay_log("url create_registration: " . $this->api_endpoints['registration'], 'info', 'ewallet');
        nicepay_log("Request headers for create_registration: " . $headerBodyEwallet, 'info', 'ewallet');
        nicepay_log("Request body for create_registration: " . $stringBody, 'info', 'ewallet');

        $response = wp_remote_post($this->api_endpoints['registration'], $args);

        if (is_wp_error($response)) {
            nicepay_log("Error in create_registration: " . $response->get_error_message(), 'error', 'ewallet');
            throw new Exception($response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("Create registration response: " . json_encode($response_body), 'info', 'ewallet');

        if (!isset($response_body['responseCode']) || $response_body['responseCode'] !== '2005400') {
            throw new Exception(
                sprintf(
                    // translators: %s: error message from payment gateway.
                    __('Failed to create registration: %s', 'nicepay-payment-gateway-for-woocommerce'),
                    $response_body['responseMessage'] ?? __('Unknown error', 'nicepay-payment-gateway-for-woocommerce')
                )
            );
        } 

        return $response_body;
    }

    /**
     * Build mandatory goods_detail for NICEPay cartData (must not be empty).
     *
     * @param WC_Product|false $product Product object.
     * @param WC_Order_Item    $item    Order line item.
     * @return string
     */
    private function get_goods_detail_for_cart($product, $item) {
        $detail = '';

        if ($product) {
            $detail = wp_strip_all_tags((string) $product->get_short_description());
            if ('' === $detail) {
                $detail = wp_strip_all_tags((string) $product->get_description());
            }
        }

        if ('' === $detail) {
            $detail = (string) $item->get_name();
        }

        return substr($detail, 0, 50);
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = (float) $item->get_total() / max(1, (int) $item->get_quantity());
            $unit_price_formatted = number_format($unit_price, 2, '.', '');
            
            $cart_items[] = array(
                'img_url' => wp_get_attachment_url($product->get_image_id()) ?: wc_placeholder_img_src(),
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => $this->get_goods_detail_for_cart($product, $item),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string) $unit_price_formatted,
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => (string) $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += (int) round($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price_formatted}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = (float) $order->get_shipping_total();
            $shipping_amount_formatted = number_format($shipping_amount, 2, '.', '');
            $cart_items[] = array(
                'img_url' => wp_get_attachment_url($product->get_image_id()) ?: wc_placeholder_img_src(),
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string) $shipping_amount_formatted,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => "1",
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += (int) round($shipping_amount);
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $tax_amount_formatted = number_format((float) $tax_difference, 2, '.', '');
            $cart_items[] = array(
                'img_url' => wp_get_attachment_url($product->get_image_id()) ?: wc_placeholder_img_src(),
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string) $tax_amount_formatted,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => "1",
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => (string) count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    /**
     * Get cart data
     */
    private function get_cart_data($order) {
        $cart_data = [
            "count" => $order->get_item_count(),
            "item" => []
        ];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $cart_data["item"][] = [
                "img_url" => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
                "goods_name" => $item->get_name(),
                "goods_detail" => $this->get_goods_detail_for_cart($product, $item),
                "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
                "goods_quantity" => $item->get_quantity()
            ];
        }

        return $cart_data;
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    /**
     * Check payment status with NICEPAY
     */
    private function check_payment_status($order, $reference_no) {
        nicepay_log("(SNAP) Starting check_payment_status for reference_no: " . $reference_no, 'info', 'ewallet');
        try {
            $access_token = $this->get_access_token();
            
            $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
            $secretClient = $this->get_option('client_secret');
            $X_TIMESTAMP = $this->generate_formatted_timestamp();
            $timestamp = date('YmdHis');
            $channel = $this->get_option('CHANNEL-ID');
            $external = $timestamp . rand(1000, 9999);
    
            $newBody = [
                "merchantId" => $X_CLIENT_KEY,
                "subMerchantId" => "",
                "originalPartnerReferenceNo" => $reference_no,
                "originalReferenceNo" => $order->get_meta('_nicepay_tXid'),
                "serviceCode" => "54",
                "transactionDate" => date('Y-m-d\TH:i:sP'), 
                "externalStoreId" => "",
                "amount" => [
                    "value" => number_format($order->get_total(), 2, '.', ''),
                    "currency" => $order->get_currency()
                ],
                "additionalInfo" => (object)[]
            ];
    
            $stringBody = json_encode($newBody, JSON_UNESCAPED_SLASHES);
            $hashbody = strtolower(hash("SHA256", $stringBody));
    
            $strigSign = "POST:/api/v1.0/debit/status:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
    
            $args = array(
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type'   => 'application/json',
                    'X-SIGNATURE'    => base64_encode($bodyHasing),
                    'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                    'X-TIMESTAMP'    => $X_TIMESTAMP,
                    'Authorization'  => "Bearer " . $access_token,
                    'CHANNEL-ID'     => $channel,
                    'X-EXTERNAL-ID'  => $external,
                    'X-PARTNER-ID'   => $X_CLIENT_KEY
                ),
                'body'    => $stringBody,
            );
    
            nicepay_log("url check_payment_status: " . $this->api_endpoints['check_status_url'], 'info', 'ewallet');
            nicepay_log("Request headers for check_payment_status: " . json_encode($args['headers']), 'info', 'ewallet');
            nicepay_log("Request body for check_payment_status: " . $stringBody, 'info', 'ewallet');
            
            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
    
            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }
    
            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            nicepay_log("Check status response: " . json_encode($response_body), 'info', 'ewallet');

            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(
                // translators: %s: error message.
                sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in check_payment_status: " . $e->getMessage(), 'info', 'ewallet');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }

    }

    /**
     * Update order status based on response from NICEPAY
     */
    private function update_order_status($order, $status_response) {
        nicepay_log ("status_response: " . json_encode($status_response),'info','ewallet');

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            if (!isset($status_response['responseCode'])) {
                nicepay_log("Invalid status response: missing responseCode", 'info', 'ewallet');
                return false;
            }
        
            // Pastikan response sukses dan ada latestTransactionStatus
            if ($status_response['responseCode'] === '2005500' && isset($status_response['latestTransactionStatus'])) {
                nicepay_log("Updating order status. Latest Transaction Status: " . $status_response['latestTransactionStatus'], 'info', 'ewallet');

                //$order->payment_complete();
                $order->update_status('processing', 'Pembayaran EWALLET berhasil.');
                $order->update_meta_data('_nicepay_status', $status_response['transactionStatusDesc']);
                $order->update_meta_data('_nicepay_status_code', $status_response['latestTransactionStatus']);
                $order->update_meta_data('_nicepay_paid_amount', $status_response['amount']['value']);
                $order->update_meta_data('_nicepay_currency', $status_response['amount']['currency']);
                $order->update_meta_data('_nicepay_transaction_datetime', $status_response['additionalInfo']['transactionDateTime']);
                $order->save();
            } else {
                nicepay_log("Invalid or unsuccessful status response: " . $status_response, 'error', 'ewallet');
                return false;
            }
        } else {
            if (!isset($status_response['resultCd']) || $status_response['resultCd'] !== '0000') {
                throw new Exception(sprintf(
                    // translators: %s: error message from payment gateway.
                    __('Failed to create Ewallet transaction: %s', 'nicepay-payment-gateway-for-woocommerce'),
                    $status_response['resultMsg'] ?? 'Unknown error'
                ));
            }

            if($status_response['status'] == '0') {
                //$order->payment_complete();
                $order->update_status('processing', 'Pembayaran EWALLET berhasil.');
                $order->update_meta_data('_nicepay_status', 'Success');
                $order->update_meta_data('_nicepay_status_code', '00');
                $order->update_meta_data('_nicepay_paid_amount', $status_response['amt']);
                $order->update_meta_data('_nicepay_currency', $status_response['currency']);
                $order->update_meta_data('_nicepay_transaction_datetime', $status_response['transDt'] . $status_response['transTm']);
                $order->save();

                nicepay_log('Order meta updated', 'info', 'ewallet');
            }
        }
    }

    /**
     * Handle return URL after payment
     */
    public function handle_return_url($order_id) {
        nicepay_log("Ewallet handle_return_url: " . $order_id, 'info', 'ewallet');
        $order = wc_get_order($order_id);
        if (!$order || $order->get_status() !== 'pending') {
            return;
        }
    }

    /**
     * Whether SNAP credentials are configured for inquiry API.
     *
     * @return bool
     */
    private function has_snap_credentials() {
        return !empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'));
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_callback() {
        nicepay_log('NICEPay ewallet callback received. Starting processing...', 'info', 'ewallet');
        status_header(200);

        $decoded_post = $this->parse_notification_payload();
        if (empty($decoded_post) && !empty($_GET)) {
            $decoded_post = wp_unslash($_GET);
            nicepay_log('Using GET parameters for ewallet callback', 'info', 'ewallet');
        }

        nicepay_log('Processed callback data: ' . wp_json_encode($decoded_post), 'info', 'ewallet');

        $headers   = function_exists('getallheaders') ? getallheaders() : array();
        $signature = is_array($headers) ? ($headers['X-SIGNATURE'] ?? null) : null;

        // Redirect dari halaman pembayaran NICEPay (user browser).
        if (isset($decoded_post['resultCd']) && empty($signature) && empty($decoded_post['merchantToken'])) {
            nicepay_log('Handle redirect from ewallet payment page', 'info', 'ewallet');

            if (empty($decoded_post['referenceNo'])) {
                wp_die('Invalid callback', 'Invalid Callback', array('response' => 400));
            }

            $order_id = $this->get_order_id_from_reference($decoded_post['referenceNo']);
            $order    = wc_get_order($order_id);

            if (!$order) {
                nicepay_log('Order not found for referenceNo: ' . $decoded_post['referenceNo'], 'error', 'ewallet');
                wp_die('Order not found', 'Order Not Found', array('response' => 404));
            }

            if ($decoded_post['resultCd'] === '0000') {
                $validation = $this->validate_notification_payload($order, $decoded_post, false);
                if (is_wp_error($validation)) {
                    nicepay_log('Ewallet return validation failed: ' . $validation->get_error_message(), 'error', 'ewallet');
                } elseif ($this->has_snap_credentials()) {
                    $status_response = $this->check_payment_status($order, $decoded_post['referenceNo']);
                    $this->update_order_status($order, $status_response);
                } else {
                    $this->check_payment_status_directv2($order_id, $decoded_post);
                }
            } else {
                $order->update_status('failed', 'Payment failed via ewallet callback');
                $order->update_meta_data('_nicepay_error_message', $decoded_post['resultMsg'] ?? 'Unknown error');
                $order->save();
            }

            wp_safe_redirect($this->get_return_url($order));
            exit;
        }

        // Notifikasi server SNAP.
        if (!empty($signature)) {
            if (
                empty($decoded_post['originalPartnerReferenceNo'])
                || empty($decoded_post['originalReferenceNo'])
            ) {
                nicepay_log('Missing required SNAP callback parameters for ewallet', 'error', 'ewallet');
                wp_send_json_error('Invalid callback', 400);
            }

            $order_id = $this->get_order_id_from_reference($decoded_post['originalPartnerReferenceNo']);
            $order    = wc_get_order($order_id);

            if (!$order) {
                nicepay_log('Order not found for SNAP callback: ' . $order_id, 'error', 'ewallet');
                wp_send_json_error('Order not found', 404);
            }

            $validation = $this->validate_snap_notification_payload($order, $decoded_post);
            if (is_wp_error($validation)) {
                wp_send_json_error(
                    array(
                        'message' => $validation->get_error_message(),
                    ),
                    400
                );
            }

            if (!$order->is_paid()) {
                if ($this->has_snap_credentials()) {
                    $status_response = $this->check_payment_status($order, $decoded_post['originalPartnerReferenceNo']);
                    $this->update_order_status($order, $status_response);
                } else {
                    $this->check_payment_status_directv2($order_id, $decoded_post);
                }
            }

            wp_send_json(
                array(
                    'status'  => 'OK',
                    'message' => 'Callback processed successfully',
                ),
                200
            );
            exit;
        }

        // Notifikasi server Direct V2 (dbProcessUrl).
        if (!empty($decoded_post['merchantToken']) && !empty($decoded_post['referenceNo'])) {
            $order_id = $this->get_order_id_from_reference($decoded_post['referenceNo']);
            $order    = wc_get_order($order_id);

            if (!$order) {
                nicepay_log('Order not found for order_id: ' . $order_id, 'error', 'ewallet');
                wp_send_json_error('Order not found', 404);
            }

            $validation = $this->validate_notification_payload($order, $decoded_post);
            if (is_wp_error($validation)) {
                wp_send_json_error(
                    array(
                        'message' => $validation->get_error_message(),
                    ),
                    400
                );
            }

            nicepay_log('Order found: ' . $order_id . ' — verifying via inquiry API', 'info', 'ewallet');
            $this->check_payment_status_directv2($order_id, $decoded_post);

            wp_send_json(array('status' => 'received'), 200);
            exit;
        }

        nicepay_log('No matching ewallet callback condition, returning 200', 'info', 'ewallet');
        status_header(200);
        exit;
    }
            
    private function generate_formatted_timestamp() {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'ewallet');
        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $reqDt = date('Ymd');
            $reqTm = date('His');
            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int)$order->get_total();
            $referenceNo = $order->get_id() . "-" . $timestamp;

            $mitraCd = WC()->session->get('nicepay_selected_mitra', '');
            if (empty($mitraCd)) {
                throw new Exception(__('No eWallet selected. Please choose an eWallet payment method.', 'nicepay-payment-gateway-for-woocommerce'));
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);
            $cart_data = $this->prepare_cart_data($order);
            $requestBody = [
                "timeStamp"     => $timestamp,
                "iMid"          => $iMid,
                "payMethod"     => "05", // Ewallet
                "currency"      => "IDR",
                "mitraCd"       => $mitraCd,
                "amt"           => (string) $amount,
                "referenceNo"   => $referenceNo,
                "merchantToken" => $merchantToken,
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_ewallet'),
                "goodsNm"       => $this->get_order_items_names($order),
                "billingNm"     => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone"  => $order->get_billing_phone(),
                "billingEmail"  => $order->get_billing_email(),
                "billingAddr"   => $order->get_billing_address_1(),
                "billingCity"   => $order->get_billing_city(),
                "billingState"  => $order->get_billing_state(),
                "billingCountry"=> $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "description"   => "Testing Ewallet - " . get_bloginfo('name'),
                "reqDomain"     => $_SERVER['HTTP_HOST'] ?? 'merchant.com',
                "reqServerIP"   => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
                "userIP"        => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "userSessionID" => session_id(),
                "userAgent"     => $_SERVER['HTTP_USER_AGENT'] ?? '',
                "userLanguage"  => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
                "cartData"      => $cart_data,
                "shopId"        => ""
            ];

            $args = [
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body'    => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("Ewallet Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'ewallet');
            nicepay_log("Ewallet Request Body: " . json_encode($requestBody), 'info', 'ewallet');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("Ewallet Response: " . json_encode($response_body), 'info', 'ewallet');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                $msg = $response_body['resultMsg'] ?? 'Unknown error';
                throw new Exception(
                    // translators: %s: error message from payment gateway.
                    sprintf(__('Failed to create eWallet transaction: %s', 'nicepay-payment-gateway-for-woocommerce'), $msg)
                );
            }

            // translators: 1: reference number, 2: transaction ID.
            $order->add_order_note( sprintf(
                __( "NICEPay E-Wallet. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s", 'nicepay-payment-gateway-for-woocommerce' ),
                $response_body['referenceNo'],
                $response_body['tXid']
            ) );

            // Save important meta
            $order->update_meta_data('_nicepay_tXid', $response_body['tXid'] ?? '');
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo'] ?? '');
            $order->update_meta_data('_nicepay_mitra', $mitraCd);
            $order->update_meta_data('_nicepay_txn_amt', (string) $amount);
            $order->save();

            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(
                // translators: %s: error message.
                sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'ewallet');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }

    public function process_paymentV2($order_id, $response_regis) {
        nicepay_log("(Direct V2) Starting process_paymentV2", 'info', 'ewallet');
        try {
            $order = wc_get_order($order_id);
            $timestamp     = date('YmdHis');
            $iMid          = $this->get_option('X-CLIENT-KEY');
            $merchantKey   = $this->get_option('merchant_key');
            $amount        = (int) $order->get_total();
            $referenceNo   = $response_regis['referenceNo'];

            if($response_regis['mitraCd'] === 'OVOE'){
                $callBackUrl = home_url('/wc-api/wc_gateway_nicepay_ewallet');
            } else {
                $callBackUrl = $this->get_return_url($order);
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            $paymentUrl = $this->api_endpoints['paymentDirectV2'] . '?' . http_build_query([
                'timeStamp'     => $timestamp,
                'tXid'          => $response_regis['tXid'],
                'merchantToken' => $merchantToken,
                'callBackUrl'   => $callBackUrl,
            ]);

            // Log buat debug
            nicepay_log("Redirecting user to: " . $paymentUrl, 'info', 'ewallet');

            return $paymentUrl;
        } catch (Exception $e) {
            wc_add_notice(
                // translators: %s: error message.
                sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'ewallet');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }

    protected function check_payment_status_directv2($order_id,$data)
    {
        nicepay_log('Starting check_payment_status_directv2 for order ' . $order_id, 'info', 'ewallet');

        $order = wc_get_order($order_id);
        if (!$order) {
            nicepay_log('Order not found when checking status for order ' . $order_id, 'error', 'ewallet');
            return false;
        }

        if ($order->is_paid()) {
            nicepay_log('Order already paid: ' . $order_id, 'info', 'ewallet');
            return true;
        }

        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $tXid = $this->get_notification_txid($data);
        if ('' === $tXid) {
            $tXid = trim((string) ($data['originalReferenceNo'] ?? $order->get_meta('_nicepay_tXid')));
        }
        $referenceNo = !empty($data['referenceNo']) ? $data['referenceNo'] : ($data['originalPartnerReferenceNo'] ?? null);
        $amount = !empty($data['amt']) ? $data['amt'] : ($data['amount']['value'] ?? null);
        $merchantKey = $this->get_option('merchant_key');

        if (empty($tXid) || empty($referenceNo) || empty($amount)) {
            nicepay_log('Missing required parameters for EWALLET status check', 'error', 'ewallet');
            return false;
        }

        nicepay_log($iMid . $tXid . $referenceNo . $amount, 'info', 'ewallet');

        // Pastikan format amount konsisten dengan saat registrasi
        $amount_int = (int) $amount;
        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount_int . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => (string) $amount_int,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("EWALLET Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'ewallet');
        nicepay_log("EWALLET Request Body: " . json_encode($requestBody), 'info', 'ewallet');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            nicepay_log('HTTP Request failed when checking EWALLET status: ' . $response->get_error_message(), 'error', 'ewallet');
            return false;
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("EWALLET Response: " . json_encode($response_body), 'info', 'ewallet');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            nicepay_log(
                'EWALLET status check failed: ' . ($response_body['resultMsg'] ?? 'Unknown error'),
                'error',
                'ewallet'
            );
            $order->update_meta_data('_nicepay_error_message', $response_body['resultMsg'] ?? 'Unknown error');
            $order->save();
            return false;
        }

        if ($response_body['status'] == '0') {
            $this->apply_paid_status_from_notification(
                $order_id,
                $response_body,
                __('E-wallet payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce')
            );
        }

        return true;
    }
}