﻿<?php
if (!defined('ABSPATH')) exit;
class Nicepay_Gateway_CC extends Nicepay_Gateway_Base {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;
    private static $thankyou_displayed = array();
    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_cc';
        $this->icon               = apply_filters( 'nicepay_gateway_cc_icon', '' );
        $this->has_fields         = false;
        $this->method_title       = __('NICEPAY Credit Card', 'nicepay-payment-gateway-for-woocommerce');
        $this->method_description = __('Allows payments using NICEPAY Credit Card', 'nicepay-payment-gateway-for-woocommerce');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        
        // $this->api_endpoints = $this->get_api_endpoints();

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        $this->api_endpoints = $this->get_api_endpoints();

        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_nicepay_return', array($this, 'handle_return_url'));
    add_action('woocommerce_api_wc_gateway_nicepay_cc', array($this, 'handle_notification'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-cc-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-cc-header {
                margin-bottom: 15px;
                text-align: center;
                padding: 10px 0;
            }
            .nicepay-cc-icon {
                max-height: 150px;
                width: auto;
                display: inline-block;
                margin: 10px 0;
            }
            .nicepay-cc-select {
                margin: 10px 0;
            }
            .nicepay-cc-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-cc-logos {
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 15px; /* Spacing antar logo */
                margin-bottom: 20px;
            }
            .nicepay-cc-logos img {
                height: 30px; /* Ukuran untuk logo individu */
                width: auto;
            }
            .nicepay-cc-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-cc-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/cc-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-cc-blocks-integration',
            'nicepayCCData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'security' => wp_create_nonce('nicepay-cc-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'iscc' => true
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');

        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-cc-style',
            NICEPAY_PLUGIN_URL . '/assets/css/cc.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-cc-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-cc-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/cc-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-cc-blocks-integration',
            'nicepayCCData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'security' => wp_create_nonce('nicepay-cc-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'iscc' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        
        return [
            'registrationRedirectV2'      => $base_url . '/nicepay/redirect/v2/registration',
            'paymentDirectV2'           => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_notification() {
        $headers   = function_exists( 'getallheaders' ) ? getallheaders() : array();
        $signature = $headers['X-SIGNATURE'] ?? null;

        if ( ! empty( $signature ) ) {
            nicepay_log( '(SNAP) callback received - not handled by this gateway.', 'info', 'cc' );
            wp_send_json( array( 'status' => 'received' ), 200 );
            exit;
        }

        nicepay_log( 'NICEPay CC callback received. Starting processing...', 'info', 'cc' );
        status_header( 200 );

        $raw_post = file_get_contents( 'php://input' );
        nicepay_log( 'Raw input: ' . $raw_post, 'info', 'cc' );

        $decoded_post = json_decode( $raw_post, true );
        if ( ! is_array( $decoded_post ) ) {
            parse_str( $raw_post, $decoded_post );
        }
        if ( empty( $decoded_post ) ) {
            $decoded_post = $_POST;
        }

        nicepay_log( 'Processed callback data: ' . wp_json_encode( $decoded_post ), 'info', 'cc' );

        if ( empty( $decoded_post['referenceNo'] ) ) {
            nicepay_log( 'Missing referenceNo in callback', 'error', 'cc' );
            wp_send_json_error( 'Invalid callback', 400 );
        }

        $reference_no = trim( (string) $decoded_post['referenceNo'] );
        $parts        = explode( '-', $reference_no );
        $order_id     = absint( $parts[0] );
        $order        = wc_get_order( $order_id );

        if ( ! $order ) {
            nicepay_log( 'Order not found for referenceNo: ' . $order_id, 'error', 'cc' );
            wp_send_json_error( 'Order not found', 404 );
        }

        $validation = $this->validate_notification_payload( $order, $decoded_post );
        if ( is_wp_error( $validation ) ) {
            wp_send_json_error(
                array(
                    'message' => $validation->get_error_message(),
                ),
                400
            );
        }

        nicepay_log( 'Order found: ' . $order_id . ' — verifying via inquiry API', 'info', 'cc' );
        $this->check_payment_status_directv2( $order_id, $decoded_post );

        wp_send_json( array( 'status' => 'received' ), 200 );
        exit;
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'title' => array(
                'title'       => __('Title', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __( 'NICEPay Kartu Kredit', 'nicepay-payment-gateway-for-woocommerce' ),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => __( 'Anda akan diarahkan ke NICEPay untuk menyelesaikan pembayaran dengan aman.', 'nicepay-payment-gateway-for-woocommerce' ),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-payment-gateway-for-woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPAY</small>.', 'nicepay-payment-gateway-for-woocommerce'),
                'default' => 'TESTMPGS05',
            ),
            // 'client_secret' => array(
            //     'title'       => __('Client Key', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type'        => 'text',
            //     'description' => __('Enter your NICEPAY Client Key.', 'nicepay-payment-gateway-for-woocommerce'),
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-payment-gateway-for-woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-payment-gateway-for-woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            // 'private_key' => array(
            //     'title'       => __('Private Key', 'nicepay-payment-gateway-for-woocommerce'),
            //     'type'        => 'textarea',
            //     'description' => __('Enter your NICEPAY Private Key.', 'nicepay-payment-gateway-for-woocommerce'),
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
        );
    }

    public function payment_fields()
{
    $i18n = function_exists( 'nicepay_get_checkout_i18n_strings' ) ? nicepay_get_checkout_i18n_strings() : array();
    echo '<div class="nicepay-cc-container">';
    echo '<div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">';
    echo '<img src="' . esc_url( NICEPAY_PLUGIN_URL . '/assets/images/ccL.png' ) . '" alt="' . esc_attr( $i18n['alt_credit_card'] ?? __( 'Kartu Kredit', 'nicepay-payment-gateway-for-woocommerce' ) ) . '" style="height: 24px; width: auto;">';
    if ( ! empty( $this->description ) ) {
        echo '<span>' . wp_kses_post( $this->description ) . '</span>';
    }
    echo '</div>';
    if ( empty( $this->description ) ) {
        echo '<p>' . esc_html( $i18n['cc_redirect'] ?? __( 'Anda akan diarahkan ke NICEPay untuk menyelesaikan pembayaran dengan aman.', 'nicepay-payment-gateway-for-woocommerce' ) ) . '</p>';
    }
    echo '</div>';
}



    /**
     * Handle the Ajax request to set card data
     */
    public function set_nicepay_CC_CardNo() {
        check_ajax_referer('nicepay-cc-nonce', 'security');

        $cardNo     = isset( $_POST['cardNo'] ) ? sanitize_text_field( wp_unslash( $_POST['cardNo'] ) ) : '';
        $expYm      = isset( $_POST['expYm'] ) ? sanitize_text_field( wp_unslash( $_POST['expYm'] ) ) : '';
        $cvv        = isset( $_POST['cvv'] ) ? sanitize_text_field( wp_unslash( $_POST['cvv'] ) ) : '';
        $cardHolder = isset( $_POST['cardHolder'] ) ? sanitize_text_field( wp_unslash( $_POST['cardHolder'] ) ) : '';

        WC()->session->set('nicepay_cc_cardNo', $cardNo);
        WC()->session->set('nicepay_cc_expYm', $expYm);
        WC()->session->set('nicepay_cc_cvv', $cvv);
        WC()->session->set('nicepay_cc_cardHolderNm', $cardHolder);

        nicepay_log("CC Data Saved: cardNo={$cardNo}, expYm={$expYm}, cvv={$cvv}", 'info', 'cc');

        wp_send_json_success(['message' => 'CC data saved']);
    }

    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment cc for order $order_id", 'info', 'cc');

        return $this->process_blocks_payment($order_id);
    }

    /**
     * Halaman receipt (order-pay) untuk Credit Card.
     *
     * process_payment mengarahkan pelanggan ke halaman order-pay internal (same-origin)
     * agar kompatibel dengan WooCommerce Blocks Checkout. Di sini kita langsung forward
     * pelanggan ke halaman pembayaran NICEPay. Forward dilakukan via JavaScript + meta
     * refresh (bukan wp_redirect) karena pada hook receipt header HTTP biasanya sudah
     * terkirim. Disediakan juga tombol manual sebagai fallback.
     */
    public function receipt_page($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $payment_url = $order->get_meta('_nicepay_payment_url');
        if (empty($payment_url)) {
            nicepay_log("receipt_page: _nicepay_payment_url kosong untuk order {$order_id}", 'error', 'cc');
            echo '<p>' . esc_html__('Payment link is not available. Please contact support.', 'nicepay-payment-gateway-for-woocommerce') . '</p>';
            return;
        }

        nicepay_log("receipt_page: forwarding order {$order_id} ke NICEPay: {$payment_url}", 'info', 'cc');

        $payment_url_js = esc_url_raw($payment_url);
        ?>
        <div class="nicepay-cc-redirect" style="text-align:center; padding:24px 12px;">
            <p style="font-size:15px; margin-bottom:8px;">
                <?php esc_html_e('Redirecting you to the secure NICEPay payment page...', 'nicepay-payment-gateway-for-woocommerce'); ?>
            </p>
            <p style="color:#666; font-size:13px;">
                <?php
                printf(
                    /* translators: %s: manual payment link */
                    esc_html__('If you are not redirected automatically, %s.', 'nicepay-payment-gateway-for-woocommerce'),
                    '<a href="' . esc_url($payment_url) . '">' . esc_html__('click here to continue', 'nicepay-payment-gateway-for-woocommerce') . '</a>'
                );
                ?>
            </p>
        </div>
        <script type="text/javascript">
            window.location.href = <?php echo wp_json_encode($payment_url_js); ?>;
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_attr($payment_url); ?>">
        </noscript>
        <?php
    }

    public function handle_return_url() {
    try {
        $order_id = isset($_GET['order_id']) ? sanitize_text_field($_GET['order_id']) : '';
        $key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';

        nicepay_log("========= RETURN URL HANDLER =========", 'info', 'cc');
        nicepay_log("Return URL accessed - Order ID: {$order_id}", 'info', 'cc');

        if (!$order_id || !$key) {
            nicepay_log("Missing required parameters in return URL", 'error', 'cc');
            wp_redirect(home_url());
            exit;
        }

        $order = wc_get_order($order_id);
        if (!$order || $order->get_order_key() !== $key) {
            nicepay_log("Invalid order or key", 'error', 'cc');
            wp_redirect(home_url());
            exit;
        }

        if ( $order->get_payment_method() !== $this->id ) {
            return;
        }
        
        // Get the Thank You page URL
        $redirect_url = $order->get_checkout_order_received_url();
        nicepay_log("Redirecting to: " . $redirect_url, 'info', 'cc');
        
        wp_redirect($redirect_url);
        exit;
    } catch (Exception $e) {
        nicepay_log("Return URL error: " . $e->getMessage(), 'error', 'cc');
        wp_redirect(home_url());
        exit;
    }
}
    /**
     * Process payment for classic checkout
     */
   /**
 * Process payment for classic checkout
 */
public function process_classic_payment($order_id) {
    nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'cc');
    
    $order = wc_get_order($order_id);
    $order->update_meta_data('_nicepay_payment_method', 'cc');
    $order->save();

    // Sama seperti blocks payment, langsung proses tanpa check mitra
    if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
        $this->process_snap($order_id);
    } else {
        try {
            $paymentUrl = $this->process_redirectV2($order_id);
            if (!is_string($paymentUrl) || $paymentUrl === '') {
                $err = (is_array($paymentUrl) && !empty($paymentUrl['resultMsg'])) ? $paymentUrl['resultMsg'] : 'Unknown error';
                throw new Exception(__('Failed to create cc transaction: ', 'nicepay-payment-gateway-for-woocommerce') . $err);
            }

            return [
                'result'   => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            ];
        } catch (Exception $e) {
            // translators: %s: error message.
            wc_add_notice(
                sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in process_classic_payment: " . $e->getMessage(), 'error', 'cc');
            
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }
}

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order " . $order_id, 'info', 'cc');
    
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'cc');
        $order->save();

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            $this->process_snap($order_id);
        } else {
            try {
                $paymentUrl = $this->process_redirectV2($order_id);
                if (!is_string($paymentUrl) || $paymentUrl === '') {
                    $err = (is_array($paymentUrl) && !empty($paymentUrl['resultMsg'])) ? $paymentUrl['resultMsg'] : 'Unknown error';
                    throw new Exception(__('Failed to create cc transaction: ', 'nicepay-payment-gateway-for-woocommerce') . $err);
                }

                // PENTING: jangan redirect langsung ke domain NICEPay (off-site).
                // WooCommerce Blocks Checkout (WC 10.x) tidak melakukan redirect lintas-domain
                // untuk gateway legacy, sehingga muncul error walau transaksi sukses.
                // Solusi: arahkan ke halaman order-pay (internal/same-origin) yang dijamin
                // didukung Blocks, lalu forward ke NICEPay dari hook receipt (lihat receipt_page()).
                $blocks_result = [
                    'result'   => 'success',
                    'redirect' => $order->get_checkout_payment_url(true),
                ];
                nicepay_log("process_blocks_payment RETURN: " . wp_json_encode($blocks_result) . " | nicepay_url=" . $paymentUrl, 'info', 'cc');

                return $blocks_result;
            } catch (Exception $e) {
                // translators: %s: error message.
                wc_add_notice(
                    sprintf(__('Payment error: %s', 'nicepay-payment-gateway-for-woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'ewallet');
                
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    public function process_redirectV2($order_id) {
        nicepay_log("Starting process_redirectV2 for order $order_id", 'info', 'cc');
        try {
            $order = wc_get_order($order_id);

            $timestamp      = date('YmdHis');
            $iMid           = $this->get_option('X-CLIENT-KEY');
            $merchantKey    = $this->get_option('merchant_key');
            $amount         = (string)$order->get_total();
            $referenceNo    = $order->get_id();
            $return_url = add_query_arg(array(
                'wc-api' => 'nicepay_return',
                'order_id' => $order->get_id(),
                'key' => $order->get_order_key()
            ), home_url('/'));
    
            nicepay_log("Return URL (for user): " . $return_url, 'info', 'cc');

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            // ================= CART DATA =================
            $cart_data = $this->prepare_cart_data($order);

            // ================= SELLERS =================
            $sellers = [[
                "sellersId"    => "SEL123",
                "sellersNm"    => "WooCommerce Seller",
                "sellersEmail" => get_option('admin_email'),
                "sellersAddress" => [
                    "sellerNm"      => "Woo",
                    "sellerLastNm"  => "Commerce",
                    "sellerAddr"    => "Merchant Address",
                    "sellerCity"    => "Jakarta",
                    "sellerPostCd"  => "12345",
                    "sellerPhone"   => "08123456789",
                    "sellerCountry" => "Indonesia"
                ]
            ]];

            // ================= REQUEST BODY =================
            $requestBody = [
                "timeStamp"      => $timestamp,
                "iMid"           => $iMid,
                "payMethod"      => "00", // CC
                "currency"       => "IDR",
                "amt"            => $amount,
                "referenceNo"    => $referenceNo,
                "merchantToken"  => $merchantToken,
                "instmntType"    => "1",
                "instmntMon"     => "1",
                "reqDt"          => date('Ymd'),
                "reqTm"          => date('His'),
                "goodsNm"        => $order->get_formatted_billing_full_name(),
                "billingNm"      => $order->get_formatted_billing_full_name(),
                "billingPhone"   => $order->get_billing_phone(),
                "billingEmail"   => $order->get_billing_email(),
                "billingAddr"    => $order->get_billing_address_1(),
                "billingCity"    => $order->get_billing_city(),
                "billingState"   => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd"  => $order->get_billing_postcode(),
                "description"    => "Payment for WooCommerce order #{$order_id}",
                "callBackUrl"    => $return_url,
                "dbProcessUrl"   => home_url('/wc-api/wc_gateway_nicepay_cc'),
                "userIP"         => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "cartData"       => $cart_data,
                "sellers"        => json_encode($sellers, JSON_UNESCAPED_SLASHES),
                "deliveryNm"     => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
                "deliveryPhone"  => $order->get_billing_phone(),
                "deliveryAddr"   => $order->get_shipping_address_1(),
                "deliveryCity"   => $order->get_shipping_city(),
                "deliveryState"  => $order->get_shipping_state(),
                "deliveryCountry"=> $order->get_shipping_country(),
                "deliveryPostCd" => $order->get_shipping_postcode(),
                "mitraCd"        => "",
                "recurrOpt"      => "",
                "userLanguage"   => "en",
                "userAgent"      => $_SERVER['HTTP_USER_AGENT'] ?? 'nicepay-payment-gateway-for-woocommerce'
            ];

            $args = [
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body'    => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("CC Request to " . $this->api_endpoints['registrationRedirectV2'], 'info', 'cc');
            nicepay_log("CC Request Body: " . json_encode($requestBody), 'info', 'cc');

            $response = wp_remote_post($this->api_endpoints['registrationRedirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("CC Response: " . json_encode($response_body), 'info', 'cc');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create CC transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($response_body['resultMsg'] ?? 'Unknown error'));
            }

            if (!isset($response_body['paymentURL'])) {
                throw new Exception(__('Failed to create CC transaction: ', 'nicepay-payment-gateway-for-woocommerce') . ($response_body['paymentURL'] ?? 'Unknown error'));
            }
            nicepay_log("Final callBackUrl sent to NICEPay: " . $return_url, 'info', 'cc');

            // translators: 1: reference number, 2: transaction ID, 3: transaction amount.
            $order->add_order_note( sprintf(
                __( "NICEPay Credit Card. Details:\nReference Number : %1\$s\nTransaction ID: %2\$s\nTransaction Amount: %3\$s", 'nicepay-payment-gateway-for-woocommerce' ),
                $response_body['referenceNo'],
                $response_body['tXid'],
                $response_body['amt']
            ) );

            $paymentUrl = $response_body['paymentURL'] . '?' . http_build_query([
                'tXid'  => $response_body['tXid'],
            ]);

            $order->update_meta_data('_nicepay_tXid', $response_body['tXid']);
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo']);
            $order->update_meta_data('_nicepay_txn_amt', $response_body['amt']);
            // Simpan URL pembayaran NICEPay agar bisa di-forward dari halaman receipt (order-pay).
            $order->update_meta_data('_nicepay_payment_url', $paymentUrl);
            $order->save();

            nicepay_log("paymentUrl: " . $paymentUrl, 'info', 'cc' );

            return $paymentUrl;

        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'nicepay-payment-gateway-for-woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_redirectV2: " . $e->getMessage(), 'error', 'cc');
            return [
                'resultCd'  => '9999',
                'resultMsg' => $e->getMessage()
            ];
        }
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    private function process_paymentV2($order_id, $cc_data) {
        nicepay_log("Starting process_paymentV2", 'info', 'cc');

        try {
            $order = wc_get_order($order_id);
            $timestamp     = date('YmdHis');
            $iMid          = $this->get_option('X-CLIENT-KEY');
            $merchantKey   = $this->get_option('merchant_key');

            // Ambil data kartu dari session
            $cardNo        = WC()->session->get('nicepay_cc_cardNo');
            $expYm         = WC()->session->get('nicepay_cc_expYm');
            $cvv           = WC()->session->get('nicepay_cc_cvv');
            $cardHolderNm  = WC()->session->get('nicepay_cc_cardHolderNm');

            if (!$cardNo || !$expYm || !$cvv) {
                throw new Exception("Incomplete credit card data in session");
            }

            if (empty($cardHolderNm)) {
                $cardHolderNm = "NICEPAY CUSTOMER";
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $cc_data['referenceNo'] . $cc_data['amt'] . $merchantKey);
            
            $paymentUrl = $this->api_endpoints['paymentDirectV2'] . '?' . http_build_query([
                'timeStamp'         => $timestamp,
                'merchantToken'     => $merchantToken,
                'tXid'              => $cc_data['tXid'],
                "callBackUrl"       => $this->get_return_url($order),
                "referenceNo"       => $cc_data['referenceNo'],
                "cardNo"            => $cardNo,
                "cardExpYymm"       => $expYm,
                "cardCvv"           => $cvv,
                "cardHolderNm"      => $cardHolderNm,
                "cardHolderEmail"   => $order->get_billing_email(),
            ]);

            // Log buat debug
            nicepay_log("Redirecting user to: " . $paymentUrl, 'info', 'cc');

            return $paymentUrl;

            return $response;
        } catch (Exception $e) {
            wc_add_notice(__('Credit Card Payment Error: ', 'nicepay-payment-gateway-for-woocommerce') . $e->getMessage(), 'error');
            nicepay_log("Exception in process_paymentV2: " . $e->getMessage(), 'error', 'cc');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }


    public function thankyou_page($order_id) {
    if (isset(self::$thankyou_displayed[$order_id])) {
        nicepay_log("Thank you page already displayed for order: " . $order_id, 'info', 'cc');
        return;
    }
    self::$thankyou_displayed[$order_id] = true;
    nicepay_log("Starting thankyou_page" .$order_id,'info','cc');
    $order = wc_get_order($order_id);
    
    if (!$order) {
        return;
    }

    if ($order->get_payment_method() !== $this->id) {
        nicepay_log("Payment method mismatch for order: " . $order_id, 'info', 'cc');
        return;
    }
    
    // Get transaction data
    $txid = $order->get_meta('_nicepay_tXid');
    $reference_no = $order->get_meta('_nicepay_reference_no');
    $amount = $order->get_meta('_nicepay_paid_amount');
    $status = $order->get_meta('_nicepay_status');
    $status_code = $order->get_meta('_nicepay_status_code');
    $payment_method = $order->get_meta('_nicepay_payment_method');
    $transaction_date = $order->get_meta('_nicepay_transaction_datetime');
    
    // Check apakah pembayaran sukses atau gagal
    $is_success = ($status === 'Success' || $status_code === '00' || $order->is_paid());
    
    // Format tanggal
    if ($transaction_date) {
        $date = DateTime::createFromFormat('YmdHis', $transaction_date);
        $formatted_date = $date ? $date->format('d M Y, H:i:s') : date('d M Y, H:i:s');
    } else {
        $formatted_date = date('d M Y, H:i:s');
    }
    
    // Payment method name
    $payment_method_name = 'Kartu Kredit/Debit';
    if ($payment_method === 'qris') {
        $payment_method_name = 'QRIS';
    } elseif ($payment_method === 'va') {
        $payment_method_name = 'Virtual Account';
    } elseif ($payment_method === 'ewallet') {
        $payment_method_name = 'E-Wallet';
    }
    
    ?>
    <style>
        .nicepay-thankyou-container {
            max-width: 800px;
            margin: 30px auto;
            padding: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nicepay-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
            margin-bottom: 30px;
        }
        
        .nicepay-logo {
            background: #00b4d8;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 18px;
        }
        
        .nicepay-status-badge {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .nicepay-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            position: relative;
        }
        
        .nicepay-icon.success {
            background: #4ade80;
        }
        
        .nicepay-icon.success::after {
            content: "✓";
            color: white;
            font-size: 32px;
            font-weight: bold;
        }
        
        .nicepay-icon.failed {
            background: #ef4444;
        }
        
        .nicepay-icon.failed::before,
        .nicepay-icon.failed::after {
            content: "";
            position: absolute;
            width: 30px;
            height: 3px;
            background: white;
            border-radius: 2px;
        }
        
        .nicepay-icon.failed::before {
            transform: rotate(45deg);
        }
        
        .nicepay-icon.failed::after {
            transform: rotate(-45deg);
        }
        
        .nicepay-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }
        
        .nicepay-amount {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .nicepay-amount.success {
            color: #00b4d8;
        }
        
        .nicepay-amount.failed {
            color: #ef4444;
        }
        
        .nicepay-date {
            color: #666;
            font-size: 14px;
        }
        
        .nicepay-error-msg {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
            padding: 12px 16px;
            border-radius: 6px;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .nicepay-detail-section {
            margin-top: 30px;
        }
        
        .nicepay-detail-header {
            color: #666;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .nicepay-detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .nicepay-detail-row:last-child {
            border-bottom: none;
        }
        
        .nicepay-label {
            color: #666;
            font-size: 14px;
        }
        
        .nicepay-value {
            color: #333;
            font-weight: 500;
            text-align: right;
            font-size: 14px;
        }
        
        .nicepay-payment-icon {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .nicepay-visa-badge {
            background: #1a1f71;
            color: white;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .nicepay-footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            color: #999;
            font-size: 12px;
        }
    </style>
    
    <div class="nicepay-thankyou-container">
        <!-- Header -->
        <div class="nicepay-header">
            <div class="nicepay-logo">NICEPAY</div>
            <div style="color: #666;">🌐 Bahasa Indonesia</div>
        </div>
        
        <!-- Status Badge -->
        <div class="nicepay-status-badge">
            <div class="nicepay-icon <?php echo $is_success ? 'success' : 'failed'; ?>"></div>
            <h2 class="nicepay-title">
                <?php echo $is_success ? 'Pembayaran Sukses!' : 'Pembayaran Gagal!'; ?>
            </h2>
            <div class="nicepay-amount <?php echo $is_success ? 'success' : 'failed'; ?>">
                Rp<?php echo number_format($amount ?: $order->get_total(), 0, ',', '.'); ?>
            </div>
            
            <?php if (!$is_success): ?>
            <div class="nicepay-error-msg">
                <?php 
                $error_msg = $order->get_meta('_nicepay_error_message');
                echo $error_msg ? esc_html($error_msg) : 'Transaksi gagal diproses. Silakan coba lagi atau hubungi customer service.';
                ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="nicepay-footer">
            Powered by <strong>NICEPAY</strong>
        </div>
    </div>
    <?php
}
        

    

    public function process_snap($order_id){
        nicepay_log("Starting process_snap soon to be", 'info', 'cc');
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    /**
     * Verifikasi status via inquiry API; status final diambil dari response inquiry.
     */
    protected function check_payment_status_directv2( $order_id, $data ) {
        nicepay_log( 'Starting check_payment_status_directv2 for order ' . $order_id, 'info', 'cc' );

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $timestamp   = date( 'YmdHis' );
        $iMid        = $this->get_option( 'X-CLIENT-KEY' );
        $merchantKey = $this->get_option( 'merchant_key' );

        if ( $order->get_meta( '_nicepay_mitra' ) === 'OVOE' ) {
            $tXid        = $order->get_meta( '_nicepay_tXid' );
            $referenceNo = $order->get_meta( '_nicepay_reference_no' );
            $amount      = $order->get_meta( '_nicepay_txn_amt' );
        } else {
            $tXid        = $data['tXid'] ?? $order->get_meta( '_nicepay_tXid' );
            $referenceNo = $data['referenceNo'] ?? $order->get_meta( '_nicepay_reference_no' );
            $amount      = $data['amt'] ?? $order->get_meta( '_nicepay_txn_amt' );
        }

        $merchantToken = hash( 'sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey );

        $requestBody = array(
            'timeStamp'     => $timestamp,
            'iMid'          => $iMid,
            'tXid'          => $tXid,
            'referenceNo'   => $referenceNo,
            'amt'           => $amount,
            'merchantToken' => $merchantToken,
        );

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => wp_json_encode( $requestBody ),
        );

        nicepay_log( 'cc Request to ' . $this->api_endpoints['check_status_url_directv2'], 'info', 'cc' );
        nicepay_log( 'cc Request Body: ' . wp_json_encode( $requestBody ), 'info', 'cc' );

        $response = wp_remote_post( $this->api_endpoints['check_status_url_directv2'], $args );

        if ( is_wp_error( $response ) ) {
            nicepay_log( 'HTTP Request failed: ' . $response->get_error_message(), 'error', 'cc' );
            return;
        }

        $response_body = json_decode( wp_remote_retrieve_body( $response ), true );
        nicepay_log( 'cc Response: ' . wp_json_encode( $response_body ), 'info', 'cc' );

        if ( ! isset( $response_body['resultCd'] ) || '0000' !== $response_body['resultCd'] ) {
            nicepay_log( 'Inquiry failed: ' . ( $response_body['resultMsg'] ?? 'Unknown error' ), 'error', 'cc' );
            return;
        }

        if ( isset( $response_body['status'] ) && (string) $response_body['status'] === '0' ) {
            $this->apply_paid_status_from_notification(
                $order_id,
                $response_body,
                __( 'CC payment completed via NICEPay.', 'nicepay-payment-gateway-for-woocommerce' )
            );
        }
    }
}