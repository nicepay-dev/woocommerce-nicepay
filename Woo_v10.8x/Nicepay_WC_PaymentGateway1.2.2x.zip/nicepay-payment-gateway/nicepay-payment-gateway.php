<?php
/**
 * Plugin Name: NICEPay Payment Gateway for WooCommerce
 * Plugin URI: https://github.com/yourusername/nicepay-woocommerce
 * Description: WooCommerce payment gateway integration with NICEPay (Virtual Account, QRIS, E-Wallet, Credit Card, Payloan, CVS).
 * Version: 1.2.2
 * Author: Nicepay
 * Author URI: https://github.com/yourusername
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: nicepay-payment-gateway-for-woocommerce
 * Domain Path: /languages
 * Requires at least: 5.8
 * Tested up to: 7.0
 * WC requires at least: 5.0
 * WC tested up to: 9.2
 */

if (!defined('ABSPATH')) exit;
if ( ! defined( 'NICEPAY_PLUGIN_URL' ) ) {
    define( 'NICEPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
define('NICEPAY_PLUGIN_PATH', plugin_dir_path(__FILE__));
if ( ! defined( 'NICEPAY_WC_VERSION' ) ) {
    if ( ! function_exists( 'get_file_data' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $nicepay_plugin_data = get_file_data(
        __FILE__,
        array(
            'Version' => 'Version',
        ),
        'plugin'
    );
    define( 'NICEPAY_WC_VERSION', ! empty( $nicepay_plugin_data['Version'] ) ? $nicepay_plugin_data['Version'] : '1.2.1' );
}

/**
 * Load plugin text domain for translations.
 */
add_action( 'init', function () {
    load_plugin_textdomain(
        'nicepay-payment-gateway-for-woocommerce',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
} );

/**
 * Declare compatibility with WooCommerce features (HPOS, block checkout).
 * Required so WooCommerce does not flag this plugin as incompatible after updates.
 */
add_action( 'before_woocommerce_init', function () {
    if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        return;
    }

    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
} );

// Load Admin Actions Class
//require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-payout';
//require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-nicepay-transaction.php';
require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-nicepay.php';
        
require_once NICEPAY_PLUGIN_PATH . 'includes/class-nicepay-log-manager.php';

// Include Log Manager

// Global helper log function
function nicepay_log($message, $type = 'info', $channel = 'va') {
    if (class_exists('NICEPay_Log_Manager')) {
        NICEPay_Log_Manager::instance($channel)->log($message, $type);
    } elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Fallback only when debug logging is enabled.
        error_log("NICEPay {$channel} {$type}: {$message}");
    }
}

/**
 * Include gateway class files once.
 * Output dari include (mis. BOM tersembunyi) ditangkap dan dibuang agar tidak
 * mencemari response JSON WooCommerce Store API.
 */
function nicepay_include_gateway_files() {
    static $loaded = false;
    if ( $loaded ) {
        return;
    }

    ob_start();

    $includes = plugin_dir_path( __FILE__ ) . 'includes/';
    include_once $includes . 'class-nicepay-gateway-base.php';

    $base = $includes . 'gateways/';
    include_once $base . 'class-wc-gateway-nicepay-qris.php';
    include_once $base . 'class-wc-gateway-nicepay-va.php';
    include_once $base . 'class-wc-gateway-nicepay-ewallet.php';
    include_once $base . 'class-wc-gateway-nicepay-cvs.php';
    include_once $base . 'class-wc-gateway-nicepay-payloan.php';
    include_once $base . 'class-wc-gateway-nicepay-cc.php';
    include_once $base . 'class-wc-gateway-nicepay-all.php';
    // include_once $base . 'class-wc-gateway-nicepay-payout.php';

    $stray = ob_get_clean();
    if ( is_string( $stray ) && $stray !== '' ) {
        nicepay_log(
            'Output liar saat load gateway files dibuang (len=' . strlen( $stray ) . '): ' . substr( $stray, 0, 200 ),
            'error',
            'va'
        );
    }

    $loaded = true;
}

/**
 * Apakah request HTTP saat ini menuju WooCommerce Store API.
 *
 * @return bool
 */
function nicepay_is_wc_store_api_request() {
    $uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    return ( false !== strpos( $uri, '/wp-json/wc/store/' ) )
        || ( false !== strpos( $uri, 'rest_route=/wc/store/' ) );
}

/**
 * Safety net: tangkap & buang output liar selama request Store API checkout.
 */
function nicepay_store_api_buffer_start() {
	if ( nicepay_is_wc_store_api_request() ) {
		ob_start();
		nicepay_store_api_buffer_mark_active( true );
	}
}
add_action( 'plugins_loaded', 'nicepay_store_api_buffer_start', 0 );

/**
 * @param bool $active Whether NicePay started a Store API buffer.
 */
function nicepay_store_api_buffer_mark_active( $active = null ) {
	static $is_active = false;
	if ( null === $active ) {
		return $is_active;
	}
	$is_active = (bool) $active;
	return $is_active;
}

/**
 * @param WP_REST_Response|WP_HTTP_Response|WP_Error|mixed $response Response.
 * @param WP_REST_Server                               $server  Server.
 * @param WP_REST_Request                              $request Request.
 * @return mixed
 */
function nicepay_store_api_buffer_end( $response, $server, $request ) {
	$route = ( $request && method_exists( $request, 'get_route' ) ) ? $request->get_route() : '';
	if ( strpos( $route, '/wc/store/' ) === false || ! nicepay_store_api_buffer_mark_active( null ) ) {
		return $response;
	}

	if ( ob_get_level() > 0 ) {
		$stray = ob_get_clean();
		if ( is_string( $stray ) && $stray !== '' ) {
			nicepay_log(
				'Output liar Store API dibuang (len=' . strlen( $stray ) . '): ' . substr( $stray, 0, 200 ),
				'error',
				'va'
			);
		}
	}

	nicepay_store_api_buffer_mark_active( false );

	return $response;
}
add_filter( 'rest_post_dispatch', 'nicepay_store_api_buffer_end', PHP_INT_MAX, 3 );

/**
 * Add NICEPay gateway classes into WooCommerce registry.
 *
 * @param array $methods Existing gateway classes.
 * @return array
 */
function nicepay_add_payment_gateway_classes( $methods ) {
    nicepay_include_gateway_files();

    $methods[] = 'Nicepay_Gateway_QRIS';
    $methods[] = 'Nicepay_Gateway_VA';
    $methods[] = 'Nicepay_Gateway_Ewallet';
    $methods[] = 'Nicepay_Gateway_Cvs';
    $methods[] = 'Nicepay_Gateway_Payloan';
    $methods[] = 'Nicepay_Gateway_CC';
    $methods[] = 'Nicepay_Gateway_All';

    return $methods;
}

add_filter( 'woocommerce_payment_gateways', 'nicepay_add_payment_gateway_classes' );

/**
 * Initialize NICEPay integration once WooCommerce gateway base class is available.
 */
function nicepay_init_woocommerce_gateway_integration() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
        return;
    }
    add_action( 'wp_enqueue_scripts', 'nicepay_enqueue_payment_assets' );

    nicepay_include_gateway_files();

    $gatewayVA = new Nicepay_Gateway_VA();
    add_action( 'wp_ajax_set_nicepay_bank', array( $gatewayVA, 'set_nicepay_bank' ) );
    add_action( 'wp_ajax_nopriv_set_nicepay_bank', array( $gatewayVA, 'set_nicepay_bank' ) );

    $gatewayEwallet = new Nicepay_Gateway_Ewallet();
    add_action( 'wp_ajax_set_nicepay_mitra', array( $gatewayEwallet, 'set_nicepay_mitra' ) );
    add_action( 'wp_ajax_nopriv_set_nicepay_mitra', array( $gatewayEwallet, 'set_nicepay_mitra' ) );

    $gatewayCvs = new Nicepay_Gateway_Cvs();
    add_action( 'wp_ajax_set_nicepay_cvs_mitra', array( $gatewayCvs, 'set_nicepay_cvs_mitra' ) );
    add_action( 'wp_ajax_nopriv_set_nicepay_cvs_mitra', array( $gatewayCvs, 'set_nicepay_cvs_mitra' ) );

    $gatewayPayloan = new Nicepay_Gateway_Payloan();
    add_action( 'wp_ajax_set_nicepay_payloan_mitra', array( $gatewayPayloan, 'set_nicepay_payloan_mitra' ) );
    add_action( 'wp_ajax_nopriv_set_nicepay_payloan_mitra', array( $gatewayPayloan, 'set_nicepay_payloan_mitra' ) );

    $gatewayCC = new Nicepay_Gateway_CC();
    add_action( 'wp_ajax_set_nicepay_CC_CardNo', array( $gatewayCC, 'set_nicepay_CC_CardNo' ) );
    add_action( 'wp_ajax_nopriv_set_nicepay_CC_CardNo', array( $gatewayCC, 'set_nicepay_CC_CardNo' ) );
}
add_action( 'plugins_loaded', 'nicepay_init_woocommerce_gateway_integration', 20 );

/**
 * Settings URLs for each NICEPay gateway (WooCommerce > Settings > Payments).
 *
 * @return array<string, string> Gateway ID => admin settings URL.
 */
function nicepay_get_gateway_settings_urls() {
    $base = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' );
    return array(
        'nicepay_qris'      => $base . 'nicepay_qris',
        'nicepay_va_snap'   => $base . 'nicepay_va_snap',
        'nicepay_ewallet'   => $base . 'nicepay_ewallet',
        'nicepay_cvs'       => $base . 'nicepay_cvs',
        'nicepay_payloan'   => $base . 'nicepay_payloan',
        'nicepay_cc'        => $base . 'nicepay_cc',
        'nicepay_all'       => $base . 'nicepay_all',
    );
}

/**
 * Add WooCommerce submenu for unified NICEPay settings.
 */
function nicepay_register_wc_submenu() {
    add_submenu_page(
        'woocommerce',
        __( 'NICEPay Payment Gateway', 'nicepay-payment-gateway-for-woocommerce' ),
        __( 'NICEPay Payment Gateway', 'nicepay-payment-gateway-for-woocommerce' ),
        'manage_woocommerce',
        'nicepay-wc-payment-methods',
        'nicepay_render_wc_payment_methods_page'
    );
}
add_action( 'admin_menu', 'nicepay_register_wc_submenu', 99 );

/**
 * Save global NICEPay settings from the unified admin page.
 */
function nicepay_handle_advanced_settings_save() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	if ( ! isset( $_POST['submit'], $_POST['nicepay_nonce'] ) ) {
		return;
	}

	if ( ! class_exists( 'WC_Nicepay_Admin' ) ) {
		return;
	}

	WC_Nicepay_Admin::instance()->save_settings_from_request();

	wp_safe_redirect( admin_url( 'admin.php?page=nicepay-wc-payment-methods&settings_saved=1' ) );
	exit;
}
add_action( 'load-woocommerce_page_nicepay-wc-payment-methods', 'nicepay_handle_advanced_settings_save', 5 );

/**
 * Get WooCommerce payment gateway instances keyed by gateway ID.
 *
 * @return array<string, WC_Payment_Gateway>
 */
function nicepay_get_wc_payment_gateways() {
	if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
		return array();
	}

	return WC()->payment_gateways()->payment_gateways();
}

/**
 * Get stored settings array for a NICEPay gateway.
 *
 * @param string $gateway_id Gateway ID.
 * @return array<string, mixed>
 */
function nicepay_get_gateway_settings_array( $gateway_id ) {
	$option_key = 'woocommerce_' . $gateway_id . '_settings';
	$settings   = get_option( $option_key, null );

	if ( is_array( $settings ) ) {
		return $settings;
	}

	$gateways = nicepay_get_wc_payment_gateways();
	if ( isset( $gateways[ $gateway_id ] ) ) {
		$gateways[ $gateway_id ]->init_settings();
		return is_array( $gateways[ $gateway_id ]->settings ) ? $gateways[ $gateway_id ]->settings : array();
	}

	return array( 'enabled' => 'no' );
}

/**
 * Set whether a NICEPay gateway is enabled.
 *
 * @param string $gateway_id Gateway ID.
 * @param bool   $enabled    True to enable, false to disable.
 * @return bool
 */
function nicepay_set_gateway_enabled( $gateway_id, $enabled ) {
	if ( ! array_key_exists( $gateway_id, nicepay_get_gateway_settings_urls() ) ) {
		return false;
	}

	$settings            = nicepay_get_gateway_settings_array( $gateway_id );
	$settings['enabled'] = $enabled ? 'yes' : 'no';

	update_option( 'woocommerce_' . $gateway_id . '_settings', $settings );

	$gateways = nicepay_get_wc_payment_gateways();
	if ( isset( $gateways[ $gateway_id ] ) ) {
		$gateways[ $gateway_id ]->settings = $settings;
		$gateways[ $gateway_id ]->enabled  = $settings['enabled'];
	}

	return true;
}

/**
 * Check whether a NICEPay gateway is enabled.
 *
 * @param string $gateway_id Gateway ID.
 * @return bool
 */
function nicepay_is_gateway_enabled( $gateway_id ) {
	$settings = nicepay_get_gateway_settings_array( $gateway_id );
	$enabled  = isset( $settings['enabled'] ) ? $settings['enabled'] : 'no';

	if ( function_exists( 'wc_string_to_bool' ) ) {
		return wc_string_to_bool( $enabled );
	}

	return 'yes' === $enabled;
}

/**
 * Teks checkout berbahasa Indonesia (block & classic).
 *
 * @return array<string, string>
 */
function nicepay_get_checkout_i18n_strings() {
	return array(
		'all_caption'               => __( 'Kartu Kredit, QRIS, E-Wallet, Virtual Account, CVS, dan lainnya.', 'nicepay-payment-gateway-for-woocommerce' ),
		'all_redirect'              => __( 'Anda akan diarahkan ke halaman pembayaran.', 'nicepay-payment-gateway-for-woocommerce' ),
		'cc_redirect'               => __( 'Anda akan diarahkan ke halaman pembayaran.', 'nicepay-payment-gateway-for-woocommerce' ),
		'qris_instruction'          => __( 'Pembayaran menggunakan QRIS dapat dilakukan melalui berbagai aplikasi e-wallet dan mobile banking yang mendukung QRIS.', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_bank'               => __( 'Pilih Bank:', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_bank_placeholder'   => __( 'Pilih Bank', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_bank_instruction'   => __( 'Silakan pilih bank untuk pembayaran Virtual Account Anda.', 'nicepay-payment-gateway-for-woocommerce' ),
		'va_after_order'            => __( 'Nomor Virtual Account akan ditampilkan setelah pesanan dibuat.', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_ewallet'            => __( 'Pilih E-wallet:', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_ewallet_placeholder' => __( 'Pilih E-wallet', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_ewallet_instruction' => __( 'Silakan pilih e-wallet untuk pembayaran Anda.', 'nicepay-payment-gateway-for-woocommerce' ),
		'no_ewallet'                => __( 'Tidak ada e-wallet yang tersedia saat ini.', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_cvs'                => __( 'Pilih CVS:', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_cvs_placeholder'    => __( 'Pilih CVS', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_cvs_instruction'    => __( 'Silakan pilih CVS untuk pembayaran Anda.', 'nicepay-payment-gateway-for-woocommerce' ),
		'no_cvs'                    => __( 'Tidak ada CVS yang tersedia saat ini.', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_payloan'            => __( 'Pilih Payloan:', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_payloan_placeholder' => __( 'Pilih Payloan', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_payloan_instruction' => __( 'Silakan pilih Payloan untuk pembayaran Anda.', 'nicepay-payment-gateway-for-woocommerce' ),
		'no_payloan'                => __( 'Tidak ada Payloan yang tersedia saat ini.', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_payloan_provider'   => __( 'Pilih Penyedia Payloan:', 'nicepay-payment-gateway-for-woocommerce' ),
		'select_payloan_provider_placeholder' => __( '-- Pilih Penyedia --', 'nicepay-payment-gateway-for-woocommerce' ),
		'no_payloan_providers'      => __( 'Tidak ada penyedia Payloan. Silakan hubungi administrator.', 'nicepay-payment-gateway-for-woocommerce' ),
		'no_banks'                  => __( 'Tidak ada bank tersedia. Silakan hubungi administrator toko.', 'nicepay-payment-gateway-for-woocommerce' ),
		'alt_credit_card'           => __( 'Kartu Kredit', 'nicepay-payment-gateway-for-woocommerce' ),
		'alt_qris'                    => __( 'Pembayaran QRIS', 'nicepay-payment-gateway-for-woocommerce' ),
		'alt_ewallet'               => __( 'E-Wallet', 'nicepay-payment-gateway-for-woocommerce' ),
		'alt_virtual_account'       => __( 'Virtual Account', 'nicepay-payment-gateway-for-woocommerce' ),
		'alt_cvs'                   => __( 'CVS', 'nicepay-payment-gateway-for-woocommerce' ),
		'alt_payloan'               => __( 'Payloan', 'nicepay-payment-gateway-for-woocommerce' ),
	);
}

/**
 * Default checkout titles and legacy English → Indonesian mapping.
 *
 * @param string $gateway_id Gateway ID.
 * @param string $saved_title Title from gateway settings (may be empty or legacy English).
 * @return string
 */
function nicepay_get_checkout_gateway_title( $gateway_id, $saved_title = '' ) {
	$defaults = array(
		'nicepay_all'     => __( 'Lanjutkan Pembayaran', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_qris'    => __( 'NICEPay QRIS', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_va_snap' => __( 'NICEPay Virtual Account', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_ewallet' => __( 'NICEPay E-Wallet', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_cvs'     => __( 'NICEPay CVS', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_payloan' => __( 'NICEPay Payloan', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_cc'      => __( 'NICEPay Kartu Kredit', 'nicepay-payment-gateway-for-woocommerce' ),
	);

	$legacy = array(
		'NICEPay All Payment Method'   => $defaults['nicepay_all'],
		'NICEPAY All Payment Method'   => $defaults['nicepay_all'],
		'NICEPay E-wallet'             => $defaults['nicepay_ewallet'],
		'NICEPAY E-wallet'             => $defaults['nicepay_ewallet'],
		'NICEPAY E-wallet'             => $defaults['nicepay_ewallet'],
		'NICEPAY Cvs'                  => $defaults['nicepay_cvs'],
		'NICEPAY CVS'                  => $defaults['nicepay_cvs'],
		'NICEPAY Credit Card'          => $defaults['nicepay_cc'],
		'NICEPay Credit Card'          => $defaults['nicepay_cc'],
		'NICEPAY Payloan'              => $defaults['nicepay_payloan'],
	);

	$saved_title = is_string( $saved_title ) ? trim( $saved_title ) : '';

	if ( '' !== $saved_title && isset( $legacy[ $saved_title ] ) ) {
		return $legacy[ $saved_title ];
	}

	if ( '' !== $saved_title ) {
		return $saved_title;
	}

	return $defaults[ $gateway_id ] ?? $saved_title;
}

/**
 * Normalize NICEPay gateway titles at checkout (classic + AJAX).
 *
 * @param string $title Gateway title.
 * @param string $gateway_id Gateway ID.
 * @return string
 */
function nicepay_filter_checkout_gateway_title( $title, $gateway_id ) {
	if ( ! in_array( $gateway_id, nicepay_get_managed_gateway_ids(), true ) ) {
		return $title;
	}
	if ( ! is_checkout() && ! wp_doing_ajax() ) {
		return $title;
	}
	return nicepay_get_checkout_gateway_title( $gateway_id, $title );
}
add_filter( 'woocommerce_gateway_title', 'nicepay_filter_checkout_gateway_title', 10, 2 );

/**
 * Handle enable/disable toggle from NICEPay methods admin page.
 */
function nicepay_handle_gateway_status_toggle() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checked below before mutating settings.
	$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
	if ( 'nicepay-wc-payment-methods' !== $page ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checked below before mutating settings.
	$toggle = isset( $_GET['nicepay_toggle'] ) ? sanitize_text_field( wp_unslash( $_GET['nicepay_toggle'] ) ) : '';
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checked below before mutating settings.
	$gateway_id = isset( $_GET['gateway'] ) ? sanitize_text_field( wp_unslash( $_GET['gateway'] ) ) : '';

	if ( ! $toggle || ! $gateway_id ) {
		return;
	}

	if ( ! array_key_exists( $gateway_id, nicepay_get_gateway_settings_urls() ) ) {
		return;
	}

	if ( ! in_array( $toggle, array( 'enable', 'disable' ), true ) ) {
		return;
	}

	check_admin_referer( 'nicepay_toggle_gateway_' . $gateway_id );

	$saved = nicepay_set_gateway_enabled( $gateway_id, 'enable' === $toggle );

	if ( $saved ) {
		wp_safe_redirect( admin_url( 'admin.php?page=nicepay-wc-payment-methods&updated=1' ) );
	} else {
		wp_safe_redirect( admin_url( 'admin.php?page=nicepay-wc-payment-methods&update_error=1' ) );
	}
	exit;
}
add_action( 'load-woocommerce_page_nicepay-wc-payment-methods', 'nicepay_handle_gateway_status_toggle' );

/**
 * Register filters so gateway Configure screens do not show a duplicate Enable/Disable field.
 */
function nicepay_register_gateway_settings_field_filters() {
	foreach ( array_keys( nicepay_get_gateway_settings_urls() ) as $gateway_id ) {
		add_filter( 'woocommerce_settings_api_form_fields_' . $gateway_id, 'nicepay_remove_enabled_setting_field' );
	}
}
add_action( 'woocommerce_init', 'nicepay_register_gateway_settings_field_filters' );

/**
 * Remove Enable/Disable from per-gateway WooCommerce settings (managed on NICEPay Payment Gateway page).
 *
 * @param array<string, array<string, mixed>> $fields Gateway form fields.
 * @return array<string, array<string, mixed>>
 */
function nicepay_remove_enabled_setting_field( $fields ) {
	unset( $fields['enabled'] );
	return $fields;
}

/**
 * Gateway IDs managed only on the NICEPay Payment Gateway admin page.
 *
 * @return string[]
 */
function nicepay_get_managed_gateway_ids() {
	return array_keys( nicepay_get_gateway_settings_urls() );
}

/**
 * Remove NICEPay gateways from the WooCommerce Payments settings list (React + legacy).
 *
 * Runs during WooCommerce's `woocommerce_admin_field_payment_gateways` hook, immediately
 * before WC builds the providers list for Settings > Payments.
 */
function nicepay_exclude_gateways_from_wc_payments_settings_list() {
	if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
		return;
	}

	foreach ( nicepay_get_managed_gateway_ids() as $gateway_id ) {
		unset( WC()->payment_gateways()->payment_gateways[ $gateway_id ] );
	}
}
add_action( 'woocommerce_admin_field_payment_gateways', 'nicepay_exclude_gateways_from_wc_payments_settings_list', 1 );

/**
 * Backup filter for wc-admin payments providers REST response (WooCommerce 8.5+).
 *
 * @param WP_REST_Response|WP_HTTP_Response|WP_Error|mixed $response REST response.
 * @param WP_REST_Server                                   $server   REST server.
 * @param WP_REST_Request                                  $request  REST request.
 * @return WP_REST_Response|WP_HTTP_Response|WP_Error|mixed
 */
function nicepay_filter_wc_admin_payment_providers_response( $response, $server, $request ) {
	unset( $server );

	if ( ! $request instanceof WP_REST_Request ) {
		return $response;
	}

	$route = (string) $request->get_route();
	if ( '/wc-admin/settings/payments/providers' !== $route ) {
		return $response;
	}

	if ( ! $response instanceof WP_REST_Response ) {
		return $response;
	}

	$data = $response->get_data();
	if ( ! is_array( $data ) || empty( $data['providers'] ) || ! is_array( $data['providers'] ) ) {
		return $response;
	}

	$hidden_ids = array_flip( nicepay_get_managed_gateway_ids() );
	$data['providers'] = array_values(
		array_filter(
			$data['providers'],
			static function ( $provider ) use ( $hidden_ids ) {
				$id = is_array( $provider ) && isset( $provider['id'] ) ? (string) $provider['id'] : '';
				return '' === $id || ! isset( $hidden_ids[ $id ] );
			}
		)
	);

	$response->set_data( $data );

	return $response;
}
add_filter( 'rest_post_dispatch', 'nicepay_filter_wc_admin_payment_providers_response', 10, 3 );

/**
 * Render WooCommerce > NICEPay Payment Gateway page.
 */
function nicepay_render_wc_payment_methods_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	$gateway_labels = array(
		'nicepay_qris'    => __( 'QRIS', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_va_snap' => __( 'Virtual Account', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_ewallet' => __( 'E-Wallet', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_cvs'     => __( 'Convenience Store (CVS)', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_payloan' => __( 'Payloan', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_cc'      => __( 'Credit Card', 'nicepay-payment-gateway-for-woocommerce' ),
		'nicepay_all'     => __( 'All Payment Method', 'nicepay-payment-gateway-for-woocommerce' ),
	);

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin notice flag.
	if ( isset( $_GET['settings_saved'] ) && '1' === $_GET['settings_saved'] ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved successfully.', 'nicepay-payment-gateway-for-woocommerce' ) . '</p></div>';
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin notice flag.
	if ( isset( $_GET['updated'] ) && '1' === $_GET['updated'] ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Payment method status updated.', 'nicepay-payment-gateway-for-woocommerce' ) . '</p></div>';
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin notice flag.
	if ( isset( $_GET['update_error'] ) && '1' === $_GET['update_error'] ) {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Could not update payment method status. Please try again.', 'nicepay-payment-gateway-for-woocommerce' ) . '</p></div>';
	}

	echo '<div class="wrap nicepay-gateway-admin">';

	if ( class_exists( 'WC_Nicepay_Admin' ) ) {
		$admin = WC_Nicepay_Admin::instance();
		$admin->render_page_header();
		$admin->render_advanced_settings_form();
	}

	echo '<h2 class="title">' . esc_html__( 'Payment Methods', 'nicepay-payment-gateway-for-woocommerce' ) . '</h2>';
	echo '<p>' . esc_html__( 'Enable or disable each NICEPay payment method here. Use Configure for credentials and method-specific options only.', 'nicepay-payment-gateway-for-woocommerce' ) . '</p>';
	echo '<style>
		.nicepay-methods-table .nicepay-status-badge{display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:600;line-height:1.4;}
		.nicepay-methods-table .nicepay-status-enabled{background:#d1fae5;color:#065f46;}
		.nicepay-methods-table .nicepay-status-disabled{background:#f3f4f6;color:#6b7280;}
		.nicepay-methods-table tr.nicepay-row-enabled{background:#f0fdf4;}
		.nicepay-methods-table .nicepay-toggle-group{display:flex;gap:6px;flex-wrap:wrap;}
		.nicepay-methods-table .nicepay-toggle-disabled{opacity:.45;pointer-events:none;cursor:default;}
	</style>';
	echo '<table class="widefat striped nicepay-methods-table" style="max-width:860px;"><thead><tr><th>' . esc_html__( 'Method', 'nicepay-payment-gateway-for-woocommerce' ) . '</th><th>' . esc_html__( 'Status', 'nicepay-payment-gateway-for-woocommerce' ) . '</th><th>' . esc_html__( 'Enable / Disable', 'nicepay-payment-gateway-for-woocommerce' ) . '</th><th>' . esc_html__( 'Action', 'nicepay-payment-gateway-for-woocommerce' ) . '</th></tr></thead><tbody>';

	foreach ( nicepay_get_gateway_settings_urls() as $gateway_id => $settings_url ) {
		$label      = isset( $gateway_labels[ $gateway_id ] ) ? $gateway_labels[ $gateway_id ] : $gateway_id;
		$is_enabled = nicepay_is_gateway_enabled( $gateway_id );

		$enable_url = wp_nonce_url(
			admin_url( 'admin.php?page=nicepay-wc-payment-methods&gateway=' . rawurlencode( $gateway_id ) . '&nicepay_toggle=enable' ),
			'nicepay_toggle_gateway_' . $gateway_id
		);
		$disable_url = wp_nonce_url(
			admin_url( 'admin.php?page=nicepay-wc-payment-methods&gateway=' . rawurlencode( $gateway_id ) . '&nicepay_toggle=disable' ),
			'nicepay_toggle_gateway_' . $gateway_id
		);

		if ( $is_enabled ) {
			$row_class   = 'nicepay-row-enabled';
			$status_html = '<span class="nicepay-status-badge nicepay-status-enabled">' . esc_html__( 'Enabled', 'nicepay-payment-gateway-for-woocommerce' ) . '</span>';
			$enable_class  = 'button nicepay-toggle-disabled';
			$disable_class = 'button button-secondary';
		} else {
			$row_class   = '';
			$status_html = '<span class="nicepay-status-badge nicepay-status-disabled">' . esc_html__( 'Disabled', 'nicepay-payment-gateway-for-woocommerce' ) . '</span>';
			$enable_class  = 'button button-primary';
			$disable_class = 'button button-secondary nicepay-toggle-disabled';
		}

		echo '<tr class="' . esc_attr( $row_class ) . '">';
		echo '<td><strong>' . esc_html( $label ) . '</strong></td>';
		echo '<td>' . $status_html . '</td>';
		echo '<td><div class="nicepay-toggle-group">';
		echo '<a class="' . esc_attr( $enable_class ) . '" href="' . esc_url( $enable_url ) . '">' . esc_html__( 'Enable', 'nicepay-payment-gateway-for-woocommerce' ) . '</a>';
		echo '<a class="' . esc_attr( $disable_class ) . '" href="' . esc_url( $disable_url ) . '">' . esc_html__( 'Disable', 'nicepay-payment-gateway-for-woocommerce' ) . '</a>';
		echo '</div></td>';
		echo '<td><a class="button" href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Configure', 'nicepay-payment-gateway-for-woocommerce' ) . '</a></td>';
		echo '</tr>';
	}

	echo '</tbody></table>';

	if ( class_exists( 'WC_Nicepay_Admin' ) ) {
		WC_Nicepay_Admin::instance()->render_footer_help();
	}

	echo '</div>';
}

function nicepay_enqueue_payment_assets() {
    if (!is_checkout()) return;

    // === QRIS ASSETS ===
    if (class_exists('Nicepay_Gateway_QRIS') && nicepay_is_gateway_enabled('nicepay_qris')) {
        $qris_gateway = new Nicepay_Gateway_QRIS();
        $qris_mode    = 'blocks';

        // QRIS Style
        $file_qris_css = plugin_dir_path(__FILE__) . 'assets/css/qris.css';
        wp_enqueue_style(
            'nicepay-qris-style',
            plugin_dir_url(__FILE__) . 'assets/css/qris.css',
            [],
            filemtime($file_qris_css)
        );

        // QRIS Script (block checkout only)
        $file_qris_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/qris-block-integration.js';
        wp_enqueue_script(
            'nicepay-qris-blocks',
            plugin_dir_url(__FILE__) . 'assets/js/qris-block-integration.js',
            ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
            filemtime($file_qris_blocks_js),
            true
        );
        $qris_script_handle = 'nicepay-qris-blocks';

        // QRIS Localized Data
        $data_qris = array_merge(
            nicepay_get_checkout_i18n_strings(),
            array(
                'ajax_url'   => admin_url( 'admin-ajax.php' ),
                'nonce'      => wp_create_nonce( 'nicepay-qris-nonce' ),
                'pluginUrl'  => plugins_url( '', __FILE__ ),
                'merchantId' => $qris_gateway->get_option( 'iMid' ),
                'shopId'     => $qris_gateway->get_option( 'shopId' ),
                'mode'       => $qris_mode,
                'title'      => nicepay_get_checkout_gateway_title( 'nicepay_qris', $qris_gateway->get_option( 'title' ) ),
            )
        );
        wp_localize_script($qris_script_handle, 'qrisData', $data_qris);
    }

    // === VA SNAP ASSETS ===
    if (class_exists('Nicepay_Gateway_VA') && nicepay_is_gateway_enabled('nicepay_va_snap')) {
        $vasnap_gateway = new Nicepay_Gateway_VA();
        $vasnap_mode    = 'blocks';

        // VA Style
        $file_va_css = plugin_dir_path(__FILE__) . 'assets/css/vasnap.css';
        wp_enqueue_style(
            'nicepay-vasnap-style',
            plugin_dir_url(__FILE__) . 'assets/css/vasnap.css',
            [],
            filemtime($file_va_css)
        );

        // VA Script (block checkout only)
        $file_va_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/vasnap-block-integration.js';
        wp_enqueue_script(
            'nicepay-vasnap-blocks',
            plugin_dir_url(__FILE__) . 'assets/js/vasnap-block-integration.js',
            ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
            filemtime($file_va_blocks_js),
            true
        );
        $vasnap_script_handle = 'nicepay-vasnap-blocks';

        // VA Localized Data
        $data_va = array_merge(
            nicepay_get_checkout_i18n_strings(),
            array(
                'banks'     => $vasnap_gateway->get_active_bank_list(),
                'ajax_url'  => admin_url( 'admin-ajax.php' ),
                'pluginUrl' => plugins_url( '', __FILE__ ),
                'isVA'      => true,
                'nonce'     => wp_create_nonce( 'nicepay-bank-selection' ),
                'title'     => nicepay_get_checkout_gateway_title( 'nicepay_va_snap', $vasnap_gateway->get_option( 'title' ) ),
            )
        );
        wp_localize_script($vasnap_script_handle, 'nicepayVAData', $data_va);
    }

    // === Ewallet ASSETS ===
    if (class_exists('Nicepay_Gateway_Ewallet') && nicepay_is_gateway_enabled('nicepay_ewallet')) {
        $ewallet_gateway = new Nicepay_Gateway_Ewallet();
        $ewallet_mode    = 'blocks';

        // ewallet Style
        $file_ewallet_css = plugin_dir_path(__FILE__) . 'assets/css/ewallet.css';
        wp_enqueue_style(
            'nicepay-ewallet-style',
            plugin_dir_url(__FILE__) . 'assets/css/ewallet.css',
            [],
            filemtime($file_ewallet_css)
        );

        // ewallet Script (block checkout only)
        $file_ewallet_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/ewallet-block-integration.js';
        wp_enqueue_script(
            'nicepay-ewallet-blocks',
            plugin_dir_url(__FILE__) . 'assets/js/ewallet-block-integration.js',
            ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
            filemtime($file_ewallet_blocks_js),
            true
        );
        $ewallet_script_handle = 'nicepay-ewallet-blocks';

        // ewallet Localized Data
        $data_ewallet = array_merge(
            nicepay_get_checkout_i18n_strings(),
            array(
                'enabled_mitra' => $ewallet_gateway->get_ewallet_options(),
                'ajax_url'      => admin_url( 'admin-ajax.php' ),
                'nonce'         => wp_create_nonce( 'nicepay-ewallet-nonce' ),
                'pluginUrl'     => plugins_url( '', __FILE__ ),
                'isEwallet'     => true,
                'title'         => nicepay_get_checkout_gateway_title( 'nicepay_ewallet', $ewallet_gateway->get_option( 'title' ) ),
            )
        );
        wp_localize_script($ewallet_script_handle, 'nicepayEwalletData', $data_ewallet);
    }

    // === cvs ASSETS ===
    if ( class_exists( 'Nicepay_Gateway_Cvs' ) && nicepay_is_gateway_enabled( 'nicepay_cvs' ) ) {
        $cvs_gateway = new Nicepay_Gateway_Cvs();

        $file_cvs_css = plugin_dir_path( __FILE__ ) . 'assets/css/cvs.css';
        wp_enqueue_style(
            'nicepay-cvs-style',
            plugin_dir_url( __FILE__ ) . 'assets/css/cvs.css',
            [],
            file_exists( $file_cvs_css ) ? filemtime( $file_cvs_css ) : NICEPAY_WC_VERSION
        );

        $file_cvs_blocks_js = plugin_dir_path( __FILE__ ) . 'assets/js/cvs-block-integration.js';
        wp_enqueue_script(
            'nicepay-cvs-blocks',
            plugin_dir_url( __FILE__ ) . 'assets/js/cvs-block-integration.js',
            array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery' ),
            filemtime( $file_cvs_blocks_js ),
            true
        );

        wp_localize_script(
            'nicepay-cvs-blocks',
            'nicepayCvsData',
            array_merge(
                nicepay_get_checkout_i18n_strings(),
                array(
                    'enabled_mitra' => $cvs_gateway->get_cvs_options(),
                    'ajax_url'      => admin_url( 'admin-ajax.php' ),
                    'nonce'         => wp_create_nonce( 'nicepay-cvs-nonce' ),
                    'pluginUrl'     => plugins_url( '', __FILE__ ),
                    'iscvs'         => true,
                    'title'         => nicepay_get_checkout_gateway_title( 'nicepay_cvs', $cvs_gateway->get_option( 'title' ) ),
                )
            )
        );
    }

    // === Payloan ASSETS ===
    if ( class_exists( 'Nicepay_Gateway_Payloan' ) && nicepay_is_gateway_enabled( 'nicepay_payloan' ) ) {
        $payloan_gateway = new Nicepay_Gateway_Payloan();

        $file_payloan_css = plugin_dir_path( __FILE__ ) . 'assets/css/payloan.css';
        wp_enqueue_style(
            'nicepay-payloan-style',
            plugin_dir_url( __FILE__ ) . 'assets/css/payloan.css',
            [],
            filemtime( $file_payloan_css )
        );

        $file_payloan_blocks_js = plugin_dir_path( __FILE__ ) . 'assets/js/payloan-block-integration.js';
        wp_enqueue_script(
            'nicepay-payloan-blocks',
            plugin_dir_url( __FILE__ ) . 'assets/js/payloan-block-integration.js',
            array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery' ),
            filemtime( $file_payloan_blocks_js ),
            true
        );

        wp_localize_script(
            'nicepay-payloan-blocks',
            'nicepaypayloanData',
            array_merge(
                nicepay_get_checkout_i18n_strings(),
                array(
                    'enabled_mitra' => $payloan_gateway->get_payloan_options(),
                    'ajax_url'      => admin_url( 'admin-ajax.php' ),
                    'nonce'         => wp_create_nonce( 'nicepay-payloan-nonce' ),
                    'pluginUrl'     => plugins_url( '', __FILE__ ),
                    'ispayloan'     => true,
                    'title'         => nicepay_get_checkout_gateway_title( 'nicepay_payloan', $payloan_gateway->get_option( 'title' ) ),
                )
            )
        );
    }

    // === Credit Card ASSETS ===
    if ( class_exists( 'Nicepay_Gateway_CC' ) && nicepay_is_gateway_enabled( 'nicepay_cc' ) ) {
        $cc_gateway = new Nicepay_Gateway_CC();

        $file_cc_css = plugin_dir_path( __FILE__ ) . 'assets/css/cc.css';
        wp_enqueue_style(
            'nicepay-cc-style',
            plugin_dir_url( __FILE__ ) . 'assets/css/cc.css',
            [],
            filemtime( $file_cc_css )
        );

        $file_cc_blocks_js = plugin_dir_path( __FILE__ ) . 'assets/js/cc-block-integration.js';
        wp_enqueue_script(
            'nicepay-cc-blocks',
            plugin_dir_url( __FILE__ ) . 'assets/js/cc-block-integration.js',
            array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry' ),
            filemtime( $file_cc_blocks_js ),
            true
        );

        wp_localize_script(
            'nicepay-cc-blocks',
            'nicepayCCData',
            array_merge(
                nicepay_get_checkout_i18n_strings(),
                array(
                    'ajax_url'  => admin_url( 'admin-ajax.php' ),
                    'security'  => wp_create_nonce( 'nicepay-cc-nonce' ),
                    'pluginUrl' => plugins_url( '', __FILE__ ),
                    'isCC'      => true,
                    'title'     => nicepay_get_checkout_gateway_title( 'nicepay_cc', $cc_gateway->get_option( 'title' ) ),
                )
            )
        );
    }

    // === All Payment Method ASSETS ===
    if ( class_exists( 'Nicepay_Gateway_All' ) && nicepay_is_gateway_enabled( 'nicepay_all' ) ) {
        $all_gateway = new Nicepay_Gateway_All();

        $file_all_blocks_js = plugin_dir_path( __FILE__ ) . 'assets/js/all-block-integration.js';
        $file_all_css       = plugin_dir_path( __FILE__ ) . 'assets/css/all.css';
        wp_enqueue_style(
            'nicepay-all-style',
            plugin_dir_url( __FILE__ ) . 'assets/css/all.css',
            [],
            file_exists( $file_all_css ) ? filemtime( $file_all_css ) : NICEPAY_WC_VERSION
        );
        wp_enqueue_script(
            'nicepay-all-blocks',
            plugin_dir_url( __FILE__ ) . 'assets/js/all-block-integration.js',
            array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry' ),
            filemtime( $file_all_blocks_js ),
            true
        );

        wp_localize_script(
            'nicepay-all-blocks',
            'nicepayAllData',
            array_merge(
                nicepay_get_checkout_i18n_strings(),
                array(
                    'ajax_url'      => admin_url( 'admin-ajax.php' ),
                    'security'      => wp_create_nonce( 'nicepay-all-nonce' ),
                    'pluginUrl'     => plugins_url( '', __FILE__ ),
                    'title'         => nicepay_get_checkout_gateway_title( 'nicepay_all', $all_gateway->get_option( 'title' ) ),
                    'isAll'         => true,
                    'methodIcons'   => $all_gateway->get_checkout_method_icons(),
                )
            )
        );
    }

    // === Payout ASSETS ===
    // if (class_exists('Nicepay_Gateway_Payout')) {
    //     $payout_gateway = new Nicepay_Gateway_Payout();
    //     $payout_mode    = $payout_gateway->get_option('enable_blocks', 'classic');

    //     // Payout Style
    //     $file_payout_css = plugin_dir_path(__FILE__) . 'assets/css/payout.css';
    //     if (file_exists($file_payout_css)) {
    //         wp_enqueue_style(
    //             'nicepay-payout-style',
    //             plugin_dir_url(__FILE__) . 'assets/css/payout.css',
    //             [],
    //             filemtime($file_payout_css)
    //         );
    //     }

    //     // Payout Script
    //     if ($payout_mode === 'classic') {
    //         $file_payout_js = plugin_dir_path(__FILE__) . 'assets/js/payout-classic-checkout.js';
    //         wp_enqueue_script(
    //             'nicepay-payout-classic',
    //             plugin_dir_url(__FILE__) . 'assets/js/payout-classic-checkout.js',
    //             ['jquery'],
    //             filemtime($file_payout_js),
    //             true
    //         );
    //         $payout_script_handle = 'nicepay-payout-classic';
    //     } else {
    //         $file_payout_js = plugin_dir_path(__FILE__) . 'assets/js/payout-block-integration.js';
    //         wp_enqueue_script(
    //             'nicepay-payout-blocks',
    //             plugin_dir_url(__FILE__) . 'assets/js/payout-block-integration.js',
    //             ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
    //             filemtime($file_payout_js),
    //             true
    //         );
    //         $payout_script_handle = 'nicepay-payout-blocks';
    //     }

    //     // VA Localized Data
    //     $data_payout = [
    //         'ajax_url'  => admin_url('admin-ajax.php'),
    //         'pluginUrl' => plugins_url('', __FILE__),
    //         'isPayout'  => true,
    //         'nonce'     => wp_create_nonce('nicepay-bank-payout-selection')
    //     ];
    //     wp_localize_script($payout_script_handle, 'nicepayPayoutData', $data_payout);
    // }
}

// /**
//  * === Admin Menu ===
//  */
// add_action('admin_menu', 'nicepay_register_admin_menu');
// function nicepay_register_admin_menu() {
//     add_menu_page(
//         'NICEPay Admin Actions',
//         'NICEPay Admin Actions',
//         'manage_options',
//         'nicepay-admin-actions',
//         'nicepay_admin_actions_page',
//         'dashicons-admin-generic',
//         56
//     );
// }

// function nicepay_admin_actions_page() {
//     $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'va';

//     $tabs = [
//         'va'      => 'VA Cancel',
//         'qris'    => 'QRIS Cancel',
//         'ewallet' => 'eWallet Cancel'
//         //'payout'  => 'Payout Actions'
//     ];

//     echo '<div class="wrap">';
//     echo '<h1>NICEPay Admin Actions</h1>';

//     // Tabs
//     echo '<h2 class="nav-tab-wrapper">';
//     foreach ($tabs as $key => $label) {
//         $class = ($active_tab == $key) ? ' nav-tab-active' : '';
//         echo '<a href="?page=nicepay-admin-actions&tab=' . $key . '" class="nav-tab' . $class . '">' . esc_html($label) . '</a>';
//     }
//     echo '</h2>';

//     echo '<div id="nicepay-admin-container">';
//     echo '<form id="nicepay-admin-form">';
//     wp_nonce_field('nicepay_admin_action', 'nicepay_admin_nonce');
//     echo '<input type="hidden" name="action" value="nicepay_admin_process">';
//     echo '<input type="hidden" name="operation" value="' . esc_attr($active_tab) . '">';

//     // Render form per tab
//     if ($active_tab === 'va') {
//         echo '<h3>VA Cancel</h3>';
//         echo '<label>virtualAccountNo</label><input type="text" name="virtualAccountNo" required />';
//         echo '<label>trxId</label><input type="text" name="trxId" required />';
//     }

//     if ($active_tab === 'qris') {
//         echo '<h3>QRIS Cancel</h3>';
//         echo '<label>originalPartnerReferenceNo</label><input type="text" name="originalPartnerReferenceNo" required />';
//         echo '<label>originalReferenceNo</label><input type="text" name="originalReferenceNo" required />';
//         echo '<label>partnerRefundNo</label><input type="text" name="partnerRefundNo" required />';
//         echo '<label>merchantId</label><input type="text" name="merchantId" required />';
//     }

//     if ($active_tab === 'ewallet') {
//         echo '<h3>eWallet Cancel</h3>';
//         echo '<label>originalPartnerReferenceNo</label><input type="text" name="originalPartnerReferenceNo" required />';
//         echo '<label>originalReferenceNo</label><input type="text" name="originalReferenceNo" required />';
//         echo '<label>partnerRefundNo</label><input type="text" name="partnerRefundNo" required />';
//         echo '<label>merchantId</label><input type="text" name="merchantId" required />';
//     }

//     if ($active_tab === 'payout') {
//         echo '<h3>Payout Actions</h3>';
//         echo '<label>originalPartnerReferenceNo</label><input type="text" name="originalPartnerReferenceNo" required />';
//         echo '<label>originalReferenceNo</label><input type="text" name="originalReferenceNo" required />';
//         echo '<label>merchantId</label><input type="text" name="merchantId" required />';
//         echo '<label>Action</label>';
//         echo '<select name="payout_action" required>
//                 <option value="">Select</option>
//                 <option value="approve">Approve</option>
//                 <option value="reject">Reject</option>
//                 <option value="cancel">Cancel</option>
//               </select>';
//     }

//     echo '<button type="submit" class="button button-primary">Submit</button>';
//     echo '</form>';
//     echo '<div id="nicepay-admin-response"></div>';
//     echo '</div>';
//     echo '</div>';
// }

// // Enqueue admin JS + CSS
// add_action('admin_enqueue_scripts', function($hook) {
//     if ($hook !== 'toplevel_page_nicepay-admin-actions') return;
//     wp_enqueue_script('nicepay-admin-js', NICEPAY_PLUGIN_URL . 'assets/js/nicepay-admin.js', ['jquery'], '1.0', true);
//     wp_localize_script('nicepay-admin-js', 'nicepayAdmin', [
//         'ajax_url' => admin_url('admin-ajax.php'),
//         'nonce'    => wp_create_nonce('nicepay_admin_action')
//     ]);
//     wp_enqueue_style('nicepay-admin-css', NICEPAY_PLUGIN_URL . 'assets/css/nicepay-admin.css');
// });

// // Handle AJAX
// add_action('wp_ajax_nicepay_admin_process', function() {
//     check_ajax_referer('nicepay_admin_action', 'security');

//     $operation = sanitize_text_field($_POST['operation']);
//     $params    = $_POST;

//     unset($params['action'], $params['security'], $params['operation']);

//     require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-nicepay-admin-actions.php';
//     $result = NICEPay_Admin_Actions::process($operation, $params);

//     wp_send_json($result);
// });

// Tambah admin menu log page
add_action('admin_menu', 'nicepay_register_log_menu');
function nicepay_register_log_menu() {
    add_menu_page(
        'NICEPay Logs',
        'NICEPay Logs',
        'manage_options',
        'nicepay-logs',
        'nicepay_logs_main_page_callback',
        'dashicons-clipboard',
        56
    );
}

// Main admin log page callback
function nicepay_logs_main_page_callback() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $allowed_channels = array( 'va', 'qris', 'ewallet', 'payout', 'cvs', 'payloan', 'cc', 'all' );
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin tab navigation.
    $active_tab = isset( $_GET['channel'] ) ? sanitize_text_field( wp_unslash( $_GET['channel'] ) ) : 'va';
    if ( ! in_array( $active_tab, $allowed_channels, true ) ) {
        $active_tab = 'va';
    }
    $channels = array( 'va' => 'VA', 'qris' => 'QRIS', 'ewallet' => 'eWallet', 'payout' => 'Payout', 'cvs' => 'Cvs', 'payloan' => 'Payloan', 'cc' => 'Credit Card', 'all' => 'All Payment' );

    echo '<div class="wrap"><h1>NICEPay Logs</h1>';

    // Tab navigation
    echo '<h2 class="nav-tab-wrapper">';
    foreach ($channels as $key => $label) {
        $active_class = ($active_tab === $key) ? ' nav-tab-active' : '';
        echo '<a href="?page=nicepay-logs&channel=' . esc_attr($key) . '" class="nav-tab' . $active_class . '">' . esc_html($label) . '</a>';
    }
    echo '</h2>';

    $log_manager = NICEPay_Log_Manager::instance($active_tab);

    // Action buttons
    echo '<p><a href="' . esc_url($log_manager->get_log_file_url()) . '" class="button button-primary" download>Download Log Hari Ini</a> ';
    echo '<a href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?page=nicepay-logs&channel=' . $active_tab . '&clear=true' ), 'nicepay_clear_log_' . $active_tab ) ) . '" class="button">Clear Log Hari Ini</a></p>';

    // Tampilkan log hari ini
    $logs = $log_manager->get_logs();
    if (empty($logs)) {
        echo '<p>Tidak ada log ditemukan.</p>';
    } else {
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Waktu</th><th>Tipe</th><th>Pesan</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            echo '<tr>';
            echo '<td>' . esc_html($log['time']) . '</td>';
            echo '<td>' . esc_html(ucfirst($log['type'])) . '</td>';
            echo '<td>' . esc_html($log['message']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    // Daftar file log lama
    $files = $log_manager->get_log_files();
    if (!empty($files)) {
        echo '<h3>Log Sebelumnya</h3><ul>';
        foreach ($files as $file) {
            if ($file === $log_manager->get_today_log_filename()) continue;
            $url = $log_manager->get_log_file_url($file);
            echo '<li><a href="' . esc_url($url) . '" download>' . esc_html($file) . '</a></li>';
        }
        echo '</ul>';
    }

    echo '</div>';
}

// Clear log dari URL param
add_action( 'admin_init', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified below for destructive action.
    $page    = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
    $channel = isset( $_GET['channel'] ) ? sanitize_text_field( wp_unslash( $_GET['channel'] ) ) : '';
    $clear   = isset( $_GET['clear'] ) ? sanitize_text_field( wp_unslash( $_GET['clear'] ) ) : '';

    if ( 'nicepay-logs' !== $page || 'true' !== $clear || empty( $channel ) ) {
        return;
    }
    if ( ! in_array( $channel, array( 'va', 'qris', 'ewallet', 'payout', 'cvs', 'payloan', 'cc', 'all' ), true ) ) {
        return;
    }

    check_admin_referer( 'nicepay_clear_log_' . $channel );

    NICEPay_Log_Manager::instance( $channel )->clear_logs();
    wp_safe_redirect( admin_url( 'admin.php?page=nicepay-logs&channel=' . $channel ) );
    exit;
} );