=== NICEPay Payment Gateway for WooCommerce ===
Contributors: nicepay
Tags: woocommerce, payment, ewallet, virtual-account, qris
Requires at least: 5.8
Tested up to: 7.0
Stable tag: 1.2.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

NICEPay payment gateway for WooCommerce: VA, QRIS, e-wallets, cards, paylater, and CVS checkout.

== Description ==

The official NICEPay Payment Gateway for WooCommerce enables merchants to offer a variety of payment methods—all processed securely through NICEPay. Customers stay on your checkout page from start to finish:

• Virtual Account (BCA, BNI, Mandiri, etc.)  
• QRIS  
• E-Wallets (OVO, DANA, LinkAja, ShopeePay)  
• Credit Card (Full Payment, One-Click)  
• Paylater / Payloan (Akulaku, Kredivo, Indodana)  
• Convenience Stores (Indomaret, Alfamart)

Supports WooCommerce Blocks and offers smooth admin configuration under WooCommerce → Settings → Payments.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/nicepay-payment-gateway-for-woocommerce`.
2. Activate the plugin via the **Plugins** screen in WordPress.
3. Navigate to **WooCommerce → Settings → Payments**.
4. Enable **NICEPay Payment Gateway** and enter your NICEPay credentials (iMid, Merchant Key, API URL).
5. Choose the payment methods you’d like to display at checkout.
6. Save settings and run test payments using NICEPay Sandbox before going live.

== Frequently Asked Questions ==

= How do I get my Merchant ID and keys? =
Register at the NICEPay Merchant Dashboard and request your iMid and API credentials.

= Does the plugin support WooCommerce Blocks? =
Yes, it is compatible with standard and block-based checkout flows.

= Can I offer installment or paylater options? =
Yes. Simply enable Paylater in settings. Available options include Akulaku, Kredivo, and Indodana.

= Where can I report bugs or request new features? =
Contact us at **integration@nicepay.co.id** or raise an issue on the GitHub repo.

== Screenshots ==
1. NICEPay setup page in WooCommerce admin.
2. Checkout view showing payment options.
3. QRIS checkout interface.

== Changelog ==
= 1.2.0 =
* Add NICEPay All Payment Method gateway (redirect/v2, payMethod 00)
* Add WooCommerce admin page to enable/disable each NICEPay method
* Block Checkout: internal redirect + receipt forward for All & CC (WC 10+ compatible)
* All gateway: notification validation (referenceNo, tXid, status), inquiry-based status update
* All gateway: detailed success order note (payment type, detail, txid, amount, datetime)
* All gateway: checkout UI with payment method icons
* Conflict fixes when All, CC, and Payloan are enabled together (single asset enqueue, return URL, AJAX)
* Store API output buffer scoped to avoid breaking other plugins
* BOM / stray output mitigation for gateway includes
= 1.0.0 =
* Initial stable release with full payment method and feature support.
= 1.0.1 =
* fixing checkstatus for CC
= 1.0.2 =
*Fixing setting host
= 1.0.3 =
* Add Checkout Status
= 1.0.4 =
* Fixing enable/disable CVS method
= 1.1.0 =
* Update Plugin versi checkout Classic Mode & fixing tampilan checkout classic
= 1.1.1 =
* Fixing Environment Global
= 1.1.2 =
* Fixing CVS method JS
= 1.1.3 =
* Fixing CVS mode classic
* thank you page notif
* Payloan Classic mode
= 1.1.4 =
*Fixing RefNo
= 1.1.5 =
*Fixing Ewallet mothod


== Upgrade Notice ==
= 1.2.2 =
Fixing Bug images payment versi mobile
= 1.2.1 =
Fixing bug all paymethod
= 1.2.0 =
New All Payment Method gateway, admin enable/disable page, Block Checkout fixes, and notification improvements. Update recommended for merchants using multiple NICEPay methods.
= 1.0.0 =
First official release! Set your merchant account and go live.