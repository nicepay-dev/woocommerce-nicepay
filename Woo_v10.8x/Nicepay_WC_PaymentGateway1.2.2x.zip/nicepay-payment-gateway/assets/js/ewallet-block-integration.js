console.log("Loading NICEPay Ewallet Plugin");

document.addEventListener('DOMContentLoaded', function () {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log("Initializing E-wallet Payment Method");
        initNicepayEwallet();
    } else {
        console.error('Required dependencies not available for E-wallet');
    }
});

function initNicepayEwallet() {
    if (window.nicepay_ewallet_registered === true) {
        return;
    }

    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment, useState, useEffect } = window.wp.element;
    const data = window.nicepayEwalletData || {};
    const label = data.title || 'NICEPay E-Wallet';

    const NicepayEwalletComponent = () => {
        const [selectedMitra, setSelectedMitra] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const mitra = window.nicepayEwalletData?.enabled_mitra || [];

        console.log('Available mitra (Ewallet):', mitra);

        useEffect(() => {
            setSelectedMitra('');
        }, []);

        const handleMitraChange = (e) => {
            const value = e.target.value;
            setSelectedMitra(value);
            setIsLoading(true);

            if (typeof jQuery === 'undefined' || !window.nicepayEwalletData) {
                console.warn('jQuery or nicepayEwalletData not available');
                setIsLoading(false);
                return;
            }
            if (!nicepayEwalletData.ajax_url || !nicepayEwalletData.nonce) {
                setIsLoading(false);
                return;
            }

            jQuery.ajax({
                url: nicepayEwalletData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_mitra',
                    mitra_code: value,
                    nonce: nicepayEwalletData.nonce
                },
                success: function (response) {
                    console.log('Mitra saved:', response);
                    setIsLoading(false);
                },
                error: function (xhr, status, error) {
                    console.error('Error saving mitra:', error);
                    setIsLoading(false);
                }
            });
        };

        if (!mitra.length) {
            return createElement('div', { className: 'nicepay-ewallet-container' },
                createElement('p', null, data.no_ewallet || 'Tidak ada e-wallet yang tersedia saat ini.')
            );
        }

        return createElement('div', { className: 'nicepay-ewallet-container' },
            createElement('div', { className: 'nicepay-ewallet-header' },
                createElement('img', {
                    src: (nicepayEwalletData?.pluginUrl || '') + '/assets/images/ewallet-logo-kecil.png',
                    alt: data.alt_ewallet || 'E-Wallet',
                    className: 'nicepay-ewallet-image'
                })
            ),
            createElement('div', { className: 'nicepay-ewallet-select' },
                createElement('label', { htmlFor: 'nicepay-ewallet-select' }, data.select_ewallet || 'Pilih E-wallet:'),
                createElement('select', {
                    name: 'nicepay_mitra',
                    id: 'nicepay-ewallet-select',
                    onChange: handleMitraChange,
                    value: selectedMitra,
                    disabled: isLoading,
                    required: true
                },
                    [
                        createElement('option', { value: '' }, data.select_ewallet_placeholder || 'Pilih E-wallet'),
                        ...mitra.map(m =>
                            createElement('option', {
                                value: m.value || m.code,
                                key: m.value || m.code
                            }, m.label || m.name)
                        )
                    ]
                ),
                isLoading && createElement('span', { className: 'nicepay-loading' }, 'Menyimpan...')
            ),
            createElement('p', { className: 'nicepay-ewallet-instruction' }, data.select_ewallet_instruction || 'Silakan pilih e-wallet untuk pembayaran Anda.'),
            createElement('input', { type: 'hidden', name: 'nicepay_selected_mitra', value: selectedMitra })
        );
    };

    registerPaymentMethod({
        name: "nicepay_ewallet",
        label: label,
        content: createElement(NicepayEwalletComponent),
        edit: createElement(NicepayEwalletComponent),
        canMakePayment: () => true,
        ariaLabel: label,
        supports: { features: ['products'] }
    });

    window.nicepay_ewallet_registered = true;
    console.log("Ewallet Payment Method successfully registered");
}
