(function () {
    console.log("Loading NICEPay VA Plugin");

    document.addEventListener('DOMContentLoaded', function () {
        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
            console.log("Initializing VA Payment Method");
            initNicepayVA();
        } else {
            console.error('Required dependencies not available for VA');
        }
    });

    function initNicepayVA() {
        if (window.nicepay_va_registered === true) {
            return;
        }

        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
        const { createElement, Fragment, useState } = window.wp.element;
        const data = window.nicepayVAData || {};
        const label = data.title || 'NICEPay Virtual Account';

        const banks = data.banks || [];

        const NicepayVAComponent = () => {
            const [selectedBank, setSelectedBank] = useState('');

            const handleBankChange = (e) => {
                const value = e.target.value;
                setSelectedBank(value);

                if (typeof jQuery !== 'undefined' && typeof nicepayVAData !== 'undefined') {
                    jQuery.ajax({
                        url: nicepayVAData.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'set_nicepay_bank',
                            bank: value,
                            security: nicepayVAData.nonce || '' 
                        }
                    });
                }
            };

            return createElement('div', { className: 'nicepay-vasnap-container' },
                createElement('div', { className: 'nicepay-vasnap-header' },
                    createElement('img', {
                        src: nicepayVAData.pluginUrl + '/assets/images/logo-bank.png',
                        alt: data.alt_virtual_account || 'Virtual Account',
                        className: 'nicepay-vasnap-image'
                    })
                ),
                createElement('div', { className: 'nicepay-vasnap-select' },
                    createElement('label', { htmlFor: 'nicepay-bank-select' }, data.select_bank || 'Pilih Bank:'),
                    createElement('select', {
                        name: 'nicepay_bank',
                        id: 'nicepay-bank-select',
                        onChange: handleBankChange,
                        value: selectedBank,
                        required: true
                    },
                        [
                            createElement('option', { value: '' }, data.select_bank_placeholder || 'Pilih Bank'),
                            ...banks.map(bank =>
                                createElement('option', {
                                    value: bank.code,
                                    key: bank.code
                                }, bank.name)
                            )
                        ]
                    )
                ),
                createElement('p', { className: 'nicepay-vasnap-instruction' }, data.select_bank_instruction || 'Silakan pilih bank untuk pembayaran Virtual Account Anda.')
            );
        };

        registerPaymentMethod({
            name: 'nicepay_va_snap',
            label: label,
            content: createElement(NicepayVAComponent),
            edit: createElement(NicepayVAComponent),
            canMakePayment: () => true,
            ariaLabel: label,
            supports: { features: ['products'] }
        });

        window.nicepay_va_registered = true;
        console.log('VA Payment Method registered');
    }
})();
