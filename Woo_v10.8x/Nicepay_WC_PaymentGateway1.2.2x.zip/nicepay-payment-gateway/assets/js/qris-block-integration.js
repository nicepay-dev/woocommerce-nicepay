document.addEventListener('DOMContentLoaded', function() {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log('Initializing QRIS payment method');
        initNicepayQrisSnap();
    } else {
        console.error('Required dependencies not available');
    }
});

function initNicepayQrisSnap() {
    if (window.nicepay_qris_registered === true) {
        return;
    }

    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment, useState } = window.wp.element;
    const data = window.qrisData || {};
    const label = data.title || 'NICEPay QRIS';

    const NicepayQrisComponent = () => {
        const [mitraCd, setMitraCd] = useState('QSHP');

        return createElement(Fragment, null,
            createElement('div', { className: 'nicepay-qris-container' },
                createElement('div', { className: 'nicepay-qris-content' },
                    createElement('div', { className: 'nicepay-qris-logos' },
                        createElement('img', {
                            src: (data.pluginUrl || '') + '/assets/images/qris-logo-besar.png',
                            alt: data.alt_qris || 'Pembayaran QRIS',
                            className: 'nicepay-qris-image'
                        })
                    ),
                    createElement('div', { className: 'nicepay-qris-info' },
                        createElement('p', { className: 'qris-instruction' },
                            data.qris_instruction || 'Pembayaran menggunakan QRIS dapat dilakukan melalui berbagai aplikasi e-wallet dan mobile banking yang mendukung QRIS'
                        )
                    ),
                    
                    createElement('input', {
                        type: 'hidden',
                        name: 'mitraCdQRISV2',
                        value: mitraCd
                    })
                )
            )
        );
    };

    registerPaymentMethod({
        name: 'nicepay_qris',
        label: label,
        content: createElement(NicepayQrisComponent),
        edit: createElement(NicepayQrisComponent),
        canMakePayment: () => true,
        ariaLabel: label,
        paymentMethodId: 'nicepay_qris',
        supports: {
            features: ['products'],
            showSaveOption: false,
            showSavedCards: false
        },
        
        getData: () => {
            return {
                mitraCdQRISV2: 'QSHP' 
            };
        }
    });

    window.nicepay_qris_registered = true;
}
