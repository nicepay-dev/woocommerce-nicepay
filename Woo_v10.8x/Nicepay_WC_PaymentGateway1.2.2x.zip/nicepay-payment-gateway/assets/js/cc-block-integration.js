(function () {
    console.log("Loading NICEPay CC Plugin");

    document.addEventListener('DOMContentLoaded', function () {
        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
            console.log('Initializing Credit Card payment method');
            initNicepayCC();
        } else {
            console.error('Required dependencies not available for CC');
        }
    });

    function initNicepayCC() {
        if (window.nicepay_cc_registered === true) {
            return;
        }

        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
        const { createElement, Fragment } = window.wp.element;
        const data = window.nicepayCCData || {};
        const label = data.title || 'NICEPay Kartu Kredit';

        const NicepayCCComponent = () => {
            return createElement(Fragment, null,
                createElement('div', { className: 'nicepay-cc-container' },
                    createElement('div', { className: 'nicepay-cc-header' },
                        createElement('img', {
                            src: (data.pluginUrl || '') + '/assets/images/credit-card-logo.png',
                            alt: data.alt_credit_card || 'Kartu Kredit',
                            className: 'nicepay-cc-image',
                            onError: e => e.target.style.display = 'none'
                        })
                    ),
                    createElement('p', null,
                        data.cc_redirect || 'Anda akan diarahkan ke NICEPay untuk menyelesaikan pembayaran dengan aman.'
                    )
                )
            );
        };

        registerPaymentMethod({
            name: 'nicepay_cc',
            label: label,
            content: createElement(NicepayCCComponent),
            edit: createElement(NicepayCCComponent),
            canMakePayment: () => true,
            ariaLabel: label,
            supports: { features: ['products'] }
        });

        window.nicepay_cc_registered = true;
        console.log('CC Payment Method registered');
    }
})();
