(function () {
    console.log("Loading NICEPay CVS Plugin");

    document.addEventListener('DOMContentLoaded', function () {
        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
            console.log("Initializing CVS Payment Method");
            initNicepayCvs();
        } else {
            console.error('Required dependencies not available for CVS');
        }
    });

    function initNicepayCvs() {
        if (window.nicepay_cvs_registered === true) {
            return;
        }

        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
        const { createElement, Fragment, useState } = window.wp.element;
        const data = window.nicepayCvsData || {};
        const label = data.title || 'NICEPay CVS';
        let selectedMitraForCheckout = '';

        const saveMitraToSession = (mitraCode) => {
            if (!mitraCode || typeof jQuery === 'undefined' || !window.nicepayCvsData) {
                return;
            }
            if (!nicepayCvsData.ajax_url || !nicepayCvsData.nonce) {
                return;
            }
            jQuery.ajax({
                url: nicepayCvsData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_cvs_mitra',
                    mitra_code: mitraCode,
                    nonce: nicepayCvsData.nonce
                }
            });
        };

        const NicepayCvsComponent = () => {
            const [selectedMitra, setSelectedMitra] = useState('');

            const handleMitraChange = (e) => {
                const value = e.target.value;
                setSelectedMitra(value);
                selectedMitraForCheckout = value;
                saveMitraToSession(value);
            };

            const mitra = data.enabled_mitra || [];

            if (!mitra.length) {
                return createElement('div', { className: 'nicepay-cvs-container' },
                    createElement('p', null, data.no_cvs || 'Tidak ada CVS yang tersedia saat ini.')
                );
            }

            return createElement('div', { className: 'nicepay-cvs-container' },
                createElement('div', { className: 'nicepay-cvs-logos' },
                    createElement('img', {
                        src: (data.pluginUrl || '') + '/assets/images/cvs-logo.png',
                        alt: data.alt_cvs || 'CVS',
                        className: 'nicepay-cvs-logo'
                    })
                ),
                createElement('div', { className: 'nicepay-cvs-select' },
                    createElement('label', { htmlFor: 'nicepay-cvs-select' }, data.select_cvs || 'Pilih CVS:'),
                    createElement('select', {
                        name: 'nicepay_cvs_mitra',
                        id: 'nicepay-cvs-select',
                        onChange: handleMitraChange,
                        value: selectedMitra,
                        required: true
                    },
                        [
                            createElement('option', { value: '' }, data.select_cvs_placeholder || 'Pilih CVS'),
                            ...mitra.map(m =>
                                createElement('option', {
                                    value: m.value || m.code,
                                    key: m.value || m.code
                                }, m.label || m.name)
                            )
                        ]
                    )
                ),
                createElement('p', { className: 'nicepay-cvs-instruction' }, data.select_cvs_instruction || 'Silakan pilih CVS untuk pembayaran Anda.'),
                createElement('input', { type: 'hidden', name: 'nicepay_selected_cvs_mitra', value: selectedMitra })
            );
        };

        registerPaymentMethod({
            name: 'nicepay_cvs',
            label: label,
            content: createElement(NicepayCvsComponent),
            edit: createElement(NicepayCvsComponent),
            canMakePayment: () => true,
            ariaLabel: label,
            supports: { features: ['products'] },
            paymentMethodId: 'nicepay_cvs',
            getData: () => ({
                nicepay_cvs_mitra: selectedMitraForCheckout,
                nicepay_selected_cvs_mitra: selectedMitraForCheckout
            })
        });

        window.nicepay_cvs_registered = true;
        console.log('CVS Payment Method registered');
    }
})();
