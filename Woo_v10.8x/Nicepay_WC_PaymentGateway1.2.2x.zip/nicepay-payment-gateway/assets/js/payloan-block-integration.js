(function () {
    console.log("Loading NICEPay Payloan Plugin");

    document.addEventListener('DOMContentLoaded', function () {
        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
            console.log("Initializing Payloan Payment Method");
            initNicepayPayloan();
        } else {
            console.error('Required dependencies not available for Payloan');
        }
    });

    function initNicepayPayloan() {
        if (window.nicepay_payloan_registered === true) {
            return;
        }

        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
        const { createElement, Fragment, useState } = window.wp.element;
        const data = window.nicepaypayloanData || {};
        const label = data.title || 'NICEPay Payloan';

        const NicepayPayloanComponent = () => {
            const [selectedMitra, setSelectedMitra] = useState('');
            const [isLoading, setIsLoading] = useState(false);
            const mitra = data.enabled_mitra || [];

            const handleMitraChange = (e) => {
                const mitraCode = e.target.value;
                setSelectedMitra(mitraCode);
                saveMitraSelection(mitraCode);
            };

            const saveMitraSelection = (mitraCode) => {
                if (typeof jQuery === 'undefined' || !window.nicepaypayloanData) {
                    return;
                }
                if (!nicepaypayloanData.ajax_url || !nicepaypayloanData.nonce) {
                    return;
                }
                setIsLoading(true);
                jQuery.ajax({
                    url: nicepaypayloanData.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'set_nicepay_payloan_mitra',
                        mitra_code: mitraCode,
                        nonce: nicepaypayloanData.nonce
                    },
                    timeout: 10000,
                    complete: function () {
                        setIsLoading(false);
                    }
                });
            };

            if (!Array.isArray(mitra) || mitra.length === 0) {
                return createElement('div', { className: 'nicepay-payloan-container' },
                    createElement('p', null, data.no_payloan || 'Tidak ada Payloan yang tersedia saat ini.')
                );
            }

            return createElement(Fragment, null,
                createElement('div', { className: 'nicepay-payloan-container' },
                    createElement('div', { className: 'nicepay-payloan-header' },
                        createElement('img', {
                            src: (data.pluginUrl || '') + '/assets/images/paylater-logo.png',
                            alt: data.alt_payloan || 'Payloan',
                            className: 'nicepay-payloan-image',
                            onError: (e) => { e.target.style.display = 'none'; }
                        })
                    ),
                    createElement('div', { className: 'nicepay-payloan-select' },
                        createElement('label', { htmlFor: 'nicepay-payloan-select' }, data.select_payloan || 'Pilih Payloan:'),
                        createElement('select', {
                            name: 'nicepay_mitra',
                            id: 'nicepay-payloan-select',
                            onChange: handleMitraChange,
                            value: selectedMitra,
                            disabled: isLoading,
                            required: true
                        },
                            [
                                createElement('option', { value: '' }, data.select_payloan_placeholder || 'Pilih Payloan'),
                                ...mitra.map(m =>
                                    createElement('option', {
                                        value: m.value || m.code,
                                        key: m.value || m.code
                                    }, m.label || m.name)
                                )
                            ]
                        ),
                        isLoading && createElement('span', { className: 'nicepay-loading' }, 'Menyimpan...')
                    ),
                    createElement('p', { className: 'nicepay-payloan-instruction' }, data.select_payloan_instruction || 'Silakan pilih Payloan untuk pembayaran Anda.'),
                    createElement('input', { type: 'hidden', name: 'nicepay_selected_payloan_mitra', value: selectedMitra })
                )
            );
        };

        registerPaymentMethod({
            name: "nicepay_payloan",
            label: label,
            content: createElement(NicepayPayloanComponent),
            edit: createElement(NicepayPayloanComponent),
            canMakePayment: () => true,
            ariaLabel: label,
            supports: { features: ['products'] }
        });

        window.nicepay_payloan_registered = true;
        console.log("Payloan Payment Method successfully registered");
    }
})();
