<?php

/**
 * NICEPay Admin Class - Simplified Version
 * 
 * Hanya untuk mengaktifkan/menonaktifkan payment methods
 * Setting credentials tetap di WooCommerce > Settings > Payments
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Admin class uses Nicepay prefix in filename.
class WC_Nicepay_Admin
{

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
    }

    /**
     * Add admin menu
     */
    public function admin_menu()
    {
        add_menu_page(
            __('NICEPay Settings', 'nicepay-payment-gateway-for-woocommerce'),
            __('NICEPay', 'nicepay-payment-gateway-for-woocommerce'),
            'manage_woocommerce',
            'nicepay-settings',
            array($this, 'admin_page'),
            'dashicons-money-alt',
            56
        );
    }

    /**
     * Initialize admin settings
     */
    // public function admin_init()
    // {
    //     register_setting('nicepay_settings', 'nicepay_enable_va');
    //     register_setting('nicepay_settings', 'nicepay_enable_cc');
    //     register_setting('nicepay_settings', 'nicepay_enable_ewallet');
    //     register_setting('nicepay_settings', 'nicepay_enable_cvs');
    //     register_setting('nicepay_settings', 'nicepay_enable_payloan');
    //     register_setting('nicepay_settings', 'nicepay_enable_qris');
    //     register_setting('nicepay_settings', 'nicepay_debug_mode');
    //     register_setting('nicepay_settings', 'nicepay_reduce_stock');
    //     // Add these new lines
    //     register_setting('nicepay_settings', 'nicepay_environment');
    //     register_setting('nicepay_settings', 'nicepay_host');
    //     register_setting('nicepay_settings', 'nicepay_merchant_id');
    //     register_setting('nicepay_settings', 'nicepay_client_secret');
    //     register_setting('nicepay_settings', 'nicepay_channel_id');
    //     register_setting('nicepay_settings', 'nicepay_merchant_key');
    //     register_setting('nicepay_settings', 'nicepay_private_key');
    // }

    public function admin_init()
    {
        // Boolean (checkbox / enable disable)
        register_setting('nicepay_settings', 'nicepay_enable_va', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_enable_cc', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_enable_ewallet', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_enable_cvs', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_enable_payloan', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_enable_qris', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_debug_mode', array(
            'sanitize_callback' => 'absint'
        ));
        register_setting('nicepay_settings', 'nicepay_reduce_stock', array(
            'sanitize_callback' => 'absint'
        ));

        // Text / string inputs
        register_setting('nicepay_settings', 'nicepay_environment', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        register_setting('nicepay_settings', 'nicepay_host', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        register_setting('nicepay_settings', 'nicepay_merchant_id', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        register_setting('nicepay_settings', 'nicepay_client_secret', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        register_setting('nicepay_settings', 'nicepay_channel_id', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        register_setting('nicepay_settings', 'nicepay_merchant_key', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        register_setting('nicepay_settings', 'nicepay_private_key', array(
            'sanitize_callback' => 'sanitize_textarea_field'
        ));
    }


    /**
     * Enqueue admin scripts
     */
    public function admin_scripts($hook)
    {
        if ($hook !== 'toplevel_page_nicepay-settings') {
            return;
        }

        wp_enqueue_style(
            'nicepay-admin-style',
            plugins_url('assets/css/admin.css', dirname(dirname(__FILE__))),
            array(),
            defined('NICEPAY_WC_VERSION') ? NICEPAY_WC_VERSION : '1.0.0'
        );
    }

    /**
     * Display admin page
     */
    public function admin_page()
    {
        // Handle form submission
        if ( isset( $_POST['submit'], $_POST['nicepay_nonce'] ) ) {
            $this->save_settings();
            echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', 'nicepay-payment-gateway-for-woocommerce') . '</p></div>';
        }

        // Get current settings
        $va_enabled = get_option('nicepay_enable_va', 'yes');
        $cc_enabled = get_option('nicepay_enable_cc', 'yes');
        $ewallet_enabled = get_option('nicepay_enable_ewallet', 'yes');
        $cvs_enabled = get_option('nicepay_enable_cvs', 'yes');
        $payloan_enabled = get_option('nicepay_enable_payloan', 'yes');
        $qris_enabled = get_option('nicepay_enable_qris', 'yes');
        $debug_mode = get_option('nicepay_debug_mode', 'no');
        $reduce_stock = get_option('nicepay_reduce_stock', 'no');

        // Add this line to get the host value
        $host = get_option('nicepay_host', 'cloud'); // Default to 'cloud' if not set
        $status = get_option('status_order', 'Processing'); // Default to 'Processing' if not set
        $environment = get_option('nicepay_environment', 'sandbox');

        // Check if credentials are configured
        $credentials_configured = $this->check_credentials();
?>
        <div class="wrap">
            <div class="nicepay-header">
                <div class="nicepay-logo">
                    <img src="<?php echo plugins_url('assets/images/logo-nicepay.jpg', dirname(dirname(__FILE__))); ?>" alt="NICEPay" />
                </div>
                <div class="nicepay-info">
                    <h1><?php _e('NICEPay Payment Gateway', 'nicepay-payment-gateway-for-woocommerce'); ?></h1>
                    <p class="nicepay-version"><?php _e('Version', 'nicepay-payment-gateway-for-woocommerce'); ?> <?php echo defined('NICEPAY_WC_VERSION') ? NICEPAY_WC_VERSION : '1.0.0'; ?></p>
                </div>
            </div>

            <div class="nicepay-description">
                <p><?php _e('Configure your NICEPay payment environment settings below. You can configure the required host environment according to your needs.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>

                <?php if (!$credentials_configured): ?>
                    <div class="notice notice-warning">
                        <p>
                            <strong><?php _e('Credentials not configured!', 'nicepay-payment-gateway-for-woocommerce'); ?></strong>
                            <?php _e('Please configure your merchant credentials in', 'nicepay-payment-gateway-for-woocommerce'); ?>
                            <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout'); ?>"><?php _e('WooCommerce > Settings > Payments', 'nicepay-payment-gateway-for-woocommerce'); ?></a>
                            <?php _e('for each payment method you want to enable.', 'nicepay-payment-gateway-for-woocommerce'); ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('nicepay_settings_save', 'nicepay_nonce'); ?>

                <h2 class="title"><?php _e('Advanced Settings', 'nicepay-payment-gateway-for-woocommerce'); ?></h2>

                <table class="form-table">
                    <tbody>
                        <!-- Environment -->
                        <tr>
                            <th scope="row">
                                <label for="nicepay_environment"><?php _e('Environment', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                            </th>
                            <td>
                                <fieldset>
                                    <select name="nicepay_environment" id="nicepay_environment">
                                        <option value="sandbox" <?php selected($environment, 'sandbox'); ?>><?php _e('Sandbox', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                        <option value="production" <?php selected($environment, 'production'); ?>><?php _e('Production', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                    </select>
                                    <p class="description"><?php _e('Select the NICEPay environment.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                                </fieldset>
                            </td>
                        </tr>

                        <!-- Host -->
                        <tr>
                            <th scope="row">
                                <label for="nicepay_host"><?php _e('Host', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                            </th>
                            <td>
                                <fieldset>
                                    <select name="nicepay_host" id="nicepay_host">
                                        <option value="cloud" <?php selected($host, 'cloud'); ?>><?php _e('Cloud', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                        <option value="premise" <?php selected($host, 'premise'); ?>><?php _e('Premise', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                    </select>
                                    <p class="description"><?php _e('Select the NICEPay host.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                                </fieldset>
                            </td>
                        </tr>

                        <!-- Debug Mode -->
                        <tr>
                            <th scope="row">
                                <label for="nicepay_debug_mode"><?php _e('Debug Mode', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                            </th>
                            <td>
                                <fieldset>
                                    <label for="nicepay_debug_mode">
                                        <input type="checkbox" id="nicepay_debug_mode" name="nicepay_debug_mode" value="yes" <?php checked($debug_mode, 'yes'); ?> />
                                        <?php _e('Enable debug mode (logging)', 'nicepay-payment-gateway-for-woocommerce'); ?>
                                    </label>
                                    <p class="description"><?php _e('Log debug messages for troubleshooting. Only enable when needed.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                                </fieldset>
                            </td>
                        </tr>

                        <!-- Status -->
                        <tr>
                            <th scope="row">
                                <label for="status_order"><?php _e('Status', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                            </th>
                            <td>
                                <fieldset>
                                    <select name="status_order" id="status_order">
                                        <option value="Completed" <?php selected($status, 'Completed'); ?>><?php _e('Completed', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                        <option value="Processing" <?php selected($status, 'Processing'); ?>><?php _e('Processing', 'nicepay-payment-gateway-for-woocommerce'); ?></option>
                                    </select>
                                    <p class="description"><?php _e('Automatic Status after Payment.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                                </fieldset>
                            </td>
                        </tr>

                        <!-- Reduce Stock -->
                        <tr>
                            <th scope="row">
                                <label for="nicepay_reduce_stock"><?php _e('Reduce Stock', 'nicepay-payment-gateway-for-woocommerce'); ?></label>
                            </th>
                            <td>
                                <fieldset>
                                    <label for="nicepay_reduce_stock">
                                        <input type="checkbox" id="nicepay_reduce_stock" name="nicepay_reduce_stock" value="yes" <?php checked($reduce_stock, 'yes'); ?> />
                                        <?php _e('Reduce stock levels when order is placed', 'nicepay-payment-gateway-for-woocommerce'); ?>
                                    </label>
                                    <p class="description"><?php _e('Reduce stock when payment is initiated rather than when completed.', 'nicepay-payment-gateway-for-woocommerce'); ?></p>
                                </fieldset>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <?php submit_button(__('Save Changes', 'nicepay-payment-gateway-for-woocommerce')); ?>
            </form>

            <div class="nicepay-footer">
                <h3><?php _e('Need Help?', 'nicepay-payment-gateway-for-woocommerce'); ?></h3>
                <p>
                    <?php _e('For technical support or questions about NICEPay integration:', 'nicepay-payment-gateway-for-woocommerce'); ?>
                </p>
                <ul>
                    <li><a href="https://docs.nicepay.co.id" target="_blank"><?php _e('NICEPay Documentation', 'nicepay-payment-gateway-for-woocommerce'); ?></a></li>
                    <li><a href="mailto:technical.support@nicepay.co.id"><?php _e('Technical Support', 'nicepay-payment-gateway-for-woocommerce'); ?></a></li>
                </ul>
            </div>
        </div>
<?php
    }

    /**
     * Save settings
     */
    private function save_settings()
    {
        check_admin_referer( 'nicepay_settings_save', 'nicepay_nonce' );

        // Nonce verified above.
        $post = wp_unslash( $_POST );

        // Existing settings
        $va_enabled      = isset( $post['nicepay_enable_va'] ) ? 'yes' : 'no';
        $cc_enabled      = isset( $post['nicepay_enable_cc'] ) ? 'yes' : 'no';
        $ewallet_enabled = isset( $post['nicepay_enable_ewallet'] ) ? 'yes' : 'no';
        $cvs_enabled     = isset( $post['nicepay_enable_cvs'] ) ? 'yes' : 'no';
        $payloan_enabled = isset( $post['nicepay_enable_payloan'] ) ? 'yes' : 'no';
        $qris_enabled    = isset( $post['nicepay_enable_qris'] ) ? 'yes' : 'no';
        $debug_mode      = isset( $post['nicepay_debug_mode'] ) ? 'yes' : 'no';
        $reduce_stock    = isset( $post['nicepay_reduce_stock'] ) ? 'yes' : 'no';

        // New settings
        $environment   = isset( $post['nicepay_environment'] ) ? sanitize_text_field( $post['nicepay_environment'] ) : 'sandbox';
        $host          = isset( $post['nicepay_host'] ) ? sanitize_text_field( $post['nicepay_host'] ) : 'cloud';
        $status        = isset( $post['status_order'] ) ? sanitize_text_field( $post['status_order'] ) : 'Processing';
        $merchant_id   = isset( $post['nicepay_merchant_id'] ) ? sanitize_text_field( $post['nicepay_merchant_id'] ) : '';
        $client_secret = isset( $post['nicepay_client_secret'] ) ? sanitize_text_field( $post['nicepay_client_secret'] ) : '';
        $channel_id    = isset( $post['nicepay_channel_id'] ) ? sanitize_text_field( $post['nicepay_channel_id'] ) : '';
        $merchant_key  = isset( $post['nicepay_merchant_key'] ) ? sanitize_text_field( $post['nicepay_merchant_key'] ) : '';
        $private_key   = isset( $post['nicepay_private_key'] ) ? sanitize_textarea_field( $post['nicepay_private_key'] ) : '';

        // Update existing options
        update_option('nicepay_enable_va', $va_enabled);
        update_option('nicepay_enable_cc', $cc_enabled);
        update_option('nicepay_enable_ewallet', $ewallet_enabled);
        update_option('nicepay_enable_cvs', $cvs_enabled);
        update_option('nicepay_enable_payloan', $payloan_enabled);
        update_option('nicepay_enable_qris', $qris_enabled);
        update_option('nicepay_debug_mode', $debug_mode);
        update_option('nicepay_reduce_stock', $reduce_stock);

        // Update new options
        update_option('nicepay_environment', $environment);
        update_option('nicepay_host', $host);
        update_option('status_order', $status);
        update_option('nicepay_merchant_id', $merchant_id);
        update_option('nicepay_client_secret', $client_secret);
        update_option('nicepay_channel_id', $channel_id);
        update_option('nicepay_merchant_key', $merchant_key);
        update_option('nicepay_private_key', $private_key);

    }

    /**
     * Check if credentials are configured
     */
    private function check_credentials()
    {
        $va_settings = get_option('woocommerce_nicepay_va_snap_settings', array());
        $cc_settings = get_option('woocommerce_nicepay_cc_settings', array());
        $ewallet_settings = get_option('woocommerce_nicepay_ewallet_settings', array());
        $cvs_settings = get_option('woocommerce_nicepay_cvs_settings', array());
        $payloan_settings = get_option('woocommerce_nicepay_payloan_settings', array());
        $qris_settings = get_option('woocommerce_nicepay_qris_settings', array());

        $va_configured = !empty($va_settings['merchant_id']) && !empty($va_settings['merchant_key']);
        $cc_configured = !empty($cc_settings['merchant_id']) && !empty($cc_settings['merchant_key']);
        $ewallet_configured = !empty($ewallet_settings['merchant_id']) && !empty($ewallet_settings['merchant_key']);
        $cvs_configured = !empty($cvs_settings['merchant_id']) && !empty($cvs_settings['merchant_key']);
        $payloan_configured = !empty($payloan_settings['merchant_id']) && !empty($payloan_settings['merchant_key']);
        $qris_configured = !empty($qris_settings['merchant_id']) && !empty($qris_settings['merchant_key']);

        // Return true if at least one payment method has credentials configured
        return $va_configured || $cc_configured || $ewallet_configured || $cvs_configured || $payloan_configured || $qris_configured;
    }
}

// Initialize admin class
new WC_Nicepay_Admin();
