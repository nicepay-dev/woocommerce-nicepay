(function () {
    console.log("Loading NICEPay All Payment Method Plugin");

    document.addEventListener('DOMContentLoaded', function () {
        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
            console.log('Initializing All Payment Method');
            initNicepayAll();
        } else {
            console.error('Required dependencies not available for All Payment Method');
        }
    });

    function initNicepayAll() {
        if (window.nicepay_all_registered === true) {
            return;
        }

        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
        const { createElement, Fragment } = window.wp.element;

        const data = window.nicepayAllData || {};
        const label = data.title || 'NICEPay All Payment Method';
        const logoUrl = (data.pluginUrl || '') + '/assets/images/all-payment-methods.svg';

        const NicepayAllComponent = () => {
            return createElement(Fragment, null,
                createElement('div', { className: 'nicepay-all-container' },
                    createElement('div', { className: 'nicepay-all-header' },
                        createElement('img', {
                            src: logoUrl,
                            alt: 'All Payment Methods',
                            className: 'nicepay-all-image',
                            onError: function (e) {
                                e.target.style.display = 'none';
                            }
                        })
                    ),
                    createElement('p', { className: 'nicepay-all-methods-caption' },
                        'Credit Card, QRIS, E-Wallet, and more.'
                    ),
                    createElement('p', null,
                        'You will be directed to the payment page.'
                    )
                )
            );
        };

        registerPaymentMethod({
            name: 'nicepay_all',
            label: label,
            content: createElement(NicepayAllComponent),
            edit: createElement(NicepayAllComponent),
            canMakePayment: () => true,
            ariaLabel: 'NICEPay All Payment Method',
            supports: { features: ['products'] }
        });

        window.nicepay_all_registered = true;
        console.log('All Payment Method registered');
    }
})();
