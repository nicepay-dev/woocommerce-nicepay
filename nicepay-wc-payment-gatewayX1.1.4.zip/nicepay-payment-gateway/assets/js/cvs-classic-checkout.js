jQuery(function ($) {
    console.log('NICEPay CVS classic checkout initialized');

    function showError(message) {
        const errorDiv = $('.nicepay-cvs-error');
        errorDiv.text(message).show();
        setTimeout(() => errorDiv.fadeOut(), 5000);
    }

    function saveMitraSelection(selectedMitra) {
        if (!selectedMitra) {
            return;
        }

        const select = $('#nicepay-cvs-select');
        select.prop('disabled', true);

        $.ajax({
            url: nicepayCvsData.ajax_url,
            type: 'POST',
            data: {
                action: 'set_nicepay_cvs_mitra',
                mitra_code: selectedMitra,
                nonce: nicepayCvsData.nonce
            },
            success: function (response) {
                if (response.success) {
                    console.log('Mitra selection saved:', response.data);
                    sessionStorage.setItem('nicepay_selected_cvs_mitra', selectedMitra);
                } else {
                    showError(response.data || 'Gagal menyimpan pilihan');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error saving mitra selection:', error);
                showError('Gagal menyimpan pilihan CVS');
            },
            complete: function () {
                select.prop('disabled', false);
            }
        });
    }

    function initCvsPaymentField() {
        // Restore selection dari sessionStorage jika ada
        const savedMitra = sessionStorage.getItem('nicepay_selected_cvs_mitra');
        if (savedMitra) {
            $('#nicepay-cvs-select').val(savedMitra);
        }

        // Handle perubahan selection
        $('#nicepay-cvs-select').off('change').on('change', function () {
            const selectedMitra = $(this).val();
            if (selectedMitra) {
                saveMitraSelection(selectedMitra);
            } else {
                sessionStorage.removeItem('nicepay_selected_cvs_mitra');
            }
        });
    }

    function toggleCvsContainer() {
        const selectedPaymentMethod = $('input[name="payment_method"]:checked').val();
        
        if (selectedPaymentMethod === 'nicepay_cvs') {
            $('.nicepay-cvs-container').slideDown(300);
        } else {
            $('.nicepay-cvs-container').slideUp(300);
        }
    }

    // Validasi saat form checkout di-submit
    $('form.checkout').on('checkout_place_order_nicepay_cvs', function () {
        const selectedMitra = $('#nicepay-cvs-select').val();
        
        if (!selectedMitra) {
            showError('Silakan pilih CVS untuk pembayaran');
            $('html, body').animate({
                scrollTop: $('.nicepay-cvs-container').offset().top - 100
            }, 500);
            return false;
        }

        return true;
    });

    // Event handler untuk payment method selection
    $(document.body).on('change', 'input[name="payment_method"]', function () {
        toggleCvsContainer();
    });

    // Init saat pertama kali load
    $(document).ready(function () {
        initCvsPaymentField();
        toggleCvsContainer();
    });

    // Reinit setelah checkout updated
    $(document.body).on('updated_checkout', function () {
        initCvsPaymentField();
        toggleCvsContainer();
    });
});