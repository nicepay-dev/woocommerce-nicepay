jQuery(function ($) {
    console.log('NICEPay Payloan classic checkout initialized');

    const config = {
        containerClass: 'nicepay-payloan-container',
        headerClass: 'nicepay-payloan-header',
        selectClass: 'nicepay-payloan-select',
        errorClass: 'nicepay-payloan-error',
        storageKey: 'nicepay_selected_payloan_mitra',
        action: 'set_nicepay_payloan_mitra',
        paymentMethod: 'nicepay_payloan',
        label: 'Pilih Payloan:',
        placeholder: 'Pilih Payloan',
        emptyMessage: 'Payloan belum tersedia saat ini.',
        image: '/assets/images/paylater-logo.png'
    };

    function createSelector() {
        if (!nicepayData || !Array.isArray(nicepayData.enabled_mitra) || nicepayData.enabled_mitra.length === 0) {
            console.log('No mitra available');
            return null;
        }

        const container = $('<div/>', { class: config.containerClass });

        container.append(
            $('<div/>', { class: config.headerClass }).append(
                $('<img/>', {
                    src: nicepayData.pluginUrl + config.image,
                    alt: 'Payloan Logo',
                    class: 'nicepay-payloan-icon',
                    onerror: function () { $(this).hide(); }
                })
            ),
            $('<div/>', { class: config.selectClass }).append(
                $('<label/>', { for: 'nicepay-payloan-select', text: config.label }),
                $('<select/>', { id: 'nicepay-payloan-select', name: 'nicepay_mitra' }).append(
                    $('<option/>', { value: '', text: config.placeholder }),
                    nicepayData.enabled_mitra.map(m => $('<option/>', { value: m.value, text: m.label }))
                )
            ),
            $('<div/>', { class: config.errorClass, style: 'display:none;color:red;margin-top:10px;' })
        );

        return container;
    }

    function showError(message) {
        const errorDiv = $('.' + config.errorClass);
        errorDiv.text(message).show();
        setTimeout(() => errorDiv.fadeOut(), 5000);
    }

    function saveMitra(selectedMitra) {
        if (!selectedMitra) return;
        const select = $('#nicepay-payloan-select').prop('disabled', true);

        $.post(nicepayData.ajax_url, {
            action: config.action,
            mitra_code: selectedMitra,
            nonce: nicepayData.nonce
        })
        .done(res => {
            if (res.success) {
                sessionStorage.setItem(config.storageKey, selectedMitra);
                console.log('Mitra saved:', res.data);
            } else {
                showError(res.data || 'Failed to save selection');
            }
        })
        .fail((xhr, status, error) => {
            console.error('AJAX error:', error);
            showError('Failed to save Payloan selection');
        })
        .always(() => select.prop('disabled', false));
    }

    function initClassic() {
        console.log('Initializing classic mode');
        
        // ✅ Cari payment method dengan ID yang benar
        const methodInput = $(`input[name="payment_method"][value="${config.paymentMethod}"]`);
        
        if (!methodInput.length) {
            console.log('Payment method not found:', config.paymentMethod);
            return;
        }

        console.log('Payment method found');

        // ✅ Hapus selector lama jika ada
        methodInput.closest('li').find('.' + config.containerClass).remove();
        
        // ✅ Buat selector baru
        const selector = createSelector();
        
        if (!selector) {
            console.log('Selector not created - no mitra available');
            return;
        }

        // ✅ Append selector SETELAH payment_fields yang sudah ada
        const paymentBox = methodInput.closest('li').find('.payment_box');
        if (paymentBox.length) {
            paymentBox.append(selector);
        } else {
            methodInput.closest('li').append(selector);
        }

        // ✅ Restore nilai yang tersimpan
        const saved = sessionStorage.getItem(config.storageKey);
        if (saved) {
            console.log('Restoring saved mitra:', saved);
            $('#nicepay-payloan-select').val(saved);
        }

        // ✅ Event handler untuk perubahan dropdown
        $('#nicepay-payloan-select').off('change').on('change', function () {
            const val = $(this).val();
            console.log('Mitra selected:', val);
            
            if (val) {
                saveMitra(val);
            } else {
                sessionStorage.removeItem(config.storageKey);
            }
        });
    }

   // ✅ Validasi sebelum submit
    $('form.checkout').on('checkout_place_order_' + config.paymentMethod, function () {
        console.log('Validating before checkout');
        
        const selected = $('#nicepay-payloan-select').val();
        console.log('Selected mitra on submit:', selected);
        
        if (!selected) {
            showError('Silakan pilih Payloan untuk pembayaran');
            $('html, body').animate({
                scrollTop: $('#nicepay-payloan-select').offset().top - 100
            }, 500);
            return false;
        }
        
        // ✅ Pastikan nilai dikirim via POST
        $('input[name="nicepay_mitra"]').remove();
        $('<input>', { 
            type: 'hidden', 
            name: 'nicepay_mitra', 
            value: selected 
        }).appendTo('form.checkout');
        
        console.log('Checkout validation passed');
        return true;
    });

    // ✅ Initialize
    initClassic();
    
    // ✅ Re-initialize saat checkout di-update
    $(document.body).on('updated_checkout payment_method_selected', function() {
        console.log('Checkout updated, re-initializing');
        initClassic();
    });
});
