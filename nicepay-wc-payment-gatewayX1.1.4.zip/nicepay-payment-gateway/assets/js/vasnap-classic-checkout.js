jQuery(function($) {
    'use strict';
    
    console.log('NICEPay VA classic checkout initialized');
    console.log('NICEPay Data:', nicepayVAData);

    let selectedBank = '';
    let isProcessing = false;

    // Handler untuk perubahan bank
    $(document).on('change', '#nicepay_bank', function() {
        var bankCode = $(this).val();
        selectedBank = bankCode;
        
        console.log('Selected bank:', bankCode);

        // Hapus pesan error jika ada
        $('.nicepay-error-message').remove();
        $(this).css('border-color', '#ddd');

        if (bankCode) {
            $.ajax({
                url: nicepayVAData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_bank',
                    bank_code: bankCode,
                    security: nicepayVAData.nonce || ''
                },
                success: function(response) {
                    console.log('Bank selection saved:', response);
                },
                error: function(error) {
                    console.error('Error saving bank selection:', error);
                }
            });
        }
    });

    // Validasi sebelum submit - menggunakan WooCommerce hook yang lebih reliable
    $('form.checkout').on('checkout_place_order_nicepay_va_snap', function() {
        console.log('Checkout place order triggered for NICEPay VA');
        
        // Cek jika sedang processing
        if (isProcessing) {
            console.log('Already processing, preventing double submission');
            return false;
        }
        
        var bankCode = $('#nicepay_bank').val();
        
        console.log('Validating bank selection:', bankCode);
        
        // Validasi pemilihan bank
        if (!bankCode || bankCode === '') {
            console.log('ERROR: No bank selected');
            
            // Hapus error message lama
            $('.woocommerce-error, .nicepay-error-message').remove();
            
            // Tampilkan pesan error WooCommerce style
            var errorHtml = '<ul class="woocommerce-error" role="alert"><li>Silakan pilih bank untuk pembayaran Virtual Account.</li></ul>';
            $('form.checkout').prepend(errorHtml);
            
            // Highlight field dengan error
            $('#nicepay_bank').css('border-color', '#e2401c');
            
            // Scroll ke elemen bank select
            $('html, body').animate({
                scrollTop: $('#nicepay_bank').offset().top - 100
            }, 500);
            
            return false;
        }
        
        console.log('Bank validation passed, proceeding with checkout');
        
        // Set flag processing
        isProcessing = true;
        
        // Disable submit button untuk prevent double click
        $('form.checkout button[type="submit"]').prop('disabled', true).addClass('processing');
        
        // Hapus pesan error jika ada
        $('.woocommerce-error, .nicepay-error-message').remove();
        $('#nicepay_bank').css('border-color', '#ddd');
        
        // Pastikan nilai bank tersimpan di form sebagai hidden input
        if (!$('input[name="nicepay_bank"]').length) {
            $('form.checkout').append('<input type="hidden" name="nicepay_bank" value="' + bankCode + '">');
        } else {
            $('input[name="nicepay_bank"]').val(bankCode);
        }
        
        return true;
    });

    // Reset flag jika ada error dari WooCommerce
    $(document.body).on('checkout_error', function() {
        console.log('Checkout error detected, resetting processing flag');
        isProcessing = false;
        $('form.checkout button[type="submit"]').prop('disabled', false).removeClass('processing');
    });

    // Event handler ketika payment method berubah
    $(document.body).on('payment_method_selected', function() {
        var paymentMethod = $('input[name="payment_method"]:checked').val();
        
        console.log('Payment method selected:', paymentMethod);
        
        if (paymentMethod === 'nicepay_va_snap') {
            // Hapus pesan error jika ada
            $('.woocommerce-error, .nicepay-error-message').remove();
            $('#nicepay_bank').css('border-color', '#ddd');
        } else {
            // Reset selection jika payment method berubah
            $('#nicepay_bank').val('');
            selectedBank = '';
        }
    });

    // Juga handle perubahan radio button secara langsung
    $(document).on('change', 'input[name="payment_method"]', function() {
        var paymentMethod = $(this).val();
        
        if (paymentMethod !== 'nicepay_va_snap') {
            $('#nicepay_bank').val('');
            selectedBank = '';
            $('.nicepay-error-message').remove();
            console.log('Payment method changed, bank selection reset');
        }
    });

    // Inisialisasi - Pre-select bank jika sudah ada di session
    if (nicepayVAData.selected_bank && nicepayVAData.selected_bank !== '') {
        console.log('Pre-selecting bank from session:', nicepayVAData.selected_bank);
        $('#nicepay_bank').val(nicepayVAData.selected_bank);
        selectedBank = nicepayVAData.selected_bank;
    }

    // Remove error on focus
    $(document).on('focus', '#nicepay_bank', function() {
        $('.nicepay-error-message').remove();
        $(this).css('border-color', '#ddd');
    });
});