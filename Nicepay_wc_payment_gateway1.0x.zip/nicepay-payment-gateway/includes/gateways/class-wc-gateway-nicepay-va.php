<?php
if (!defined('ABSPATH')) exit;
class WC_Gateway_Nicepay_VA extends WC_Payment_Gateway
{
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;
    public function __construct()
    {
        //nicepay_log('Initializing VA Payment Gateway', 'info', 'va');

        $this->id                 = 'nicepay_va_snap';
        $this->icon               = apply_filters('woocommerce_nicepay_vasnap_icon', '');
        $this->has_fields         = false;
        $this->method_title       = __('NICEPay Virtual Account', 'nicepay-vasnap-gateway');
        $this->method_description = __('Allows payments using NICEPay Virtual Account.', 'nicepay-vasnap-gateway');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Set option dari admin
        $this->enabled      = $this->get_option('enabled');
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');

        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        $this->iMid         = $this->get_option('iMid');
        $this->XCLIENTKEY   = $this->get_option('X-CLIENT-KEY');
        $this->mKey         = $this->get_option('mKey');
        $this->privateKey   = $this->get_option('privateKey');
        $this->SecretClient = $this->get_option('SecretClient');
        $this->reduceStock  = $this->get_option('reduceStock');
        $this->shopId       = $this->get_option('shopId');
        $this->api_endpoints = $this->get_api_endpoints();

        if (get_option('nicepay_checkout_mode') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        if ($this->environment === 'sandbox') {
            @ini_set('display_errors', 1);
            @ini_set('display_startup_errors', 1);
            @error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED & ~E_USER_DEPRECATED);
        }

        add_action('admin_init', function () {
            //nicepay_log("NICEPay settings: " . print_r(get_option('woocommerce_nicepay_va_snap_settings'), true), 'info', 'va');
        });
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_ajax_set_nicepay_bank', array($this, 'set_nicepay_bank'));
        add_action('wp_ajax_nopriv_set_nicepay_bank', array($this, 'set_nicepay_bank'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('init', array($this, 'add_endpoint'));
        add_action('woocommerce_api_wc_gateway_nicepay_snap', array($this, 'handle_callback'));
    }

    public function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPay Payment', 'woocommerce'),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
                'default'     => __('NICEPay Virtual Account', 'woocommerce'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'woocommerce'),
                'default'     => __('Pay with NICEPay', 'woocommerce'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID / Client ID', 'woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPay</small>.', 'woocommerce'),
                'default' => 'TNICEVA023',
            ),
            'client_secret' => array(
                'title'       => __('Client Secret Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Client Key.', 'woocommerce'),
                'default'     => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
                //'default'     => '',
                'desc_tip'    => true,
            ),
            'Channel_ID' => array(
                'title'       => __('Channel ID', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Channel ID.', 'woocommerce'),
                'default'     => 'TNICEVA023',
                'desc_tip'    => true,
            ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Merchant Key.', 'woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            'private_key' => array(
                'title'       => __('Private Key', 'woocommerce'),
                'type'        => 'textarea',
                'description' => __('Enter your NICEPay Private Key.', 'woocommerce'),
                'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
                //'default'     => '',
                'desc_tip'    => true,
            ),
            'active_banks' => array(
                'title'       => __('Active Banks', 'woocommerce'),
                'type'        => 'multiselect',
                'description' => __('Select which banks should be available at checkout. Leave empty to show all banks.', 'woocommerce'),
                'default'     => array(),
                'options'     => $this->get_bank_options(),
                'css'         => 'height: 200px;',
                'class'       => 'wc-enhanced-select',
            ),
            'debug' => array(
                'title'       => __('Debug Mode', 'woocommerce'),
                'type'        => 'checkbox',
                'label'       => __('Enable debug logging', 'woocommerce'),
                'default'     => 'yes',
                'description' => __('Log NICEPay API interactions for debugging purposes. Logs will be stored in the NICEPay Logs page.', 'woocommerce'),
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'data-debug-toggle' => 'true'
                )
            ),
            'log_retention' => array(
                'title'       => __('Log Retention', 'woocommerce'),
                'type'        => 'select',
                'description' => __('How long to keep debug logs before automatic deletion.', 'woocommerce'),
                'default'     => '7',
                'options'     => array(
                    '1'  => __('1 day', 'woocommerce'),
                    '7'  => __('7 days', 'woocommerce'),
                    '30' => __('30 days', 'woocommerce'),
                    '0'  => __('Keep indefinitely', 'woocommerce'),
                ),
            )
        );
    }

    private function get_api_endpoints()
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }

        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'create_va'        => $base_url . '/nicepay/api/v1.0/transfer-va/create-va',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/transfer-va/status',
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    public function enqueue_classic_mode()
    {
        if (!is_checkout()) {
            return;
        }

        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-vasnap-style',
            NICEPAY_PLUGIN_URL . 'assets/css/vasnap.css'
        );

        // Inline CSS untuk quick styling
        $inline_css = "
            .nicepay-vasnap-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-vasnap-bank-select {
                margin: 10px 0;
            }
            .nicepay-vasnap-bank-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-vasnap-bank-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .nicepay-vasnap-instruction {
                margin-top: 10px;
                font-size: 0.9em;
                color: #666;
            }
        ";
        wp_add_inline_style('nicepay-vasnap-style', $inline_css);

        // Enqueue JS
        if (!wp_script_is('nicepay-va-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-vasnap-classic-checkout',
                NICEPAY_PLUGIN_URL . 'assets/js/vasnap-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        $active_banks   = $this->get_active_bank_list();
        $selected_bank  = WC()->session->get('nicepay_selected_bank', '');

        wp_localize_script(
            'nicepay-vasnap-classic-checkout',
            'nicepayVAData',
            array(
                'ajax_url'       => admin_url('admin-ajax.php'),
                'pluginUrl'      => NICEPAY_PLUGIN_URL,
                'banks'          => $active_banks,
                'selected_bank'  => $selected_bank,
                'nonce'          => wp_create_nonce('nicepay-bank-selection')
            )
        );
    }

    public function enqueue_blocks_mode()
    {
        if (!is_checkout()) {
            return;
        }

        add_action('wp_loaded', function () {
            if (! WC()->session) {
                WC()->initialize_session();
            }
        });

        wp_enqueue_style(
            'nicepay-vasnap-style',
            NICEPAY_PLUGIN_URL . '/assets/css/vasnap.css'
        );

        // Inline CSS untuk quick styling
        $inline_css = "
            .nicepay-vasnap-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-vasnap-bank-select {
                margin: 10px 0;
            }
            .nicepay-vasnap-bank-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-vasnap-bank-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .nicepay-vasnap-instruction {
                margin-top: 10px;
                font-size: 0.9em;
                color: #666;
            }
        ";
        wp_add_inline_style('nicepay-vasnap-style', $inline_css);

        if (!wp_script_is('nicepay-va-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-vasnap-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/vasnap-block-integration.js',
                ['wc-blocks-registry', 'wp-element', 'jquery'],
                '1.0.0',
                time(),
                true
            );
        }

        $active_banks = $this->get_active_bank_list();

        wp_localize_script(
            'nicepay-vasnap-blocks-integration',
            'nicepayVAData',
            array(
                'ajax_url'  => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'banks'     => $active_banks,
                'isVA'      => true,
                'nonce'     => wp_create_nonce('nicepay-bank-selection')
            )
        );
    }

    public function process_admin_options()
    {
        $old_settings = $this->settings;

        $result = parent::process_admin_options();

        $this->init_settings();
        $new_settings = $this->settings;

        nicepay_log("NICEPay settings - Old debug: " . (isset($old_settings['debug']) ? $old_settings['debug'] : 'not set'), 'info', 'va');
        nicepay_log("NICEPay settings - New debug: " . (isset($new_settings['debug']) ? $new_settings['debug'] : 'not set'), 'info', 'va');

        return $result;
    }

    public function handle_set_nicepay_bank() {
        $this->log("handle_set_nicepay_bank called" . print_r($_POST, true));
        $this->log("POST data: " . print_r($_POST, true));
        if (isset($_POST['security']) && !wp_verify_nonce($_POST['security'], 'nicepay-bank-selection')) {
            $this->log("Invalid nonce in handle_set_nicepay_bank");
            wp_send_json_error('Invalid security token');
            wp_die();
        }
        if (isset($_POST['bank_code'])) {
            $bank_code = sanitize_text_field($_POST['bank_code']);
            $active_banks = $this->get_active_bank_list();
            $valid_banks = array_column($this->get_bank_list(), 'code');
            
            if (!in_array($bank_code, $valid_banks)) {
                $this->log("Invalid bank code: " . $bank_code);
                wp_send_json_error('Invalid bank code');
                wp_die();
            }

            // Set ke session
            WC()->session->set('nicepay_selected_bank', $bank_code);
            $this->log("Bank code saved to session: " . $bank_code);

            // Tambahkan ke order meta jika ada order yang sedang diproses
            if (WC()->session->get('order_awaiting_payment')) {
                $order_id = WC()->session->get('order_awaiting_payment');
                $order = wc_get_order($order_id);
                if ($order) {
                    $order->update_meta_data('_nicepay_selected_bank', $bank_code);
                    $order->save();
                    $this->log("Bank code saved to order meta: " . $bank_code);
                }
            }

            wp_send_json_success(array(
                'message' => 'Bank code saved: ' . $bank_code,
                'bank_code' => $bank_code
            ));
            wp_die();
        }

        $this->log("Bank code not provided in POST data");
        wp_send_json_error('Bank code not provided');
        wp_die();
    }

    public function set_nicepay_bank()
    {
        if (isset($_POST['security']) && !wp_verify_nonce($_POST['security'], 'nicepay-bank-selection')) {
            nicepay_log("Invalid nonce in handle_set_nicepay_bank", 'error', 'va');
            wp_send_json_error('Invalid security token');
            wp_die();
        }

        if (isset($_POST['bank_code'])) {
            $bank_code = sanitize_text_field($_POST['bank_code']);
            $active_banks = $this->get_active_bank_list();
            $valid_banks = array_column($this->get_bank_list(), 'code');

            if (!in_array($bank_code, $valid_banks)) {
                nicepay_log("Invalid bank code: " . $bank_code, 'error', 'va');
                wp_send_json_error('Invalid bank code');
                wp_die();
            }

            // Set ke session
            WC()->session->set('nicepay_selected_bank', $bank_code);
            nicepay_log("Bank code saved to session: " . $bank_code, 'info', 'va');

            // Tambahkan ke order meta jika ada order yang sedang diproses
            if (WC()->session->get('order_awaiting_payment')) {
                $order_id = WC()->session->get('order_awaiting_payment');
                $order = wc_get_order($order_id);
                if ($order) {
                    $order->update_meta_data('_nicepay_selected_bank', $bank_code);
                    $order->save();
                    nicepay_log("Bank code saved to order meta: " . $bank_code, 'info', 'va');
                }
            }

            wp_send_json_success(array(
                'message' => 'Bank code saved: ' . $bank_code,
                'bank_code' => $bank_code
            ));
            wp_die();
        }

        nicepay_log("Bank code not provided in POST data", 'info', 'va');
        wp_send_json_error('Bank code not provided');
        wp_die();
    }

    private function is_valid_bank_code($code)
    {
        $valid_banks = array_column($this->get_bank_list(), 'code');
        return in_array($code, $valid_banks);
    }

    public function add_endpoint()
    {
        add_rewrite_endpoint('wc-api', EP_ALL);
    }

    public function admin_options()
    {
        parent::admin_options();
?>
        <script type="text/javascript">
            jQuery(function($) {
                // Log status checkbox saat halaman dimuat
                var debugCheckbox = $('[data-debug-toggle="true"]');
                console.log('Debug checkbox initial state:', debugCheckbox.is(':checked'));

                // Tambahkan event listener untuk perubahan checkbox
                debugCheckbox.on('change', function() {
                    console.log('Debug checkbox changed to:', $(this).is(':checked'));
                });
            });
        </script>
        <?php
    }

    private function get_bank_options()
    {
        $banks = $this->get_bank_list();
        $options = array();

        foreach ($banks as $bank) {
            $options[$bank['code']] = $bank['name'];
        }

        return $options;
    }

    public function is_available()
    {
        if ('yes' !== $this->enabled) {
            return false;
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    public function get_bank_list()
    {
        return [
            ['code' => 'BMRI', 'name' => 'Bank Mandiri'],
            ['code' => 'BNIN', 'name' => 'Bank BNI'],
            ['code' => 'BRIN', 'name' => 'Bank BRI'],
            ['code' => 'BBBA', 'name' => 'Bank Permata'],
            ['code' => 'CENA', 'name' => 'Bank BCA'],
            ['code' => 'IBBK', 'name' => 'Maybank'],
            ['code' => 'BBBB', 'name' => 'Bank Permata Syariah'],
            ['code' => 'HNBN', 'name' => 'Bank KEB Hana Indonesia'],
            ['code' => 'BNIA', 'name' => 'Bank CIMB'],
            ['code' => 'BDIN', 'name' => 'Bank Bank Danamon'],
            ['code' => 'PDJB', 'name' => 'Bank BJB'],
            ['code' => 'YUDB', 'name' => 'Bank Neo Commerce (BNC)'],
            ['code' => 'BDKI', 'name' => 'Bank DKI']
        ];
    }

    public function get_active_bank_list()
    {
        $all_banks = $this->get_bank_list();
        $active_bank_codes = $this->get_option('active_banks', array());

        // Jika tidak ada bank yang dipilih, tampilkan semua bank
        if (empty($active_bank_codes)) {
            return $all_banks;
        }

        // Filter hanya bank yang aktif
        $active_banks = array();
        foreach ($all_banks as $bank) {
            if (in_array($bank['code'], $active_bank_codes)) {
                $active_banks[] = $bank;
            }
        }

        return $active_banks;
    }

    public function process_payment($order_id)
    {
        nicepay_log("Starting process_payment VA for order $order_id", 'info', 'va');
        $checkout_mode = get_option('nicepay_checkout_mode');

        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }

    private function process_classic_payment($order_id)
    {
        nicepay_log("Processing classic payment for order $order_id", 'info', 'va');

        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'va');
        $order->save();

        $selected_bank = WC()->session->get('nicepay_selected_bank');
        $selected_bank = isset($_POST['nicepay_bank']) ?
            sanitize_text_field($_POST['nicepay_bank']) :
            WC()->session->get('nicepay_selected_bank');

        nicepay_log("Selected bank from POST/session: " . ($selected_bank ?: 'Not set'), 'info', 'va');

        if (!$selected_bank) {
            wc_add_notice(__('Please select a bank for payment', 'woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        WC()->session->set('nicepay_selected_bank', $selected_bank);

        try {
            $access_token = $this->get_access_token();
            $va_data = $this->create_virtual_account($order, $access_token, $selected_bank);

            if (isset($va_data['virtualAccountData'])) {
                $this->handle_va_creation_response($order, $va_data);
                WC()->cart->empty_cart();

                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                throw new Exception(__('Failed to create Virtual Account', 'woocommerce'));
            }
        } catch (Exception $e) {
            wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
            nicepay_log("Payment error in process_classic_payment: " . $e->getMessage(), 'error', 'va');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    private function process_blocks_payment($order_id)
    {
        nicepay_log("Processing blocks payment for order $order_id", 'info', 'va');

        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'va');
        $order->save();

        $selected_bank = isset($_POST['nicepay_bank']) ?
        sanitize_text_field($_POST['nicepay_bank']) :
        WC()->session->get('nicepay_selected_bank');
        nicepay_log("Selected bank from session in process_blocks_payment: " . ($selected_bank ?: 'Not set'), 'info', 'va');

        if (!$selected_bank) {
            wc_add_notice(__('Please select a bank for payment', 'woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            try {
                $access_token = $this->get_access_token();
                $va_data = $this->create_virtual_account($order, $access_token, $selected_bank);

                if (isset($va_data['virtualAccountData'])) {
                    $this->handle_va_creation_response($order, $va_data);
                    WC()->cart->empty_cart();

                    return array(
                        'result'   => 'success',
                        'redirect' => $this->get_return_url($order),
                    );
                } else {
                    throw new Exception(__('Failed to create Virtual Account', 'woocommerce'));
                }
            } catch (Exception $e) {
                wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'va');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        } else {
            try {
                $va_data = $this->process_directV2($order_id);

                if (isset($va_data['vacctNo'])){
                    $this-> handle_v2va_creation_response($order_id,$va_data);
                    WC()->cart->empty_cart();
                    return array(
                            'result'   => 'success',
                            'redirect' => $this->get_return_url($order),
                        );
                } else {
                    throw new Exception(__('Failed to create Virtual Account', 'woocommerce'));
                }
            } catch (Exception $e) {
                wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'va');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }

    }

    private function get_access_token()
    {
        nicepay_log("Starting get_access_token process in " . $this->environment . " environment", 'info', 'va');

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $timestamp = $this->generate_formatted_timestamp();
        $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;

        $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
            $this->get_option('private_key') . "\r\n" .
            "-----END RSA PRIVATE KEY-----";

        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);

        if ($pKey === false) {
            nicepay_log("Failed to get private key: " . openssl_error_string(), 'error', 'va');
            throw new Exception("Invalid private key");
        }

        $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);

        if ($sign_result === false) {
            nicepay_log("Failed to create signature: " . openssl_error_string(), 'error', 'va');
            throw new Exception("Failed to create signature");
        }

        $signature = base64_encode($binary_signature);

        $jsonData = array(
            "grantType" => "client_credentials",
            "additionalInfo" => ""
        );

        $jsonDataEncode = json_encode($jsonData);

        $requestToken = $this->api_endpoints['access_token'];

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SIGNATURE'  => $signature,
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP'  => $timestamp
            ),
            'body'    => $jsonDataEncode,
        );

        $response = wp_remote_post($requestToken, $args);

        nicepay_log("url access_token: " . $this->api_endpoints['access_token'], 'info', 'va');
        nicepay_log("Request headers for get_access_token: " . json_encode($args['headers']), 'info', 'va');
        nicepay_log("Request body for get_access_token: " . json_encode($jsonDataEncode), 'info', 'va');

        if (is_wp_error($response)) {
            nicepay_log("Error in get_access_token: " . $response->get_error_message(), 'error', 'va');
            throw new Exception($response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response));
        nicepay_log("Access token response: " . json_encode($body), 'info', 'va');

        if (!isset($body->accessToken)) {
            nicepay_log("Invalid access token response: " . json_encode($body));
            throw new Exception(__('Invalid access token response', 'nicepay-vasnap-gateway'), 'error', 'va');
        }

        nicepay_log("Successfully obtained access token", 'info', 'va');
        WC()->session->set('accessToken', $body->responseCode);

        return $body->accessToken;
    }

    private function create_virtual_account($order, $access_token, $selected_bank)
    {
        nicepay_log("Starting create_virtual_account for order " . $order->get_id(), 'info', 'va');
        nicepay_log("Starting create_virtual_account in " . $this->environment . " environment", 'info', 'va');
        $selected_bank = WC()->session->get('nicepay_selected_bank');

        nicepay_log("Selected bank from session: " . ($selected_bank ?: 'Not set'), 'info', 'va');

        if (!$selected_bank) {
            throw new Exception(__('Please select a bank for payment', 'woocommerce'));
        }

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $channel = $this->get_option('Channel_ID');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $timestamp = date('YmdHis');
        $external = $timestamp . rand(1000, 9999);

        $additionalInfo = [
            "bankCd" => $selected_bank,
            "goodsNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_snap'),
            "vacctValidDt" => date('Ymd', strtotime('+1 day')),
            "vacctValidTm" => date('His', strtotime('+1 day')),
            "msId" => "",
            "msFee" => "",
            "msFeeType" => "",
            "mbFee" => "",
            "mbFeeType" => ""
        ];

        $TotalAmount = [
            "value" => number_format($order->get_total(), 2, '.', ''),
            "currency" => $order->get_currency()
        ];

        $newBody = [
            "partnerServiceId" => "",
            "customerNo" => "",
            "virtualAccountNo" => "",
            "virtualAccountName" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            "trxId" => $order->get_id() . "-" . $timestamp,
            "totalAmount" => $TotalAmount,
            "additionalInfo" => $additionalInfo
        ];

        $stringBody = json_encode($newBody);
        $hashbody = strtolower(hash("SHA256", $stringBody));

        $strigSign = "POST:/api/v1.0/transfer-va/create-va:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type'   => 'application/json',
                'X-SIGNATURE'    => base64_encode($bodyHasing),
                'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                'X-TIMESTAMP'    => $X_TIMESTAMP,
                'Authorization'  => "Bearer " . $access_token,
                'CHANNEL-ID'     => $channel,
                'X-EXTERNAL-ID'  => $external,
                'X-PARTNER-ID'   => $X_CLIENT_KEY
            ),
            'body'    => $stringBody,
        );
        $headerBodyVA = json_encode($args['headers']);

        nicepay_log("url create_registration: " . $this->api_endpoints['create_va'], 'info', 'va');
        nicepay_log("Request header for create_virtual_account: " . $headerBodyVA, 'info', 'va');
        nicepay_log("Request body for create_virtual_account: " . $stringBody, 'info', 'va');

        $response = wp_remote_post($this->api_endpoints['create_va'], $args);

        if (is_wp_error($response)) {
            nicepay_log("Error in create_virtual_account: " . $response->get_error_message(), 'error', 'va');
            throw new Exception($response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("Create virtual account response: " . json_encode($response_body), 'info', 'va');

        if (isset($response_body['responseCode']) && $response_body['responseCode'] === '2002700') {
            $va_data = $response_body['virtualAccountData'];
            $order->update_meta_data('_nicepay_va_number', $va_data['virtualAccountNo']);
            $order->update_meta_data('_nicepay_bank_code', $va_data['additionalInfo']['bankCd']);
            $order->update_meta_data('_nicepay_va_expiry', $va_data['additionalInfo']['vacctValidDt'] . ' ' . $va_data['additionalInfo']['vacctValidTm']);
            $order->update_meta_data('_nicepay_tXid', $va_data['additionalInfo']['tXidVA']);
            $order->update_meta_data('_nicepay_reference_no', $va_data['trxId']);
            $order->save();
        } else {
            throw new Exception(sprintf(__('Failed to create Virtual Account: %s', 'nicepay-vasnap-gateway'), $response_body['responseMessage'] ?? 'Unknown error'));
        }

        return $response_body;
    }

    private function handle_va_creation_response($order, $data)
    {
        if (isset($data['responseCode']) && $data['responseCode'] == "2002700") {
            $refno = $data['virtualAccountData']['trxId'];
            $txid_va = $data['virtualAccountData']['additionalInfo']['tXidVA'];
            $amount = $data['virtualAccountData']['totalAmount']['value'];
            $va_number = $data['virtualAccountData']['virtualAccountNo'];
            $bank_code = $data['virtualAccountData']['additionalInfo']['bankCd'];
            $expiry_date = $data['virtualAccountData']['additionalInfo']['vacctValidDt'];
            $expiry_time = $data['virtualAccountData']['additionalInfo']['vacctValidTm'];
            $expiry_dt = DateTime::createFromFormat('YmdHis', $expiry_date . $expiry_time);
            if ($expiry_dt) {
                $expiry = $expiry_dt->format('Y-m-d H:i:s');
            } else {
                $expiry = $expiry_date . ' ' . $expiry_time; // fallback jika parsing gagal
            }

            $status_note = sprintf(
                __('Awaiting NICEPay payment', 'nicepay-vasnap-gateway'),
                $va_number,
                $txid_va
            );

            $order->update_status('on-hold', $status_note);
            $order->add_order_note(sprintf(
                __('NICEPay Virtual Account created. Details:
                Reference Number : %s
                Transaction ID: %s
                Transaction Amount: %s
                VA Number: %s
                Bank: %s
                Expired VA: %s', 'nicepay-vasnap-gateway'),
                $refno,
                $txid_va,
                $amount,
                $va_number,
                $this->get_bank_name($bank_code),
                $expiry
            ));

            WC()->session->set('nicepay_va_number', $data['virtualAccountData']['virtualAccountNo']);
            WC()->session->set('nicepay_bank_name', $data['virtualAccountData']['additionalInfo']['bankCd']);

            if ($this->get_option('reduceStock') === 'yes' && !$order->get_meta('_stock_reduced', true)) {
                wc_reduce_stock_levels($order->get_id());
                $order->update_meta_data('_stock_reduced', 'yes');
                $order->save();
            }
        } else {
            throw new Exception(__('Failed to create Virtual Account', 'nicepay-vasnap-gateway'));
        }
    }

    public function get_bank_name($bank_code)
    {
        $banks = $this->get_bank_list();
        foreach ($banks as $bank) {
            if ($bank['code'] === $bank_code) {
                return $bank['name'];
            }
        }
        return $bank_code;
    }

    private function generate_formatted_timestamp()
    {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'va');
        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int)$order->get_total();
            $referenceNo = $order->get_id() . "-" . $timestamp;
            $bankCd = WC()->session->get('nicepay_selected_bank', '');

            if (empty($bankCd)) {
                throw new Exception(__('No VA selected. Please choose a VA payment method.', 'nicepay-wc'));
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);
            $cart_data = $this->prepare_cart_data($order);
            $requestBody = [
                "timeStamp" => $timestamp,
                "iMid" => $iMid,
                "payMethod" => "02",
                "currency" => "IDR",
                "amt" => $amount,
                "referenceNo" => $referenceNo,
                "merchantToken" => $merchantToken,
                "bankCd" => $bankCd,
                "goodsNm" => $this->get_order_items_names($order),
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_snap'),
                "description" => "Testing API VA - " . get_bloginfo('name'),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $order->get_billing_phone(),
                "billingEmail" => $order->get_billing_email(),
                "billingAddr" => $order->get_billing_address_1(),
                "billingCity" => $order->get_billing_city(),
                "billingState" => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "userIP" => $_SERVER['REMOTE_ADDR'],
                "cartData" => $cart_data,
                "payValidDt" => date('Ymd', strtotime('+1 day')),
                "payValidTm" => "235959"
            ];

            $args = [
                'method' => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("VA Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'va');
            nicepay_log("VA Request Body: " . json_encode($requestBody), 'info', 'va');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("VA Response: " . json_encode($response_body), 'info', 'va');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(sprintf(__('Failed to create VA transaction: %s', 'nicepay-wc'), $response_body['resultMsg'] ?? 'Unknown error'));            }

            $order->update_meta_data('_nicepay_va_number', $response_body['vacctNo']);
            $order->update_meta_data('_nicepay_bank_code', $response_body['bankCd']);
            $order->update_meta_data('_nicepay_va_expiry', $response_body['vacctValidDt'] . ' ' . $response_body['vacctValidTm']);
            $order->update_meta_data('_nicepay_tXid', $response_body['tXid']);
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo']);
            $order->save();
            
        } catch (Exception $e) {
            wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'va');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        return $response_body;
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    private function handle_v2va_creation_response($order_id, $data) {
        nicepay_log("Starting handle_v2va_creation_response for order " . $order_id, 'info', 'va');
        
        if (isset($data['vacctNo'])) {
            $order = wc_get_order($order_id);
            $refno = $data['referenceNo'];
            $txid_va = $data['tXid'];
            $amount = $data['amt'];
            $va_number = $data['vacctNo'];
            $bank_code = $data['bankCd'];
            $expiry_date = $data['vacctValidDt'];
            $expiry_time = $data['vacctValidTm'];
            $expiry_dt = DateTime::createFromFormat('YmdHis', $expiry_date . $expiry_time);
            if ($expiry_dt) {
                $expiry = $expiry_dt->format('Y-m-d H:i:s');
            } else {
                $expiry = $expiry_date . ' ' . $expiry_time; // fallback jika parsing gagal
            }

            $status_note = sprintf(
                __('Awaiting NICEPay payment', 'nicepay-vasnap-gateway'),
                $va_number,
                $txid_va
            );

            $order->update_status('on-hold', $status_note);
            $order->add_order_note(sprintf(
                __('NICEPay Virtual Account created. Details:
                Reference Number : %s
                Transaction ID: %s
                Transaction Amount: %s
                VA Number: %s
                Bank: %s
                Expired VA: %s', 'nicepay-vasnap-gateway'),
                $refno,
                $txid_va,
                $amount,
                $va_number,
                $this->get_bank_name($bank_code),
                $expiry
            ));

            WC()->session->set('nicepay_va_number', $data['virtualAccountData']['virtualAccountNo']);
            WC()->session->set('nicepay_bank_name', $data['virtualAccountData']['additionalInfo']['bankCd']);

            if ($this->get_option('reduceStock') === 'yes' && !$order->get_meta('_stock_reduced', true)) {
                wc_reduce_stock_levels($order->get_id());
                $order->update_meta_data('_stock_reduced', 'yes');
                $order->save();
            }
        } else {
            throw new Exception(__('Failed to create Virtual Account', 'nicepay-vasnap-gateway'));
        }
    }

    public function thankyou_page($order_id)
    {
        $order = wc_get_order($order_id);
        if ($order && $order->get_payment_method() === $this->id) {
            $va_number = $order->get_meta('_nicepay_va_number');
            $bank_code = $order->get_meta('_nicepay_bank_code');
            $expiry_date = $order->get_meta('_nicepay_va_expiry');
            $payment_status = $order->get_status();

            if (!$order->get_meta('_nicepay_thankyou_displayed')) {
        ?>
                <script>
                    function copyToClipboard(elementId) {
                        var copyText = document.getElementById(elementId);

                        // Pilih teks
                        var range = document.createRange();
                        range.selectNode(copyText);
                        window.getSelection().removeAllRanges();
                        window.getSelection().addRange(range);

                        // Salin teks
                        try {
                            document.execCommand('copy');
                            // Tampilkan notifikasi berhasil disalin
                            var tooltip = document.getElementById("copyTooltip");
                            tooltip.innerHTML = "Copied!";
                            setTimeout(function() {
                                tooltip.innerHTML = "Click to copy";
                            }, 1500);
                        } catch (err) {
                            console.error('Failed to copy text: ', err);
                        }

                        // Hapus seleksi
                        window.getSelection().removeAllRanges();
                    }
                </script>
                <style>
                    .nicepay-va-copy {
                        position: relative;
                        display: inline-block;
                        cursor: pointer;
                        padding: 5px 10px;
                        background-color: #f8f9fa;
                        border-radius: 4px;
                        border: 1px solid #ddd;
                        font-weight: bold;
                    }

                    .nicepay-va-copy .tooltip {
                        visibility: hidden;
                        width: 100px;
                        background-color: #555;
                        color: #fff;
                        text-align: center;
                        border-radius: 4px;
                        padding: 5px;
                        position: absolute;
                        z-index: 1;
                        bottom: 125%;
                        left: 50%;
                        margin-left: -50px;
                        opacity: 0;
                        transition: opacity 0.3s;
                        font-size: 12px;
                        font-weight: normal;
                    }

                    .nicepay-va-copy:hover .tooltip {
                        visibility: visible;
                        opacity: 1;
                    }
                </style>
<?php
                echo '<div class="woocommerce-order-payment-details">';
                echo '<h2>' . __('Payment Instructions', 'woocommerce') . '</h2>';

                echo '<p><strong>' . __('Payment Status:', 'woocommerce') . '</strong> ' . $this->get_payment_status_description($payment_status) . '</p>';

                if ($payment_status !== 'completed' && $payment_status !== 'processing') {
                    echo '<p>' . sprintf(
                        __('Please transfer %s to the following Virtual Account details:', 'woocommerce'),
                        wc_price($order->get_total())
                    ) . '</p>';
                    echo '<ul>';
                    echo '<li><strong>' . __('Bank:', 'woocommerce') . '</strong> ' . esc_html($this->get_bank_name($bank_code)) . '</li>';
                    echo '<li><strong>' . __('Virtual Account Number:', 'woocommerce') . '</strong> ';
                    echo '<span class="nicepay-va-copy" onclick="copyToClipboard(\'va-number\')">';
                    echo '<span id="va-number">' . esc_html($va_number) . '</span>';
                    echo '<span class="tooltip" id="copyTooltip">Click to copy</span>';
                    echo '</span></li>';
                    echo '<li><strong>' . __('Amount:', 'woocommerce') . '</strong> ' . wc_price($order->get_total()) . '</li>';
                    if ($expiry_date) {
                        $formatted_expiry = $this->format_expiry_date($expiry_date);
                        echo '<li><strong>' . __('Expiry Date:', 'woocommerce') . '</strong> ' . esc_html($formatted_expiry) . '</li>';
                    }
                    echo '</ul>';


                    echo '<p>' . sprintf(
                        __('For detailed payment instructions, please visit <a href="%s" target="_blank">NICEPay Payment Guide</a>.', 'woocommerce'),
                        'https://template.nicepay.co.id/'
                    ) . '</p>';

                    echo '<p>' . __('Please complete the payment before the VA expires. After payment is completed, it may take a few moments for the system to confirm your payment.', 'woocommerce') . '</p>';
                } else {
                    echo '<p>' . __('Thank you for your payment. Your transaction has been completed.', 'woocommerce') . '</p>';
                }

                echo '</div>';
                $order->update_meta_data('_nicepay_thankyou_displayed', 'yes');
                $order->save();
            }
        }
    }

    private function format_expiry_date($expiry_date)
    {
        $datetime = DateTime::createFromFormat('Ymd His', $expiry_date);
        if ($datetime) {
            return $datetime->format('d F Y H:i:s');
        }
        return $expiry_date;
    }

    private function get_payment_status_description($status)
    {
        switch ($status) {
            case 'pending':
                return __('Pending payment', 'woocommerce');
            case 'on-hold':
                return __('Awaiting payment confirmation', 'woocommerce');
            case 'processing':
                return __('Payment received, processing order', 'woocommerce');
            case 'completed':
                return __('Payment completed', 'woocommerce');
            case 'cancelled':
                return __('Order cancelled', 'woocommerce');
            case 'failed':
                return __('Payment failed', 'woocommerce');
            default:
                return ucfirst($status);
        }
    }

    public function handle_callback()
    {
        nicepay_log('NICEPay callback received. Starting processing...', 'info', 'va');
        status_header(200);

        // Ambil header request
        $headers = getallheaders();
        nicepay_log('Headers: ' . print_r($headers, true), 'info', 'va');

        // Contoh akses header tertentu
        $timestamp = $headers['X-TIMESTAMP'] ?? null;
        $client_key = $headers['X-CLIENT-KEY'] ?? null;
        $signature = $headers['X-SIGNATURE'] ?? null;

        $raw_post = file_get_contents('php://input');
        nicepay_log('Raw input: ' . $raw_post, 'info', 'va');

        $decoded_post = json_decode($raw_post, true);

        // Fallback parsing kalau bukan JSON (biasanya jarang terjadi)
        if (!$decoded_post) {
            parse_str($raw_post, $decoded_post);
        }
        if (empty($decoded_post)) {
            $decoded_post = $_POST;
        }

        if (!empty($signature)) {
             nicepay_log("(SNAP) Attempting to find order with ID: " . $decoded_post['trxId'], 'info', 'va');

            $reference_no = $decoded_post['trxId'];
            $tXid = $decoded_post['paymentRequestId'];

            $parts = explode('-', $reference_no);
            $order_id = $parts[0];
            $order = wc_get_order($order_id);

            if (!empty($decoded_post['virtualAccountNo']) &&
                !empty($decoded_post['trxId']) &&
                !empty($decoded_post['paymentRequestId']) &&
                !empty($decoded_post['paidAmount']['value'])) {

                if ($order) { 
                    $this->check_payment_status($order,$decoded_post);

                    wp_send_json(array('status' => 'received'), 200);
                    exit;
                } else {
                    nicepay_log('Order not found for paymentRequestId: ' . $order_id, 'error', 'va');
                    wp_send_json_error('Order not found', 404);
                }
            } else {
                nicepay_log('Invalid callback data: Missing expected fields. Full data: ' . $decoded_post, 'error', 'va');
                wp_send_json_error('Invalid callback data', 400);
            }
        } else {
            nicepay_log('(Direct V2) Attempting to find order with ID: ' . $decoded_post['referenceNo'], 'info', 'va');

            $referenceNo = trim($decoded_post['referenceNo']);
            $parts = explode('-', $referenceNo);
            $order_id = $parts[0];
            $order = wc_get_order($order_id);

            if ($order) { 
                nicepay_log('Order found: ' . $order_id, 'info', 'va');

                // You might have a method to handle status update
                $this->check_payment_status_directv2($order_id,$decoded_post);

                wp_send_json(array('status' => 'received'), 200);
                exit;
            } else {
                nicepay_log('Order not found for paymentRequestId: ' . $order_id, 'error', 'va');
                wp_send_json_error('Order not found', 404);
            }
        }
    }

    private function check_payment_status($order,$data)
    {
        nicepay_log('Starting check_payment_status for order ' . $order->get_id(), 'info', 'va');

        $access_token = $this->get_access_token();
        if (!$access_token) {
            nicepay_log('Failed to get access token for status check', 'info', 'va');
            return;
        }

        $partnerServiceId = $data['partnerServiceId'];
        $customerNo = $data['customerNo'];
        $virtualAccountNo = $data['virtualAccountNo'];
        $amt = $data['paidAmount']['value'];
        $currency = $data['paidAmount']['currency'];
        $txid = $data['paymentRequestId'];
        $reference_no = $data['trxId'];

        $check_status_url = $this->api_endpoints['check_status_url'];

        $body = [
            "partnerServiceId" => $partnerServiceId,
            "customerNo" => $customerNo,
            "virtualAccountNo" => $virtualAccountNo,
            "inquiryRequestId" => $virtualAccountNo,
            "additionalInfo" => [
                "totalAmount" => [
                    "value" => number_format($amt, 2, '.', ''),
                    "currency" => $currency
                ],
                "tXidVA" => $txid,
                "trxId" => $reference_no
            ]
        ];

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $external = $timestamp . rand(1000, 9999);
        $channel = $this->get_option('Channel_ID');


        $stringBody = json_encode($body);
        $hashbody = strtolower(hash("SHA256", $stringBody));

        $strigSign = "POST:/api/v1.0/transfer-va/status:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
        $X_SIGNATURE = base64_encode($bodyHasing);

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => "Bearer " . $access_token,
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP'  => $X_TIMESTAMP,
                'X-SIGNATURE' => $X_SIGNATURE,
                'X-PARTNER-ID' => $X_CLIENT_KEY,
                'X-EXTERNAL-ID' => $external,
                'CHANNEL-ID' => $channel
            ),
            'body'    => $stringBody,
        );

        nicepay_log("url check_payment_status: " . $check_status_url, 'info', 'va');
        nicepay_log("Request header for check_payment_status: " . json_encode($args['headers']), 'info', 'va');
        nicepay_log("Request body for check_payment_status: " . $stringBody, 'info', 'va');

        $response = wp_remote_post($check_status_url, $args);

        if (is_wp_error($response)) {
            nicepay_log('Error checking payment status: ' . $response->get_error_message(), 'info', 'va');
            return;
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        nicepay_log('Received check status response' . json_encode($response_body), 'info', 'va');

        if (isset($response_body['responseCode']) && $response_body['responseCode'] === '2002600') {
            // Inisialisasi variabel
            $status = null;
            $status_desc = null;
            $txid_va = null;

            // Cek Struktur Response
            if (
                isset($response_body['additionalInfo']) &&
                isset($response_body['additionalInfo']['latestTransactionStatus'])
            ) {

                $status = $response_body['additionalInfo']['latestTransactionStatus'];
                $status_desc = $response_body['additionalInfo']['transactionStatusDesc'] ?? '';
                $txid_va = $response_body['additionalInfo']['tXidVA'] ?? '';

                nicepay_log('Using merchant response structure (additionalInfo at root level)', 'info', 'va');
            } else if (
                isset($response_body['virtualAccountData']) &&
                isset($response_body['virtualAccountData']['additionalInfo']) &&
                isset($response_body['virtualAccountData']['additionalInfo']['latestTransactionStatus'])
            ) {

                $status = $response_body['virtualAccountData']['additionalInfo']['latestTransactionStatus'];
                $status_desc = $response_body['virtualAccountData']['additionalInfo']['transactionStatusDesc'] ?? '';
                $txid_va = $response_body['virtualAccountData']['additionalInfo']['tXidVA'] ?? '';

                nicepay_log('Using localhost response structure (additionalInfo inside virtualAccountData)', 'info', 'va');
            }

            // Validasi nilai status
            if ($status === null || $status === '' || $status === '-') {
                nicepay_log('Invalid or empty status value: ' . var_export($status, true), 'error');
                $order->add_order_note('Invalid payment status value from NICEPay: ' . var_export($status, true));
                $order->save();
                return;
            }

            nicepay_log('Payment status for order ' . $order->get_id() . ': ' . $status . ' - ' . $status_desc, 'info', 'va');

            if (empty($txid_va)) {
                $txid_va = $order->get_meta('_nicepay_tXid');
                nicepay_log('Using txid_va from order meta: ' . $txid_va, 'info', 'va');
            }

            switch ($status) {
                case '00':
                    //$order->payment_complete();
                    $order->update_status('processing', 'Pembayaran VA berhasil.');
                    $order->add_order_note('Payment completed via NICEPay Virtual Account. Status: ' . $status_desc);
                    nicepay_log('Order ' . $order->get_id() . ' marked as processing. Status: ' . $status_desc, 'info', 'va');
                    break;
                case '03':
                    if ($order->get_status() !== 'on-hold') {
                        $order->update_status('on-hold', 'Payment still pending via NICEPay Virtual Account. Status: ' . $status_desc);
                    } else {
                        $order->add_order_note('Payment still pending via NICEPay Virtual Account. Status: ' . $status_desc);
                    }
                    nicepay_log('Order ' . $order->get_id() . ' is still pending. Status: ' . $status_desc, 'info', 'va');
                    break;
                case '04':
                    $order->update_status('cancelled', 'NICEPay Virtual Account payment expired. Status: ' . $status_desc);
                    nicepay_log('Order ' . $order->get_id() . ' marked as expired. Status: ' . $status_desc, 'info', 'va');
                    break;
                default:
                    $order->add_order_note('Unknown payment status from NICEPay: ' . $status . ' - ' . $status_desc);
                    nicepay_log('Unknown payment status for order ' . $order->get_id() . ': ' . $status . ' - ' . $status_desc, 'info', 'va');
                    break;
            }

            if (isset($status)) {
                $order->update_meta_data('_nicepay_status', $status_desc);
                $order->update_meta_data('_nicepay_status_code', $status);
                $order->update_meta_data('_nicepay_paid_amount', $response_body['paidAmount']['value']);
                $order->update_meta_data('_nicepay_currency', $response_body['paidAmount']['currency']);
                $order->update_meta_data('_nicepay_transaction_datetime', $response_body['trxDateTime']);

                nicepay_log('Order meta updated for order ' . $order_id, 'info', 'va');
            }

            $order->save();
        } else {
            nicepay_log('Invalid response from NICEPay status check: ' . $response_body, 'info', 'va');
            $order->add_order_note('Failed to check payment status with NICEPay. Response: ' . $response_body);
            $order->save();
        }
    }

    private function check_payment_status_directv2($order_id,$decoded_post)
    {
        nicepay_log('Starting check_payment_status for order ' . $order_id, 'info', 'va');

        $order = wc_get_order($order_id);

        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $txId = $decoded_post['txId'];
        $referenceNo = $decoded_post['referenceNo'];
        $amount = $decoded_post['amt'];
        $merchantKey = $this->get_option('merchant_key');

        nicepay_log($iMid . $txId . $referenceNo . $amount);

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $txId,
            "referenceNo" => $referenceNo,
            "amt" => $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("VA Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'va');
        nicepay_log("VA Request Body: " . json_encode($requestBody), 'info', 'va');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            throw new Exception("HTTP Request failed: " . $response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("VA Response: " . json_encode($response_body), 'info', 'va');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            throw new Exception(sprintf(__('Failed to create VA transaction: %s', 'nicepay-wc'), $response_body['resultMsg'] ?? 'Unknown error'));        }

        if($response_body['status'] == '0') {
            // Save metadata from callback
            //$order->payment_complete();
            $order->update_status('processing', 'Pembayaran VA berhasil.');
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency']);
            $order->update_meta_data('_nicepay_transaction_datetime', $response_body['transDt'] . $response_body['transTm']);
            $order->save();

            nicepay_log('Order meta updated for order ' . $order_id, 'info', 'va');
        }
    }
}
