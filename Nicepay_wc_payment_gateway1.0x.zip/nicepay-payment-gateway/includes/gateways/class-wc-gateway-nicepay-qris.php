<?php
if (!defined('ABSPATH')) exit;
class WC_Gateway_Nicepay_QRIS extends WC_Payment_Gateway
{
    protected $redirect_url;
    protected $environment;
    protected $host;
    protected $api_endpoints;
    protected $iMid;
    protected $XCLIENTKEY;
    protected $mKey;
    protected $privateKey;
    protected $SecretClient;
    protected $reduceStock;
    protected $shopeepay;
    protected $shopId;
    public function __construct()
    {

        // plugin id
        $this->id = 'nicepay_qris';
        $this->method_title = 'NICEPay QRIS';
        $this->has_fields = false;
        $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'wc_gateway_nicepay_qris', home_url('/')));
        $this->method_description = __('Allows payments using NICEPay QRIS.', 'nicepay-qr-snap-gateway');

        $this->supports = [
            'products',
            'refunds',
        ];

        //Load settings
        $this->init_form_fields();
        $this->init_settings();

        $this->api_endpoints = $this->get_api_endpoints();

        if (get_option('nicepay_checkout_mode') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        if ($this->environment === 'sandbox') {
            @ini_set('display_errors', 1);
            @ini_set('display_startup_errors', 1);
            @error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED & ~E_USER_DEPRECATED);
        }
        // Define user set variables
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        // $this->environment = $this->get_option('environment', 'sandbox');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        $this->iMid = $this->get_option('iMid');
        $this->XCLIENTKEY = $this->get_option('X-CLIENT-KEY');
        $this->mKey = $this->get_option('mKey');
        $this->privateKey = $this->get_option('privateKey');
        $this->SecretClient = $this->get_option('SecretClient');
        //---------------------------------------------//
        $this->reduceStock   = $this->get_option('reduceStock');
        //---------------------------------------------//
        $this->shopeepay = $this->get_option('shopeepay');
        $this->shopId = $this->get_option('shopId');

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_qris', array($this, 'handle_callback'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
        add_action('wp_ajax_check_qris_payment_status', array($this, 'ajax_check_payment_status'));
        add_action('wp_ajax_nopriv_check_qris_payment_status', array($this, 'ajax_check_payment_status'));
        add_action('woocommerce_thankyou', array($this, 'add_qris_payment_status'), 10, 1);
    }

    public function is_available()
    {
        if ('yes' !== $this->enabled) {
            return false;
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    public function update_api_endpoints()
    {
        // $this->environment = $this->get_option('environment', 'sandbox');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set
        $this->api_endpoints = $this->get_api_endpoints();
    }

    public function enqueue_classic_mode()
    {
        if (!is_checkout()) {
            return;
        }

        wp_enqueue_style(
            'nicepay-qris-style',
            NICEPAY_PLUGIN_URL . '/assets/css/qris.css'
        );

        $inline_css = "
            .nicepay-qris-container { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .nicepay-qris-header { text-align: center; margin-bottom: 20px; }
            .nicepay-qris-logo { max-width: 200px; height: auto; }
            .nicepay-qris-description { text-align: center; }
            .qris-apps-list ul { list-style: none; padding: 0; margin: 15px 0; display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; }
            .qris-apps-list li { background: #fff; padding: 8px 15px; border-radius: 20px; border: 1px solid #ddd; }
            .nicepay-qris-instructions { text-align: center; margin-top: 20px; font-weight: 500; }
        ";
        wp_add_inline_style('nicepay-qris-style', $inline_css);

        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-qris-classic',
                NICEPAY_PLUGIN_URL . '/assets/js/qris-classic-checkout.js',
                ['jquery'],
                '1.0.0',
                true
            );
        }
    }

    public function enqueue_blocks_mode()
    {
        if (!is_checkout()) {
            return;
        }

        wp_enqueue_style(
            'nicepay-qris-style',
            NICEPAY_PLUGIN_URL . '/assets/css/qris.css'
        );

        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-qris-blocks',
                NICEPAY_PLUGIN_URL . '/assets/js/qris-block-integration.js',
                ['jquery'],
                '1.0.0',
                true
            );
        }

        wp_localize_script(
            'nicepay-qris-blocks',
            'qrisData',
            array(
                'ajax_url'   => admin_url('admin-ajax.php'),
                'pluginUrl'  => NICEPAY_PLUGIN_URL,
                'nonce'      => wp_create_nonce('nicepay-qris-nonce'),
                'merchantId' => $this->get_option('iMid'),
                'shopId'     => $this->get_option('shopId')
            )
        );
    }

    private function get_api_endpoints()
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }

        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/qr/qr-mpm-generate',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/qr/qr-mpm-query',
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    public function add_qris_payment_status($order_id)
    {
        $order = wc_get_order($order_id);

        // Hanya tampilkan untuk pembayaran QRIS
        if ($order->get_payment_method() !== 'nicepay_qris') {
            return;
        }

        echo '<section class="woocommerce-qris-status">';
        echo '<h2>Status Pembayaran QRIS</h2>';

        // Default status awal
        $status_text = 'Menunggu Pembayaran';
        $status_class = 'woocommerce-message';

        if ($order->get_status() === 'processing') {
            $status_text = 'Pembayaran berhasil diverifikasi';
            $status_class = 'woocommerce-success';
        } elseif ($order->get_status() === 'failed' || $order->get_status() === 'cancelled') {
            $status_text = 'Pembayaran gagal atau dibatalkan';
            $status_class = 'woocommerce-error';
        }

        // Jika tombol check status ditekan
        if (
            isset($_POST['check_qris_status']) &&
            !get_transient('checking_status_' . $order_id) &&
            wp_verify_nonce($_POST['qris_nonce'], 'check_qris_status')
        ) {
            set_transient('checking_status_' . $order_id, true, 10);
            try {
                // Ambil status terbaru dari API
                if (!empty($this->get_option('SecretClient')) && !empty($this->get_option('privateKey'))) {
                    $access_token = WC()->session->get('accessToken') ?: $order->get_meta('_nicepay_access_token');
                    if (empty($access_token)) {
                        throw new Exception('Token akses tidak ditemukan.');
                    }

                    $body = [
                        "originalReferenceNo" => $order->get_meta('_nicepay_tXid'),
                        "originalPartnerReferenceNo" => $order->get_meta('_nicepay_reference_no'),
                        "merchantId" => $this->XCLIENTKEY,
                        "externalStoreId" => $this->shopId,
                        "serviceCode" => "47",
                        "additionalInfo" => new stdClass()
                    ];

                    $timestamp = $this->generate_timestamp();
                    $stringBody = json_encode($body);
                    $hashbody = strtolower(hash("SHA256", $stringBody));
                    $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $access_token . ":" . $hashbody . ":" . $timestamp;
                    $bodyHasing = hash_hmac("sha512", $strigSign, $this->SecretClient, true);

                    $args = [
                        'method' => 'POST',
                        'timeout' => 45,
                        'headers' => [
                            'Content-Type' => 'application/json',
                            'X-SIGNATURE' => base64_encode($bodyHasing),
                            'X-TIMESTAMP' => $timestamp,
                            'Authorization' => "Bearer " . $access_token,
                            'CHANNEL-ID' => $this->XCLIENTKEY . "01",
                            'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
                            'X-PARTNER-ID' => $this->XCLIENTKEY
                        ],
                        'body' => $stringBody
                    ];

                    $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
                    if (is_wp_error($response)) {
                        throw new Exception($response->get_error_message());
                    }

                    $result = json_decode(wp_remote_retrieve_body($response));
                    if (isset($result->latestTransactionStatus)) {
                        if ($result->latestTransactionStatus === '00') {
                            $status_text = 'Pembayaran berhasil diverifikasi';
                            $status_class = 'woocommerce-success';
                            $order->update_status('processing', 'Pembayaran QRIS berhasil.');
                        } elseif ($result->latestTransactionStatus === '03') {
                            $status_text = 'Menunggu Pembayaran';
                            $status_class = 'woocommerce-message';
                        } else {
                            $status_text = 'Pembayaran gagal atau dibatalkan';
                            $status_class = 'woocommerce-error';
                        }
                    } else {
                        throw new Exception($result->responseMessage ?? 'Gagal mendapatkan status pembayaran');
                    }
                } else {
                    // Direct V2 fallback
                    $dataStore = [
                        "tXid" => $order->get_meta('_nicepay_tXid'),
                        "referenceNo" => $order->get_meta('_nicepay_reference_no'),
                        "amt" => (int)$order->get_total(),
                    ];
                    $result = $this->check_payment_status_directv2($order_id, $dataStore);
                    if (isset($result['status'])) {
                        if ($result['status'] === '0') {
                            $status_text = 'Pembayaran berhasil diverifikasi';
                            $status_class = 'woocommerce-success';
                            $order->update_status('processing', 'Pembayaran QRIS berhasil.');
                        } elseif ($result['status'] === '3') {
                            $status_text = 'Menunggu Pembayaran';
                            $status_class = 'woocommerce-message';
                        } else {
                            $status_text = 'Pembayaran gagal atau dibatalkan';
                            $status_class = 'woocommerce-error';
                        }
                    } else {
                        throw new Exception($result['responseMessage'] ?? 'Gagal mendapatkan status pembayaran');
                    }
                }
            } catch (Exception $e) {
                $status_text = $e->getMessage();
                $status_class = 'woocommerce-error';
            }
            delete_transient('checking_status_' . $order_id);
        }

        // Output status terbaru
        echo '<div class="' . esc_attr($status_class) . '">' . esc_html($status_text) . '</div>';

        // Tampilkan tombol check status jika belum sukses
        if ($order->get_status() !== 'completed') {
            echo '<form method="post" class="qris-check-form">';
            wp_nonce_field('check_qris_status', 'qris_nonce');
            echo '<input type="hidden" name="check_qris_status" value="1">';
            echo '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">';
            echo '<button type="submit" 
                    class="button" 
                    style="background: #ff6b00; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px;">
                    Periksa Status Pembayaran
                </button>';
            echo '</form>';
        }

        echo '</section>';
    }

    // function add_content() {}
    function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Enable/Disable',
                'label' => 'Enable NICEPay',
                'type' => 'checkbox',
                'description' => '',
                'default' => 'yes',
            ),
            'title' => array(
                'title' => 'Title',
                'type' => 'text',
                'description' => '',
                'default' => 'Pembayaran dengan QRIS',
            ),
            'description' => array(
                'title' => 'Description',
                'type' => 'textarea',
                'description' => '',
                'default' => 'Sistem pembayaran menggunakan QRIS.',
            ),
            'X-CLIENT-KEY' => array(
                'title' => 'Merchant ID / Client ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Merchant ID dari NICEPay</small>.',
                'default' => 'TNICEQR081',
                //'default' => 'IONPAYTEST',
            ),
            'SecretClient' => array(
                'title' => 'Client Secret Key',
                'type' => 'text',
                'description' => '<small>Isikan dengan Client Secret anda</small>.',
                //'default' => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
                'default' => '',
            ),
            'Chanel-ID' => array(
                'title' => 'Chanel ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Chanel ID dari NICEPay</small>.',
                'default' => 'TNICEQR08101',
                //'default' => '',
            ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Merchant Key.', 'woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            'privateKey' => array(
                'title' => 'Private Key',
                'type' => 'text',
                'description' => '<small>Isikan dengan Private Key dari NICEPay</small>.',
                //'default' => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
                'default' => '',
            ),
            'shopId' => array(
                'title' => 'QRIS Shop ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Shop ID dari NICEPay</small>',
                'default' => 'NICEPAY',
            ),
            'shopeepay' => array(
                'title' => 'Shopeepay QRIS',
                'type' => 'checkbox',
                'description' => '<small>Check to enable. Please confirm to NICEPay before changing this.</small>',
                'default' => 'yes',
            ),
            'reduceStock' => array(
                'title' => __('Reduce stock', 'woocommerce'),
                'type' => 'checkbox',
                'description' => __('<small>Check to enable.</small>', 'woocommerce'),
                'default' => 'no',
            ),
            'debug' => array(
                'title'       => __('Debug Mode', 'nicepay-qr-gateway'),
                'type'        => 'checkbox',
                'label'       => __('Enable logging', 'nicepay-qr-gateway'),
                'default'     => 'yes',
                'description' => __('Log QRIS API interactions, helpful for troubleshooting', 'nicepay-qr-gateway'),
            ),
            'log_retention' => array(
                'title'       => __('Log Retention Period', 'nicepay-qr-gateway'),
                'type'        => 'select',
                'description' => __('How long to keep logs before automatic cleanup', 'nicepay-qr-gateway'),
                'default'     => '7',
                'options'     => array(
                    '1'  => __('1 day', 'nicepay-qr-gateway'),
                    '2'  => __('2 days', 'nicepay-qr-gateway'),
                    '0'  => __('Keep indefinitely (not recommended)', 'nicepay-qr-gateway')
                ),
            ),
        );
    }

    public function admin_options()
    {
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';
    }

    function payment_fields()
    {
        if ($this->get_option('enable_blocks') === 'classic') {
            if (!empty($this->description)) {
                echo wp_kses_post($this->description);
            }

            echo '<div id="nicepay-qris-payment-container"></div>';
        }
    }

    public function validate_fields()
    {
        nicepay_log("Validating fields", 'info', 'qris');

        // Set default mitraCd 
        $mitraCd = isset($_POST['mitraCdQRISV2']) ? sanitize_text_field($_POST['mitraCdQRISV2']) : 'QSHP';
        WC()->session->set('mitraCd', $mitraCd);

        return true;
    }

    private function generate_timestamp()
    {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    function payment_list()
    {
        $payment = array(
            "QSHP" => array(
                "label" => "QRIS Shopeepay",
                "enabled" => $this->shopeepay,
            )
        );

        return $payment;
    }

    function receipt_page($order_id)
    {
        $order = wc_get_order($order_id);
        $qr_url = $order->get_meta('_nicepay_qr_url');

        nicepay_log("Displaying receipt page for order: " . $order_id, 'info', 'qris');
        nicepay_log("QR URL: " . $qr_url, 'info', 'qris');

        if (empty($qr_url)) {
            $qr_url = WC()->session->get('qr_url');
        }

        if (empty($qr_url)) {
            echo "<div class='woocommerce-error'>Error: QR Code not generated. Please try again.</div>";
            return;
        }

        echo "<div class='qris-payment-container'>";
        echo "<h2>QRIS Payment</h2>";

        // QR Code
        echo "<div class='qris-code'>";
        echo "<img src='" . esc_url($qr_url) . "' alt='QRIS Code' style='width:280px; height:280px;'>";
        echo "</div>";

        // Instructions
        echo "<div class='qris-instructions'>";
        echo "<p><strong>Silahkan scan QR Code di atas menggunakan aplikasi e-wallet atau m-banking yang mendukung QRIS</strong></p>";
        echo "<p><strong>Tekan Lanjutkan jika sudah melakukan pembayaran</strong></p>";
        echo "<p>QR Code akan kadaluarsa dalam: <span id='countdown'>5:00</span></p>";
        echo "</div>";

        // Download button
        echo "<div class='qris-actions'>";
        echo "<button onclick='window.location.href=\"" . esc_url($qr_url) . "\"' class='button download-qr'>";
        echo "<i class='fa fa-download'></i> Download QR";
        echo "</button>";
        echo "</div>";

        // Continue button
        echo "<div class='qris-continue'>";
        echo "<button onclick='window.location.href=\"" . esc_url($this->get_return_url($order)) . "\"' class='button continue-btn'>";
        echo "Lanjutkan";
        echo "</button>";
        echo "</div>";

        // Timer script
        echo "<script>
            function startTimer(duration, display) {
                var timer = duration, minutes, seconds;
                var interval = setInterval(function () {
                    minutes = parseInt(timer / 60, 10);
                    seconds = parseInt(timer % 60, 10);
    
                    minutes = minutes < 10 ? '0' + minutes : minutes;
                    seconds = seconds < 10 ? '0' + seconds : seconds;
    
                    display.textContent = minutes + ':' + seconds;
    
                    if (--timer < 0) {
                        clearInterval(interval);
                        window.location.href = '" . esc_js($this->get_return_url($order)) . "';
                    }
                }, 1000);
            }
    
            window.onload = function () {
                var fiveMinutes = 60 * 5,
                    display = document.querySelector('#countdown');
                startTimer(fiveMinutes, display);
            };
        </script>";

        // Styles
        echo "<style>
            .qris-payment-container {
                max-width: 600px;
                margin: 0 auto;
                text-align: center;
                padding: 20px;
            }
            .qris-logo img {
                max-width: 200px;
                margin-bottom: 20px;
            }
            .qris-code {
                margin: 20px 0;
            }
            .qris-instructions {
                margin: 20px 0;
            }
            .qris-actions {
                margin: 20px 0;
            }
            .download-qr {
                background: #f8f9fa;
                border: 1px solid #ddd;
                padding: 10px 20px;
            }
            .continue-btn {
                background: #ff6b00;
                color: white;
                padding: 15px 30px;
                font-size: 18px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .continue-btn:hover {
                background: #ff8533;
            }
            #countdown {
                font-weight: bold;
                color: #ff6b00;
            }
            .woocommerce-success {
            padding: 1em;
            margin-bottom: 1em;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            border-radius: 4px;
        }
        .woocommerce-error {
            padding: 1em;
            margin-bottom: 1em;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            color: #a94442;
            border-radius: 4px;
        }
        </style>";
        echo "</div>";
    }

    function includes()
    {
        // Validation class payment gateway woocommerce
        if (!class_exists('NicepayLibQRISV2')) {
            include_once "NicepayLibQRISV2/NicepayLibQRISV2.php";
        }
    }

    function konversi($nilai, $currency)
    {
        if ($currency == 'USD') {
            return $nilai * (int)13500;
        } else {
            return $nilai * (int)1;
        }
    }

    // public function generate_nicepay_form($order_id)
    // {


    //     global $woocommerce;

    //     $order = new WC_Order($order_id);
    //     $currency = $order->get_currency();
    //     $fees = $order->get_fees();
    //     $total_quantity = 0;

    //     if (sizeof($order->get_items()) > 0) {
    //         foreach ($order->get_items() as $item) {
    //             if (!$item['qty']) {
    //                 continue;
    //             }


    //             $item_name = $item->get_name();;
    //             $item_quantity = $item->get_quantity();
    //             $product_id = $item->get_product_id();
    //             $item_cost_non_discount = $item->get_subtotal();
    //             $item_cost_discounted = $item->get_total();;
    //             $item_url = get_permalink($product_id);

    //             $orderInfo[] = array(
    //                 'goods_name' => $this->nicepay_item_name($item_name),
    //                 'goods_detail' => $this->nicepay_item_name($item_name),
    //                 'goods_amt' => strval($this->konversi($item_cost_non_discount / $item_quantity, $currency)),
    //                 'goods_quantity' => strval($item_quantity),
    //                 'img_url' => "https://image.freepik.com/free-psd/simple-black-men-s-tee-mockup_53876-57893.jpg"
    //             );

    //             if (count($orderInfo) < 0) {
    //                 return false; // Abort - negative line
    //             }

    //             $total_quantity = $total_quantity + $item_quantity;
    //         }

    //         function clean($string)
    //         {
    //             $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

    //             return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
    //         }

    //         // Loop over $cart fees
    //         if (!empty($fees)) {
    //             foreach ($fees as $fees_key => $fee) {
    //                 $name = $fee['name'];
    //                 $total = $fee['total'];
    //                 if ($total != 0) {
    //                     $orderInfo[] = array(
    //                         'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
    //                         'goods_name' => clean($name),
    //                         'goods_detail' => clean($name) . " for " . $order_id,
    //                         'goods_amt' => wc_float_to_string($total),
    //                         'goods_quantity' => "1",
    //                         'goods_url' => "https://" . $_SERVER['SERVER_NAME']
    //                     );
    //                 }
    //                 $total_quantity = $total_quantity + 1;
    //             }
    //         }

    //         //Shipping
    //         if ($order->calculate_shipping() > 0) {
    //             $orderInfo[] = array(
    //                 'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
    //                 'goods_name' => "Shipping Fee",
    //                 'goods_detail' => $order->get_shipping_method(),
    //                 'goods_amt' => wc_float_to_string($order->calculate_shipping()),
    //                 'goods_quantity' => "1",
    //                 'goods_url' => "https://" . $_SERVER['SERVER_NAME']
    //             );
    //             $total_quantity = $total_quantity + 1;
    //         }
    //         //Coupons
    //         $coupons = $order->get_coupon_codes();
    //         if (!empty($coupons)) {
    //             foreach ($coupons as $coupon_code) {
    //                 $coupon = new WC_Coupon($coupon_code);
    //                 $couponName = $coupon_code;

    //                 $orderInfo[] = array(
    //                     'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
    //                     'goods_name' => "COUPON",
    //                     'goods_detail' => $couponName . " " . $coupon->get_amount(),
    //                     'goods_quantity' => "1",
    //                     'goods_amt' => "-" . $coupon->get_amount(),
    //                     'goods_url' => "https://" . $_SERVER['SERVER_NAME']
    //                 );
    //                 $total_quantity = $total_quantity + 1;
    //             }
    //         }

    //         $cartData = array(
    //             'count' => count($orderInfo),
    //             'item' => $orderInfo
    //         );
    //     }

    //     //Order Total
    //     if ($currency == 'USD') {
    //         $order_total = $this->get_order_total() * (int)13500;
    //     } else {
    //         $order_total = $this->get_order_total();
    //     }

    //     //Get current user
    //     $current_user = wp_get_current_user();

    //     //Get Address customer
    //     $billingFirstName = ($current_user->ID == 0) ? $order->get_billing_first_name() : get_user_meta($current_user->ID, "billing_first_name", true);
    //     $billingLastName = ($current_user->ID == 0) ? $order->get_billing_last_name() : get_user_meta($current_user->ID, "billing_last_name", true);
    //     $billingNm = $billingFirstName . " " . $billingLastName;
    //     $billingPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
    //     $billingEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
    //     $billingAddr1 = ($current_user->ID == 0) ? $order->get_billing_address_1() : get_user_meta($current_user->ID, "billing_address_1", true);
    //     $billingAddr2 = ($current_user->ID == 0) ? $order->get_billing_address_2() : get_user_meta($current_user->ID, "billing_address_2", true);
    //     $billingAddr = $billingAddr1 . "-" . $billingAddr2;
    //     $billingCity = ($current_user->ID == 0) ? $order->get_billing_city() : get_user_meta($current_user->ID, "billing_city", true);
    //     $billingState = WC()->countries->states[$order->get_billing_country()][$order->get_billing_state()];
    //     $billingPostCd = ($current_user->ID == 0) ? $order->get_billing_postcode() : get_user_meta($current_user->ID, "billing_postcode", true);
    //     $billingCountry = WC()->countries->countries[$order->get_billing_country()];

    //     $deliveryFirstName = $order->get_shipping_first_name();
    //     $deliveryLastName = $order->get_shipping_last_name();
    //     $deliveryNm = $deliveryFirstName . " " . $deliveryLastName;
    //     $deliveryPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
    //     $deliveryEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
    //     $deliveryAddr1 = $order->get_shipping_address_1();
    //     $deliveryAddr2 = $order->get_shipping_address_2();
    //     $deliveryAddr = $deliveryAddr1 . " " . $deliveryAddr2;
    //     $deliveryCity = $order->get_billing_city();
    //     $deliveryState = WC()->countries->states[$order->get_shipping_country()][$order->get_shipping_state()];
    //     $deliveryPostCd = $order->get_shipping_postcode();
    //     $deliveryCountry = WC()->countries->countries[$order->get_shipping_country()];

    //     // Prepare Parameters
    //     $nicepay = new NicepayLibQRISV2();

    //     $dateNow        = date('Ymd');

    //     $nicepay->set('mKey', $this->mKey);
    //     $nicepay->set('privateKey', $this->privateKey);
    //     $nicepay->set('SecretClient', $this->SecretClient);
    //     $paymentExpiryDate   = date('Ymd', strtotime($dateNow . ' +1 day'));
    //     $paymentExpiryTime   = date('His', strtotime($dateNow . ' +1 hour'));
    //     $timeStamp = date("Ymdhis");
    //     date_default_timezone_set('Asia/Jakarta');
    //     $nicepay->set('X-TIMESTAMP', date('c'));
    //     $nicepay->set('timeStamp', $timeStamp);
    //     //$nicepay->set('instmntType', '2');
    //     //$nicepay->set('instmntMon', '1');
    //     // $nicepay->set('payValidDt', $paymentExpiryDate);
    //     // $nicepay->set('payValidTm', $paymentExpiryTime);
    //     $nicepay->set('iMid', $this->iMid);
    //     $nicepay->set('X-CLIENT-KEY', $this->XCLIENTKEY);
    //     // $nicepay->set('payMethod', '08');
    //     $nicepay->set('currency', 'IDR');
    //     $nicepay->set('amt', $order_total);
    //     $nicepay->set('referenceNo', $order_id);
    //     $nicepay->set('goodsNm', 'Payment of invoice No ' . $order_id);
    //     $nicepay->set('dbProcessUrl', home_url('/wc-api/wc_gateway_nicepay_qris'));
    //     $nicepay->set('description', 'Payment of invoice No ' . $order_id);
    //     // $merchantToken = $nicepay->merchantToken();
    //     // $nicepay->set('merchantToken', $merchantToken);
    //     $nicepay->set('reqDt', date('Ymd'));
    //     $nicepay->set('reqTm', date('His'));
    //     $nicepay->set('mitraCd', WC()->session->get('mitraCd'));
    //     $nicepay->set('userIP', $nicepay->getUserIP());
    //     $nicepay->set('cartData', json_encode($cartData, JSON_UNESCAPED_SLASHES));
    //     //$nicepay->set('sellers', json_encode($sellers, JSON_UNESCAPED_SLASHES ));
    //     $nicepay->set('billingNm', $billingNm);
    //     $nicepay->set('billingPhone', $billingPhone);
    //     $nicepay->set('billingEmail', $billingEmail);
    //     $nicepay->set('billingAddr', $billingAddr);
    //     $nicepay->set('billingCity', $billingCity);
    //     $nicepay->set('billingState', $billingState);
    //     $nicepay->set('billingPostCd', $billingPostCd);
    //     $nicepay->set('billingCountry', $billingCountry);
    //     // $nicepay->set('deliveryNm', $deliveryNm);
    //     // $nicepay->set('deliveryPhone', $deliveryPhone);
    //     // $nicepay->set('deliveryAddr', $deliveryAddr);
    //     // $nicepay->set('deliveryCity', $deliveryCity);
    //     // $nicepay->set('deliveryState', $deliveryState);
    //     // $nicepay->set('deliveryPostCd', $deliveryPostCd);
    //     // $nicepay->set('deliveryCountry', $deliveryCountry);
    //     $nicepay->set('shopId', $this->shopId);

    //     unset($nicepay->requestData['mKey']);

    //     // $validate = $nicepay->requestQRISV2();
    //     $validate = $nicepay->requestQRISV2();

    //     $X_CLIENT_KEY = $this->XCLIENTKEY;
    //     $requestToken = SNAPQRConfig::NICEPAY_ACCESSTOKEN;
    //     // date_default_timezone_set('Asia/Jakarta');
    //     // $X_TIMESTAMP = date('c');
    //     $stringToSign = $X_CLIENT_KEY . "|" . $nicepay->get('X-TIMESTAMP');
    //     $privatekey = "-----BEGIN RSA PRIVATE KEY-----" . "\r\n" .
    //         $this->privateKey . // string private key
    //         "\r\n" .
    //         "-----END RSA PRIVATE KEY-----";
    //     $binary_signature = "";
    //     $pKey = openssl_pkey_get_private($privatekey);


    //     openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);

    //     openssl_pkey_free($pKey);
    //     $signature = base64_encode($binary_signature);
    //     $jsonData = array(
    //         "grantType" => "client_credentials",
    //         "additionalInfo" => ""
    //     );


    //     $jsonDataEncode = json_encode($jsonData);
    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_URL, $requestToken);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    //     curl_setopt($ch, CURLOPT_HEADER, false);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncode);
    //     curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    //         'Content-Type: application/json',
    //         'X-SIGNATURE: ' . base64_encode($binary_signature),
    //         'X-CLIENT-KEY: ' . $X_CLIENT_KEY,
    //         'X-TIMESTAMP: ' . $nicepay->get('X-TIMESTAMP')
    //     ));

    //     $output = curl_exec($ch);
    //     $data = json_decode($output);
    //     $accessToken = $data->accessToken;
    //     WC()->session->set('accessToken', $data->accessToken);

    //     $X_TIMESTAMP = $nicepay->get("X-TIMESTAMP");
    //     $timestamp = date('YmdHis');
    //     $CreateQR = SNAPQRConfig::NICEPAY_SNAP_CREATEQR;
    //     $authorization = "Bearer " . $accessToken;
    //     $channel = $this->get_option('Chanel-ID');
    //     $external = $timestamp . rand();
    //     $partner = $X_CLIENT_KEY;
    //     $amt = $nicepay->get("amt");
    //     $secretClient =
    //         $this->SecretClient;
    //     // "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
    //     // $this->secretClient;
    //     $additionalInfo = [
    //         //   "bankCd" => $nicepay->get("bankCd"),
    //         "goodsNm" => $nicepay->get("goodsNm"),
    //         "dbProcessUrl" => $nicepay->get("dbProcessUrl"),
    //         //   "payValidDt" => $nicepay->get("payValidDt"),
    //         //   "payValidTm" => $nicepay->get("payValidTm"),
    //         "billingNm" => $nicepay->get("billingNm"),
    //         "billingPhone" => $nicepay->get("billingPhone"),
    //         "billingEmail" => $nicepay->get("billingEmail"),
    //         "billingCity" => $nicepay->get("billingCity"),
    //         "billingState" => $nicepay->get("billingState"),
    //         "billingPostCd" => $nicepay->get("billingPostCd"),
    //         "billingCountry" => $nicepay->get("billingCountry"),
    //         "callBackUrl" => "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp",
    //         "mitraCd" => $nicepay->get("mitraCd"),
    //         "cartData" => $nicepay->get("cartData"),
    //         "msId" => "",
    //         "msFee" => "",
    //         "msFeeType" => "",
    //         "mbFee" => "",
    //         "mbFeeType" => ""
    //     ];

    //     $TotalAmount = [
    //         "value" => $nicepay->get("amt") . ".00",
    //         "currency" => $nicepay->get("currency")
    //     ];

    //     $newBody = [
    //         "partnerReferenceNo" => "ncpy20221017161458",
    //         "amount" => $TotalAmount,
    //         "validityPeriod" => "",
    //         "merchantId" => $X_CLIENT_KEY,
    //         "storeId" => $nicepay->get("shopId"),
    //         "additionalInfo" => $additionalInfo
    //     ];

    //     $stringBody = json_encode($newBody);

    //     $hashbody = strtolower(hash("SHA256", $stringBody));

    //     $strigSign = "POST:/api/v1.0/qr/qr-mpm-generate:" . $accessToken . ":" . $hashbody . ":" . $X_TIMESTAMP;
    //     $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
    //     // echo base64_encode($bodyHasing);exit();

    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_URL, $CreateQR);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    //     curl_setopt($ch, CURLOPT_HEADER, false);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $stringBody);
    //     curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    //         'Content-Type: application/json',
    //         'X-SIGNATURE: ' . base64_encode($bodyHasing),
    //         'X-CLIENT-KEY: ' . $X_CLIENT_KEY,
    //         'X-TIMESTAMP: ' . $X_TIMESTAMP,
    //         'Authorization: ' . $authorization,
    //         'CHANNEL-ID: ' . $channel,
    //         'X-EXTERNAL-ID: ' . $external,
    //         'X-PARTNER-ID: ' . $X_CLIENT_KEY
    //     ));

    //     $output = curl_exec($ch);
    //     $response = json_decode($output);
    //     //   $responseMessage = $data->responseMessage;
    //     //   $trxId = $data->referenceNo;
    //     //   $RefrenceNo = $data->partnerReferenceNo;
    //     //   $QRurl = $data->qrUrl;
    //     //   $goodsNm = $data->additionalInfo->goodsNm;
    //     //   $billingNm = $data->additionalInfo->billingNm;
    //     //   $bankCd = $data->virtualAccountData->additionalInfo->bankCd;
    //     //   $tXidVA = $data->virtualAccountData->additionalInfo->tXidVA;
    //     //   $goodsNm = $data->virtualAccountData->additionalInfo->goodsNm;
    //     //   $vacctValidDt = $data->virtualAccountData->additionalInfo->vacctValidDt;
    //     //   $vacctValidTm = $data->virtualAccountData->additionalInfo->vacctValidTm;

    //     // Send Data
    //     // $registResponse = $nicepay->requestQRISV2();

    //     // Response from NICEPAY
    //     if (isset($response->responseCode) && $response->responseCode == "2004700") {
    //         //Set Session
    //         WC()->session->set('tXid', $response->referenceNo); //from response
    //         WC()->session->set('referenceNo', $response->partnerReferenceNo); //from response
    //         // WC()->session->set('payMethod', $registResponse->payMethod); //from response
    //         WC()->session->set('amt', $nicepay->get("amt")); //from response
    //         WC()->session->set('billingNm', $billingNm);
    //         // WC()->session->set('mitraCd', $response->mitraCd); //from response
    //         // WC()->session->set('transDt', $registResponse->transDt); //from response
    //         // WC()->session->set('description', $registResponse->description); //from response
    //         // WC()->session->set('paymentExpDt', $registResponse->paymentExpDt); //from response
    //         // WC()->session->set('validityPeriod', $response->validityPeriod); //from response
    //         WC()->session->set('qrContent', $response->qrContent); //from response
    //         WC()->session->set('qrUrl', $response->qrUrl); //from response

    //         WC()->cart->empty_cart();

    //         $order->add_order_note(
    //             sprintf(
    //                 __('Menunggu pembayaran melalui NICEPay Payment Gateway dengan id transaksi %s', 'woocommerce'),
    //                 $response->referenceNo
    //             )
    //         );

    //         $order->add_order_note(
    //             sprintf(
    //                 __('QRContent: %s', 'woocommerce'),
    //                 $response->qrContent
    //             )
    //         );

    //         $order->add_order_note(
    //             sprintf(
    //                 __('QR Image URL: %s', 'woocommerce'),
    //                 $response->qrUrl
    //             )
    //         );

    //         //REDUCE WC Stock
    //         if (property_exists($this, 'reduceStock') && $this->reduceStock == 'yes') {
    //             wc_reduce_stock_levels($order);
    //         }

    //         // REDIRECT Continue Button
    //         $callBackUrl = $order->get_checkout_order_received_url();
    //         $qrisLogo = NICEPAY_PLUGIN_URL . '/assets/images/qris-logo.png';
    //         echo "<script>
    //                 function startTimer(duration, display) {
    //                     var timer = duration, minutes, seconds;
    //                     setInterval(function () {
    //                         minutes = parseInt(timer / 60, 10);
    //                         seconds = parseInt(timer % 60, 10);
                    
    //                         minutes = minutes < 10 ? \"0\" + minutes : minutes;
    //                         seconds = seconds < 10 ? \"0\" + seconds : seconds;
                    
    //                         display.textContent = minutes + \":\" + seconds;
                    
    //                         if (--timer < 0) {
    //                             timer = duration;
    //                         }
    //                     }, 1000);
    //                 }
                    
    //                 window.onload = function () {
    //                     var fiveMinutes = 60 * 5,
    //                         display = document.querySelector('#time');
    //                     startTimer(fiveMinutes, display);
    //                 };
                
    //             </script>";
    //         echo "<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">";

    //         echo "<style>
    //               .qrdetails{
    //                   align-content: center;
    //                   text-align: center;
    //               }
    //               .qrdetailsimage{
    //                 display: flex;
    //                   justify-content: center;
    //               }
    //               .continue-btn{
    //               width: 10em;  
    //               height: 3em;
    //               font-size: 30px;
    //               color: white !important;
    //               background-color: orange !important;
    //               }
    //               .continue-btn:hover{
    //               color: white !important;
    //               background-color: darkorange !important;
    //               }
    //               </style>";

    //         echo "
    //             <ul class=\"order_details\">
    //                     <li class=\"qrdetails\">
    //                     <h4><strong>Silahkan Scan QRIS berikut menggunakan Applikasi pembayaran yang mendukung QRIS.</strong></h4>
    //                     </li>
                        
    //                     <li class=\"qrdetailsimage\">
    //                     <img src=\"$qrisLogo\" alt=\"QRIS Logo\">
    //                     </li>

    //                     <li class=\"qrdetailsimage\">
    //                     <img src=\"$response->qrUrl\" alt=\"QRIS Image\" width=\"280px\" height=\"280px\">
    //                     </li>
                        
    //                     <li class=\"qrdetails\">
    //                     <button onClick=\"window . location = '$response->qrUrl';\" class=\"btn\"> <i class=\"fa fa-download\"></i> Download QR</button>

    //                     <strong>QR hanya valid dalam <strong><p id='time'>5 Menit</p></strong>Tekan tombol Continue jika sudah melakukan pembayaran.</strong>
    //                     <p><small>Halaman ini akan otomatis redirect dalam 5 menit.</small></p>
    //                     </li>
                        
    //                     <li class=\"qrdetailsimage\">
    //                         <button onClick=\"window.location='$callBackUrl';\" class=\"continue-btn\">Continue</button>
    //                     </li>
    //                     <br>
    //             </ul>";

    //         header("Refresh: 300; Location:" . $callBackUrl);
    //     } elseif (isset($data->responseCode)) {
    //         // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
    //         // In this sample, we echo error message
    //         // header("Location: "."http://example.com/checkout.php");
    //         echo "<pre>";
    //         echo "result code: " . $response->responseCode . "\n";
    //         echo "result message: " . $response->responseMessage . "\n";
    //         // echo "requestUrl: ".$registResponse->data->requestURL."\n";
    //         echo "</pre>";
    //     } else {
    //         // Timeout, you can redirect back to checkout page or echo error message.
    //         // In this sample, we echo error message
    //         // header("Location: "."http://example.com/checkout.php");
    //         echo "<pre>Registration Connection Timeout. Please Try again.</pre>";
    //     }
    // }

    public function add_description_payment_success($orderdata)
    {
        $order = new WC_Order($orderdata);
        if ($order->get_payment_method() == 'nicepay_qris') {
            $nicepay = new NicepayLibQRISV2();

            // Set checkStatus Token For Inquiry
            $X_CLIENT_KEY = $this->XCLIENTKEY;
            $shopId = $this->shopId;
            $accessToken = WC()->session->get('accessToken');
            $CheckStts = SNAPQRConfig::NICEPAY_SNAP_INQUIRY;
            $timestamp = date('YmdHis');
            date_default_timezone_set('Asia/Jakarta');
            $nicepay->set('X-TIMESTAMP', date('c'));
            $X_TIMESTAMP = $nicepay->get("X-TIMESTAMP");
            $authorization = "Bearer " . $accessToken;
            $channel = $this->get_option('Chanel-ID');
            $external = $timestamp . rand();
            $partner = $X_CLIENT_KEY;
            $amt = $nicepay->get("amt");
            $tXid = WC()->session->get('tXid');
            $referenceno = WC()->session->get('referenceNo');
            $secretClient =
                $this->SecretClient;

            $additonalInfo = new \stdClass();
            $bodyInqu = [
                "originalReferenceNo" => $tXid,
                "originalPartnerReferenceNo" => $referenceno,
                //   "payValidDt" => $nicepay->get("payValidDt"),
                //   "payValidTm" => $nicepay->get("payValidTm"),
                "merchantId" => $X_CLIENT_KEY,
                "externalStoreId" => $shopId,
                "serviceCode" => "51",
                "additionalInfo" => $additonalInfo
            ];

            // $Validate = $nicepay->checkPaymentStatus($X_TIMESTAMP, $X_CLIENT_KEY, $tXid, $referenceno);

            $StringBody = json_encode($bodyInqu);

            $hashbody = strtolower(hash("SHA256", $StringBody));

            $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $accessToken . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $CheckStts);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $StringBody);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'X-SIGNATURE: ' . base64_encode($bodyHasing),
                'X-CLIENT-KEY: ' . $X_CLIENT_KEY,
                'X-TIMESTAMP: ' . $X_TIMESTAMP,
                'Authorization: ' . $authorization,
                'CHANNEL-ID: ' . $channel,
                'X-EXTERNAL-ID: ' . $external,
                'X-PARTNER-ID: ' . $X_CLIENT_KEY
            ));

            $output = curl_exec($ch);
            $paymentStatus = json_decode($output);

            if ($paymentStatus->latestTransactionStatus == '00') {
                echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                echo '<table border="0" cellpadding="10">';
                echo '<tr><td><strong>Status</strong></td><td>' . ucfirst($paymentStatus->responseMessage) . '</td></tr>';
                echo '<tr><td><strong>Reference Code</strong></td><td>' . WC()->session->get('referenceNo') . '</td></tr>';
                echo '<tr><td><strong>Billing Name</strong></td><td>' . WC()->session->get('billingNm') . '</td></tr>';
                echo '<tr><td><strong>Transaction Amount</strong></td><td>' . WC()->session->get('amt') . '</td></tr>';
                echo '<tr><td><strong>Transaction Date</strong></td><td>' . $paymentStatus->paidTime . '</td></tr>';
                echo '</table>';
            } elseif ($paymentStatus->latestTransactionStatus != '00') {
                echo '<h1 id="h2thanks">Your Transaction has not been processed.</h1>';
                echo '<h1 style="color: red;"><strong>Status: ' . ucfirst($paymentStatus->latestTransactionStatus) . '</strong></h1><br>';
            } else {
                echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                echo '<table border="0" cellpadding="10">';
                echo '<tr><td><strong>Timeout To Nicepay, Please Try Again.</strong></td></tr>';
                echo '</table>';
            }
        }
    }

    //Add details to Processing Order email
    public function np_add_payment_email_detail($orderdata, $sent_to_admin, $plain_text, $email)
    {
        $order = new WC_Order($orderdata);
        if ($order->get_payment_method() == 'nicepay_qris') {
            if ($email->id == 'customer_processing_order') {
                echo '<h2 class="email-upsell-title">We Have Received Your Payment!</h2>';
            }
        }
    }

    //Change Email Subject for Processing Email
    public function np_change_subject_payment_email_detail($formated_subject, $orderdata)
    {
        $order = new WC_Order($orderdata);
        if ($order->get_payment_method() == 'nicepay_qris') {
            $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
            $subject = sprintf('Hi %s, Thank you for your payment on %s', $order->billing_first_name, $blogname);
            return $subject;
        }
    }

    public function modify_fee_html_for_taxes($cart_fee_html, $fees)
    {
        if ('incl' === get_option('woocommerce_tax_display_cart') && isset($fees->tax) && $fees->tax > 0 && in_array($fees->name, $this->fees_added, true)) {
            $cart_fee_html .= '<small class="includes_tax">' . sprintf(__('(includes %s Tax)', 'checkout-fees-for-woocommerce'), wc_price($fees->tax)) . '</small>'; // phpcs:ignore
        }
        return $cart_fee_html;
    }

    private function get_access_token()
    {
        nicepay_log("Starting get_access_token process", 'info', 'qris');

        try {
            $X_CLIENT_KEY = $this->XCLIENTKEY;
            $timestamp = $this->generate_timestamp();
            $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;
            nicepay_log("X_CLIENT_KEY: " . $X_CLIENT_KEY, 'info', 'qris');
            nicepay_log("Timestamp: " . $timestamp, 'info', 'qris');
            nicepay_log("StringToSign: " . $stringToSign, 'info', 'qris');

            $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
                $this->get_option('privateKey') .
                "\r\n-----END RSA PRIVATE KEY-----";
            nicepay_log("Private Key Structure: " . substr($privatekey, 0, 100) . "...", 'info', 'qris');
            $binary_signature = "";
            $pKey = openssl_pkey_get_private($privatekey);

            if ($pKey === false) {
                $error = openssl_error_string();
                nicepay_log("Failed to get private key. OpenSSL Error: " . $error, 'error', 'qris');
                throw new Exception("Invalid private key: " . $error);
            }

            $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);

            if ($sign_result === false) {
                $error = openssl_error_string();
                nicepay_log("Failed to create signature. OpenSSL Error: " . $error, 'error', 'qris');
                throw new Exception("Failed to create signature: " . $error);
            }

            $signature = base64_encode($binary_signature);
            nicepay_log("Generated Signature: " . $signature, 'info', 'qris');

            // Prepare request data
            $jsonData = array(
                "grantType" => "client_credentials"
            );

            $jsonDataEncode = json_encode($jsonData);
            nicepay_log("Request Body JSON: " . $jsonDataEncode, 'info', 'qris');

            // Prepare request
            $requestToken = $this->api_endpoints['access_token'];
            nicepay_log("Request URL: " . $requestToken, 'info', 'qris');

            $args = array(
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE'  => $signature,
                    'X-CLIENT-KEY' => $X_CLIENT_KEY,
                    'X-TIMESTAMP'  => $timestamp
                ),
                'body'    => $jsonDataEncode,
            );

            nicepay_log("url access_token: " . $this->api_endpoints['access_token'], 'info', 'qris');
            nicepay_log("Request headers for get_access_token: " . json_encode($args['headers']), 'info', 'qris');
            nicepay_log("Request body for get_access_token: " . json_encode($jsonDataEncode), 'info', 'qris');

            // Send request
            $response = wp_remote_post($requestToken, $args);

            if (is_wp_error($response)) {
                nicepay_log("Error in get_access_token: " . $response->get_error_message(), 'error', 'qris');
                throw new Exception($response->get_error_message());
            }

            $body = json_decode(wp_remote_retrieve_body($response));
            nicepay_log("Access token response: " . json_encode($body), 'info', 'qris');

            if (!isset($body->accessToken)) {
                nicepay_log("Invalid access token response: " . json_encode($body), 'error', 'qris');
                throw new Exception(__('Invalid access token response', 'nicepay-qris-gateway'));
            }

            nicepay_log("Successfully obtained access token", 'info');
            WC()->session->set('accessToken', $body->accessToken);

            return $body->accessToken;
        } catch (Exception $e) {
            nicepay_log("Failed to get access token: " . $e->getMessage(), 'error', 'qris');
            throw $e;
        }
    }

    public function process_payment($order_id)
    {
        nicepay_log("Starting process_payment for QRIS order $order_id", 'info', 'qris');

        $checkout_mode = get_option('nicepay_checkout_mode');
        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }

    public function process_classic_payment($order_id)
    {
        nicepay_log("Starting payment process for order: $order_id", 'info');

        try {
            $order = wc_get_order($order_id);
            $order->update_meta_data('_nicepay_payment_method', 'qris');
            $order->save();

            if (!$order) {
                throw new Exception("Invalid order ID");
            }

            WC()->session->set('mitraCd', 'QSHP');

            // Get access token
            nicepay_log("Requesting access token", 'info', 'qris');
            $access_token = $this->get_access_token();

            if (!$access_token) {
                throw new Exception("Failed to obtain access token");
            }

            // Prepare payment data
            $payment_data = $this->prepare_payment_data($order);
            nicepay_log("Payment data prepared: " . json_encode($payment_data), 'info', 'qris');

            // Create QRIS request
            $result = $this->create_qris_request($payment_data, $access_token, $order);
            nicepay_log("QRIS response received: " . json_encode($result), 'info', 'qris');

            if (!isset($result->responseCode) || $result->responseCode !== "2004700") {
                throw new Exception($result->responseMessage ?? "Failed to create QRIS");
            }

            // Save transaction data
            $this->save_transaction_data($order, $result);
            WC()->session->set('qr_url', $result->qrUrl);
            WC()->session->set('qr_content', $result->qrContent);

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
        } catch (Exception $e) {
            nicepay_log("Payment process failed: " . $e->getMessage(), 'error', 'qris');
            wc_add_notice($e->getMessage(), 'error', 'qris');
            return array('result' => 'failure');
        }
    }

    public function process_blocks_payment($order_id)
    {
        nicepay_log("Starting payment process for order: $order_id", 'info');
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'qris');
        $order->save();

        if (!empty($this->get_option('SecretClient')) && !empty($this->get_option('privateKey'))) {
            try {
                WC()->session->set('mitraCd', 'QSHP');
                nicepay_log("Requesting access token", 'info', 'qris');
                $access_token = $this->get_access_token();

                if (!$access_token) {
                    throw new Exception("Failed to obtain access token");
                }

                $payment_data = $this->prepare_payment_data($order);
                nicepay_log("Payment data prepared: " . json_encode($payment_data), 'info', 'qris');

                $result = $this->create_qris_request($payment_data, $access_token, $order);
                nicepay_log("QRIS response received: " . json_encode($result), 'info', 'qris');

                if (!isset($result->responseCode) || $result->responseCode !== "2004700") {
                    throw new Exception($result->responseMessage ?? "Failed to create QRIS");
                }

                $this->save_transaction_data($order, $result);
                WC()->session->set('qr_url', $result->qrUrl);
                WC()->session->set('qr_content', $result->qrContent);
                WC()->cart->empty_cart();

                return array(
                    'result' => 'success',
                    'redirect' => $order->get_checkout_payment_url(true)
                );
            } catch (Exception $e) {
                nicepay_log("Payment process failed: " . $e->getMessage(), 'error', 'qris');
                wc_add_notice($e->getMessage(), 'error', 'qris');
                return array('result' => 'failure');
            }
        } else {
            try {
                $qris_data = $this->process_directV2($order_id);
                if (!isset($qris_data['resultCd']) || $qris_data['resultCd'] !== '0000') {
                    throw new Exception(sprintf(__('Failed to create QRIS transaction: %s', 'nicepay-wc'), $qris_data['resultMsg'] ?? 'Unknown error'));
                }

                $this->save_transaction_data($order, $qris_data);
                WC()->session->set('qr_url', $qris_data->qrUrl);
                WC()->session->set('qr_content', $qris_data->qrContent);
                WC()->cart->empty_cart();

                return array(
                    'result' => 'success',
                    'redirect' => $order->get_checkout_payment_url(true)
                );
            } catch (Exception $e) {
                wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
                nicepay_log("Payment error in Processing blocks payment: " . $e->getMessage(), 'error', 'qris');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    private function get_cart_data($order)
    {
        $items = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $items[] = [
                "goods_name" => $item->get_name(),
                "goods_detail" => $product->get_short_description() ?: $item->get_name(),
                "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
                "goods_quantity" => (string)$item->get_quantity()
            ];
        }

        return json_encode([
            "count" => count($items),
            "item" => $items
        ], JSON_UNESCAPED_SLASHES);
    }

    private function prepare_payment_data($order)
    {
        nicepay_log("Preparing payment data for order: " . $order->get_id(), 'info', 'qris');

        try {
            $timestamp = date('YmdHis');
            // Prepare cart data
            $cart_data = $this->prepare_cart_data($order);

            // Prepare request data structure
            $payment_data = [
                "partnerReferenceNo" => $order->get_id() . "-" . $timestamp,
                "amount" => [
                    "value" => number_format($order->get_total(), 2, '.', ''),
                    "currency" => $order->get_currency()
                ],
                "merchantId" => $this->get_option('X-CLIENT-KEY'),
                "storeId" => $this->get_option('shopId'),
                "validityPeriod" => '',
                "additionalInfo" => [
                    "goodsNm" => "Payment for Order #" . $order->get_id(),
                    "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    "billingPhone" => $order->get_billing_phone(),
                    "billingEmail" => $order->get_billing_email(),
                    "billingAddr" => $order->get_billing_address_1(),
                    "billingCity" => $order->get_billing_city(),
                    "billingState" => WC()->countries->states[$order->get_billing_country()][$order->get_billing_state()],
                    "billingPostCd" => $order->get_billing_postcode(),
                    "billingCountry" => WC()->countries->countries[$order->get_billing_country()],
                    "callBackUrl" => $this->get_return_url($order),
                    "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_qris'),
                    "userIP" => $this->get_user_ip(),
                    "cartData" => $cart_data,
                    "mitraCd" => WC()->session->get('mitraCd', 'QSHP')
                ]
            ];

            nicepay_log("Payment data prepared: " . json_encode($payment_data), 'info', 'qris');
            return $payment_data;
        } catch (Exception $e) {
            nicepay_log("Error preparing payment data: " . $e->getMessage(), 'error', 'qris');
            throw $e;
        }
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    private function save_transaction_data($order, $result)
    {
        try {
            nicepay_log("Saving transaction data for order: " . $order->get_id(), 'info', 'qris');
            nicepay_log("result create QR: " . json_encode($result), 'info', 'qris');

            if (!empty($this->get_option('SecretClient')) && !empty($this->get_option('privateKey'))) {
                $referenceNo = $result->partnerReferenceNo ?? '';
                $tXid        = $result->referenceNo ?? '';
                $qrUrl       = $result->qrUrl ?? '';
                $qrContent   = $result->qrContent ?? '';
                
                nicepay_log("(SNAP) save_transaction_data ", 'info', 'qris');
                nicepay_log("(SNAP) qrUrl: " . $qrUrl, 'info', 'qris');
                nicepay_log("(SNAP) qrContent : " . $qrContent, 'info', 'qris');

            } else {
                $referenceNo = $result['referenceNo'] ?? '';
                $tXid = $result['tXid'] ?? '';
                $qrUrl = $result['qrUrl'] ?? '';
                $qrContent = $result['qrContent'] ?? '';

                nicepay_log("(Direct V2) save_transaction_data ", 'info', 'qris');
                nicepay_log("(Direct V2) qrUrl: " . $qrUrl, 'info', 'qris');
                nicepay_log("(Direct V2) qrContent : " . $qrContent, 'info', 'qris');
            }

            $order->add_order_note(sprintf(
                __('NICEPay QRIS. Details:
                Reference Number : %s
                Transaction ID: %s', 'nicepay-wc'),
                $referenceNo,
                $tXid
            ));

            $order->update_meta_data('_nicepay_reference_no', $referenceNo);
            $order->update_meta_data('_nicepay_tXid', $tXid);
            $order->update_meta_data('_nicepay_qr_url', $qrUrl);
            $order->update_meta_data('_nicepay_qr_content', $qrContent);

            WC()->session->set('qr_url', $qrUrl);
            WC()->session->set('qr_content', $qrContent);
            $order->save();
        } catch (Exception $e) {
            nicepay_log("Error saving transaction data: " . $e->getMessage(), 'error', 'qris');
            throw $e;
        }
    }

    private function create_qris_request($data, $access_token, $order)
    {
        nicepay_log("Starting QRIS request for order " . $order->get_id(), 'info', 'qris');
        try {
            $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
            $secretClient = $this->get_option('SecretClient');
            $X_TIMESTAMP = $this->generate_timestamp();
            $timestamp = date('YmdHis');

            nicepay_log("Starting QRIS request with data: " . json_encode($data), 'info', 'qris');

            $stringBody = json_encode($data, JSON_UNESCAPED_SLASHES);
            $hashbody = strtolower(hash("SHA256", $stringBody));

            nicepay_log("Request body hash: " . $hashbody, 'info', 'qris');

            $strigSign = "POST:/api/v1.0/qr/qr-mpm-generate:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

            $args = array(
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type'   => 'application/json',
                    'X-SIGNATURE'    => base64_encode($bodyHasing),
                    'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                    'X-TIMESTAMP'    => $X_TIMESTAMP,
                    'Authorization'  => "Bearer " . $access_token,
                    'CHANNEL-ID'     => $this->get_option('Chanel-ID'),
                    'X-EXTERNAL-ID'  => $timestamp . rand(1000, 9999),
                    'X-PARTNER-ID'   => $X_CLIENT_KEY
                ),
                'body'    => $stringBody,
            );

            nicepay_log("url create_qris_request: " . $this->api_endpoints['registration'], 'info', 'qris');
            nicepay_log("Request headers for create_qris_request: " . json_encode($args['headers']), 'info', 'qris');
            nicepay_log("Request body for create_qris_request: " . $stringBody, 'info', 'qris');

            $response = wp_remote_post($this->api_endpoints['registration'], $args);

            if (is_wp_error($response)) {
                throw new Exception("QRIS request failed: " . $response->get_error_message());
            }

            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            $result = json_decode($response_body);

            nicepay_log("Create QRIS Response: " . $response_code, 'info', 'qris');
            nicepay_log("Create QRIS Response: " . $response_body, 'info', 'qris');

            if (!$result || !isset($result->responseCode) || $result->responseCode !== '2004700') {
                nicepay_log("Invalid API response: " . json_encode($result), 'error', 'qris');
                throw new Exception($result->responseMessage ?? "Failed to create QRIS");
            }


            return $result;
        } catch (Exception $e) {
            nicepay_log("Error in create_qris_request: " . $e->getMessage(), 'error', 'qris');
            throw $e;
        }
    }

    private function get_user_ip()
    {
        $ip = '';
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

    public function handle_callback()
    {
        nicepay_log('NICEPay callback received. Starting processing...', 'info', 'qris');
        status_header(200);

        // Ambil header request
        $headers = getallheaders();
        nicepay_log('Headers: ' . print_r($headers, true), 'info', 'va');

        // Contoh akses header tertentu
        $timestamp = $headers['X-TIMESTAMP'] ?? null;
        $client_key = $headers['X-CLIENT-KEY'] ?? null;
        $signature = $headers['X-SIGNATURE'] ?? null;
        $raw_post = file_get_contents('php://input');
        nicepay_log('Raw input: ' . $raw_post, 'info', 'qris');

        $decoded_post = json_decode($raw_post, true);

        // Fallback parsing kalau bukan JSON (biasanya jarang terjadi)
        if (!$decoded_post) {
            parse_str($raw_post, $decoded_post);
        }
        if (empty($decoded_post)) {
            $decoded_post = $_POST;
        }

        if (!empty($signature)) {
            try {
                nicepay_log("(SNAP) Attempting to find order with ID: " . $decoded_post['originalPartnerReferenceNo'], 'info', 'va');

            if (!isset($decoded_post['originalPartnerReferenceNo']) || !isset($decoded_post['originalReferenceNo'])) {
                throw new Exception("Missing required callback parameters");
            }

                $reference_no = $decoded_post['originalPartnerReferenceNo'];
                $tXid = $decoded_post['originalReferenceNo'];

                $parts = explode('-', $reference_no);
                $order_id = $parts[0];
            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception("Order not found: " . $order_id);
            }

                $stored_refNo = $order->get_meta('_nicepay_reference_no');
                if ($reference_no !== $stored_refNo) {
                throw new Exception("Reference number mismatch");
            }

                $this->check_payment_status($decoded_post, $order_id);

            // Respond to the callback
            wp_send_json(array(
                'status' => 'OK',
                'message' => 'Callback processed successfully'
            ));

                } catch (Exception $e) {
                wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
                nicepay_log("Payment error in handle_callback: " . $e->getMessage(), 'error', 'qris');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        } else {
            nicepay_log('(Direct V2) Attempting to find order with ID: ' . $decoded_post['referenceNo'], 'info', 'qris');

            $referenceNo = trim($decoded_post['referenceNo']);
            $parts = explode('-', $referenceNo);
            $order_id = $parts[0];
            $order = wc_get_order($order_id);

                if ($order) { 
                    $this->check_payment_status_directv2($order_id,$decoded_post);

                    wp_send_json(array('status' => 'received'), 200);
                    exit;
                } else {
                    nicepay_log('Order not found for paymentRequestId: ' . $order_id, 'error', 'qris');
                    wp_send_json_error('Order not found', 404);
                }
        }
        nicepay_log("====== NOTIF CALLBACK COMPLETED ======", 'info','qris');
        exit;
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'qris');
        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int)$order->get_total();
            $referenceNo = $order->get_id() . "-" . $timestamp;
            $mitraCd = WC()->session->get('mitraCd', 'QSHP');
            $shopId = $this->get_option('shopId');

            if (empty($mitraCd)) {
                throw new Exception(__('No QRIS selected. Please choose a QRIS payment method.', 'nicepay-wc'));
            }
            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            $cart_data = $this->prepare_cart_data($order);

            $requestBody = [
                "timeStamp" => $timestamp,
                "iMid" => $iMid,
                "payMethod" => "08",
                "currency" => "IDR",
                "amt" => $amount,
                "referenceNo" => $referenceNo,
                "merchantToken" => $merchantToken,
                "mitraCd" => $mitraCd,
                "shopId" => $shopId,
                "goodsNm" => $this->get_order_items_names($order),
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_qris'),
                "description" => "Testing API QRIS - " . get_bloginfo('name'),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $order->get_billing_phone(),
                "billingEmail" => $order->get_billing_email(),
                "billingAddr" => $order->get_billing_address_1(),
                "billingCity" => $order->get_billing_city(),
                "billingState" => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "userIP" => $_SERVER['REMOTE_ADDR'],
                "cartData" => $cart_data,
                "payValidDt" => date('Ymd', strtotime('+1 day')),
                "payValidTm" => "235959"
            ];

            $args = [
                'method' => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("QRIS Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'qris');
            nicepay_log("QRIS Request Body: " . json_encode($requestBody), 'info', 'qris');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("QRIS Response: " . json_encode($response_body), 'info', 'qris');
            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'error', 'qris');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    // Function untuk check status
    private function check_payment_status($callbackData, $order_id){
        try {
            $order = wc_get_order($order_id);
            $access_token = $this->get_access_token();

            // Request body
            $request_body = [
                "originalReferenceNo" => $callbackData['originalReferenceNo'],
                "originalPartnerReferenceNo" => $callbackData['originalPartnerReferenceNo'],
                "merchantId" => $this->XCLIENTKEY,
                "externalStoreId" => $this->shopId,
                "serviceCode" => "47",
                "additionalInfo" => new stdClass()
            ];

            $timestamp = $this->generate_timestamp();
            $stringBody = json_encode($request_body);
            $hashbody = strtolower(hash("SHA256", $stringBody));

            $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $access_token . ":" . $hashbody . ":" . $timestamp;
            $bodyHasing = hash_hmac("sha512", $strigSign, $this->SecretClient, true);

            $args = [
                'method' => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE' => base64_encode($bodyHasing),
                    'X-CLIENT-KEY' => $this->XCLIENTKEY,
                    'X-TIMESTAMP' => $timestamp,
                    'Authorization' => "Bearer " . $access_token,
                    'CHANNEL-ID' => $this->get_option('Chanel-ID'),
                    'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
                    'X-PARTNER-ID' => $this->XCLIENTKEY
                ],
                'body' => $stringBody
            ];

            nicepay_log("url check_payment_status: " . $this->api_endpoints['check_status_url'], 'info', 'qris');
            nicepay_log("Request headers for check_payment_status: " . json_encode($args['headers']), 'info', 'qris');
            nicepay_log("Request body for check_payment_status: " . $stringBody, 'info', 'qris');

            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);

            if (is_wp_error($response)) {
                throw new Exception("Check status request failed: " . $response->get_error_message());
            }

            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            nicepay_log("Check status response code: " . json_encode($response_code), 'info', 'qris');
            nicepay_log("Check status response body: " . json_encode($response_body), 'info', 'qris');

            if ($response_body['responseCode'] === '2005100' && isset($response_body['latestTransactionStatus'])) {   
                //$order->payment_complete();
               $order->update_status('processing', 'Pembayaran QRIS berhasil.');
                $order->update_meta_data('_nicepay_status', $response_body['transactionStatusDesc']);
                $order->update_meta_data('_nicepay_status_code', $response_body['latestTransactionStatus']);
                $order->update_meta_data('_nicepay_paid_amount', $response_body['amount']['value']);
                $order->update_meta_data('_nicepay_currency', $response_body['amount']['currency']);
                $order->update_meta_data('_nicepay_transaction_datetime', $response_body['additionalInfo']['transactionDateTime']);
                $order->save();

                nicepay_log('Order meta updated for order ' . $order_id, 'info', 'qris');
            }

            return $response_body;
        } catch (Exception $e) {
            nicepay_log("Error in check_payment_status: " . $e->getMessage(), 'error', 'qris');
            throw $e;
        }
    }

    public function ajax_check_payment_status(){
        nicepay_log("Starting payment status check", 'info', 'qris');

        try {
            // 1. Validasi dan Persiapan Data
            if (!check_ajax_referer('check-qris-payment', 'security', false)) {
                throw new Exception('Invalid security token');
            }

            $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
            nicepay_log("Checking status for order ID: " . $order_id, 'info', 'qris');

            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception('Order tidak ditemukan');
            }

            if (!empty($this->get_option('SecretClient')) && !empty($this->get_option('privateKey'))) {
            $accessToken = WC()->session->get('accessToken');
            if (empty($accessToken)) {
                throw new Exception('Sesi tidak valid');
            }

            // 2. Persiapan Request ke NicePay
            $bodyInqu = array(
                    "originalReferenceNo" => $order->get_meta('_nicepay_tXid'),
                    "originalPartnerReferenceNo" => $order->get_meta('_nicepay_reference_no'),
                "merchantId" => $this->XCLIENTKEY,
                "externalStoreId" => $this->shopId,
                "serviceCode" => "47",
                "additionalInfo" => new stdClass()
            );

            // 3. Persiapan Headers dan Signature
            $X_TIMESTAMP = $this->generate_timestamp();
            $stringBody = json_encode($bodyInqu);
            $hashbody = strtolower(hash("SHA256", $stringBody));

            $strigSign = "POST:/api/v1.0/qr/qr-mpm-query:" . $accessToken . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $this->SecretClient, true);

            $args = array(
                'method' => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-SIGNATURE' => base64_encode($bodyHasing),
                    'X-CLIENT-KEY' => $this->XCLIENTKEY,
                    'X-TIMESTAMP' => $X_TIMESTAMP,
                    'Authorization' => "Bearer " . $accessToken,
                    'CHANNEL-ID' => $this->get_option('Chanel-ID'),
                    'X-EXTERNAL-ID' => date('YmdHis') . rand(1000, 9999),
                    'X-PARTNER-ID' => $this->XCLIENTKEY
                ),
                'body' => $stringBody
            );

            // 4. Kirim Request ke NicePay
            nicepay_log("url ajax_check_payment_status: " . $this->api_endpoints['check_status_url'], 'info', 'qris');
            nicepay_log("Request headers for ajax_check_payment_status: " . json_encode($args['headers']), 'info', 'qris');
            nicepay_log("Request body for ajax_check_payment_status: " . $stringBody, 'info', 'qris');

            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);

            if (is_wp_error($response)) {
                throw new Exception("Request failed: " . $response->get_error_message());
            }

            $result = json_decode(wp_remote_retrieve_body($response));

            nicepay_log("Check Payment Status Response: " . $response, 'info', 'qris');

            if (!$result) {
                throw new Exception("Invalid response from server");
            }

            // 5. Proses Response dan Update Status
            $status = $result->latestTransactionStatus;
            $message = '';

            switch ($status) {
                case '00':
                    $order->update_status('processing', 'Pembayaran QRIS berhasil.');
                    $message = 'Pembayaran berhasil diverifikasi';
                    break;
                case '03':
                    $order->update_status('pending', 'Menunggu pembayaran QRIS.');
                    $message = 'Menunggu pembayaran';
                    break;
                case '04':
                    $order->update_status('refunded', 'Pembayaran QRIS direfund.');
                    $message = 'Pembayaran telah direfund';
                    break;
                case '05':
                    $order->update_status('cancelled', 'Pembayaran QRIS dibatalkan.');
                    $message = 'Pembayaran dibatalkan';
                    break;
                case '06':
                    $order->update_status('failed', 'Pembayaran QRIS gagal.');
                    $message = 'Pembayaran gagal';
                    break;
                default:
                    $message = 'Status tidak dikenal';
            }
            } else {
              nicepay_log("(Direct V2) ", 'info', 'qris');
            }
            // 6. Kirim Response ke Frontend
            wp_send_json_success(array(
                'transactionStatus' => $status,
                'message' => $message,
                'paidTime' => $result->paidTime ?? null,
                'amount' => $result->amount ?? null,
                'additionalInfo' => $result->additionalInfo ?? null
            ));
        } catch (Exception $e) {
            nicepay_log("Error: " . $e->getMessage(), 'error', 'qris');
            wp_send_json_error(array('message' => $e->getMessage()));
        }
        wp_die();
    }

    private function check_payment_status_directv2($order_id,$decoded_post)
    {
        nicepay_log('Starting check_payment_status for order ' . $order_id, 'info', 'qris');

        $order = wc_get_order($order_id);

        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $tXid = $decoded_post['tXid'];
        $referenceNo = $decoded_post['referenceNo'];
        $amount = $decoded_post['amt'];
        $merchantKey = $this->get_option('merchant_key');

        nicepay_log($iMid . $tXid . $referenceNo . $amount);

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("QRIS Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'qris');
        nicepay_log("QRIS Request Body: " . json_encode($requestBody), 'info', 'qris');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            throw new Exception("HTTP Request failed: " . $response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("QRIS Response: " . json_encode($response_body), 'info', 'qris');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            throw new Exception(sprintf(__('Failed to create QRIS transaction: %s', 'nicepay-wc'), $response_body['resultMsg'] ?? 'Unknown error'));
        }

        if($response_body['status'] == '0') {
            // Save metadata from callback
            //$order->payment_complete();
            $order->update_status('processing', 'Pembayaran QRIS berhasil.');
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency']);
            $order->update_meta_data('_nicepay_transaction_datetime', $response_body['transDt'] . $response_body['transTm']);
            $order->save();

            nicepay_log('Order meta updated for order ' . $order_id, 'info', 'qris');
        }
        return $response_body;
    }

}