<?php
if (!defined('ABSPATH')) exit;
class WC_Gateway_Nicepay_Payloan extends WC_Payment_Gateway {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;

    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_payloan';
        $this->method_title       = __('NICEPAY Payloan', 'nicepay-wc');
        $this->has_fields         = false;
        $this->icon               = apply_filters('woocommerce_nicepay_payloan_icon','');
        $this->method_description = __('Allows payments using NICEPAY Payloan like akulaku, indodana, and kredivo.', 'nicepay-wc');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        
        $this->api_endpoints = $this->get_api_endpoints();

        if (get_option('nicepay_checkout_mode') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_ajax_set_nicepay_payloan_mitra', array($this, 'set_nicepay_payloan_mitra'));
        add_action('wp_ajax_nopriv_set_nicepay_payloan_mitra', array($this, 'set_nicepay_payloan_mitra'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_payloan', array($this, 'handle_callback'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'handle_return_url'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-payloan-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-payloan-header {
                margin-bottom: 15px;
                text-align: center;
                padding: 10px 0;
            }
            .nicepay-payloan-icon {
                max-height: 150px;
                width: auto;
                display: inline-block;
                margin: 10px 0;
            }
            .nicepay-payloan-select {
                margin: 10px 0;
            }
            .nicepay-payloan-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-payloan-logos {
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 15px; /* Spacing antar logo */
                margin-bottom: 20px;
            }
            .nicepay-payloan-logos img {
                height: 30px; /* Ukuran untuk logo individu */
                width: auto;
            }
            .nicepay-payloan-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-payloan-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/payloan-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-classic-checkout',
            'nicepayData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'enabled_mitra' => $this->get_payloan_options(),
                'nonce' => wp_create_nonce('nicepay-payloan-nonce')
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');
        $this->init_form_fields();
        $this->init_settings();
    
        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-payloan-style',
            NICEPAY_PLUGIN_URL . '/assets/css/payloan.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-payloan-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-payloan-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/payloan-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-payloan-blocks-integration',
            'nicepaypayloanData',
            array(
                'enabled_mitra' => $this->get_payloan_options(),
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('nicepay-payloan-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'ispayloan' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        
        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/debit/payment-host-to-host',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/debit/status',
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'paymentDirectV2'       => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPAY Payloan Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-wc'),
                'default'     => __('NICEPAY Payloan', 'nicepay-wc'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-wc'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-wc'),
                'default'     => __('Pay with payloan via NICEPAY (akulaku, indodana, kredivo)', 'nicepay-wc'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-wc'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPAY</small>.', 'nicepay-wc'),
                'default' => 'IONPAYTEST',
            ),
            // 'CHANNEL-ID' => array(
            //     'title' => __('Channel ID', 'nicepay-wc'),
            //     'type' => 'text',
            //     'description' => __('<small>Isikan dengan Channel ID dari NICEPAY</small>.', 'nicepay-wc'),
            //     'default' => '',
            // ),
            // 'client_secret' => array(
            //     'title'       => __('Client Key', 'nicepay-wc'),
            //     'type'        => 'text',
            //     'description' => __('Enter your NICEPAY Client Key.', 'nicepay-wc'),
            //     //'default'     => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-wc'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            // 'private_key' => array(
            //     'title'       => __('Private Key', 'nicepay-wc'),
            //     'type'        => 'textarea',
            //     'description' => __('Enter your NICEPAY Private Key.', 'nicepay-wc'),
            //     //'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'mitra_options' => array(
                'title'       => __('payloan Options', 'nicepay-wc'),
                'type'        => 'title',
                'description' => __('Select which payloans you want to enable.', 'nicepay-wc'),
            ),
            'enable_akulaku' => array(
                'title'   => __('Akulaku', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable Akulaku Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'enable_indodana' => array(
                'title'   => __('Indodana', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable Indodana Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'enable_kredivo' => array(
                'title'   => __('Kredivo', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable Kredivo Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
        );
    }

    /**
     * Get available payloan options
     */
    public function get_payloan_options() {
        $available_options = array();

        if ($this->get_option('enable_akulaku') === 'yes') {
            $available_options[] = array('value' => 'AKLP', 'label' => 'akulaku');
        }
        if ($this->get_option('enable_indodana') === 'yes') {
            $available_options[] = array('value' => 'IDNA', 'label' => 'indodana');
        }
        if ($this->get_option('enable_kredivo') === 'yes') {
            $available_options[] = array('value' => 'KDVI', 'label' => 'kredivo');
        }
        return $available_options;
    }

    /**
     * Handle the Ajax request to set the selected mitra
     */
    public function set_nicepay_payloan_mitra() {
        check_ajax_referer('nicepay-payloan-nonce', 'nonce');
        
        if (!isset($_POST['mitra_code'])) {
            wp_send_json_error('Mitra not specified');
        }

        $mitra = sanitize_text_field($_POST['mitra_code']);
        WC()->session->set('nicepay_selected_payloan_mitra', $mitra);
        
        wp_send_json_success('Mitra selection saved');
    }

    public function is_available() {
        $is_available = ('yes' === $this->enabled);
        if ('yes' !== $this->enabled) {
            return false;
        }

        if ($is_available) {
            $available_mitra = $this->get_payloan_options();
            if (empty($available_mitra)) {
                return false;
            }
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment payloan for order $order_id", 'info', 'payloan');

        $checkout_mode = get_option('nicepay_checkout_mode');
        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }

    /**
     * Process payment for classic checkout
     */
    public function process_classic_payment($order_id) {
        nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'payloan');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'payloan');
        $order->save();

        $selected_mitra = sanitize_text_field($_POST['nicepay_mitra'] ?? '');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an payloan payment method.', 'nicepay-wc'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        WC()->session->set('nicepay_selected_payloan_mitra', $selected_mitra);

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            nicepay_log("(SNAP) payloan registration start for order " . $order_id, 'info', 'payloan');
        } else {
            try {
                $payloanRegis_data = $this->process_directV2($order_id);

                if (!isset($payloanRegis_data['resultCd']) || $payloanRegis_data['resultCd'] !== '0000') {
                    throw new Exception(__('Failed to create payloan transaction: ', 'nicepay-wc') . ($payloanRegis_data['resultMsg'] ?? 'Unknown error'));
                }
                
                $paymentUrl = $this->process_paymentV2($order_id, $payloanRegis_data);

                return [
                    'result'   => 'success',
                    'redirect' => $paymentUrl,
                ];

                WC()->cart->empty_cart();
                throw new Exception(sprintf(
                    __('Payment gateway error: %s', 'nicepay-wc'),
                    $payloanRegis_data['responseMessage'] ?? 'Unknown error'
                ));
            } catch (Exception $e) {
                wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'va');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order $order_id", 'info', 'payloan');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'payloan');
        $order->save();

        $selected_mitra = WC()->session->get('nicepay_selected_payloan_mitra');
        nicepay_log("Selected mitra from session: " . $selected_mitra, 'info', 'payloan');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an payloan payment method.', 'nicepay-wc'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            nicepay_log("(SNAP) payloan registration startfor order " . $order_id, 'info', 'payloan');
        } else {
            try {
                $payloanRegis_data = $this->process_directV2($order_id);
                $order->update_status('processing', 'Pembayaran Payloan berhasil');
                if (!isset($payloanRegis_data['resultCd']) || $payloanRegis_data['resultCd'] !== '0000') {
                    throw new Exception(__('Failed to create payloan transaction: ', 'nicepay-wc') . ($payloanRegis_data['resultMsg'] ?? 'Unknown error'));
                }
               
                $paymentUrl = $this->process_paymentV2($order_id, $payloanRegis_data);

                WC()->cart->empty_cart();

                return [
                    'result'   => 'success',
                    'redirect' => $paymentUrl,
                ];

                throw new Exception(sprintf(
                    __('Payment gateway error: %s', 'nicepay-wc'),
                    $payloanRegis_data['responseMessage'] ?? 'Unknown error'
                ));
            } catch (Exception $e) {
                wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'va');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'payloan');

        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $reqDt = date('Ymd');
            $reqTm = date('His');

            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int) $order->get_total();
            // $amount = 100000;
            $referenceNo = $order->get_id() . "-" . $timestamp;
            $mitraCd = WC()->session->get('nicepay_selected_payloan_mitra', '');

            if (empty($mitraCd)) {
                throw new Exception(__('No payloan selected. Please choose a payloan payment method.', 'nicepay-wc'));
            }

            // Generate merchant token
            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);
            $cart_data = $this->prepare_cart_data($order);
            $sellers_data = [[
                "sellersId" => "STORE",
                "sellersNm" => "STORESHOP",
                "sellersUrl" => "http://nicestore.store/product/beanie/",
                "sellersEmail" => "sellers@test.com",
                "sellersAddress" => [
                    "sellerNm" => "STORESHOP",
                    "sellerLastNm" => "STORESHOP",
                    "sellerAddr" => "Jln. Kasablanka Kav 88",
                    "sellerCity" => "Jakarta",
                    "sellerPostCd" => "14350",
                    "sellerPhone" => "082111111111",
                    "sellerCountry" => "ID"
                ]
            ]];

            // Request body lengkap
            $requestBody = [
                "timeStamp" => $timestamp,
                "iMid" => $iMid,
                "payMethod" => "06",
                "currency" => "IDR",
                "mitraCd" => $mitraCd,
                "amt" => (string) $amount,
                "referenceNo" => $referenceNo,
                "goodsNm" => $this->get_order_items_names($order),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $order->get_billing_phone(),
                // "billingPhone" => "081234567890",
                "billingEmail" => $order->get_billing_email(),
                "billingAddr" => $order->get_billing_address_1(),
                "billingCity" => $order->get_billing_city(),
                "billingState" => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "deliveryNm" => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
                "deliveryPhone" => $order->get_billing_phone(),
                // "deliveryPhone" => "081234567890",
                "deliveryAddr" => $order->get_shipping_address_1() ?: $order->get_billing_address_1(),
                "deliveryCity" => $order->get_shipping_city() ?: $order->get_billing_city(),
                "deliveryState" => $order->get_shipping_state() ?: $order->get_billing_state(),
                "deliveryPostCd" => $order->get_shipping_postcode() ?: $order->get_billing_postcode(),
                "deliveryCountry" => $order->get_shipping_country() ?: $order->get_billing_country(),
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_payloan'),
                "vat" => "",
                "fee" => "",
                "notaxAmt" => "",
                "description" => "Testing API payloan - " . get_bloginfo('name'),
                "merchantToken" => $merchantToken,
                "reqDt" => $reqDt,
                "reqTm" => $reqTm,
                "reqDomain" => $_SERVER['HTTP_HOST'],
                "reqServerIP" => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
                "reqClientVer" => "",
                "userIP" => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "userSessionID" => session_id(),
                "userAgent" => $_SERVER['HTTP_USER_AGENT'] ?? '',
                "userLanguage" => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
                "cartData" => $cart_data,
                "sellers" => json_encode($sellers_data, JSON_UNESCAPED_SLASHES),
                "instmntType" => "1",
                "instmntMon" => "1",
                "recurrOpt" => "0",
                "bankCd" => "",
                "vacctValidDt" => "",
                "vacctValidTm" => "",
                "merFixAcctId" => "",
                "payValidDt" => date('Ymd', strtotime('+1 day')),
                "payValidTm" => "235959"
            ];

            $args = [
                'method' => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("Payloan Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'payloan');
            nicepay_log("Payloan Request Body: " . json_encode($requestBody, JSON_UNESCAPED_SLASHES), 'info', 'payloan');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("Payloan Response: " . json_encode($response_body), 'info', 'payloan');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create payloan transaction: ', 'nicepay-wc') . ($response_body['resultMsg'] ?? 'Unknown error'));
            }

            $order->add_order_note(sprintf(
                __('NICEPay Payloan. Details:
                Reference Number : %s
                Transaction ID: %s
                Transaction Amount: %s', 'nicepay-wc'),
                $response_body['referenceNo'],
                $response_body['tXid'],
                $response_body['amt']
            ));

             // Save important meta
            $order->update_meta_data('_nicepay_tXid', $response_body['tXid'] ?? '');
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo'] ?? '');
            $order->save();
            
            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'payloan');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }

        return $response_body;
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => "http://merchant.com/cellphones/iphone5s_64g",
                //get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => "http://merchant.com/cellphones/iphone5s_64g",
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => "http://merchant.com/cellphones/iphone5s_64g",
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    public function process_paymentV2($order_id, $response_regis) {
        nicepay_log("Starting process_paymentV2", 'info', 'payloan');
        try {
            $order = wc_get_order($order_id);
            $timestamp     = date('YmdHis');
            $iMid          = $this->get_option('X-CLIENT-KEY');
            $merchantKey   = $this->get_option('merchant_key');
            $amount        = (int) $order->get_total();
            $referenceNo   = $response_regis['referenceNo'];

            if($response_regis['mitraCd'] === 'IDNA'){
                $callBackUrl = home_url('/wc-api/wc_gateway_nicepay_payloan');
            } else {
                $callBackUrl = $this->get_return_url($order);
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            $paymentUrl = $this->api_endpoints['paymentDirectV2'] . '?' . http_build_query([
                'timeStamp'     => $timestamp,
                'tXid'          => $response_regis['tXid'],
                'merchantToken' => $merchantToken,
                'callBackUrl'   => $callBackUrl,
            ]);

            nicepay_log("Redirecting user to: " . $paymentUrl, 'info', 'payloan');

            return $paymentUrl;
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'payloan');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_callback() {
        nicepay_log('NICEPay callback received. Starting processing...', 'info', 'payloan');
        status_header(200);

        // Ambil header request
        $headers = getallheaders();
        nicepay_log('Headers: ' . print_r($headers, true), 'info', 'payloan');

        // Contoh akses header tertentu
        $timestamp = $headers['X-TIMESTAMP'] ?? null;
        $client_key = $headers['X-CLIENT-KEY'] ?? null;
        $signature = $headers['X-SIGNATURE'] ?? null;

        $raw_post = file_get_contents('php://input');
        nicepay_log('Raw input: ' . $raw_post, 'info', 'payloan');

        $decoded_post = json_decode($raw_post, true);

        // Fallback parsing kalau bukan JSON (biasanya jarang terjadi)
        if (!$decoded_post) {
            parse_str($raw_post, $decoded_post);
        }
        if (empty($decoded_post)) {
            $decoded_post = $_POST;
        }

        nicepay_log('Processed callback data: ' . $decoded_post, 'info', 'payloan');

        if (!empty($signature)) {
            nicepay_log('(SNAP) Attempting to find order with ID: ' . $decoded_post['referenceNo'], 'info', 'payloan');
        } else if (!empty($decoded_post['merchantToken'])){
            nicepay_log('(Direct V2) Attempting to find order with ID: ' . $decoded_post['referenceNo'], 'info', 'payloan');

            if (!empty($decoded_post['referenceNo'])) {
                $referenceNo = trim($decoded_post['referenceNo']);
                $parts = explode('-', $referenceNo);
                $order_id = $parts[0];
                $order = wc_get_order($order_id);

                if ($order) { 
                    $this->check_payment_status_directv2($order_id,$decoded_post);

                    wp_send_json(array('status' => 'received'), 200);
                    exit;
                } else {
                    nicepay_log('Order not found for paymentRequestId: ' . $order_id, 'error', 'payloan');
                    wp_send_json_error('Order not found', 404);
                }
            }
        } else {
            nicepay_log("Handle Callback from Mitra Page", 'info', 'payloan');

            if (!empty($decoded_post['referenceNo'])) {
                $referenceNo = trim($decoded_post['referenceNo']);
                $parts = explode('-', $referenceNo);
                $order_id = $parts[0];
                $order = wc_get_order($order_id);

                if ($order) {

                    if (!empty($decoded_post['resultCd']) && $decoded_post['resultCd'] === '0000') {
                        //$order->payment_complete();
                        $order->update_status('processing', 'Pembayaran Payloan berhasil.');
                    } else {
                        $order->update_status('failed', 'Payment failed via Payloan callback');
                    }

                    // 🚀 Langsung redirect ke order-received page
                    $redirect_url = $this->get_return_url($order);
                    nicepay_log("(Payloan) Redirecting to: " . $redirect_url, 'info', 'payloan');

                    wp_safe_redirect($redirect_url);
                    exit;
                }
            }

            status_header(200);
            exit;
        }
    }

    /**
    * Check payment status with NICEPAY
    */
    private function check_payment_status_directv2($order_id, $decoded_post) {
        nicepay_log("(Direct V2) Starting check_payment_status_directv2 for reference_no: " . $decoded_post['referenceNo'] , 'info', 'payloan');
        
        $order = wc_get_order($order_id);

        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $tXid = $decoded_post['tXid'];
        $referenceNo = $decoded_post['referenceNo'];
        $amount = $decoded_post['amt'];
        $merchantKey = $this->get_option('merchant_key');

        nicepay_log($iMid . $tXid . $referenceNo . $amount);

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("Payloan Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'payloan');
        nicepay_log("Payloan Request Body: " . json_encode($requestBody), 'info', 'payloan');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            throw new Exception("HTTP Request failed: " . $response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("Payloan Response: " . json_encode($response_body), 'info', 'payloan');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            throw new Exception(__('Failed to create Payloan transaction: ', 'nicepay-wc') . ($response_body['resultMsg'] ?? 'Unknown error'));
        }

        if($response_body['status'] == '0') {
            // Save metadata from callback
            //$order->payment_complete();
           $order->update_status('processing', 'Pembayaran Payloan berhasil.');
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency']);
            $order->update_meta_data('_nicepay_transaction_datetime', $response_body['transDt'] . $response_body['transTm']);
            $order->save();

            nicepay_log('Order meta updated for order ' . $order_id, 'info', 'payloan');
        }
    }

    /**
     * Handle return URL after payment
     */
    public function handle_return_url($order_id) {
        nicepay_log("Payloan handle_return_url: " . $order_id, 'info', 'payloan');
        $order = wc_get_order($order_id);

        if (!$order) {
            nicepay_log("(Payloan) Order not found for key", 'error', 'payloan');
            wp_die('Invalid order.');
        }
    }
}