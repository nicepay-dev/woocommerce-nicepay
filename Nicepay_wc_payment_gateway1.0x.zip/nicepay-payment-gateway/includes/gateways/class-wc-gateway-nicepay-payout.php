<?php
if (!defined('ABSPATH')) exit;

class WC_Gateway_Nicepay_Payout extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'nicepay_payout';
        $this->method_title       = __('NICEPay Payout', 'nicepay-payout-gateway');
        $this->has_fields         = false;
        $this->method_description = __('NICEPay Payout Registration.', 'nicepay-payout-gateway');

        $this->supports = [
            'products',
            'refunds',
        ];

        $this->init_form_fields();
        $this->init_settings();

        $this->enabled      = $this->get_option('enabled');
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment  = $this->get_option('environment', 'sandbox');
        $this->iMid         = $this->get_option('iMid');
        $this->XCLIENTKEY   = $this->get_option('X-CLIENT-KEY');
        $this->mKey         = $this->get_option('mKey');
        $this->privateKey   = $this->get_option('privateKey');
        $this->SecretClient = $this->get_option('SecretClient');
        $this->reduceStock  = $this->get_option('reduceStock');
        $this->shopId       = $this->get_option('shopId');
        $this->api_endpoints = $this->get_api_endpoints();

        if ($this->get_option('enable_blocks') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_ajax_set_nicepay_payout_bank', array($this, 'set_nicepay_payout_bank'));
        add_action('wp_ajax_nopriv_set_nicepay_payout_bank', array($this, 'set_nicepay_payout_bank'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPay Payment', 'woocommerce'),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
                'default'     => __('NICEPay', 'woocommerce'),
                'desc_tip'    => true,
            ),
            'enable_blocks' => array(
                'title'       => __('Checkout Mode', 'woocommerce'),
                'type'        => 'select',
                'description' => __('Select checkout mode. Block checkout is for modern WooCommerce checkout, while Classic is for traditional checkout.', 'woocommerce'),
                'default'     => 'blocks',
                'options'     => array(
                    'classic' => __('Classic Checkout (Non-Blocks)', 'woocommerce'),
                    'blocks'  => __('Block Checkout', 'woocommerce')
                )
            ),
            'description' => array(
                'title'       => __('Description', 'woocommerce'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'woocommerce'),
                'default'     => __('Pay with NICEPay', 'woocommerce'),
                'desc_tip'    => true,
            ),
            'environment' => array(
                'title'       => __('Environment', 'woocommerce'),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('Select the NICEPay environment.', 'woocommerce'),
                'default'     => 'sandbox',
                'options'     => array(
                    'sandbox'    => __('Sandbox / Development', 'woocommerce'),
                    'production' => __('Production', 'woocommerce'),
                ),
            ),
            'X-CLIENT-KEY' => array(
                    'title' => __('Merchant ID / Client ID', 'woocommerce'),
                    'type' => 'text',
                    'description' => __('<small>Isikan dengan Merchant ID dari NICEPay</small>.', 'woocommerce'),
                    'default' => 'TNICEPO071',
                ),
            'client_secret' => array(
                'title'       => __('Client Secret Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Client Key.', 'woocommerce'),
                'default'     => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
                'desc_tip'    => true,
            ),
            'Channel_ID' => array(
                'title'       => __('Channel ID', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Channel ID.', 'woocommerce'),
                'default'     => '30628',
                'desc_tip'    => true,
            ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Merchant Key.', 'woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            'private_key' => array(
                'title'       => __('Private Key', 'woocommerce'),
                'type'        => 'textarea',
                'description' => __('Enter your NICEPay Private Key.', 'woocommerce'),
                'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
                'desc_tip'    => true,
            ),
            'active_banks' => array(
                'title'       => __('Active Banks', 'woocommerce'),
                'type'        => 'multiselect',
                'description' => __('Select which banks should be available at checkout. Leave empty to show all banks.', 'woocommerce'),
                'default'     => array(),
                'options'     => $this->get_bank_options(),
                'css'         => 'height: 200px;', 
                'class'       => 'wc-enhanced-select',
            ),
            'debug' => array(
                'title'       => __('Debug Mode', 'woocommerce'),
                'type'        => 'checkbox',
                'label'       => __('Enable debug logging', 'woocommerce'),
                'default'     => 'yes',
                'description' => __('Log NICEPay API interactions for debugging purposes. Logs will be stored in the NICEPay Logs page.', 'woocommerce'),
                'desc_tip'    => true,
                'custom_attributes' => array(
                'data-debug-toggle' => 'true'
                )
            ),
        );
    }

    private function get_api_endpoints() {
        $base_url = $this->environment === 'production' 
            ? 'https://www.nicepay.co.id'
            : 'https://dev.nicepay.co.id';

        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/transfer/registration',
        ];
    }

    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-payout-style',
            NICEPAY_PLUGIN_URL . 'assets/css/payout.css'
        );

        // Inline CSS untuk quick styling
        $inline_css = "
            .nicepay-payout-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-payout-bank-select {
                margin: 10px 0;
            }
            .nicepay-payout-bank-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-payout-bank-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .nicepay-payout-instruction {
                margin-top: 10px;
                font-size: 0.9em;
                color: #666;
            }
        ";
        wp_add_inline_style('nicepay-payout-style', $inline_css);

        // Enqueue JS
        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-payout-classic-checkout',
                NICEPAY_PLUGIN_URL . 'assets/js/payout-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }


        $active_banks   = $this->get_active_bank_list();
        $selected_bank  = WC()->session->get('nicepay_selected_bank', '');

        wp_localize_script(
            'nicepay-payout-classic-checkout',
            'nicepayPayoutBlocksData',
            array(
                'ajax_url'       => admin_url('admin-ajax.php'),
                'pluginUrl'      => NICEPAY_PLUGIN_URL,
                'banks'          => $active_banks,
                'selected_bank'  => $selected_bank,
                'nonce'          => wp_create_nonce('nicepay-bank-payout-selection')
            )
        );
    }

    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        add_action('wp_loaded', function() {
            if ( ! WC()->session ) {
                WC()->initialize_session();
            }
        });

        wp_enqueue_style(
            'nicepay-payout-style',
            NICEPAY_PLUGIN_URL . '/assets/css/payout.css'
        );

        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-payout-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/payout-block-integration.js',
                ['wc-blocks-registry', 'wp-element', 'jquery'],
                '1.0.0',
                time(),
                true
            );
        }

        $active_banks = $this->get_active_bank_list();

        wp_localize_script(
            'nicepay-payout-blocks-integration',
            'nicepayPayoutBlocksData',
            array(
                'ajax_url'  => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'banks'     => $active_banks,
                'isVA'      => true,
                'nonce'     => wp_create_nonce('nicepay-bank-payout-selection')
            )
        );
    }

    private function get_bank_options() {
        $banks = $this->get_bank_list();
        $options = array();
        
        foreach ($banks as $bank) {
            $options[$bank['code']] = $bank['name'];
        }
        
        return $options;
    }

    public function is_available() {
        if ('yes' !== $this->enabled) {
            return false;
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    
    public function get_active_bank_list() {
        $all_banks = $this->get_bank_list();
        $active_bank_codes = $this->get_option('active_banks', array());
    
        // Jika tidak ada bank yang dipilih, tampilkan semua bank
        if (empty($active_bank_codes)) {
            return $all_banks;
        }
        
        // Filter hanya bank yang aktif
        $active_banks = array();
        foreach ($all_banks as $bank) {
            if (in_array($bank['code'], $active_bank_codes)) {
                $active_banks[] = $bank;
            }
        }
        
        return $active_banks;
    }

    public function get_bank_list() {
        return [
            ['code' => 'BMRI', 'name' => 'Bank Mandiri'],
            ['code' => 'BNIN', 'name' => 'Bank BNI'],
            ['code' => 'BRIN', 'name' => 'Bank BRI'],
            ['code' => 'BBBA', 'name' => 'Bank Permata'],
            ['code' => 'CENA', 'name' => 'Bank BCA'],
            ['code' => 'IBBK', 'name' => 'Maybank'],
            ['code' => 'BBBB', 'name' => 'Bank Permata Syariah'],
            ['code' => 'HNBN', 'name' => 'Bank KEB Hana Indonesia'],
            ['code' => 'BNIA', 'name' => 'Bank CIMB'],
            ['code' => 'BDIN', 'name' => 'Bank Bank Danamon'],
            ['code' => 'PDJB', 'name' => 'Bank BJB'],
            ['code' => 'YUDB', 'name' => 'Bank Neo Commerce (BNC)'],
            ['code' => 'BDKI', 'name' => 'Bank DKI']
        ];
    }

    public function process_admin_options() {
        $old_settings = $this->settings;
        
        $result = parent::process_admin_options();
        
        $this->init_settings();
        $new_settings = $this->settings;
    
        nicepay_log("NICEPay settings - Old debug: " . (isset($old_settings['debug']) ? $old_settings['debug'] : 'not set'), 'info', 'payout');
        nicepay_log("NICEPay settings - New debug: " . (isset($new_settings['debug']) ? $new_settings['debug'] : 'not set'), 'info', 'payout');
        
        return $result;
    }

    public function set_nicepay_payout_bank() {
        nicepay_log("set_nicepay_payout_bank", 'info', 'payout');

        // Cek nonce untuk keamanan
        if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'nicepay-bank-payout-selection')) {
            wp_send_json_error('Invalid security token');
            wp_die();
        }

        // Ambil bank_code dari request
        $bank_code = isset($_POST['bank_code']) ? sanitize_text_field($_POST['bank_code']) : '';

        if (empty($bank_code)) {
            wp_send_json_error('Bank code not provided');
            wp_die();
        }

        // Simpan ke WooCommerce session
        WC()->session->set('nicepay_payout_bank', $bank_code);

        // Beres
        wp_send_json_success([
            'message'   => 'Bank code saved',
            'bank_code' => $bank_code,
        ]);
        wp_die();
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return [
                'result'   => 'fail',
                'message'  => 'Order not found',
            ];
        }
        $order->update_meta_data('_nicepay_payment_method', 'payout');
        $order->save();

        $checkout_mode = $this->get_option('enable_blocks', 'blocks');
        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }

    private function process_classic_payment($order_id) {
        nicepay_log("Processing classic payment for order $order_id", 'info', 'payout');
        
        $order = wc_get_order($order_id);
        $selected_bank = WC()->session->get('nicepay_selected_bank');
        $selected_bank = isset($_POST['nicepay_bank']) ? 
        sanitize_text_field($_POST['nicepay_bank']) : 
        WC()->session->get('nicepay_selected_bank');
        
        nicepay_log("Selected bank from POST/session: " . ($selected_bank ?: 'Not set'), 'info', 'payout');
    
        if (!$selected_bank) {
            wc_add_notice(__('Please select a bank for payment', 'woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        WC()->session->set('nicepay_selected_bank', $selected_bank);
    
        try {
            $access_token = $this->get_access_token();
            $payout_data = $this->create_payout_request($order, $access_token, $selected_bank);
            
            if (isset($payout_data['originalReferenceNo'])) {
                $this->handle_payout_creation_response($order, $payout_data);
                WC()->cart->empty_cart();
    
                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                throw new Exception(__('Failed to create Virtual Account', 'woocommerce'));
            }
        } catch (Exception $e) {
            wc_add_notice(
                sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in process_classic_payment: " . $e->getMessage(), 'error', 'payout');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    private function process_blocks_payment($order_id) {
        nicepay_log("Processing blocks payment for order $order_id",'info','payout');
        
        $order = wc_get_order($order_id);
        $selected_bank = isset($_POST['nicepay_payout_bank']) ? 
        sanitize_text_field($_POST['nicepay_payout_bank']) : 
        WC()->session->get('nicepay_payout_bank');
        nicepay_log("Selected bank from session in process_blocks_payment: " . ($selected_bank ?: 'Not set'),'info','payout');
    
        if (!$selected_bank) {
            wc_add_notice(__('Please select a bank for payment', 'woocommerce'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    
        try {
            $access_token = $this->get_access_token();
            $payout_data = $this->create_payout_request($order, $access_token, $selected_bank);
            
            if (isset($payout_data['originalReferenceNo'])) {
                $this->handle_payout_creation_response($order, $payout_data);
                WC()->cart->empty_cart();
    
                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                throw new Exception(__('Failed to create Virtual Account', 'woocommerce'));
            }
        } catch (Exception $e) {
            wc_add_notice(
                sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(),'error','payout');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    private function get_access_token() {
        nicepay_log("Starting get_access_token process in " . $this->environment . " environment", 'info', 'payout');
    
        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $timestamp = $this->generate_formatted_timestamp();
        $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;
        
        $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
            $this->get_option('private_key') . "\r\n" .
            "-----END RSA PRIVATE KEY-----";
        
        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);
        
        if ($pKey === false) {
            nicepay_log("Failed to get private key: " . openssl_error_string(), 'error', 'payout');
            throw new Exception("Invalid private key");
        }
        
        $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        
        if ($sign_result === false) {
            nicepay_log("Failed to create signature: " . openssl_error_string(), 'error', 'payout');
            throw new Exception("Failed to create signature");
        }
        
        $signature = base64_encode($binary_signature);
        
        $jsonData = array(
            "grantType" => "client_credentials",
            "additionalInfo" => ""
        );
        
        $jsonDataEncode = json_encode($jsonData);
        
        $requestToken = $this->api_endpoints['access_token'];
        
        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SIGNATURE'  => $signature,
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP'  => $timestamp
            ),
            'body'    => $jsonDataEncode,
        );
        
        $response = wp_remote_post($requestToken, $args);
        
        if (is_wp_error($response)) {
            nicepay_log("Error in get_access_token: " . $response->get_error_message(), 'error', 'payout');
            throw new Exception($response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response));
        nicepay_log("Access token response: " . json_encode($body), 'info', 'payout');
        
        if (!isset($body->accessToken)) {
            nicepay_log("Invalid access token response: " . json_encode($body));
            throw new Exception(__('Invalid access token response', 'nicepay-vasnap-gateway'), 'error', 'payout');
        }
        
        nicepay_log("Successfully obtained access token", 'info', 'payout');
        WC()->session->set('accessToken', $body->responseCode);
        
        return $body->accessToken;
    }

    private function create_payout_request($order, $access_token, $selected_bank) {
        nicepay_log("Starting create_payout_request for order " . $order->get_id(), 'info', 'payout');
        
        if (!$selected_bank) {
            throw new Exception(__('Please select a bank for payout', 'woocommerce'));
        }

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $channel = $this->get_option('Channel_ID');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $timestamp = date('YmdHis');
        $external = $timestamp . rand(1000, 9999);

        $description = "WooCommerce NICEPay Payout";
        $partnerReferenceNo = "Refno" . $external;
        $original_phone = $order->get_billing_phone();
        $beneficiaryPhone = preg_replace('/^\+62/', '0', $original_phone);

        // Prepare amount
        $amount = [
            "value"    => number_format("100000", 2, '.', ''),
            "currency" => "IDR"
        ];

        // Prepare body sesuai spesifikasi payout
        // $body = [
        //     "merchantId" => $X_CLIENT_KEY,
        //     "msId" => "",
        //     "beneficiaryAccountNo" => "701075323",
        //     "beneficiaryName" => $order->get_billing_first_name(),
        //     "beneficiaryPhone" => $beneficiaryPhone,
        //     "beneficiaryCustomerResidence" => "1",
        //     "beneficiaryCustomerType" => "1",
        //     "beneficiaryPostalCode" => $order->get_billing_postcode(),
        //     "payoutMethod" => "1",
        //     "beneficiaryBankCode" => $selected_bank,
        //     "amount" => $amount,
        //     "partnerReferenceNo" => $partnerReferenceNo,
        //     "reservedDt" => "",
        //     "reservedTm" => "",
        //     "description" => $description
        // ];
        //         $totalAmount = [
        //     "value" => $this->amt,
        //     "currency" => "IDR"
        // ];     

        $body = [
            "merchantId" => $X_CLIENT_KEY,
            "msId" => "",
            "beneficiaryAccountNo" => "800152779200",
            "beneficiaryName" => "Laravel Test",
            "beneficiaryPhone" => "08123456789",
            "beneficiaryCustomerResidence" => "1",
            "beneficiaryCustomerType" => "1",
            "beneficiaryPostalCode" => "123456",
            "beneficiaryBankCode" => $selected_bank,
            "amount" => $amount,
            "partnerReferenceNo" => $partnerReferenceNo,
            "description" => "SNAP Payout from Laravel",
            "deliveryName" => "Laravel",
            "deliveryId" => "",
            "beneficiaryPOE" => "",
            "beneficiaryDOE" => "",
            "beneficiaryCoNo" => "",
            "beneficiaryAddress" => "",
            "beneficiaryAuthPhoneNumber" => "",
            "beneficiaryMerCategory" => "",
            "beneficiaryCoMgmtName" => "",
            "beneficiaryCoShName" => ""
        ];
        $jsonBody = json_encode($body);

        // Prepare headers
        $hashbody = strtolower(hash("SHA256", $jsonBody));
    
        $strigSign = "POST:/api/v1.0/transfer/registration:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
    
        $headers = [
            'Content-Type'   => 'application/json',
                'X-SIGNATURE'    => base64_encode($bodyHasing),
                'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                'X-TIMESTAMP'    => $X_TIMESTAMP,
                'Authorization'  => $access_token,
                'CHANNEL-ID'     => $channel,
                'X-EXTERNAL-ID'  => $external,
                'X-PARTNER-ID'   => $X_CLIENT_KEY
        ];
        $headerBody = json_encode($headers);

        // Buat args request
        $args = [
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => $headers,
            'body'    => $jsonBody,
        ];

        // Logging
        nicepay_log("url create_registration: " . $this->api_endpoints['registration'], 'info', 'payout');
        nicepay_log("Request headers for create_payout_request:" . $headerBody, 'info', 'payout');
        nicepay_log("Request body for create_payout_request: " . $jsonBody, 'info', 'payout');

        // Endpoint untuk transfer/registration
        $response = wp_remote_post($this->api_endpoints['registration'], $args);

        if (is_wp_error($response)) {
            nicepay_log("Error in payout request: " . $response->get_error_message(), 'error', 'payout');
            throw new Exception($response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("Payout response: " . json_encode($response_body), 'info', 'payout');

        // Validasi hasil
        if (!empty($response_body) && $response_body['responseCode'] === '2000000') {
            // Bisa update meta order kalau mau
            $order->update_meta_data('_nicepay_payout_reference', $partnerReferenceNo);
            $order->save();
        } else {
            throw new Exception(
                sprintf(
                    __('Failed to create Payout: %s', 'nicepay-payout-gateway'),
                    $response_body['responseMessage'] ?? __('Unknown error', 'nicepay-payout-gateway')
                )
            );
        }

        return $response_body;
    }
    
    private function handle_payout_creation_response($order, $data) {
        if (isset($data['responseCode']) && $data['responseCode'] === "2000000") {
            // Ambil data dari response
            $account_no   = $data['beneficiaryaccountNo'];
            $account_name = $data['beneficiaryName'];
            $bank_code    = $data['beneficiaryBankCode'];
            $amount_value = $data['amount']['value'];
            $currency     = $data['amount']['currency'];
            $partner_ref  = $data['partnerReferenceNo'];
            $original_ref = $data['originalReferenceNo'];

            // Buat status note untuk admin
            $status_note = sprintf(
                __('Payout created. Beneficiary: %s (%s) Bank: %s Amount: %s %s', 'nicepay-vasnap-gateway'),
                $account_name,
                $account_no,
                $bank_code,
                $amount_value,
                $currency
            );

            $order->update_status('on-hold', $status_note);

            // Tambah order note detail
            $order->add_order_note(sprintf(
                __('NICEPay Payout Details:
                Beneficiary Name: %s
                Account No: %s
                Bank Code: %s
                Amount: %s %s
                Partner Reference No: %s
                Original Reference No: %s', 'nicepay-vasnap-gateway'),
                $account_name,
                $account_no,
                $bank_code,
                $amount_value,
                $currency,
                $partner_ref,
                $original_ref
            ));

            // Simpan meta data
            $order->update_meta_data('_nicepay_beneficiary_account_no', $account_no);
            $order->update_meta_data('_nicepay_beneficiary_name', $account_name);
            $order->update_meta_data('_nicepay_bank_code', $bank_code);
            $order->update_meta_data('_nicepay_payout_amount', $amount_value);
            $order->update_meta_data('_nicepay_currency', $currency);
            $order->update_meta_data('_nicepay_partner_reference_no', $partner_ref);
            $order->update_meta_data('_nicepay_original_reference_no', $original_ref);

            $order->save();

            // Kosongkan cart kalau mau
            WC()->cart->empty_cart();

        } else {
            throw new Exception(__('Failed to create payout', 'nicepay-vasnap-gateway'));
        }
    }

    public function get_bank_name($bank_code) {
        $banks = $this->get_bank_list();
        foreach ($banks as $bank) {
            if ($bank['code'] === $bank_code) {
                return $bank['name'];
            }
        }
        return $bank_code;
    }

    private function generate_formatted_timestamp() {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    public function thankyou_page($order_id) {
        echo '<p>' . __('Thank you for your order. Your payout request is being processed.', 'nicepay-payout-gateway') . '</p>';
    }
}