<?php
if (!defined('ABSPATH')) exit;
class WC_Gateway_Nicepay_Ewallet extends WC_Payment_Gateway {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;

    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_ewallet';
        $this->method_title       = __('NICEPAY E-wallet', 'nicepay-wc');
        $this->has_fields         = false;
        $this->icon               = apply_filters('woocommerce_nicepay_ewallet_icon','');
        $this->method_description = __('Allows payments using NICEPAY E-wallet like OVO, DANA, LinkAja, and ShopeePay.', 'nicepay-wc');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        //$this->register_scheduled_hooks();
        
        $this->api_endpoints = $this->get_api_endpoints();

        if (get_option('nicepay_checkout_mode') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_ajax_set_nicepay_mitra', array($this, 'set_nicepay_mitra'));
        add_action('wp_ajax_nopriv_set_nicepay_mitra', array($this, 'set_nicepay_mitra'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_ewallet', array($this, 'handle_callback'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'handle_return_url'));
        add_action('woocommerce_api_nicepay_linkaja_process', array($this, 'process_linkaja_payment'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-ewallet-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-ewallet-header {
                margin-bottom: 15px;
                text-align: center;
                padding: 10px 0;
            }
            .nicepay-ewallet-icon {
                max-height: 150px;
                width: auto;
                display: inline-block;
                margin: 10px 0;
            }
            .nicepay-ewallet-select {
                margin: 10px 0;
            }
            .nicepay-ewallet-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-ewallet-logos {
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 15px; /* Spacing antar logo */
                margin-bottom: 20px;
            }
            .nicepay-ewallet-logos img {
                height: 30px; /* Ukuran untuk logo individu */
                width: auto;
            }
            .nicepay-ewallet-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/ewallet-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-classic-checkout',
            'nicepayData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'enabled_mitra' => $this->get_ewallet_options(),
                'nonce' => wp_create_nonce('nicepay-ewallet-nonce')
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');
        $this->init_form_fields();
        $this->init_settings();
    
        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-ewallet-style',
            NICEPAY_PLUGIN_URL . '/assets/css/ewallet.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-ewallet-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-ewallet-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/ewallet-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-ewallet-blocks-integration',
            'nicepayEwalletData',
            array(
                'enabled_mitra' => $this->get_ewallet_options(),
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('nicepay-ewallet-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'isEwallet' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        
        return [
            'access_token'     => $base_url . '/nicepay/v1.0/access-token/b2b',
            'registration'     => $base_url . '/nicepay/api/v1.0/debit/payment-host-to-host',
            'check_status_url' => $base_url . '/nicepay/api/v1.0/debit/status',
            'registrationDirectV2'  => $base_url . '/nicepay/direct/v2/registration',
            'paymentDirectV2'       => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPAY E-wallet Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-wc'),
                'default'     => __('NICEPAY E-wallet', 'nicepay-wc'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-wc'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-wc'),
                'default'     => __('Pay with e-wallet via NICEPAY (OVO, DANA, LinkAja, ShopeePay)', 'nicepay-wc'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-wc'),
                'type' => 'text',
                'description' => '<small>' . __('Isikan dengan Merchant ID dari NICEPAY.', 'nicepay-wc') . '</small>',
                'default' => 'TNICEEW051',
            ),
            'CHANNEL-ID' => array(
                'title' => __('Channel ID', 'nicepay-wc'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Channel ID dari NICEPAY</small>.', 'nicepay-wc'),
                'default' => 'TNICEEW05101',
                //'default' => '',
            ),
            'client_secret' => array(
                'title'       => __('Client Key', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Client Key.', 'nicepay-wc'),
                //'default'     => '1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a',
                'default'     => '',
                'desc_tip'    => true,
            ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-wc'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            'private_key' => array(
                'title'       => __('Private Key', 'nicepay-wc'),
                'type'        => 'textarea',
                'description' => __('Enter your NICEPAY Private Key.', 'nicepay-wc'),
                //'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
                'default'     => '',
                'desc_tip'    => true,
            ),
            'mitra_options' => array(
                'title'       => __('E-wallet Options', 'nicepay-wc'),
                'type'        => 'title',
                'description' => __('Select which e-wallets you want to enable.', 'nicepay-wc'),
            ),
            'enable_ovo' => array(
                'title'   => __('OVO', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable OVO Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'enable_dana' => array(
                'title'   => __('DANA', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable DANA Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'enable_linkaja' => array(
                'title'   => __('LinkAja', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable LinkAja Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'enable_shopeepay' => array(
                'title'   => __('ShopeePay', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable ShopeePay Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
        );
    }

    /**
     * Get available e-wallet options
     */
    public function get_ewallet_options() {
        $available_options = array();

        if ($this->get_option('enable_ovo') === 'yes') {
            $available_options[] = array('value' => 'OVOE', 'label' => 'OVO');
        }
        if ($this->get_option('enable_dana') === 'yes') {
            $available_options[] = array('value' => 'DANA', 'label' => 'DANA');
        }
        if ($this->get_option('enable_linkaja') === 'yes') {
            $available_options[] = array('value' => 'LINK', 'label' => 'LINK AJA');
        }
        if ($this->get_option('enable_shopeepay') === 'yes') {
            $available_options[] = array('value' => 'ESHP', 'label' => 'ShopeePay');
        }
        return $available_options;
    }

    /**
     * Handle the Ajax request to set the selected mitra
     */
    public function set_nicepay_mitra() {
        check_ajax_referer('nicepay-ewallet-nonce', 'nonce');
        
        if (!isset($_POST['mitra_code'])) {
            wp_send_json_error('Mitra not specified');
        }

        $mitra = sanitize_text_field($_POST['mitra_code']);
        WC()->session->set('nicepay_selected_mitra', $mitra);
        
        wp_send_json_success('Mitra selection saved');
    }

    public function is_available() {
        $is_available = ('yes' === $this->enabled);
        if ('yes' !== $this->enabled) {
            return false;
        }

        if ($is_available) {
            $available_mitra = $this->get_ewallet_options();
            if (empty($available_mitra)) {
                return false;
            }
        }

        if (get_woocommerce_currency() !== 'IDR') {
            return false;
        }

        return true;
    }

    /**
     * Output payment fields
     */
    public function payment_fields() {
        if ($this->get_option('enable_blocks') === 'classic') {
            if ($this->description) {
                echo wpautop(wptexturize($this->description));
            }
            
            $selected_mitra = WC()->session->get('nicepay_selected_mitra');
            
            ?>
            <div class="nicepay-ewallet-container">
                <!-- Logo container -->
                <div class="nicepay-ewallet-header">
                    <div class="nicepay-ewallet-logos">
                        <img src="<?php echo NICEPAY_PLUGIN_URL; ?>/assets/images/ewallet-logo.png" 
                             alt="E-wallet Logo" 
                             class="nicepay-ewallet-icon">
                    </div>
                </div>
                
                <!-- Selector container -->
                <div class="nicepay-ewallet-select">
                    <label for="nicepay-ewallet-select">Pilih E-wallet:</label>
                    <select name="nicepay_mitra" id="nicepay-ewallet-select">
                        <option value="">Pilih E-wallet</option>
                        <?php foreach ($this->get_ewallet_options() as $mitra): ?>
                            <option value="<?php echo esc_attr($mitra['value']); ?>" 
                                    <?php selected($selected_mitra, $mitra['value']); ?>>
                                <?php echo esc_html($mitra['label']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
        }
    }

    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment Ewallet for order $order_id", 'info', 'ewallet');

        $checkout_mode = get_option('nicepay_checkout_mode');
        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }

    /**
     * Process payment for classic checkout
     */
    public function process_classic_payment($order_id) {
        nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'ewallet');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'ewallet');
        $order->save();

        $selected_mitra = sanitize_text_field($_POST['nicepay_mitra'] ?? '');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an e-wallet payment method.', 'nicepay-wc'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        WC()->session->set('nicepay_selected_mitra', $selected_mitra);
        // Empty cart
        WC()->cart->empty_cart();
    }

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order $order_id", 'info', 'ewallet');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'ewallet');
        $order->save();

        $selected_mitra = WC()->session->get('nicepay_selected_mitra');
        nicepay_log("Selected mitra from session: " . $selected_mitra, 'info', 'ewallet');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an e-wallet payment method.', 'nicepay-wc'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            try {
                $access_token = $this->get_access_token();
                $ewallet_data = $this->create_registration($order, $access_token);
                
                if (!isset($ewallet_data['responseCode'])) {
                    throw new Exception(__('Invalid response from payment gateway', 'nicepay-wc'));
                }
                nicepay_log("E-wallet registration response: " . $ewallet_data, 'info', 'ewallet');

                if ($ewallet_data['responseCode'] === '2005400' && $ewallet_data['responseMessage'] === 'Successful') {
                    
                    $order->add_order_note(sprintf(
                        __('NICEPay E-Wallet. Details:
                        Reference Number : %s
                        Transaction ID: %s', 'nicepay-wc'),
                        $ewallet_data['partnerReferenceNo'],
                        $ewallet_data['referenceNo']
                    ));

                    // Simpan data response ke order meta
                    $order->update_meta_data('_nicepay_tXid', $ewallet_data['referenceNo']);
                    $order->update_meta_data('_nicepay_reference_no', $ewallet_data['partnerReferenceNo']);
                    $order->update_meta_data('_nicepay_mitra', $selected_mitra);
                    $order->save();
                    
                    // Return success with redirect URL
                    if ($selected_mitra === 'OVOE') {
                        // Untuk OVO, check status setelah mendapat response sukses
                        nicepay_log("Checking payment status for OVO payment...", 'info', 'ewallet');
                        $status_response = $this->check_payment_status($order, $ewallet_data['partnerReferenceNo']);
                        nicepay_log("Status check response: " . $status_response, 'info', 'ewallet');

                        // Update order status berdasarkan response check status
                        $this->update_order_status($order, $status_response);

                        return array(
                            'result' => 'success',
                            'redirect' => $this->get_return_url($order)
                        );
                    } elseif ($selected_mitra === 'LINK' && isset($ewallet_data['additionalInfo']['redirectToken'])) {
                        nicepay_log("Processing LinkAja payment...", 'info', 'ewallet');
                        
                        // Ensure correct URL format
                        $redirectUrl = $ewallet_data['webRedirectUrl'] . "?Message=" . $ewallet_data['additionalInfo']['redirectToken'];
                        nicepay_log("LinkAja Redirect URL: " . $redirectUrl, 'info', 'ewallet');
                        
                        $order->update_status('pending', sprintf(
                            __('Menunggu pembayaran %s', 'nicepay-wc'),
                            $selected_mitra
                        ));

                        return array(
                            'result' => 'success',
                            'redirect' => $redirectUrl
                        );
                    } elseif (isset($ewallet_data['webRedirectUrl'])) {
                        // Untuk DANA, Shopee Pay
                        nicepay_log("E-wallet webRedirectUrl: " . $ewallet_data['webRedirectUrl'], 'info', 'ewallet');
                        $order->update_meta_data('_nicepay_redirect_url', $ewallet_data['webRedirectUrl']);
                        $order->update_status('pending', sprintf(
                            __('Menunggu pembayaran %s', 'nicepay-wc'),
                            $selected_mitra
                        ));
                        $order->save();

                        return array(
                            'result' => 'success',
                            'redirect' => $ewallet_data['webRedirectUrl']
                        );
                    }
                }
                
                WC()->cart->empty_cart();
                throw new Exception(sprintf(
                    __('Payment gateway error: %s', 'nicepay-wc'),
                    $ewallet_data['responseMessage'] ?? 'Unknown error'
                ));

            } catch (Exception $e) {
            wc_add_notice(
                sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                'error'
            );
                nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'ewallet');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        } else {
            try {
                $ewallet_data = $this->process_directV2($order_id);

                if (!isset($ewallet_data['resultCd']) || $ewallet_data['resultCd'] !== '0000') {
                    throw new Exception(sprintf(
                        __('Failed to create eWallet transaction: %s', 'nicepay-wc'),
                        $ewallet_data['resultMsg'] ?? 'Unknown error'
                    ));                
                }
                nicepay_log("(Direct V2) E-wallet registration response: " . json_encode($ewallet_data), 'info', 'ewallet');
                
                $paymentUrl = $this->process_paymentV2($order_id,$ewallet_data);
                WC()->cart->empty_cart();

                return [
                    'result'   => 'success',
                    'redirect' => $paymentUrl,
                ];
            } catch (Exception $e) {
                wc_add_notice(
                    sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'ewallet');
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    /**
     * Process LinkAja payment with redirect
     */
    public function process_linkaja_payment() {
        if (!isset($_GET['url']) || !isset($_GET['token'])) {
            wp_die('Invalid request');
        }

        $url = sanitize_text_field($_GET['url']);
        $token = sanitize_text_field($_GET['token']);

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Processing LinkAja Payment</title>
            <style>
                body { 
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding: 20px;
                    background: #f5f5f5;
                    margin: 0;
                }
                .container {
                    max-width: 500px;
                    margin: 40px auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                .spinner {
                    display: inline-block;
                    width: 50px;
                    height: 50px;
                    margin: 20px auto;
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid #ff0000;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                h2 {
                    color: #333;
                    margin-bottom: 20px;
                }
                p {
                    color: #666;
                    margin: 15px 0;
                }
                button {
                    background: #ff0000;
                    color: white;
                    border: none;
                    padding: 12px 25px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 16px;
                    margin-top: 20px;
                }
                button:hover {
                    background: #e60000;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Menghubungkan ke LinkAja</h2>
                <div class="spinner"></div>
                <p>Mohon tunggu, Anda akan diarahkan ke halaman pembayaran LinkAja...</p>
                <form id="linkaja_form" method="POST" action="<?php echo esc_url($url); ?>">
                    <input type="hidden" name="redirectToken" value="<?php echo esc_attr($token); ?>">
                </form>
                <script>
                    // Submit form setelah semua konten dimuat
                    window.onload = function() {
                        setTimeout(function() {
                            document.getElementById('linkaja_form').submit();
                        }, 1000);
                    };
                </script>
                <noscript>
                    <p>Jika Anda tidak dialihkan secara otomatis, silakan klik tombol di bawah ini:</p>
                    <button type="submit" form="linkaja_form">Lanjutkan ke LinkAja</button>
                </noscript>
            </div>
        </body>
        </html>
        <?php
        exit;
    }

    /**
     * Get access token from NICEPAY
     */
    private function get_access_token() {
        nicepay_log("Starting get_access_token process", 'info', 'ewallet');

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $timestamp = $this->generate_formatted_timestamp();
        $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;

        nicepay_log("X_CLIENT_KEY: " . $X_CLIENT_KEY, 'info', 'ewallet');
        nicepay_log("Timestamp: " . $timestamp, 'info', 'ewallet');
        nicepay_log("StringToSign: " . $stringToSign, 'info', 'ewallet');
        
        $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
            $this->get_option('private_key') . "\r\n" .
            "-----END RSA PRIVATE KEY-----";
        
        nicepay_log("Private Key Structure: " . substr($privatekey, 0, 100) . "...", 'info', 'ewallet');
        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);
        
        if ($pKey === false) {
            $error = openssl_error_string();
            nicepay_log("Failed to get private key. OpenSSL Error: " . $error, 'error', 'ewallet');
            throw new Exception("Invalid private key: " . $error);
        }
        
        $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        
        if ($sign_result === false) {
            $error = openssl_error_string();
            nicepay_log("Failed to create signature. OpenSSL Error: " . $error, 'error', 'ewallet');
            throw new Exception("Failed to create signature: " . $error);
        }
        
        $signature = base64_encode($binary_signature);
        nicepay_log("Generated Signature: " . $signature, 'info', 'ewallet');
        
        $jsonData = array(
            "grantType" => "client_credentials"
        );
        
        $jsonDataEncode = json_encode($jsonData);
        nicepay_log("Request Body JSON: " . $jsonDataEncode, 'info', 'ewallet');
        
        $requestToken = $this->api_endpoints['access_token'];
        nicepay_log("Request URL: " . $requestToken, 'info', 'ewallet');
        
        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SIGNATURE'  => $signature,
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP'  => $timestamp
            ),
            'body'    => $jsonDataEncode,
        );

        nicepay_log("url access_token: " . $this->api_endpoints['access_token'], 'info', 'ewallet');
        nicepay_log("Request headers for get_access_token: " . json_encode($args['headers']), 'info', 'ewallet');
        nicepay_log("Request body for get_access_token: " . json_encode($jsonDataEncode), 'info', 'ewallet');
        
        $response = wp_remote_post($requestToken, $args);
        
        if (is_wp_error($response)) {
            nicepay_log("Error in get_access_token: " . $response->get_error_message(), 'error', 'ewallet');
            throw new Exception($response->get_error_message());
        }
         
        $body = json_decode(wp_remote_retrieve_body($response));
        nicepay_log("Access token response: " . json_encode($body), 'info', 'ewallet');
        
        if (!isset($body->accessToken)) {
            nicepay_log("Invalid access token response: " . json_encode($body), 'info', 'ewallet');
            throw new Exception(__('Invalid access token response', 'nicepay-wc'));
        }
        
        nicepay_log("Successfully obtained access token", 'info', 'ewallet');
        WC()->session->set('accessToken', $body->accessToken);
        
        return $body->accessToken;
    }

    /**
     * Create payment registration with NICEPAY
     */
    private function create_registration($order, $access_token) {
        nicepay_log("Starting create_registration for order " . $order->get_id(), 'info', 'ewallet');

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $timestamp = date('YmdHis');
        $channel = $this->get_option('CHANNEL-ID');
        $external = $timestamp . rand(1000, 9999);
        $original_phone = $order->get_billing_phone();
        $beneficiaryPhone = preg_replace('/^\+62/', '0', $original_phone);
        $selected_mitra = WC()->session->get('nicepay_selected_mitra', '');

        nicepay_log("Selected mitra: " . $selected_mitra, 'info', 'ewallet');

        if (empty($selected_mitra)) {
            throw new Exception(__('No e-wallet selected. Please choose an e-wallet payment method.', 'nicepay-wc'));
        }

        $cart_data = $this->prepare_cart_data($order);
        $newBody = [
            "partnerReferenceNo" => $order->get_id() . "-" . $timestamp,
            "merchantId" => $X_CLIENT_KEY,
            "subMerchantId" => "",
            "externalStoreId" => "",
            "validUpTo" => date('Y-m-d\TH:i:s\Z', strtotime('+1 day')),
            "pointOfInitiation" => "MOBILE_APP",
            "amount" => [
                "value" => number_format($order->get_total(), 2, '.', ''),
                "currency" => $order->get_currency()
            ],
            "urlParam" => [
                [
                    "url" => home_url('/wc-api/wc_gateway_nicepay_ewallet'),
                    "type" => "PAY_NOTIFY",
                    "isDeeplink" => "Y" 
                ],
                [
                    "url" => $this->get_return_url($order),
                    "type" => "PAY_RETURN",
                    "isDeeplink" => "Y" 
                ]
            ],
            "additionalInfo" => [
                "mitraCd" => $selected_mitra,
                "goodsNm" => $this->get_order_items_names($order),
                "billingNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone" => $beneficiaryPhone,
                "customerEmail" => $order->get_billing_email(), 
                "cartData" => $cart_data, 
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_ewallet'),
                "callBackUrl" => $this->get_return_url($order),
                "msId" => ""
            ]
        ];
        nicepay_log("Request body structure: " . $newBody, 'info', 'ewallet');

        $stringBody = json_encode($newBody, JSON_UNESCAPED_SLASHES);;
        $hashbody = strtolower(hash("SHA256", $stringBody));

        $strigSign = "POST:/api/v1.0/debit/payment-host-to-host:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type'   => 'application/json',
                'X-SIGNATURE'    => base64_encode($bodyHasing),
                'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                'X-TIMESTAMP'    => $X_TIMESTAMP,
                'Authorization'  => "Bearer " . $access_token,
                'CHANNEL-ID'     => $channel,
                'X-EXTERNAL-ID'  => $external,
                'X-PARTNER-ID'   => $X_CLIENT_KEY
            ),
            'body'    => $stringBody,
        );
        $headerBodyEwallet = json_encode($args['headers']);

        nicepay_log("url create_registration: " . $this->api_endpoints['registration'], 'info', 'ewallet');
        nicepay_log("Request headers for create_registration: " . $headerBodyEwallet, 'info', 'ewallet');
        nicepay_log("Request body for create_registration: " . $stringBody, 'info', 'ewallet');

        $response = wp_remote_post($this->api_endpoints['registration'], $args);

        if (is_wp_error($response)) {
            nicepay_log("Error in create_registration: " . $response->get_error_message(), 'error', 'ewallet');
            throw new Exception($response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("Create registration response: " . json_encode($response_body), 'info', 'ewallet');

        if (!isset($response_body['responseCode']) || $response_body['responseCode'] !== '2005400') {
            throw new Exception(
                sprintf(
                    __('Failed to create registration: %s', 'nicepay-wc'),
                    $response_body['responseMessage'] ?? __('Unknown error', 'nicepay-wc')
                )
            );
        } 

        return $response_body;
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'img_url' => wp_get_attachment_url($product->get_image_id()) ?: wc_placeholder_img_src(),
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'img_url' => wp_get_attachment_url($product->get_image_id()) ?: wc_placeholder_img_src(),
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'img_url' => wp_get_attachment_url($product->get_image_id()) ?: wc_placeholder_img_src(),
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    /**
     * Get cart data
     */
    private function get_cart_data($order) {
        $cart_data = [
            "count" => $order->get_item_count(),
            "item" => []
        ];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $cart_data["item"][] = [
                "img_url" => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
                "goods_name" => $item->get_name(),
                "goods_detail" => $product->get_short_description(),
                "goods_amt" => number_format($order->get_item_total($item, true), 2, '.', ''),
                "goods_quantity" => $item->get_quantity()
            ];
        }

        return $cart_data;
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    /**
     * Check payment status with NICEPAY
     */
    private function check_payment_status($order, $reference_no) {
        nicepay_log("(SNAP) Starting check_payment_status for reference_no: " . $reference_no, 'info', 'ewallet');
        try {
            $access_token = $this->get_access_token();
            
            $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
            $secretClient = $this->get_option('client_secret');
            $X_TIMESTAMP = $this->generate_formatted_timestamp();
            $timestamp = date('YmdHis');
            $channel = $this->get_option('CHANNEL-ID');
            $external = $timestamp . rand(1000, 9999);
    
            $newBody = [
                "merchantId" => $X_CLIENT_KEY,
                "subMerchantId" => "",
                "originalPartnerReferenceNo" => $reference_no,
                "originalReferenceNo" => $order->get_meta('_nicepay_tXid'),
                "serviceCode" => "54",
                "transactionDate" => date('Y-m-d\TH:i:sP'), 
                "externalStoreId" => "",
                "amount" => [
                    "value" => number_format($order->get_total(), 2, '.', ''),
                    "currency" => $order->get_currency()
                ],
                "additionalInfo" => (object)[]
            ];
    
            $stringBody = json_encode($newBody, JSON_UNESCAPED_SLASHES);
            $hashbody = strtolower(hash("SHA256", $stringBody));
    
            $strigSign = "POST:/api/v1.0/debit/status:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
            $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
    
            $args = array(
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => array(
                    'Content-Type'   => 'application/json',
                    'X-SIGNATURE'    => base64_encode($bodyHasing),
                    'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                    'X-TIMESTAMP'    => $X_TIMESTAMP,
                    'Authorization'  => "Bearer " . $access_token,
                    'CHANNEL-ID'     => $channel,
                    'X-EXTERNAL-ID'  => $external,
                    'X-PARTNER-ID'   => $X_CLIENT_KEY
                ),
                'body'    => $stringBody,
            );
    
            nicepay_log("url check_payment_status: " . $this->api_endpoints['check_status_url'], 'info', 'ewallet');
            nicepay_log("Request headers for check_payment_status: " . json_encode($args['headers']), 'info', 'ewallet');
            nicepay_log("Request body for check_payment_status: " . $stringBody, 'info', 'ewallet');
            
            $response = wp_remote_post($this->api_endpoints['check_status_url'], $args);
    
            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }
    
            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            nicepay_log("Check status response: " . json_encode($response_body), 'info', 'ewallet');

            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(
                sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in check_payment_status: " . $e->getMessage(), 'info', 'ewallet');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }

    }

    /**
     * Update order status based on response from NICEPAY
     */
    private function update_order_status($order, $status_response) {
        nicepay_log ("status_response: " . json_encode($status_response),'info','ewallet');

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            if (!isset($status_response['responseCode'])) {
                nicepay_log("Invalid status response: missing responseCode", 'info', 'ewallet');
                return false;
            }
        
            // Pastikan response sukses dan ada latestTransactionStatus
            if ($status_response['responseCode'] === '2005500' && isset($status_response['latestTransactionStatus'])) {
                nicepay_log("Updating order status. Latest Transaction Status: " . $status_response['latestTransactionStatus'], 'info', 'ewallet');

                //$order->payment_complete();
                $order->update_status('processing', 'Pembayaran EWALLET berhasil.');
                $order->update_meta_data('_nicepay_status', $status_response['transactionStatusDesc']);
                $order->update_meta_data('_nicepay_status_code', $status_response['latestTransactionStatus']);
                $order->update_meta_data('_nicepay_paid_amount', $status_response['amount']['value']);
                $order->update_meta_data('_nicepay_currency', $status_response['amount']['currency']);
                $order->update_meta_data('_nicepay_transaction_datetime', $status_response['additionalInfo']['transactionDateTime']);
                $order->save();
            } else {
                nicepay_log("Invalid or unsuccessful status response: " . $status_response, 'error', 'ewallet');
                return false;
            }
        } else {
            if (!isset($status_response['resultCd']) || $status_response['resultCd'] !== '0000') {
                throw new Exception(sprintf(
                    __('Failed to create Ewallet transaction: %s', 'nicepay-wc'),
                    $status_response['resultMsg'] ?? 'Unknown error'
                ));
            }

            if($status_response['status'] == '0') {
                //$order->payment_complete();
                $order->update_status('processing', 'Pembayaran EWALLET berhasil.');
                $order->update_meta_data('_nicepay_status', 'Success');
                $order->update_meta_data('_nicepay_status_code', '00');
                $order->update_meta_data('_nicepay_paid_amount', $status_response['amt']);
                $order->update_meta_data('_nicepay_currency', $status_response['currency']);
                $order->update_meta_data('_nicepay_transaction_datetime', $status_response['transDt'] . $status_response['transTm']);
                $order->save();

                nicepay_log('Order meta updated', 'info', 'ewallet');
            }
        }
    }

    /**
     * Handle return URL after payment
     */
    public function handle_return_url($order_id) {
        nicepay_log("Ewallet handle_return_url: " . $order_id, 'info', 'ewallet');
        $order = wc_get_order($order_id);
        if (!$order || $order->get_status() !== 'pending') {
            return;
        }
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_callback() {
        nicepay_log('NICEPay callback received. Starting processing...', 'info', 'ewallet');
        status_header(200);

        // Ambil header request
        $headers = getallheaders();
        nicepay_log('Headers: ' . print_r($headers, true), 'info', 'ewallet');

        // Contoh akses header tertentu
        $timestamp = $headers['X-TIMESTAMP'] ?? null;
        $client_key = $headers['X-CLIENT-KEY'] ?? null;
        $signature = $headers['X-SIGNATURE'] ?? null;

        $raw_post = file_get_contents('php://input');
        nicepay_log('Raw input: ' . $raw_post, 'info', 'ewallet');

        $decoded_post = json_decode($raw_post, true);

        // Fallback parsing kalau bukan JSON (biasanya jarang terjadi)
        if (!$decoded_post) {
            parse_str($raw_post, $decoded_post);
        }
        if (empty($decoded_post)) {
            $decoded_post = $_POST;
        }

        nicepay_log('Processed callback data: ' . json_encode($decoded_post), 'info', 'ewallet');

        if (!empty($signature)) {
            try {
                nicepay_log("(SNAP) Attempting to find order with ID: " . $decoded_post['originalPartnerReferenceNo'], 'info', 'ewallet');

                if (!isset($decoded_post['originalPartnerReferenceNo']) || !isset($decoded_post['originalReferenceNo'])) {
                    throw new Exception("Missing required callback parameters");
                }

                $reference_no = $decoded_post['originalPartnerReferenceNo'];
                $tXid = $decoded_post['originalReferenceNo'];

                $parts = explode('-', $reference_no);
                $order_id = $parts[0];
                $order = wc_get_order($order_id);
        
                if (!$order) {
                    throw new Exception("Order not found: " . $order_id);
                }

                // Verify that the tXid number matches
                $stored_refNo = $order->get_meta('_nicepay_reference_no');
                if ($reference_no !== $stored_refNo) {
                    throw new Exception("Reference number mismatch");
                }

                if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
                    $status_response = $this->check_payment_status($order, $reference_no);
                    $this->update_order_status($order, $status_response);
                } else {
                    $this->check_payment_status_directv2($order_id,$decoded_post);
                }

                // Respond to the callback
                wp_send_json(array(
                    'status' => 'OK',
                    'message' => 'Callback processed successfully'
                ));
            } catch (Exception $e) {
                wc_add_notice(
                    sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in handle_callback: " . $e->getMessage(), 'info', 'ewallet');
                return [
                    'result'   => 'failure',
                    'redirect' => '',
                ];
            }
        } else if (!empty($decoded_post['merchantToken'])){
            nicepay_log("(Direct V2) Attempting to find order with ID: " . $decoded_post['referenceNo'], 'info', 'ewallet');

            if (!empty($decoded_post['referenceNo'])) {
                $referenceNo = trim($decoded_post['referenceNo']);
                $parts = explode('-', $referenceNo);
                $order_id = $parts[0];
                $order = wc_get_order($order_id);

                if ($order) { 
                    $this->check_payment_status_directv2($order_id,$decoded_post);

                    wp_send_json(array('status' => 'received'), 200);
                    exit;
                } else {
                    nicepay_log('Order not found for order_id: ' . $order_id, 'error', 'ewallet');
                    wp_send_json_error('Order not found', 404);
                }
            }
        } else {
            nicepay_log("Handle Callback from Mitra Page", 'info', 'ewallet');

            if (!empty($decoded_post['referenceNo'])) {
                $referenceNo = trim($decoded_post['referenceNo']);
                $parts = explode('-', $referenceNo);
                $order_id = $parts[0];
                $order = wc_get_order($order_id);

                if ($order) {
                    // Update status sesuai result
                    if (!empty($decoded_post['resultCd']) && $decoded_post['resultCd'] === '0000') {
                        //$order->payment_complete();
                        $order->update_status('processing', 'Pembayaran EWALLET berhasil.');

                        if($decoded_post['mitraCd'] === 'OVOE'){
                            nicepay_log("(Direct V2) OVO check status", 'info', 'ewallet');

                            if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
                                $status_response = $this->check_payment_status($order, $referenceNo);
                                $this->update_order_status($order, $status_response);
                            } else {
                                $this->check_payment_status_directv2($order_id,$decoded_post);
                            }
                        }
                    } else {
                        $order->update_status('failed', 'Payment failed via ewallet callback');
                    }

                    // 🚀 Langsung redirect ke order-received page
                    $redirect_url = $this->get_return_url($order);
                    nicepay_log("(ewallet) Redirecting to: " . $redirect_url, 'info', 'ewallet');

                    wp_safe_redirect($redirect_url);
                    exit;
                }
            }

            status_header(200);
            exit;
        }
    }
            
    private function generate_formatted_timestamp() {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    public function process_directV2($order_id) {
        nicepay_log("Starting process_directV2 for order $order_id", 'info', 'ewallet');
        try {
            $order = wc_get_order($order_id);

            $timestamp = date('YmdHis');
            $reqDt = date('Ymd');
            $reqTm = date('His');
            $iMid = $this->get_option('X-CLIENT-KEY');
            $merchantKey = $this->get_option('merchant_key');
            $amount = (int)$order->get_total();
            $referenceNo = $order->get_id() . "-" . $timestamp;

            $mitraCd = WC()->session->get('nicepay_selected_mitra', '');
            if (empty($mitraCd)) {
                throw new Exception(__('No eWallet selected. Please choose an eWallet payment method.', 'nicepay-wc'));
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);
            $cart_data = $this->prepare_cart_data($order);
            $requestBody = [
                "timeStamp"     => $timestamp,
                "iMid"          => $iMid,
                "payMethod"     => "05", // Ewallet
                "currency"      => "IDR",
                "mitraCd"       => $mitraCd,
                "amt"           => (string) $amount,
                "referenceNo"   => $referenceNo,
                "merchantToken" => $merchantToken,
                "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_ewallet'),
                "goodsNm"       => $this->get_order_items_names($order),
                "billingNm"     => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                "billingPhone"  => $order->get_billing_phone(),
                "billingEmail"  => $order->get_billing_email(),
                "billingAddr"   => $order->get_billing_address_1(),
                "billingCity"   => $order->get_billing_city(),
                "billingState"  => $order->get_billing_state(),
                "billingCountry"=> $order->get_billing_country(),
                "billingPostCd" => $order->get_billing_postcode(),
                "description"   => "Testing Ewallet - " . get_bloginfo('name'),
                "reqDomain"     => $_SERVER['HTTP_HOST'] ?? 'merchant.com',
                "reqServerIP"   => $_SERVER['SERVER_ADDR'] ?? '127.0.0.1',
                "userIP"        => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "userSessionID" => session_id(),
                "userAgent"     => $_SERVER['HTTP_USER_AGENT'] ?? '',
                "userLanguage"  => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
                "cartData"      => $cart_data,
                "shopId"        => ""
            ];

            $args = [
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body'    => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("Ewallet Request to " . $this->api_endpoints['registrationDirectV2'], 'info', 'ewallet');
            nicepay_log("Ewallet Request Body: " . json_encode($requestBody), 'info', 'ewallet');

            $response = wp_remote_post($this->api_endpoints['registrationDirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("Ewallet Response: " . json_encode($response_body), 'info', 'ewallet');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                $msg = $response_body['resultMsg'] ?? 'Unknown error';
                throw new Exception(
                    sprintf(__('Failed to create eWallet transaction: %s', 'nicepay-wc'), $msg)
                );
            }

            $order->add_order_note(sprintf(
                __('NICEPay E-Wallet. Details:
                Reference Number : %s
                Transaction ID: %s', 'nicepay-wc'),
                $response_body['referenceNo'],
                $response_body['tXid']
            ));

            // Save important meta
            $order->update_meta_data('_nicepay_tXid', $response_body['tXid'] ?? '');
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo'] ?? '');
            $order->update_meta_data('_nicepay_mitra', $mitraCd);
            $order->update_meta_data('_nicepay_txn_amt', (string) $amount);
            $order->save();

            return $response_body;
        } catch (Exception $e) {
            wc_add_notice(
                sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'ewallet');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }

    public function process_paymentV2($order_id, $response_regis) {
        nicepay_log("(Direct V2) Starting process_paymentV2", 'info', 'ewallet');
        try {
            $order = wc_get_order($order_id);
            $timestamp     = date('YmdHis');
            $iMid          = $this->get_option('X-CLIENT-KEY');
            $merchantKey   = $this->get_option('merchant_key');
            $amount        = (int) $order->get_total();
            $referenceNo   = $response_regis['referenceNo'];

            if($response_regis['mitraCd'] === 'OVOE'){
                $callBackUrl = home_url('/wc-api/wc_gateway_nicepay_ewallet');
            } else {
                $callBackUrl = $this->get_return_url($order);
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            $paymentUrl = $this->api_endpoints['paymentDirectV2'] . '?' . http_build_query([
                'timeStamp'     => $timestamp,
                'tXid'          => $response_regis['tXid'],
                'merchantToken' => $merchantToken,
                'callBackUrl'   => $callBackUrl,
            ]);

            // Log buat debug
            nicepay_log("Redirecting user to: " . $paymentUrl, 'info', 'ewallet');

            return $paymentUrl;
        } catch (Exception $e) {
            wc_add_notice(
                sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                'error'
            );
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'info', 'ewallet');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }

    private function check_payment_status_directv2($order_id,$data)
    {
        nicepay_log('Starting check_payment_status_directv2 for order ' . $order_id, 'info', 'ewallet');

        $order = wc_get_order($order_id);
        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        $tXid = !empty($data['tXid']) ? $data['tXid'] : ($data['originalReferenceNo'] ?? null);
        $referenceNo = !empty($data['referenceNo']) ? $data['referenceNo'] : ($data['originalPartnerReferenceNo'] ?? null);
        $amount = !empty($data['amt']) ? $data['amt'] : ($data['amount']['value'] ?? null);
        $merchantKey = $this->get_option('merchant_key');

        nicepay_log($iMid . $tXid . $referenceNo . $amount, 'info', 'ewallet');

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . (int) $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => (int) $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("EWALLET Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'ewallet');
        nicepay_log("EWALLET Request Body: " . json_encode($requestBody), 'info', 'ewallet');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            throw new Exception("HTTP Request failed: " . $response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("EWALLET Response: " . json_encode($response_body), 'info', 'ewallet');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            throw new Exception(
                sprintf(
                    __('Failed to create EWALLET transaction: %s', 'nicepay-wc'),
                    $response_body['resultMsg'] ?? 'Unknown error'
                )
            );
        }

        if($response_body['status'] == '0') {
            // Save metadata from callback
            //$order->payment_complete();
            $order->update_status('processing', 'Pembayaran EWALLET berhasil.');
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency']);
            $order->update_meta_data('_nicepay_transaction_datetime', $response_body['transDt'] . $response_body['transTm']);
            $order->save();

            nicepay_log('Order meta updated for order ' . $order_id, 'info', 'ewallet');
        }
    }
}