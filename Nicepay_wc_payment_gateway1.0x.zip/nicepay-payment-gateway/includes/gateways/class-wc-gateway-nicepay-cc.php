<?php
if (!defined('ABSPATH')) exit;
class WC_Gateway_Nicepay_CC extends WC_Payment_Gateway {
    protected $instructions;
    protected $environment;
    protected $host;
    protected $api_endpoints;

    /**
     * Constructor for the gateway
     */
    public function __construct() {

        $this->id                 = 'nicepay_cc';
        $this->icon               = apply_filters('woocommerce_nicepay_cc_icon','');
        $this->has_fields         = false;
        $this->method_title       = __('NICEPAY Credit Card', 'nicepay-wc');
        $this->method_description = __('Allows payments using NICEPAY Credit Card', 'nicepay-wc');

        $this->supports = [
            'products',
            'refunds',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();
        
        $this->api_endpoints = $this->get_api_endpoints();

        if (get_option('nicepay_checkout_mode') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');
        $this->environment = get_option('nicepay_environment', 'sandbox'); // Default to sandbox if not set
        $this->host = get_option('nicepay_host', 'premise'); // Default to sandbox if not set

        // Actions
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_ajax_set_nicepay_CC_CardNo', array($this, 'set_nicepay_CC_CardNo'));
        add_action('wp_ajax_nopriv_set_nicepay_CC_CardNo', array($this, 'set_nicepay_CC_CardNo'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_cc', array($this, 'handle_callback'));
    }

    /**
     * Enqueue scripts and styles for classic checkout
     */
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }

        ?>
        <style>
            .nicepay-cc-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-cc-header {
                margin-bottom: 15px;
                text-align: center;
                padding: 10px 0;
            }
            .nicepay-cc-icon {
                max-height: 150px;
                width: auto;
                display: inline-block;
                margin: 10px 0;
            }
            .nicepay-cc-select {
                margin: 10px 0;
            }
            .nicepay-cc-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-cc-logos {
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 15px; /* Spacing antar logo */
                margin-bottom: 20px;
            }
            .nicepay-cc-logos img {
                height: 30px; /* Ukuran untuk logo individu */
                width: auto;
            }
            .nicepay-cc-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php

        // Enqueue JS
        if (!wp_script_is('nicepay-cc-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_PLUGIN_URL . '/assets/js/cc-classic-checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-cc-blocks-integration',
            'nicepayCCData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'security' => wp_create_nonce('nicepay-cc-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'iscc' => true
            )
        );
    }

    /**
     * Enqueue scripts and styles for blocks checkout
     */
    public function enqueue_blocks_mode() {
        if (!is_checkout()) {
            return;
        }

        $version = date('YmdHis');

        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-cc-style',
            NICEPAY_PLUGIN_URL . '/assets/css/cc.css',
            [],
            $version
        );

        // Register blocks script
        if (!wp_script_is('nicepay-cc-block', 'enqueued')) {
            wp_enqueue_script(
                'nicepay-cc-blocks-integration',
                NICEPAY_PLUGIN_URL . '/assets/js/cc-block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                '1.0.0',
                true
            );
        }

        // Localize script
        wp_localize_script(
            'nicepay-cc-blocks-integration',
            'nicepayCCData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'security' => wp_create_nonce('nicepay-cc-nonce'),
                'pluginUrl' => NICEPAY_PLUGIN_URL,
                'iscc' => true
            )
        );
    }

    /**
     * Update API endpoints based on environment
     */
    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }

    /**
     * Get API endpoints based on environment
     */
    private function get_api_endpoints() 
    {
        $isProduction = $this->environment === 'production';
        $isCloud = $this->host === 'cloud';

        $base_url = "";
        if ($isProduction && $isCloud) {
            $base_url = 'https://services.nicepay.co.id';
        } elseif ($isProduction) {
            $base_url = 'https://www.nicepay.co.id';
        } elseif ($isCloud) {
            $base_url = 'https://dev-services.nicepay.co.id';
        } else {
            $base_url = 'https://dev.nicepay.co.id';
        }
        
        return [
            'registrationRedirectV2'      => $base_url . '/nicepay/redirect/v2/registration',
            'paymentDirectV2'           => $base_url . '/nicepay/direct/v2/payment',
            'check_status_url_directv2' => $base_url .'/nicepay/direct/v2/inquiry',
        ];
    }

    /**
     * Initialize Gateway Settings Form Fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'nicepay-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPAY CC Payment', 'nicepay-wc'),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'nicepay-wc'),
                'default'     => __('NICEPAY Credit Card', 'nicepay-wc'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'nicepay-wc'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'nicepay-wc'),
                'default'     => __('Pay with Credit Card via NICEPAY', 'nicepay-wc'),
                'desc_tip'    => true,
            ),
            'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'nicepay-wc'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPAY</small>.', 'nicepay-wc'),
                'default' => 'TESTMPGS05',
            ),
            // 'CHANNEL-ID' => array(
            //     'title' => __('Channel ID', 'nicepay-wc'),
            //     'type' => 'text',
            //     'description' => __('<small>Isikan dengan Channel ID dari NICEPAY</small>.', 'nicepay-wc'),
            //     'default' => '',
            // ),
            // 'client_secret' => array(
            //     'title'       => __('Client Key', 'nicepay-wc'),
            //     'type'        => 'text',
            //     'description' => __('Enter your NICEPAY Client Key.', 'nicepay-wc'),
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
            'merchant_key' => array(
                'title'       => __('Merchant Key', 'nicepay-wc'),
                'type'        => 'text',
                'description' => __('Enter your NICEPAY Merchant Key.', 'nicepay-wc'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),
            // 'private_key' => array(
            //     'title'       => __('Private Key', 'nicepay-wc'),
            //     'type'        => 'textarea',
            //     'description' => __('Enter your NICEPAY Private Key.', 'nicepay-wc'),
            //     'default'     => '',
            //     'desc_tip'    => true,
            // ),
        );
    }


    /**
     * Handle the Ajax request to set card data
     */
    public function set_nicepay_CC_CardNo() {
        check_ajax_referer('nicepay-cc-nonce', 'security');

        $cardNo = isset($_POST['cardNo']) ? sanitize_text_field($_POST['cardNo']) : '';
        $expYm  = isset($_POST['expYm']) ? sanitize_text_field($_POST['expYm']) : '';
        $cvv    = isset($_POST['cvv']) ? sanitize_text_field($_POST['cvv']) : '';
        $cardHolder    = isset($_POST['cardHolder']) ? sanitize_text_field($_POST['cardHolder']) : '';

        WC()->session->set('nicepay_cc_cardNo', $cardNo);
        WC()->session->set('nicepay_cc_expYm', $expYm);
        WC()->session->set('nicepay_cc_cvv', $cvv);
        WC()->session->set('nicepay_cc_cardHolderNm', $cardHolder);

        nicepay_log("CC Data Saved: cardNo={$cardNo}, expYm={$expYm}, cvv={$cvv}", 'info', 'cc');

        wp_send_json_success(['message' => 'CC data saved']);
    }

    /**
     * Process the payment
     */
    public function process_payment($order_id) {
        nicepay_log("Starting process_payment cc for order $order_id", 'info', 'cc');

        $checkout_mode = get_option('nicepay_checkout_mode');
        if ($checkout_mode === 'classic') {
            return $this->process_classic_payment($order_id);
        } else {
            return $this->process_blocks_payment($order_id);
        }
    }

    /**
     * Process payment for classic checkout
     */
    public function process_classic_payment($order_id) {
        nicepay_log("Starting process_classic_payment for order $order_id", 'info', 'cc');
        
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'cc');
        $order->save();

        $selected_mitra = sanitize_text_field($_POST['nicepay_mitra'] ?? '');

        if (empty($selected_mitra)) {
            wc_add_notice(__('Please select an CC payment method.', 'nicepay-wc'), 'error');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
        WC()->session->set('nicepay_selected_cc_mitra', $selected_mitra);

        try {
    
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_payment: " . $e->getMessage(), 'error', 'cc');
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    /**
     * Process payment for blocks checkout
     */
    public function process_blocks_payment($order_id) {
        nicepay_log("Starting process_blocks_payment for order " . $order_id, 'info', 'cc');
    
        $order = wc_get_order($order_id);
        $order->update_meta_data('_nicepay_payment_method', 'cc');
        $order->save();

        if (!empty($this->get_option('client_secret')) && !empty($this->get_option('private_key'))) {
            $this->process_snap($order_id);
        } else {
            try {
                $paymentUrl = $this->process_redirectV2($order_id);
                if (!isset($paymentUrl)) {
                    throw new Exception(__('Failed to create cc transaction: ', 'nicepay-wc') . ($paymentUrl ?? 'Unknown error'));
                }
                //WC()->cart->empty_cart();

                return [
                    'result'   => 'success',
                    'redirect' => $paymentUrl,
                ];
            } catch (Exception $e) {
                wc_add_notice(
                    sprintf(__('Payment error: %s', 'woocommerce'), $e->getMessage()),
                    'error'
                );
                nicepay_log("Payment error in Processing blocks paymentt: " . $e->getMessage(), 'error', 'ewallet');
                
                return array(
                    'result'   => 'failure',
                    'redirect' => '',
                );
            }
        }
    }

    public function process_redirectV2($order_id) {
        nicepay_log("Starting process_redirectV2 for order $order_id", 'info', 'cc');
        try {
            $order = wc_get_order($order_id);

            $timestamp      = date('YmdHis');
            $iMid           = $this->get_option('X-CLIENT-KEY');
            $merchantKey    = $this->get_option('merchant_key');
            $amount         = (string)$order->get_total();
            $referenceNo    = $order->get_id() . "-" . $timestamp;

            $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

            // ================= CART DATA =================
            $cart_data = $this->prepare_cart_data($order);

            // ================= SELLERS =================
            $sellers = [[
                "sellersId"    => "SEL123",
                "sellersNm"    => "WooCommerce Seller",
                "sellersEmail" => get_option('admin_email'),
                "sellersAddress" => [
                    "sellerNm"      => "Woo",
                    "sellerLastNm"  => "Commerce",
                    "sellerAddr"    => "Merchant Address",
                    "sellerCity"    => "Jakarta",
                    "sellerPostCd"  => "12345",
                    "sellerPhone"   => "08123456789",
                    "sellerCountry" => "Indonesia"
                ]
            ]];

            // ================= REQUEST BODY =================
            $requestBody = [
                "timeStamp"      => $timestamp,
                "iMid"           => $iMid,
                "payMethod"      => "01", // CC
                "currency"       => "IDR",
                "amt"            => $amount,
                "referenceNo"    => $referenceNo,
                "merchantToken"  => $merchantToken,
                "instmntType"    => "1",
                "instmntMon"     => "1",
                "reqDt"          => date('Ymd'),
                "reqTm"          => date('His'),
                "goodsNm"        => $order->get_formatted_billing_full_name(),
                "billingNm"      => $order->get_formatted_billing_full_name(),
                "billingPhone"   => $order->get_billing_phone(),
                "billingEmail"   => $order->get_billing_email(),
                "billingAddr"    => $order->get_billing_address_1(),
                "billingCity"    => $order->get_billing_city(),
                "billingState"   => $order->get_billing_state(),
                "billingCountry" => $order->get_billing_country(),
                "billingPostCd"  => $order->get_billing_postcode(),
                "description"    => "Payment for WooCommerce order #{$order_id}",
                "callBackUrl"    => $this->get_return_url($order),
                "dbProcessUrl"   => home_url('/wc-api/wc_gateway_nicepay_cc'),
                "userIP"         => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                "cartData"       => $cart_data,
                "sellers"        => json_encode($sellers, JSON_UNESCAPED_SLASHES),
                "deliveryNm"     => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
                "deliveryPhone"  => $order->get_billing_phone(),
                "deliveryAddr"   => $order->get_shipping_address_1(),
                "deliveryCity"   => $order->get_shipping_city(),
                "deliveryState"  => $order->get_shipping_state(),
                "deliveryCountry"=> $order->get_shipping_country(),
                "deliveryPostCd" => $order->get_shipping_postcode(),
                "mitraCd"        => "",
                "recurrOpt"      => "",
                "userLanguage"   => "en",
                "userAgent"      => $_SERVER['HTTP_USER_AGENT'] ?? 'WooCommerce'
            ];

            $args = [
                'method'  => 'POST',
                'timeout' => 45,
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body'    => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
            ];

            nicepay_log("CC Request to " . $this->api_endpoints['registrationRedirectV2'], 'info', 'cc');
            nicepay_log("CC Request Body: " . json_encode($requestBody), 'info', 'cc');

            $response = wp_remote_post($this->api_endpoints['registrationRedirectV2'], $args);

            if (is_wp_error($response)) {
                throw new Exception("HTTP Request failed: " . $response->get_error_message());
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);
            nicepay_log("CC Response: " . json_encode($response_body), 'info', 'cc');

            if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
                throw new Exception(__('Failed to create CC transaction: ', 'nicepay-wc') . ($response_body['resultMsg'] ?? 'Unknown error'));
            }

            if (!isset($response_body['paymentURL'])) {
                throw new Exception(__('Failed to create CC transaction: ', 'nicepay-wc') . ($response_body['paymentURL'] ?? 'Unknown error'));
            }

            $order->add_order_note(sprintf(
                __('NICEPay Credit Card. Details:
                Reference Number : %s
                Transaction ID: %s
                Transaction Amount: %s', 'nicepay-wc'),
                $response_body['referenceNo'],
                $response_body['tXid'],
                $response_body['amt']
            ));

            $order->update_meta_data('_nicepay_tXid', $response_body['tXid']);
            $order->update_meta_data('_nicepay_reference_no', $response_body['referenceNo']);
            $order->update_meta_data('_nicepay_txn_amt', $response_body['amt']);
            $order->save();

            $paymentUrl = $response_body['paymentURL'] . '?' . http_build_query([
                'tXid'  => $response_body['tXid'],
            ]);

            nicepay_log("paymentUrl: " . $paymentUrl, 'info', 'cc' );

            return $paymentUrl;

        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
            nicepay_log("Payment error in process_redirectV2: " . $e->getMessage(), 'error', 'cc');
            return [
                'resultCd'  => '9999',
                'resultMsg' => $e->getMessage()
            ];
        }
    }

    private function prepare_cart_data($order) {
        $items = $order->get_items();
        $cart_items = array();
        $calculated_total = 0;
        $order_total = intval(number_format($order->get_total(), 0, '', ''));

        foreach ($items as $item) {
            $product = $item->get_product();
            $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
            
            $cart_items[] = array(
                'goods_id' => $product->get_sku() ?: $product->get_id(),
                'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
                'goods_name' => $item->get_name(),
                'goods_amt' => (string)$unit_price, 
                'goods_type' => $product->get_type(),
                'goods_url' => get_permalink($product->get_id()),
                'goods_quantity' => $item->get_quantity(),
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += ($unit_price * $item->get_quantity());
            nicepay_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()),'info','qris');
        }
        if ($order->get_shipping_total() > 0) {
            $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
            $cart_items[] = array(
                'goods_id' => 'SHIPPING',
                'goods_detail' => 'Delivery Fee',
                'goods_name' => 'Shipping Cost',
                'goods_amt' => (string)$shipping_amount,
                'goods_type' => 'shipping',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );
            $calculated_total += $shipping_amount;
            nicepay_log("",'info','qris');
        }
        $tax_difference = $order_total - $calculated_total;
            
        nicepay_log("Calculated total before tax: {$calculated_total}",'info','qris');
        nicepay_log("Order total: {$order_total}",'info','qris');
        nicepay_log("Difference (tax): {$tax_difference}",'info','qris');
        if ($tax_difference > 0) {
            $cart_items[] = array(
                'goods_id' => 'TAX',
                'goods_detail' => 'Tax',
                'goods_name' => 'Tax',
                'goods_amt' => (string)$tax_difference,
                'goods_type' => 'tax',
                'goods_url' => '',
                'goods_quantity' => 1,
                'goods_sellers_id' => 'STORE',
                'goods_sellers_name' => get_bloginfo('name')
            );

            $calculated_total += $tax_difference;
            nicepay_log("Tax added: {$tax_difference}",'info','qris');
        }

        nicepay_log("Final calculated total: {$calculated_total}",'info','qris');
        $cart_data = array(
            'count' => count($cart_items),
            'item' => $cart_items
        );
        return json_encode($cart_data);
    }

    private function process_paymentV2($order_id, $cc_data) {
        nicepay_log("Starting process_paymentV2", 'info', 'cc');

        try {
            $order = wc_get_order($order_id);
            $timestamp     = date('YmdHis');
            $iMid          = $this->get_option('X-CLIENT-KEY');
            $merchantKey   = $this->get_option('merchant_key');

            // Ambil data kartu dari session
            $cardNo        = WC()->session->get('nicepay_cc_cardNo');
            $expYm         = WC()->session->get('nicepay_cc_expYm');
            $cvv           = WC()->session->get('nicepay_cc_cvv');
            $cardHolderNm  = WC()->session->get('nicepay_cc_cardHolderNm');

            if (!$cardNo || !$expYm || !$cvv) {
                throw new Exception("Incomplete credit card data in session");
            }

            if (empty($cardHolderNm)) {
                $cardHolderNm = "NICEPAY CUSTOMER";
            }

            $merchantToken = hash('sha256', $timestamp . $iMid . $cc_data['referenceNo'] . $cc_data['amt'] . $merchantKey);
            
            $paymentUrl = $this->api_endpoints['paymentDirectV2'] . '?' . http_build_query([
                'timeStamp'         => $timestamp,
                'merchantToken'     => $merchantToken,
                'tXid'              => $cc_data['tXid'],
                "callBackUrl"       => $this->get_return_url($order),
                "referenceNo"       => $cc_data['referenceNo'],
                "cardNo"            => $cardNo,
                "cardExpYymm"       => $expYm,
                "cardCvv"           => $cvv,
                "cardHolderNm"      => $cardHolderNm,
                "cardHolderEmail"   => $order->get_billing_email(),
            ]);

            // Log buat debug
            nicepay_log("Redirecting user to: " . $paymentUrl, 'info', 'cc');

            return $paymentUrl;

            return $response;
        } catch (Exception $e) {
            wc_add_notice(__('Credit Card Payment Error: ', 'woocommerce') . $e->getMessage(), 'error');
            nicepay_log("Exception in process_paymentV2: " . $e->getMessage(), 'error', 'cc');
            return [
                'result'   => 'failure',
                'redirect' => '',
            ];
        }
    }


    public function thankyou_page($order_id) {
        nicepay_log("Starting thankyou_page" .$order_id,'info','cc');

    }

    public function process_snap($order_id){
        nicepay_log("Starting process_snap soon to be", 'info', 'cc');
    }

    /**
     * Get order items names
     */
    private function get_order_items_names($order) {
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $item_names[] = $item->get_name();
        }
        return implode(', ', $item_names);
    }

    /**
     * Handle callback from NICEPAY
     */
    public function handle_callback() {
        nicepay_log('NICEPay callback received. Starting processing...', 'info', 'cc');
        status_header(200);

        // Ambil header request
        $headers = getallheaders();
        nicepay_log('Headers: ' . print_r($headers, true), 'info', 'cc');

        // Contoh akses header tertentu
        $timestamp = $headers['X-TIMESTAMP'] ?? null;
        $client_key = $headers['X-CLIENT-KEY'] ?? null;
        $signature = $headers['X-SIGNATURE'] ?? null;

        nicepay_log("Timestamp: $timestamp", 'info', 'cc');
        nicepay_log("Client Key: $client_key", 'info', 'cc');
        nicepay_log("Signature: $signature", 'info', 'cc');

        $raw_post = file_get_contents('php://input');
        nicepay_log('Raw input: ' . $raw_post, 'info', 'cc');

        $decoded_post = json_decode($raw_post, true);

        // Fallback parsing kalau bukan JSON (biasanya jarang terjadi)
        if (!$decoded_post) {
            parse_str($raw_post, $decoded_post);
        }
        if (empty($decoded_post)) {
            $decoded_post = $_POST;
        }

        nicepay_log('Processed callback data: ' . $decoded_post, 'info', 'cc');

        if (!empty($signature)) {
            nicepay_log("(SNAP)", 'info', 'cc');
        } else {
            nicepay_log("(Direct V2) Attempting to find order with ID: " . $decoded_post['referenceNo'], 'info', 'cc');

            $referenceNo = trim($decoded_post['referenceNo']);
            $parts = explode('-', $referenceNo);
            $order_id = $parts[0];
            $order = wc_get_order($order_id);

            if ($order) { 
                nicepay_log('Order found: ' . $order_id, 'info', 'cc');

                // You might have a method to handle status update
                $this->check_payment_status_directv2($order_id,$decoded_post);

                wp_send_json(array('status' => 'received'), 200);
                exit;
            } else {
                nicepay_log('Order not found for paymentRequestId: ' . $order_id, 'error', 'cc');
                wp_send_json_error('Order not found', 404);
            }
        }
    }

    private function check_payment_status_directv2($order_id,$data)
    {
        nicepay_log('Starting check_payment_status_directv2 for order ' . $order_id, 'info', 'cc');

        $order = wc_get_order($order_id);
        $timestamp = date('YmdHis');
        $iMid = $this->get_option('X-CLIENT-KEY');
        if ($order->get_meta('_nicepay_mitra') === 'OVOE'){
            $tXid = $order->get_meta('_nicepay_tXid');
            $referenceNo = $order->get_meta('_nicepay_reference_no');
            $amount = $order->get_meta('_nicepay_txn_amt');
        } else {
            $tXid = $data['tXid'];
            $referenceNo = $data['referenceNo'];
            $amount = $data['amt'];
        }
        $merchantKey = $this->get_option('merchant_key');

        nicepay_log($iMid . $tXid . $referenceNo . $amount);

        $merchantToken = hash('sha256', $timestamp . $iMid . $referenceNo . $amount . $merchantKey);

        $requestBody = [
            "timeStamp" => $timestamp,
            "iMid" => $iMid,
            "tXid" => $tXid,
            "referenceNo" => $referenceNo,
            "amt" => $amount,
            "merchantToken" => $merchantToken
        ];

        $args = [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($requestBody, JSON_UNESCAPED_SLASHES)
        ];

        nicepay_log("cc Request to " . $this->api_endpoints['check_status_url_directv2'], 'info', 'cc');
        nicepay_log("cc Request Body: " . json_encode($requestBody), 'info', 'cc');

        $response = wp_remote_post($this->api_endpoints['check_status_url_directv2'], $args);

        if (is_wp_error($response)) {
            throw new Exception("HTTP Request failed: " . $response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        nicepay_log("cc Response: " . json_encode($response_body), 'info', 'cc');

        if (!isset($response_body['resultCd']) || $response_body['resultCd'] !== '0000') {
            throw new Exception(__('Failed to create cc transaction: ', 'nicepay-wc') . ($response_body['resultMsg'] ?? 'Unknown error'));
        }

        //if($response_body['status'] == '0') {
            // Save metadata from callback
            //$order->payment_complete();
            $order->update_status('processing', 'Pembayaran CC berhasil.');
            $order->update_meta_data('_nicepay_status', 'Success');
            $order->update_meta_data('_nicepay_status_code', '00');
            $order->update_meta_data('_nicepay_paid_amount', $response_body['amt']);
            $order->update_meta_data('_nicepay_currency', $response_body['currency']);
            $order->update_meta_data('_nicepay_transaction_datetime', $response_body['transDt'] . $response_body['transTm']);
            $order->save();

            nicepay_log('Order meta updated for order ' . $order_id, 'info', 'cc');
        //}
    }
}