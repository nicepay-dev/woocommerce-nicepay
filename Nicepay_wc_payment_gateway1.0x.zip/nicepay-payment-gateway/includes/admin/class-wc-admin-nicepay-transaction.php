<?php
if (!defined('ABSPATH')) exit;

class NICEPay_Admin_Page {

    public static function init() {
        add_menu_page(
            'NICEPay Transactions',
            'NICEPay Transactions',
            'manage_woocommerce',
            'nicepay-transactions',
            [__CLASS__, 'render_page'],
            'dashicons-feedback',
            56
        );
    }

    public static function render_page() {
        echo '<div class="wrap">';
        echo '<h1>NICEPay Transactions</h1>';

        // Start scrollable container
        echo '<div style="overflow-x: auto; margin-top: 20px;">';
        echo '<table class="widefat fixed striped" style="min-width: 1100px; table-layout: auto;">';
        echo '<thead>
                <tr>
                    <th style="white-space: nowrap;">Order ID</th>
                    <th style="white-space: nowrap;">Reference No</th>
                    <th style="white-space: nowrap;">TX ID</th>
                    <th style="white-space: nowrap;">Status</th>
                    <th style="white-space: nowrap;">Amount</th>
                    <th style="white-space: nowrap;">Datetime</th>
                    <th style="white-space: nowrap;">Payment Method</th>
                    <th style="white-space: nowrap;">Details</th>
                </tr>
              </thead><tbody>';

        $args = [
            'limit'   => 20,
            'orderby' => 'date',
            'order'   => 'DESC',
        ];

        $orders = wc_get_orders($args);

        foreach ($orders as $order) {
            $order_id  = $order->get_id();
            $reference = $order->get_meta('_nicepay_reference_no');
            $txid      = $order->get_meta('_nicepay_tXid');
            $status    = $order->get_meta('_nicepay_status');
            $amount    = $order->get_meta('_nicepay_paid_amount');
            $datetime  = $order->get_meta('_nicepay_transaction_datetime');
            $method    = $order->get_meta('_nicepay_payment_method');

            $details = '';
            switch ($method) {
                case 'va':
                    $details .= 'Bank: ' . esc_html($order->get_meta('_nicepay_bank_code')) . '<br>';
                    $details .= 'VA No: ' . esc_html($order->get_meta('_nicepay_va_number')) . '<br>';
                    $details .= 'Expiry: ' . esc_html($order->get_meta('_nicepay_va_expiry'));
                    break;
                case 'ewallet':
                    $details .= 'Mitra: ' . esc_html($order->get_meta('_nicepay_mitra'));
                    break;
                case 'qris':
                    //$details .= 'QRIS TX ID: ' . esc_html($order->get_meta('_nicepay_qris_txid'));
                    break;
                default:
                    $details .= '-';
                    break;
            }

            echo '<tr>';
            echo '<td><a href="' . esc_url(admin_url('post.php?post=' . $order_id . '&action=edit')) . '" target="_blank">#' . esc_html($order_id) . '</a></td>';
            echo '<td>' . esc_html($reference) . '</td>';
            echo '<td>' . esc_html($txid) . '</td>';
            echo '<td>' . esc_html($status) . '</td>';
            echo '<td>' . esc_html(get_woocommerce_currency_symbol() . ' ' . number_format((float)$amount, 2)) . '</td>';
            echo '<td>' . esc_html($datetime) . '</td>';
            echo '<td>' . esc_html(ucfirst($method)) . '</td>';
            echo '<td style="white-space: normal;">' . wp_kses_post($details) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>'; // close scrollable container

        // CSS tambahan supaya tabel tetap rapi
        echo '<style>
            table.widefat td {
                word-break: break-word;
                vertical-align: top;
            }
            table.widefat th {
                text-align: left;
            }
            @media screen and (max-width: 768px) {
                table.widefat {
                    font-size: 14px;
                }
            }
        </style>';

        echo '</div>'; // close wrap
    }
}
