jQuery(function ($) {
    console.log('NICEPay Ewallet classic checkout initialized');

    function createEwalletSelector() {
        if (!nicepayData || !Array.isArray(nicepayData.enabled_mitra) || nicepayData.enabled_mitra.length === 0) {
            console.error('NICEPay configuration is missing or no mitra available');
            return $('<div>').text('E-wallet belum tersedia saat ini.');
        }

        const container = $('<div/>', {
            class: 'nicepay-ewallet-container'
        });

        const header = $('<div/>', { class: 'nicepay-ewallet-header' }).append(
            $('<img/>', {
                src: nicepayData.pluginUrl + '/assets/images/ewallet-logo.png',
                alt: 'Ewallet Logo',
                class: 'nicepay-ewallet-icon'
            })
        );

        const ewalletSelect = $('<div/>', { class: 'nicepay-ewallet-select' }).append(
            $('<label/>', {
                for: 'nicepay-ewallet-select',
                text: 'Pilih E-wallet:'
            }),
            $('<select/>', {
                name: 'nicepay_mitra',
                id: 'nicepay-ewallet-select'
            }).append(
                $('<option/>', { value: '', text: 'Pilih E-wallet' }),
                nicepayData.enabled_mitra.map(mitra =>
                    $('<option/>', { value: mitra.value, text: mitra.label })
                )
            )
        );

        const errorContainer = $('<div/>', {
            class: 'nicepay-ewallet-error',
            style: 'display: none; color: red; margin-top: 10px;'
        });

        container.append(header, ewalletSelect, errorContainer);
        return container;
    }

    function showError(message, container) {
        const errorDiv = container.find('.nicepay-ewallet-error');
        errorDiv.text(message).show();
        setTimeout(() => errorDiv.fadeOut(), 5000);
    }

    function saveMitraSelection(selectedMitra, container) {
        if (!selectedMitra) {
            return;
        }

        const select = container.find('#nicepay-ewallet-select');
        select.prop('disabled', true);

        $.ajax({
            url: nicepayData.ajax_url,
            type: 'POST',
            data: {
                action: 'set_nicepay_mitra',
                mitra_code: selectedMitra,
                nonce: nicepayData.nonce
            },
            success: function (response) {
                if (response.success) {
                    console.log('Mitra selection saved:', response.data);
                    sessionStorage.setItem('nicepay_selected_mitra', selectedMitra);
                } else {
                    showError(response.data || 'Failed to save selection', container);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error saving mitra selection:', error);
                showError('Failed to save e-wallet selection', container);
            },
            complete: function () {
                select.prop('disabled', false);
            }
        });
    }

    function initNicepayClassic() {
        const paymentMethod = $('input[name="payment_method"][value="nicepay_ewallet_snap"]');

        if (paymentMethod.length) {
            // Remove existing container biar gak dobel
            paymentMethod.closest('li').find('.nicepay-ewallet-container').remove();

            const ewalletSelector = createEwalletSelector();
            paymentMethod.closest('li').append(ewalletSelector);

            // Restore selection kalau ada
            const savedMitra = sessionStorage.getItem('nicepay_selected_mitra');
            if (savedMitra) {
                $('#nicepay-ewallet-select').val(savedMitra);
            }

            // Handle selection
            $('#nicepay-ewallet-select').on('change', function () {
                const selectedMitra = $(this).val();
                if (selectedMitra) {
                    sessionStorage.setItem('nicepay_selected_mitra', selectedMitra);
                    saveMitraSelection(selectedMitra, ewalletSelector);
                } else {
                    sessionStorage.removeItem('nicepay_selected_mitra');
                }
            });
        }
    }

    // Validasi pas form submit
    $('form.checkout').on('checkout_place_order_nicepay_ewallet_snap', function () {
        const selectedMitra = $('#nicepay-ewallet-select').val();
        if (!selectedMitra) {
            showError('Silakan pilih e-wallet untuk pembayaran', $('.nicepay-ewallet-container'));
            return false;
        }

        // Bersihkan input hidden sebelumnya
        $('input[name="nicepay_mitra"]').remove();

        // Tambahkan hidden input ke form
        $('<input>').attr({
            type: 'hidden',
            name: 'nicepay_mitra',
            value: selectedMitra
        }).appendTo('form.checkout');

        return true;
    });

    // Init saat halaman ready
    initNicepayClassic();

    // Reinit tiap checkout di-refresh / payment method diganti
    $(document.body).on('updated_checkout payment_method_selected', function () {
        initNicepayClassic();
    });
});