document.addEventListener('DOMContentLoaded', function() {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log('Initializing QRIS payment method');
        initNicepayQrisSnap();
    } else {
        console.error('Required dependencies not available');
    }
});

function initNicepayQrisSnap() {
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment, useState } = window.wp.element;

    const NicepayQrisComponent = () => {
        const [mitraCd, setMitraCd] = useState('QSHP');

        return createElement(Fragment, null,
            createElement('div', { className: 'nicepay-qris-container' },
                createElement('div', { className: 'nicepay-qris-content' },
                    createElement('div', { className: 'nicepay-qris-logos' },
                        createElement('img', {
                            src: qrisData.pluginUrl + '/assets/images/qris-logo.png',
                            alt: 'QRIS Payment',
                            className: 'nicepay-qris-image'
                        })
                    ),
                    createElement('div', { className: 'nicepay-qris-info' },
                        createElement('p', { className: 'qris-instruction' },
                            'Pembayaran menggunakan QRIS dapat dilakukan melalui berbagai aplikasi e-wallet dan mobile banking yang mendukung QRIS'
                        )
                    ),
                    
                    createElement('input', {
                        type: 'hidden',
                        name: 'mitraCdQRISV2',
                        value: mitraCd
                    })
                )
            )
        );
    };

    registerPaymentMethod({
        name: 'nicepay_qris',
        label: 'NICEPay QRIS',
        content: createElement(NicepayQrisComponent),
        edit: createElement(NicepayQrisComponent),
        canMakePayment: () => true,
        ariaLabel: 'QRIS payment method',
        paymentMethodId: 'nicepay_qris',
        supports: {
            features: ['products'],
            showSaveOption: false,
            showSavedCards: false
        },
        
        getData: () => {
            return {
                mitraCdQRISV2: 'QSHP' 
            };
        }
    });
}