<?php
if (!defined('ABSPATH')) {
    exit;
}

class NICEPay_CCLog_Manager {
    private $parent_slug = 'woocommerce';
    private $capability = 'manage_woocommerce';
    private $option_name = 'nicepay_cc_debug_logs';
    
    public function __construct() {
         add_action('admin_menu', array($this, 'maybe_add_admin_menu'), 99);
        
       
        add_action('wp_ajax_nicepay_clear_cc_logs', array($this, 'ajax_clear_logs'));
        
        
        add_action('nicepay_cleanup_cc_logs', array($this, 'cleanup_logs'));
        
      
        register_deactivation_hook(NICEPAY_CCV2_PLUGIN_FILE, array($this, 'deactivate'));
        
        
        $this->schedule_cleanup();
        add_action('admin_init', array($this, 'check_debug_status'));
    }
    private function is_debug_enabled() {
        $gateway_settings = get_option('woocommerce_nicepay_ccv2_settings', array());
        return isset($gateway_settings['debug']) && 
               ($gateway_settings['debug'] === 'yes' || 
                $gateway_settings['debug'] === '1' || 
                $gateway_settings['debug'] === true);
    }
     public function check_debug_status() {
        static $checked = false;
        
        if ($checked) {
            return;
        }
        
        $checked = true;
        
        if (!$this->is_debug_enabled()) {
            update_option('nicepay_cc_debug_enabled', 'no');
        } else {
            update_option('nicepay_cc_debug_enabled', 'yes');
        }
    }

      public function maybe_add_admin_menu() {
        if ($this->is_debug_enabled()) {
            add_submenu_page(
                $this->parent_slug,
                __('NICEPay CC Logs', 'nicepay-cc-gateway'),
                __('NICEPay CC Logs', 'nicepay-cc-gateway'),
                $this->capability,
                'nicepay-cc-logs',
                array($this, 'render_logs_page')
            );
        }
    }
    
    public function schedule_cleanup() {
        if (!wp_next_scheduled('nicepay_cleanup_cc_logs')) {
            wp_schedule_event(time(), 'daily', 'nicepay_cleanup_cc_logs');
        }
    }
    
    public function deactivate() {
        wp_clear_scheduled_hook('nicepay_cleanup_cc_logs');
    }
    
    // public function add_admin_menu() {
    //     add_submenu_page(
    //         $this->parent_slug,
    //         __('NICEPay CC Logs', 'nicepay-cc-gateway'),
    //         __('NICEPay CC Logs', 'nicepay-cc-gateway'),
    //         $this->capability,
    //         'nicepay-cc-logs',
    //         array($this, 'render_logs_page')
    //     );
        
    //     // Handler untuk download
    //     if (isset($_GET['page']) && $_GET['page'] === 'nicepay-cc-logs' && 
    //         isset($_GET['action']) && $_GET['action'] === 'download_logs' && 
    //         isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'nicepay_download_cc_logs')) {
    //         $this->download_logs();
    //     }
    // }
    
    public function ajax_clear_logs() {
        check_ajax_referer('nicepay_clear_cc_logs', 'nonce');
        
        if (!current_user_can($this->capability)) {
            wp_send_json_error('Permission denied');
        }
        
        delete_option($this->option_name);
        wp_send_json_success();
    }
    
     public function cleanup_logs() {
        // Ambil settings dari payment gateway
        $gateway_settings = get_option('woocommerce_nicepay_ccv2_settings', array());
        $retention_days = isset($gateway_settings['log_retention']) ? (int) $gateway_settings['log_retention'] : 7;
        
        // Skip jika retention diatur "keep indefinitely"
        if ($retention_days <= 0) {
            return;
        }
        
        $logs = get_option($this->option_name, array());
        $cutoff_time = date('Y-m-d H:i:s', strtotime("-{$retention_days} days"));
        
        $filtered_logs = array_filter($logs, function($log) use ($cutoff_time) {
            return $log['time'] >= $cutoff_time;
        });
        
        if (count($filtered_logs) !== count($logs)) {
            update_option($this->option_name, $filtered_logs);
        }
    }
    
    public function download_logs() {
        if (!current_user_can($this->capability)) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'nicepay-cc-gateway'));
        }
        
        $logs = get_option($this->option_name, array());
        
        // Format logs sebagai CSV
        $csv = "Time,Type,Message\n";
        foreach ($logs as $log) {
            $message = str_replace('"', '""', $log['message']); // Escape double quotes
            $csv .= '"' . $log['time'] . '","' . $log['type'] . '","' . $message . "\"\n";
        }
        
        // Set headers untuk download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="nicepay_cc_logs_' . date('Y-m-d_H-i-s') . '.csv"');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        
        echo $csv;
        exit;
    }
    
    public function render_logs_page() {
        // Tambahkan debug message
        error_log('NICEPay_CCLog_Manager::render_logs_page called');

         if (!$this->is_debug_enabled()) {
            echo '<div class="notice notice-warning"><p>' . 
                __('Warning: Debug mode is currently disabled in the NICEPay CC settings. No new logs will be recorded.', 'nicepay-cc-gateway') . 
                ' <a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=nicepay_ccv2') . '">' . 
                __('Enable debug mode', 'nicepay-cc-gateway') . '</a>' .
                '</p></div>';
        }
        
        // Handle clear logs action
        if (isset($_GET['action']) && $_GET['action'] === 'clear_logs' && 
            isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'nicepay_clear_cc_logs')) {
            delete_option($this->option_name);
            echo '<div class="notice notice-success"><p>' . __('Logs cleared successfully.', 'nicepay-cc-gateway') . '</p></div>';
        }
        
        // Handle test log action
        if (isset($_GET['action']) && $_GET['action'] === 'test_logs' && 
            isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'nicepay_test_cc_logs')) {
            $this->create_test_logs();
            echo '<div class="notice notice-success"><p>' . __('Test logs created successfully.', 'nicepay-cc-gateway') . '</p></div>';
        }
        
        $logs = get_option($this->option_name, array());
        
        // Render the page
        ?>
        <div class="wrap">
            <h1><?php echo __('NICEPay CC Debug Logs', 'nicepay-cc-gateway'); ?></h1>
            
            <div class="tablenav top">
                <div class="alignleft actions">
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nicepay-cc-logs&action=clear_logs'), 'nicepay_clear_cc_logs'); ?>" 
                       class="button" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to clear all logs?', 'nicepay-cc-gateway')); ?>');">
                       <?php echo __('Clear Logs', 'nicepay-cc-gateway'); ?>
                    </a>
                    
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nicepay-cc-logs&action=test_logs'), 'nicepay_test_cc_logs'); ?>" 
                       class="button">
                       <?php echo __('Add Test Logs', 'nicepay-cc-gateway'); ?>
                    </a>
                    
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nicepay-cc-logs&action=download_logs'), 'nicepay_download_cc_logs'); ?>" 
                       class="button">
                       <?php echo __('Download Logs', 'nicepay-cc-gateway'); ?>
                    </a>
                    
                    <select id="log-filter-type">
                        <option value=""><?php echo __('All types', 'nicepay-cc-gateway'); ?></option>
                        <option value="info"><?php echo __('Info', 'nicepay-cc-gateway'); ?></option>
                        <option value="error"><?php echo __('Error', 'nicepay-cc-gateway'); ?></option>
                        <option value="warning"><?php echo __('Warning', 'nicepay-cc-gateway'); ?></option>
                    </select>
                    
                    <button class="button" id="log-filter-button"><?php echo __('Filter', 'nicepay-cc-gateway'); ?></button>
                </div>
                
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo sprintf(_n('%s item', '%s items', count($logs), 'nicepay-cc-gateway'), number_format_i18n(count($logs))); ?></span>
                </div>
                <br class="clear">
            </div>
            
            <table class="wp-list-table widefat fixed striped posts">
                <thead>
                    <tr>
                        <th scope="col" class="manage-column column-time"><?php echo __('Time', 'nicepay-cc-gateway'); ?></th>
                        <th scope="col" class="manage-column column-type"><?php echo __('Type', 'nicepay-cc-gateway'); ?></th>
                        <th scope="col" class="manage-column column-message"><?php echo __('Message', 'nicepay-cc-gateway'); ?></th>
                    </tr>
                </thead>
                <tbody id="the-list">
                    <?php if (empty($logs)) : ?>
                        <tr>
                            <td colspan="3"><?php echo __('No logs found.', 'nicepay-cc-gateway'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach (array_reverse($logs) as $log) : ?>
                            <tr class="log-entry log-type-<?php echo esc_attr($log['type']); ?>">
                                <td class="column-time">
                                    <?php echo esc_html($log['time']); ?>
                                </td>
                                <td class="column-type">
                                    <span class="log-type log-type-<?php echo esc_attr($log['type']); ?>">
                                        <?php echo esc_html(ucfirst($log['type'])); ?>
                                    </span>
                                </td>
                                <td class="column-message">
                                    <?php 
                                    // Deteksi dan format JSON untuk keterbacaan lebih baik
                                    $message = $log['message'];
                                    if (substr($message, 0, 1) === '{' && json_decode($message)) {
                                        echo '<pre class="json-message">' . esc_html(json_encode(json_decode($message), JSON_PRETTY_PRINT)) . '</pre>';
                                    } else {
                                        echo esc_html($message);
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <style>
            .log-type {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-weight: bold;
            }
            .log-type-info {
                background-color: #e5f5fa;
                color: #0073aa;
            }
            .log-type-error {
                background-color: #fbeaea;
                color: #dc3232;
            }
            .log-type-warning {
                background-color: #fff8e5;
                color: #ffb900;
            }
            .column-time {
                width: 150px;
            }
            .column-type {
                width: 100px;
            }
            pre.json-message {
                white-space: pre-wrap;
                word-wrap: break-word;
                background: #f7f7f7;
                padding: 10px;
                margin: 0;
                max-height: 200px;
                overflow: auto;
            }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#log-filter-button').on('click', function() {
                var filterType = $('#log-filter-type').val();
                
                if (filterType === '') {
                    $('.log-entry').show();
                } else {
                    $('.log-entry').hide();
                    $('.log-type-' + filterType).closest('tr').show();
                }
            });
        });
        </script>
        <?php
    }
    
    // Method untuk membuat test logs
    private function create_test_logs() {
        $test_logs = array(
            array(
                'time'    => current_time('mysql'),
                'type'    => 'info',
                'message' => 'Test CC log entry - info'
            ),
            array(
                'time'    => current_time('mysql'),
                'type'    => 'warning',
                'message' => 'Test CC log entry - warning'
            ),
            array(
                'time'    => current_time('mysql'),
                'type'    => 'error',
                'message' => 'Test CC log entry - error'
            ),
            array(
                'time'    => current_time('mysql'),
                'type'    => 'info',
                'message' => 'Test CC Payment process: Transaction started'
            ),
            array(
                'time'    => current_time('mysql'),
                'type'    => 'info',
                'message' => json_encode([
                    'orderId' => '12345',
                    'amount' => '150000',
                    'cardType' => 'VISA',
                    'status' => 'PENDING'
                ])
            )
        );
        
        $logs = get_option($this->option_name, array());
        $logs = array_merge($logs, $test_logs);
        
        // Batasi jumlah log entries
        if (count($logs) > 1000) {
            $logs = array_slice($logs, -1000);
        }
        
        update_option($this->option_name, $logs);
        error_log('NICEPay test CC logs created');
    }
    
    // Static method untuk logging
    public static function cclog($message, $type = 'info') {
       $gateway_settings = get_option('woocommerce_nicepay_ccv2_settings', array());
        
        $debug_enabled = isset($gateway_settings['debug']) && 
                        ($gateway_settings['debug'] === 'yes' || 
                         $gateway_settings['debug'] === '1' || 
                         $gateway_settings['debug'] === true);
        
        // Selalu log error untuk troubleshooting bahkan jika debug dinonaktifkan
        if ($type === 'error') {
            error_log("NICEPay CC Log ({$type}): " . (is_array($message) || is_object($message) ? json_encode($message) : $message));
        }
        
        // Jika debug dinonaktifkan, tidak perlu menyimpan log
        if (!$debug_enabled) {
            return;
        }
        
        $log_entry = array(
            'time'    => current_time('mysql'),
            'type'    => $type,
            'message' => is_array($message) || is_object($message) ? json_encode($message) : $message
        );
        
        $logs = get_option('nicepay_cc_debug_logs', array());
        $logs[] = $log_entry;

        // Batasi jumlah log entries yang disimpan
        if (count($logs) > 1000) {
            $logs = array_slice($logs, -1000);
        }
        
        update_option('nicepay_cc_debug_logs', $logs);
    }
}

// Inisialisasi class
new NICEPay_CCLog_Manager();