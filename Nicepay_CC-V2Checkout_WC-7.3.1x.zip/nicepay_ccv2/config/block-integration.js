console.log('NICEPay CCV2 script loaded');

document.addEventListener('DOMContentLoaded', function() {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log('Initializing Credit Card method');
        initNicepayccv2();
    } else {
        console.error('Required dependencies not available');
    }
});

function initNicepayccv2() {
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment } = window.wp.element;

    const NicepayCCComponent = () => {
        return createElement(Fragment, null,
            createElement('div', { className: 'nicepay-cc-container' },
                createElement('div', { className: 'nicepay-cc-content' },
                    // Logo kartu kredit
                    createElement('div', { className: 'nicepay-cc-logos' },
                        createElement('img', {
                            src: ccData.pluginUrl + 'images/nicepay.png',
                            alt: 'Credit Card Payment',
                            className: 'nicepay-cc-image'
                        })
                    ),
                    // Informasi pembayaran
                    createElement('div', { className: 'nicepay-cc-info' },
                        createElement('p', { className: 'cc-instruction' },
                            'Credit Card Payment Gateway via NICEPay'
                        )
                    ),
                    // Hidden input jika diperlukan
                    createElement('input', {
                        type: 'hidden',
                        name: 'payment_method',
                        value: 'nicepay_ccv2'
                    })
                )
            )
        );
    };

    registerPaymentMethod({
        name: 'nicepay_ccv2',
        label: 'Credit Card (Pembayaran Dengan Kartu Kredit)',
        content: createElement(NicepayCCComponent),
        edit: createElement(NicepayCCComponent),
        canMakePayment: () => true,
        ariaLabel: 'Credit Card payment method',
        paymentMethodId: 'nicepay_ccv2',
        supports: {
            features: ['products']
        },
        getData: () => {
            return {
                paymentMethod: 'nicepay_ccv2'
            };
        }
    });
}