<?php
/*
  Plugin Name: NICEPay Credit Card Payment Gateway
  Plugin URI: http://nicepay.co.id
  Description: NICEPay Plugin for WooCommerce to support payment via Credit Card
  Version: 7.3.1
  Author: NICEPay <codeNinja>
  Author URI: http://nicepay.co.id
*/

// Security check
if (!defined('ABSPATH')) {
    exit;
}

ob_start();
// Define plugin constants
define('NICEPAY_CCV2_VERSION', '7.2');
define('NICEPAY_CCV2_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NICEPAY_CCV2_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NICEPAY_CCV2_PLUGIN_FILE', __FILE__);
// Fungsi logging
// function nicepay_cc_log($message, $type = 'info') {
//     $log_file = WP_CONTENT_DIR . '/debug.log';
//     $timestamp = current_time('Y-m-d H:i:s');
    
//     if (is_array($message) || is_object($message)) {
//         $message = print_r($message, true);
//     }
    
//     $log_message = sprintf("[%s] CC %s: %s\n", $timestamp, strtoupper($type), $message);
//     error_log($log_message, 3, $log_file);
// }
require_once(NICEPAY_CCV2_PLUGIN_PATH . 'config/class-cclog-manager.php');
function nicepay_cc_log($message, $type = 'info') {
    if (class_exists('NICEPay_CCLog_Manager')) {
        NICEPay_CCLog_Manager::cclog($message, $type);
    } else {
        // Fallback to error_log if log manager not available
        error_log("NICEPay CC {$type}: {$message}");
    }
}

// Inisialisasi plugin setelah semua plugin dimuat
add_action('plugins_loaded', 'woocommerce_nicepay_ccv2_init', 0);

function woocommerce_nicepay_ccv2_init() {
    nicepay_cc_log('Initializing CC Payment Gateway plugin', 'init');
    
    // Pastikan WooCommerce ada
    if (!class_exists('WooCommerce')) {
        nicepay_cc_log('WooCommerce is not installed or activated', 'error');
        return;
    }

    try {
        // Load main gateway class
        require_once(NICEPAY_CCV2_PLUGIN_PATH . 'config/ccv2.php');
        nicepay_cc_log('Gateway class loaded successfully', 'debug');
        
        // Register gateway dan scripts
        add_filter('woocommerce_payment_gateways', 'add_nicepay_ccv2_gateway');
        
        // Register block support
        add_action('wp_enqueue_scripts', 'register_nicepay_cc_scripts');
        
        if (class_exists('Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry')) {
            add_action('init', 'register_nicepay_ccv2_block_support');
        }
        nicepay_cc_log('Plugin initialized successfully', 'info');
        
    } catch (Exception $e) {
        nicepay_cc_log('Failed to initialize plugin: ' . $e->getMessage(), 'error');
    }
}

/**
 * Add the Credit Card Gateway to WooCommerce
 */
function add_nicepay_ccv2_gateway($methods) {
    nicepay_cc_log('Adding CC gateway to payment methods', 'debug');
    $methods[] = 'WC_Gateway_NICEPay_CCV2';
    return $methods;
}

function register_nicepay_cc_scripts() {
    if (!class_exists('WC_Gateway_NICEPay_CCV2') || !is_checkout()) {
        return;
    }

    try {
        $gateway = new WC_Gateway_NICEPay_CCV2();
        $checkout_mode = $gateway->get_option('enable_blocks', 'classic');
        
        // Enqueue CSS for both modes
        wp_enqueue_style(
            'nicepay-cc-style',
            NICEPAY_CCV2_PLUGIN_URL . 'config/ccv2.css',
            array(),
            NICEPAY_CCV2_VERSION
        );

        if ($checkout_mode === 'blocks') {
            // Blocks mode scripts
            wp_enqueue_script(
                'nicepay-cc-blocks-integration',
                NICEPAY_CCV2_PLUGIN_URL . 'config/block-integration.js',
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'),
                NICEPAY_CCV2_VERSION,
                true
            );

            $block_data = array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('nicepay-cc-nonce'),
                'pluginUrl' => NICEPAY_CCV2_PLUGIN_URL,
                'merchantId' => $gateway->get_option('iMid', ''),
                'version' => NICEPAY_CCV2_VERSION
            );
            
            wp_localize_script(
                'nicepay-cc-blocks-integration',
                'ccData',
                $block_data
            );
        } else {
            // Classic mode scripts
            wp_enqueue_script(
                'nicepay-classic-checkout',
                NICEPAY_CCV2_PLUGIN_URL . 'config/classic-checkout.js',
                array('jquery'),
                NICEPAY_CCV2_VERSION,
                true
            );

            $classic_data = array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => NICEPAY_CCV2_PLUGIN_URL,
                'nonce' => wp_create_nonce('nicepay-ccv2-nonce'),
                'merchantId' => $gateway->get_option('iMid', ''),
                'version' => NICEPAY_CCV2_VERSION
            );
            
            wp_localize_script(
                'nicepay-classic-checkout',
                'nicepayData',
                $classic_data
            );
        }
        
        nicepay_cc_log('Scripts registered successfully for ' . $checkout_mode . ' mode', 'debug');
    } catch (Exception $e) {
        nicepay_cc_log('Failed to register scripts: ' . $e->getMessage(), 'error');
    }
}


/**
 * Register Block Support for WooCommerce Blocks
 */
function register_nicepay_ccv2_block_support() {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        nicepay_cc_log('WooCommerce Blocks not available', 'debug');
        return;
    }

    try {
        // Inisialisasi gateway
        if (!class_exists('WC_Gateway_NICEPay_CCV2')) {
            nicepay_cc_log('Gateway class not available', 'debug');
            return;
        }
        
        $gateway = new WC_Gateway_NICEPay_CCV2();
        
        // Hanya daftarkan jika mode blocks diaktifkan dan gateway enabled
        if ($gateway->get_option('enable_blocks') === 'blocks' && $gateway->get_option('enabled') === 'yes') {
            if (class_exists('Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry')) {   
                nicepay_cc_log('Block support would be registered here', 'debug');
            }
            nicepay_cc_log('Block support registered successfully', 'debug');
        } else {
            nicepay_cc_log('Block support not enabled in settings', 'debug');
        }
    } catch (Exception $e) {
        nicepay_cc_log('Failed to register block support: ' . $e->getMessage(), 'error');
    }
}
