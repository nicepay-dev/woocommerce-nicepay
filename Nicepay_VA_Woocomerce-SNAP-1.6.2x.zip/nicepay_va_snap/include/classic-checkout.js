jQuery(function($) {
    console.log('NICEPay classic checkout initialized');

    // Handler untuk perubahan bank
    $(document).on('change', '#nicepay-bank-select', function() {
        var selectedBank = $(this).val();
        console.log('Selected bank:', selectedBank);

        if (selectedBank) {
            $.ajax({
                url: nicepayData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_bank',
                    bank_code: selectedBank,
                    security: nicepayData.nonce || '' // Gunakan nonce jika tersedia
                },
                success: function(response) {
                    console.log('Bank selection saved:', response);
                },
                error: function(error) {
                    console.error('Error saving bank selection:', error);
                }
            });
        }
    });

    $('form.checkout').on('submit', function(e) {
        // Periksa apakah metode pembayaran yang dipilih adalah nicepay
        var paymentMethod = $('input[name="payment_method"]:checked').val();
        
        if (paymentMethod === 'nicepay_va_snap') {
            var selectedBank = $('#nicepay-bank-select').val();
            
            // Validasi pemilihan bank
            if (!selectedBank) {
                e.preventDefault(); // Mencegah submit form
                
                // Tampilkan pesan error
                if ($('.nicepay-error-message').length === 0) {
                    $('#nicepay-bank-select').after('<div class="nicepay-error-message" style="color: red; margin-top: 5px;">Silakan pilih bank untuk pembayaran</div>');
                }
                
                // Scroll ke elemen bank select
                $('html, body').animate({
                    scrollTop: $('#nicepay-bank-select').offset().top - 100
                }, 500);
                
                return false;
            } else {
                // Hapus pesan error jika ada
                $('.nicepay-error-message').remove();
                
                // Pastikan nilai bank tersimpan di form
                if (!$('input[name="nicepay_bank"]').length) {
                    $(this).append('<input type="hidden" name="nicepay_bank" value="' + selectedBank + '">');
                } else {
                    $('input[name="nicepay_bank"]').val(selectedBank);
                }
            }
        }
    });

    // Tambahkan event handler untuk update ketika payment method berubah
    $(document.body).on('payment_method_selected', function() {
        // Periksa jika bank select sudah dimuat dan nicepay dipilih
        var paymentMethod = $('input[name="payment_method"]:checked').val();
        
        if (paymentMethod === 'nicepay_va_snap') {
            // Hapus pesan error jika ada
            $('.nicepay-error-message').remove();
            
            // Pre-select bank jika sebelumnya sudah memilih
            if (nicepayData.selected_bank) {
                $('#nicepay-bank-select').val(nicepayData.selected_bank);
            }
        }
    });

    // Inisialisasi - Jika select bank sudah ada saat halaman dimuat
    if ($('#nicepay-bank-select').length) {
        // Trigger change jika nilai sudah dipilih
        if ($('#nicepay-bank-select').val()) {
            $('#nicepay-bank-select').trigger('change');
        }
    }
});