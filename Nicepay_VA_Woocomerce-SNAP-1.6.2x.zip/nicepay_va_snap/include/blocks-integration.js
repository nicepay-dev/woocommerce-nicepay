(function() {
    console.log("Loading VA Plugin");
    
    // Gunakan React elements dari WP
    const wpElement = window.wp.element;
    const { createElement, useState } = wpElement;
    
    // VA Component
    const NicepayVASNAPComponent = () => {
        const [selectedBank, setSelectedBank] = useState('');
        
        const banks = [
            { code: 'BMRI', name: 'Bank Mandiri' },
            { code: 'BNIN', name: 'Bank BNI' },
            { code: 'BRIN', name: 'Bank BRI' },
            { code: 'BBBA', name: 'Bank Permata' },
            { code: 'CENA', name: 'Bank BCA' },
            { code: 'IBBK', name: 'Maybank' },
            { code: 'BBBB', name: 'Bank Permata Syariah' },
            { code: 'HNBN', name: 'Bank KEB Hana Indonesia' },
            { code: 'BNIA', name: 'Bank CIMB' },
            { code: 'BDIN', name: 'Bank Bank Danamon' },
            { code: 'PDJB', name: 'Bank BJB' },
            { code: 'YUDB', name: 'Bank Neo Commerce (BNC)' },
            { code: 'BDKI', name: 'Bank DKI' },
            
        ];
        
        const handleBankChange = (e) => {
            const selectedBankCode = e.target.value;
            console.log('Bank selected:', selectedBankCode);
            setSelectedBank(selectedBankCode);
            saveBankSelection(selectedBankCode);
        };
        
        const saveBankSelection = (bankCode) => {
            console.log('Attempting to save bank selection:', bankCode);
            if (typeof jQuery !== 'undefined' && typeof nicepayVAData !== 'undefined') {
                jQuery.ajax({
                    url: nicepayVAData.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'set_nicepay_bank',
                        bank_code: bankCode
                    },
                    success: function(response) {
                        console.log('Bank selection saved:', response);
                    },
                    error: function(error) {
                        console.error('Error saving bank selection:', error);
                    }
                });
            } else {
                console.error('jQuery or nicepayVAData is not available');
            }
        };

        return createElement('div', { className: 'nicepay-vasnap-container' }, [
            createElement('div', { className: 'nicepay-vasnap-header' }, [
                createElement('img', { 
                    src: nicepayVAData.pluginUrl + '/images/logobank.png', 
                    alt: 'Bank Icon', 
                    className: 'nicepay-vasnap-bank-icon' 
                }),
            ]),
            createElement('div', { className: 'nicepay-vasnap-bank-select' }, [
                createElement('label', { htmlFor: 'nicepay-bank-select' }, 'Pilih Bank:'),
                createElement('select',
                    {
                        name: 'nicepay_bank',
                        id: 'nicepay-bank-select',
                        onChange: handleBankChange,
                        value: selectedBank
                    },
                    [
                        createElement('option', { value: '' }, 'Pilih Bank'),
                        ...banks.map(bank =>
                            createElement('option', { value: bank.code, key: bank.code }, bank.name)
                        )
                    ]
                )
            ]),
            createElement('p', { className: 'nicepay-vasnap-instruction' }, 'Silakan pilih bank untuk pembayaran Virtual Account Anda.')
        ]);
    };

    // Fungsi untuk registrasi yang aman
    const safelyRegisterVAPaymentMethod = function() {
        console.log("Attempting to register VA Payment Method");
        
        // Periksa apakah registry tersedia
        if (!window.wc || !window.wc.wcBlocksRegistry) {
            console.error('WooCommerce Blocks registry tidak tersedia untuk VA');
            setTimeout(safelyRegisterVAPaymentMethod, 300);
            return;
        }
        
        try {
            // Hanya jalankan sekali menggunakan flag
            if (window.nicepay_va_registered === true) {
                console.log("VA already registered, skipping");
                return;
            }
            
            const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
            
            registerPaymentMethod({
                name: "nicepay_va_snap",
                label: "NICEPay Virtual Account SNAP",
                content: createElement(NicepayVASNAPComponent),
                edit: createElement(NicepayVASNAPComponent),
                canMakePayment: () => true,
                ariaLabel: "NICEPay Virtual Account SNAP payment method",
                supports: {
                    features: ['products'],
                },
            });
            
            // Set flag global
            window.nicepay_va_registered = true;
            console.log("VA Payment Method successfully registered");
        } catch (error) {
            console.error("Error registering VA Payment Method:", error);
            
            // Retry dengan delay jika gagal
            setTimeout(safelyRegisterVAPaymentMethod, 500);
        }
    };

    // Cek apakah document sudah siap
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            // Register segera untuk VA
            safelyRegisterVAPaymentMethod();
        });
    } else {
        // Document sudah siap, register langsung
        safelyRegisterVAPaymentMethod();
    }
})();