Plugin VA V1.1.0
- Plugin VA version SNAP
- Update version PHP
Versi 1.2.0
- Fixing Checkout mode classic ( Non Basis blok )
Versi 1.3.0
- Fixing Checkout Mode Basis Blok
Versi 1.4.0
- Fixing Dry_Limit
Versi 1.5.0 
- Update payment status to completed
- fitur one klik copy VA
Versi 1.6.0
- Add Nicepay Log
Versi 1.6.1
- Add handle response check status
Versi 1.6.2
- Add Fitur selected bank on option