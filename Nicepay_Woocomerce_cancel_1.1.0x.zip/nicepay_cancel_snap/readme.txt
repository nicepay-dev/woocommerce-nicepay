=== NICEPay Payment Gateway for WooCommerce ===
Contributors: nicepay
Plugin : Cancel
Tags: woocommerce, cancel, ewallet, virtual-account, qris, Credit Card, Payloan
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 8.2 ++
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

---ChangeLog---
--1.1.0---
*Create Plugin Cancel