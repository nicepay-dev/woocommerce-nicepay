<?php
/**
 * Debug file untuk troubleshoot plugin activation
 * Letakkan file ini di wp-content/plugins/nicepay-cancel-transaction/debug-plugin.php
 * Lalu akses via browser: yoursite.com/wp-content/plugins/nicepay-cancel-transaction/debug-plugin.php
 */

// For debugging purpose, allow direct access
if (!defined('ABSPATH')) {
    define('ABSPATH', '../../../');
}

// Include WordPress bootstrap
require_once(ABSPATH . 'wp-config.php');
require_once(ABSPATH . 'wp-includes/wp-db.php');
require_once(ABSPATH . 'wp-includes/pluggable.php');

echo "<h2>🔍 NICEPay Cancel Plugin Debug</h2>";
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.success { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
.warning { color: orange; font-weight: bold; }
.info { color: blue; font-weight: bold; }
pre { background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
</style>";

// Check PHP version
echo "<h3>1. 🐘 PHP Environment Check</h3>";
echo "<table>";
echo "<tr><th>Item</th><th>Value</th><th>Status</th></tr>";
echo "<tr><td>PHP Version</td><td>" . phpversion() . "</td>";
if (version_compare(phpversion(), '7.4', '>=')) {
    echo "<td class='success'>✓ Compatible</td>";
} else {
    echo "<td class='error'>✗ Too Old (Need 7.4+)</td>";
}
echo "</tr>";

$wordpress_loaded = defined('ABSPATH');
$wp_status_class = $wordpress_loaded ? 'success' : 'error';
$wp_status_text = $wordpress_loaded ? '✅ OK' : '❌ Failed';
$wp_value = $wordpress_loaded ? 'Loaded' : 'Not Loaded';
echo "<tr><td>WordPress</td><td>$wp_value</td><td class='$wp_status_class'>$wp_status_text</td></tr>";


$woo_available = class_exists('WooCommerce');
$woo_status_class = $woo_available ? 'success' : 'warning';
$woo_status_text = $woo_available ? '✔ Active' : '⚠ Not Detected';
$woo_value = $woo_available ? 'Available' : 'Not Available';
echo "<tr><td>WooCommerce</td><td>$woo_value</td><td class='$woo_status_class'>$woo_status_text</td></tr>";

// Check file structure
echo "<h3>2. 📁 File Structure Check</h3>";
$plugin_dir = dirname(__FILE__);
$required_files = array(
    'nicepay-cancel-transaction.php' => 'Main Plugin File',
    'assets/admin.js' => 'JavaScript Admin',
    'assets/admin.css' => 'CSS Admin',
    'includes/class-admin-settings.php' => 'Settings Class',
    'includes/class-nicepay-api.php' => 'API Class'
);

echo "<table>";
echo "<tr><th>File</th><th>Status</th><th>Size</th><th>Modified</th></tr>";

foreach ($required_files as $file => $description) {
    $file_path = $plugin_dir . '/' . $file;
    $exists = file_exists($file_path);
    $readable = $exists ? is_readable($file_path) : false;
    
    echo "<tr>";
    echo "<td><strong>" . $description . "</strong><br><code>" . $file . "</code></td>";
    
    if ($exists && $readable) {
        echo "<td class='success'>✓ OK</td>";
        echo "<td>" . number_format(filesize($file_path)) . " bytes</td>";
        echo "<td>" . date('Y-m-d H:i:s', filemtime($file_path)) . "</td>";
    } elseif ($exists && !$readable) {
        echo "<td class='error'>✗ Not Readable</td>";
        echo "<td>-</td><td>-</td>";
    } else {
        echo "<td class='error'>✗ Missing</td>";
        echo "<td>-</td><td>-</td>";
    }
    echo "</tr>";
}
echo "</table>";

// Check file permissions
echo "<h3>3. 🔐 File Permissions Check</h3>";
$main_file = $plugin_dir . '/nicepay-cancel-transaction.php';
if (file_exists($main_file)) {
    $perms = fileperms($main_file);
    $perms_octal = substr(sprintf('%o', $perms), -4);
    echo "<table>";
    echo "<tr><th>Item</th><th>Value</th><th>Status</th></tr>";
   echo "<tr><td>Main File Permissions</td><td>" . $perms_octal . "</td>";
echo "<td class='" . (is_readable($main_file) ? 'success' : 'error') . "'>" . 
     (is_readable($main_file) ? "✓ Readable" : "✗ Not Readable") . "</td></tr>";
    echo "<tr><td>Directory Writable</td><td>" . (is_writable($plugin_dir) ? 'Yes' : 'No') . "</td>";
    echo "<td class='" . (is_writable($plugin_dir) ? 'success' : 'warning') . "'>" .
     (is_writable($plugin_dir) ? '✓ OK' : '⚠ Read Only') . "</td></tr>";
    echo "</table>";
} else {
    echo "<p class='error'>❌ Main plugin file not found!</p>";
}

// Check PHP syntax
echo "<h3>4. ⚡ PHP Syntax Check</h3>";
if (file_exists($main_file)) {
    $output = array();
    $return_var = 0;
    exec("php -l " . escapeshellarg($main_file) . " 2>&1", $output, $return_var);
    
    if ($return_var === 0) {
        echo "<p class='success'>✅ PHP Syntax: OK</p>";
    } else {
        echo "<p class='error'>❌ PHP Syntax Errors:</p>";
        echo "<pre>" . htmlspecialchars(implode("\n", $output)) . "</pre>";
    }
} else {
    echo "<p class='warning'>⚠ Cannot check syntax - file missing</p>";
}

// WordPress Integration Check
echo "<h3>5. 🔌 WordPress Integration Check</h3>";
if (defined('ABSPATH')) {
    echo "<table>";
    echo "<tr><th>Check</th><th>Status</th><th>Details</th></tr>";
    
    // Check if plugin is detected by WordPress
    if (!function_exists('get_plugins')) {
        require_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }
    
    $all_plugins = get_plugins();
    $plugin_found = false;
    $plugin_key = '';
    
    foreach ($all_plugins as $plugin_file => $plugin_data) {
        if (strpos($plugin_file, 'nicepay-cancel') !== false) {
            $plugin_found = true;
            $plugin_key = $plugin_file;
            break;
        }
    }
    
    echo "<tr><td>Plugin Detected by WordPress</td>";
    if ($plugin_found) {
        echo "<td class='success'>✓ Yes</td>";
        echo "<td>Key: <code>" . $plugin_key . "</code></td>";
    } else {
        echo "<td class='error'>✗ No</td>";
        echo "<td>Plugin not in WordPress plugin list</td>";
    }
    echo "</tr>";
    
    // Check if plugin is active
    $is_active = $plugin_found ? is_plugin_active($plugin_key) : false;
    echo "<tr><td>Plugin Active</td>";
    echo "<td class='" . ($is_active ? 'success' : 'warning') . "'>" .
     ($is_active ? "✓ Active" : "⚠ Inactive") . "</td>";
    echo "<td>" . ($is_active ? 'Plugin is currently active' : 'Plugin needs activation') . "</td>";
    echo "</tr>";
    
    echo "</table>";
} else {
    echo "<p class='error'>❌ WordPress not loaded properly</p>";
}

// Plugin Header Check
echo "<h3>6. 📋 Plugin Header Check</h3>";
if (file_exists($main_file)) {
    $plugin_content = file_get_contents($main_file, false, null, 0, 2000); // Read first 2KB
    $headers = array(
        'Plugin Name' => 'Plugin Name:',
        'Version' => 'Version:',
        'Description' => 'Description:',
        'Author' => 'Author:',
        'Text Domain' => 'Text Domain:'
    );
    
    echo "<table>";
    echo "<tr><th>Header</th><th>Status</th><th>Value</th></tr>";
    
    foreach ($headers as $header => $search) {
        $found = strpos($plugin_content, $search) !== false;
        echo "<tr><td>" . $header . "</td>";
       echo "<td class='" . ($found ? 'success' : 'error') . "'>" .
     ($found ? "✓ Found" : "✘ Missing") . "</td>";
        
        if ($found) {
            // Extract the value
            preg_match('/' . preg_quote($search, '/') . '\s*(.+)/i', $plugin_content, $matches);
            $value = isset($matches[1]) ? trim($matches[1]) : 'Found but no value';
            echo "<td>" . htmlspecialchars($value) . "</td>";
        } else {
            echo "<td>-</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
}

// Database Check
echo "<h3>7. 🗄️ Database Check</h3>";
global $wpdb;
if (isset($wpdb)) {
    echo "<table>";
    echo "<tr><th>Check</th><th>Status</th><th>Details</th></tr>";
    
    // Check if options table accessible
    $test_option = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'siteurl'");
    echo "<tr><td>Database Connection</td>";
    echo "<td class='" . ($test_option ? 'success' : 'error') . "'>" .
     ($test_option ? "✓ OK" : "✘ Failed") . "</td>";
    echo "<td>" . ($test_option ? "Site URL: " . $test_option : "Cannot access options table") . "</td>";
    echo "</tr>";
    
    // Check for plugin options
    $plugin_options = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'nicepay_cancel_options'");
    echo "<tr><td>Plugin Settings</td>";
    echo "<td class='" . ($plugin_options ? 'success' : 'warning') . "'>" .
     ($plugin_options ? "✓ Found" : "⚠ Not Set") . "</td>";
    echo "<td>" . ($plugin_options ? "Settings exist" : "No settings saved yet") . "</td>";
    echo "</tr>";
    
    echo "</table>";
} else {
    echo "<p class='error'>❌ WordPress database not available</p>";
}

// Memory and Server Info
echo "<h3>8. 🖥️ Server Information</h3>";
echo "<table>";
echo "<tr><th>Setting</th><th>Value</th><th>Status</th></tr>";

$memory_limit = ini_get('memory_limit');
echo "<tr><td>PHP Memory Limit</td><td>" . $memory_limit . "</td>";
$memory_bytes = wp_convert_hr_to_bytes($memory_limit);
if ($memory_bytes >= 134217728) { // 128MB
    echo "<td class='success'>✓ Adequate</td>";
} else {
    echo "<td class='warning'>⚠ Low</td>";
}
echo "</tr>";

$max_execution_time = ini_get('max_execution_time');
echo "<tr><td>Max Execution Time</td><td>" . $max_execution_time . "s</td>";
echo "<td class='" . ($max_execution_time >= 30 ? 'success' : 'warning') . "'>" .
     ($max_execution_time >= 30 ? "✓ OK" : "⚠ Short") . "</td>";
echo "</tr>";

$upload_max = ini_get('upload_max_filesize');
echo "<tr><td>Upload Max Filesize</td><td>" . $upload_max . "</td><td class='info'>ℹ Info</td></tr>";

echo "</table>";

// Plugin Class Check
echo "<h3>9. 🏗️ Plugin Class Check</h3>";
if (class_exists('NicePayCancelPlugin')) {
    echo "<p class='success'>✅ NicePayCancelPlugin class is loaded</p>";
    
    // Try to get instance
    try {
        $instance = NicePayCancelPlugin::get_instance();
        echo "<p class='success'>✅ Plugin instance created successfully</p>";
    } catch (Exception $e) {
        echo "<p class='error'>❌ Plugin instance creation failed: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p class='error'>❌ NicePayCancelPlugin class not found</p>";
    echo "<p>This usually means the main plugin file has syntax errors or hasn't been loaded.</p>";
}

// Action Hooks Check
echo "<h3>10. 🎣 WordPress Hooks Check</h3>";
if (function_exists('has_action')) {
    $hooks_to_check = array(
        'plugins_loaded' => 'Plugin initialization',
        'admin_menu' => 'Admin menu',
        'wp_ajax_nicepay_cancel_transaction' => 'AJAX cancel handler',
        'wp_ajax_nicepay_search_transaction' => 'AJAX search handler'
    );
    
    echo "<table>";
    echo "<tr><th>Hook</th><th>Purpose</th><th>Status</th></tr>";
    
    foreach ($hooks_to_check as $hook => $purpose) {
        $has_hook = has_action($hook);
        echo "<tr><td><code>" . $hook . "</code></td><td>" . $purpose . "</td>";
        echo "<td class='" . ($has_hook ? 'success' : 'warning') . "'>" .
     ($has_hook ? "✓ Registered" : "⚠ Not Found") . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p class='warning'>⚠ WordPress hook functions not available</p>";
}

// Final Recommendations
echo "<h3>11. 💡 Recommendations</h3>";
echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 5px; border-left: 4px solid #0073aa;'>";

$issues = array();
if (version_compare(phpversion(), '7.4', '<')) {
    $issues[] = "❌ Upgrade PHP to version 7.4 or higher";
}
if (!class_exists('WooCommerce')) {
    $issues[] = "⚠ Install and activate WooCommerce plugin";
}
if (!file_exists($main_file)) {
    $issues[] = "❌ Upload the main plugin file: nicepay-cancel-transaction.php";
}
if (!file_exists($plugin_dir . '/includes/class-admin-settings.php')) {
    $issues[] = "📁 Upload missing file: includes/class-admin-settings.php";
}
if (!file_exists($plugin_dir . '/assets/admin.js')) {
    $issues[] = "📁 Upload missing file: assets/admin.js";
}

if (empty($issues)) {
    echo "<p class='success'><strong>🎉 All checks passed!</strong></p>";
    echo "<p>Your NICEPay Cancel plugin should be working correctly. If you're still experiencing issues, check the WordPress error logs.</p>";
} else {
    echo "<p><strong>🔧 Issues to fix:</strong></p>";
    echo "<ul>";
    foreach ($issues as $issue) {
        echo "<li>" . $issue . "</li>";
    }
    echo "</ul>";
}
echo "</div>";

echo "<hr>";
echo "<p><small>Debug completed at: " . date('Y-m-d H:i:s') . "</small></p>";
echo "<p><small>File: " . __FILE__ . "</small></p>";

// Helper function if not available
if (!function_exists('wp_convert_hr_to_bytes')) {
    function wp_convert_hr_to_bytes($size) {
        $size = trim($size);
        $last = strtolower($size[strlen($size)-1]);
        $size = (int) $size;
        switch($last) {
            case 'g': $size *= 1024;
            case 'm': $size *= 1024;
            case 'k': $size *= 1024;
        }
        return $size;
    }
}
?>