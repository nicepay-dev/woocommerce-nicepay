<?php
/**
 * Admin Settings Class untuk NICEPay Cancel Plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class NicePayCancelAdminSettings {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_menu'));
        add_action('admin_init', array($this, 'init_settings'));
        add_action('wp_ajax_nicepay_test_connection', array($this, 'handle_test_connection'));
    }
    
    public function add_settings_menu() {
        add_submenu_page(
            'nicepay-cancel',
            __('NICEPay Settings', 'nicepay-cancel'),
            __('Settings', 'nicepay-cancel'),
            'manage_options',
            'nicepay-cancel-settings',
            array($this, 'settings_page_callback')
        );
    }
    
    public function init_settings() {
        register_setting('nicepay_cancel_settings', 'nicepay_cancel_options', array($this, 'sanitize_settings'));
        
        // API Configuration Section
        add_settings_section(
            'nicepay_api_section',
            __('API Configuration', 'nicepay-cancel'),
            array($this, 'api_section_callback'),
            'nicepay-cancel-settings'
        );
        
        add_settings_field('merchant_id', __('Merchant ID', 'nicepay-cancel'), array($this, 'merchant_id_callback'), 'nicepay-cancel-settings', 'nicepay_api_section');
        add_settings_field('merchant_key', __('Merchant Key', 'nicepay-cancel'), array($this, 'merchant_key_callback'), 'nicepay-cancel-settings', 'nicepay_api_section');
        add_settings_field('environment', __('Environment', 'nicepay-cancel'), array($this, 'environment_callback'), 'nicepay-cancel-settings', 'nicepay_api_section');
        
        // General Settings Section
        add_settings_section(
            'nicepay_general_section',
            __('General Settings', 'nicepay-cancel'),
            array($this, 'general_section_callback'),
            'nicepay-cancel-settings'
        );
        
        add_settings_field('cancel_reason', __('Default Cancel Reason', 'nicepay-cancel'), array($this, 'cancel_reason_callback'), 'nicepay-cancel-settings', 'nicepay_general_section');
        add_settings_field('enable_logging', __('Enable Logging', 'nicepay-cancel'), array($this, 'enable_logging_callback'), 'nicepay-cancel-settings', 'nicepay_general_section');
        add_settings_field('auto_update_order', __('Auto Update Order Status', 'nicepay-cancel'), array($this, 'auto_update_order_callback'), 'nicepay-cancel-settings', 'nicepay_general_section');
    }
    
    public function settings_page_callback() {
        ?>
        <div class="wrap">
            <h1><?php _e('NICEPay Cancel Settings', 'nicepay-cancel'); ?></h1>
            
            <?php settings_errors(); ?>
            
            <form method="post" action="options.php" id="nicepay-settings-form">
                <?php
                settings_fields('nicepay_cancel_settings');
                do_settings_sections('nicepay-cancel-settings');
                submit_button();
                ?>
            </form>
            
            <!-- Test Connection Section -->
            <div class="postbox" style="margin-top: 20px;">
                <h2 class="hndle"><?php _e('Test API Connection', 'nicepay-cancel'); ?></h2>
                <div class="inside" style="padding: 20px;">
                    <p><?php _e('Test koneksi ke NICEPay API dengan kredential yang sudah disimpan.', 'nicepay-cancel'); ?></p>
                    <button type="button" id="test-api-connection" class="button button-secondary">
                        <?php _e('Test Connection', 'nicepay-cancel'); ?>
                    </button>
                    <div id="test-connection-result" style="margin-top: 15px;"></div>
                </div>
            </div>
            
            <!-- API Information -->
            <div class="postbox" style="margin-top: 20px;">
                <h2 class="hndle"><?php _e('API Information', 'nicepay-cancel'); ?></h2>
                <div class="inside" style="padding: 20px;">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Current API URL', 'nicepay-cancel'); ?></th>
                            <td>
                                <code id="current-api-url"><?php echo $this->get_current_api_url(); ?></code>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Cancel Endpoint', 'nicepay-cancel'); ?></th>
                            <td>
                                <code>/direct/v2/cancel</code>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Documentation', 'nicepay-cancel'); ?></th>
                            <td>
                                <a href="https://docs.nicepay.co.id/" target="_blank">NICEPay API Documentation</a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Update API URL display when environment changes
            $('#environment').on('change', function() {
                var env = $(this).val();
                var apiUrl = env === 'prod' ? 'https://www.nicepay.co.id/nicepay' : 'https://dev.nicepay.co.id/nicepay';
                $('#current-api-url').text(apiUrl);
            });
            
            // Test API Connection
            $('#test-api-connection').on('click', function() {
                var $button = $(this);
                var $result = $('#test-connection-result');
                var originalText = $button.text();
                
                $button.text('<?php _e('Testing...', 'nicepay-cancel'); ?>').prop('disabled', true);
                $result.html('');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'nicepay_test_connection',
                        nonce: '<?php echo wp_create_nonce('nicepay_test_api'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $result.html('<div class="notice notice-success inline"><p><strong><?php _e('Success!', 'nicepay-cancel'); ?></strong> ' + response.data.message + '</p></div>');
                        } else {
                            $result.html('<div class="notice notice-error inline"><p><strong><?php _e('Error!', 'nicepay-cancel'); ?></strong> ' + response.data.message + '</p></div>');
                        }
                    },
                    error: function() {
                        $result.html('<div class="notice notice-error inline"><p><strong><?php _e('Error!', 'nicepay-cancel'); ?></strong> <?php _e('Failed to connect to server', 'nicepay-cancel'); ?></p></div>');
                    },
                    complete: function() {
                        $button.text(originalText).prop('disabled', false);
                    }
                });
            });
        });
        </script>
        
        <style>
        .postbox {
            max-width: 100%;
        }
        .notice.inline {
            margin: 0;
            padding: 10px;
        }
        #current-api-url {
            background: #f1f1f1;
            padding: 5px 10px;
            border-radius: 3px;
        }
        </style>
        <?php
    }
    
    public function api_section_callback() {
        echo '<p>' . __('Konfigurasi API untuk koneksi ke NICEPay. Pastikan kredential sudah benar sebelum melakukan cancel transaksi.', 'nicepay-cancel') . '</p>';
    }
    
    public function general_section_callback() {
        echo '<p>' . __('Pengaturan umum untuk plugin NICEPay Cancel.', 'nicepay-cancel') . '</p>';
    }
    
    public function merchant_id_callback() {
        $options = get_option('nicepay_cancel_options');
        $value = isset($options['merchant_id']) ? $options['merchant_id'] : '';
        echo '<input type="text" name="nicepay_cancel_options[merchant_id]" value="' . esc_attr($value) . '" class="regular-text" required />';
        echo '<p class="description">' . __('Merchant ID yang diberikan oleh NICEPay (contoh: IONPAYTEST)', 'nicepay-cancel') . '</p>';
    }
    
    public function merchant_key_callback() {
        $options = get_option('nicepay_cancel_options');
        $value = isset($options['merchant_key']) ? $options['merchant_key'] : '';
        echo '<input type="password" name="nicepay_cancel_options[merchant_key]" value="' . esc_attr($value) . '" class="regular-text" required />';
        echo '<p class="description">' . __('Merchant Key untuk autentikasi API', 'nicepay-cancel') . '</p>';
    }
    
    public function environment_callback() {
        $options = get_option('nicepay_cancel_options');
        $value = isset($options['environment']) ? $options['environment'] : 'dev';
        ?>
        <select name="nicepay_cancel_options[environment]" id="environment">
            <option value="dev" <?php selected($value, 'dev'); ?>><?php _e('Development (dev.nicepay.co.id)', 'nicepay-cancel'); ?></option>
            <option value="prod" <?php selected($value, 'prod'); ?>><?php _e('Production (www.nicepay.co.id)', 'nicepay-cancel'); ?></option>
        </select>
        <p class="description"><?php _e('Pilih environment yang sesuai dengan kredential Anda', 'nicepay-cancel'); ?></p>
        <?php
    }
    
    public function cancel_reason_callback() {
        $options = get_option('nicepay_cancel_options');
        $value = isset($options['cancel_reason']) ? $options['cancel_reason'] : 'Cancellation Of Transaction Credit Card by Admin';
        echo '<input type="text" name="nicepay_cancel_options[cancel_reason]" value="' . esc_attr($value) . '" class="large-text" />';
        echo '<p class="description">' . __('Alasan default untuk cancel transaksi', 'nicepay-cancel') . '</p>';
    }
    
    public function enable_logging_callback() {
        $options = get_option('nicepay_cancel_options');
        $value = isset($options['enable_logging']) ? $options['enable_logging'] : '1';
        echo '<input type="checkbox" name="nicepay_cancel_options[enable_logging]" value="1" ' . checked($value, '1', false) . ' />';
        echo ' ' . __('Aktifkan logging untuk debug dan audit', 'nicepay-cancel');
    }
    
    public function auto_update_order_callback() {
        $options = get_option('nicepay_cancel_options');
        $value = isset($options['auto_update_order']) ? $options['auto_update_order'] : '1';
        echo '<input type="checkbox" name="nicepay_cancel_options[auto_update_order]" value="1" ' . checked($value, '1', false) . ' />';
        echo ' ' . __('Otomatis update status order ke "cancelled" jika cancel berhasil', 'nicepay-cancel');
    }
    
    /**
     * Sanitize settings input
     */
    public function sanitize_settings($input) {
        $sanitized = array();
        
        if (isset($input['merchant_id'])) {
            $sanitized['merchant_id'] = sanitize_text_field($input['merchant_id']);
        }
        
        if (isset($input['merchant_key'])) {
            $sanitized['merchant_key'] = sanitize_text_field($input['merchant_key']);
        }
        
        if (isset($input['environment'])) {
            $sanitized['environment'] = in_array($input['environment'], array('dev', 'prod')) ? $input['environment'] : 'dev';
        }
        
        if (isset($input['cancel_reason'])) {
            $sanitized['cancel_reason'] = sanitize_text_field($input['cancel_reason']);
        }
        
        if (isset($input['enable_logging'])) {
            $sanitized['enable_logging'] = '1';
        } else {
            $sanitized['enable_logging'] = '0';
        }
        
        if (isset($input['auto_update_order'])) {
            $sanitized['auto_update_order'] = '1';
        } else {
            $sanitized['auto_update_order'] = '0';
        }
        
        return $sanitized;
    }
    
    /**
     * Get current API URL based on environment
     */
    private function get_current_api_url() {
        $environment = self::get_option('environment', 'dev');
        return $environment === 'prod' ? 'https://www.nicepay.co.id/nicepay' : 'https://dev.nicepay.co.id/nicepay';
    }
    
    /**
     * Handle test connection AJAX
     */
    public function handle_test_connection() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'nicepay_test_api')) {
            wp_send_json_error(array('message' => __('Security check failed', 'nicepay-cancel')));
        }
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'nicepay-cancel')));
        }
        
        // Check if API class exists
        if (!class_exists('NicePayAPI')) {
            wp_send_json_error(array('message' => __('NicePayAPI class not found', 'nicepay-cancel')));
        }
        
        $api = new NicePayAPI();
        $result = $api->test_connection();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * Get option value
     */
    public static function get_option($key, $default = '') {
        $options = get_option('nicepay_cancel_options');
        return isset($options[$key]) ? $options[$key] : $default;
    }
    
    /**
     * Get all options
     */
    public static function get_all_options() {
        return get_option('nicepay_cancel_options', array());
    }
    
    /**
     * Check if plugin is configured
     */
    public static function is_configured() {
        $merchant_id = self::get_option('merchant_id');
        $merchant_key = self::get_option('merchant_key');
        
        return !empty($merchant_id) && !empty($merchant_key);
    }
}

// Initialize settings
new NicePayCancelAdminSettings();