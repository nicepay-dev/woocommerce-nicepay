<?php
/**
 * NICEPay API Class untuk Cancel Transaction
 * 
 * @package NicePayCancel
 * @since 1.1.0
 */

 declare(strict_types=1);
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class NicePayAPI {
    
    private readonly string $merchantId;
    private readonly string $merchantKey;
    private readonly string $privateKey;
    private readonly string $channelId;
    /**
     * SecretClient (key HMAC untuk SNAP signature service).
     * Di credential manager kami, value ini diambil dari field `client_key`.
     */
    private readonly string $snapSecretClient;
    private readonly string $environment;
    private readonly string $apiUrl;
    
    /**
     * Map payMethod code per NicePayPaymentMethod enum
     * Sesuai dokumentasi NICEPay:
     *   01 = Credit Card
     *   02 = Virtual Account
     *   08 = QRIS
     *   05 = E-Wallet
     *   03 = Convenience Store
     */
    private const PAY_METHOD_MAP = [
        'cc'      => '01',
        'va'      => '02',
        'qris'    => '08',
        'ewallet' => '05',
        'cstore'  => '03',
        'payloan' => '06',
    ];
    private const CANCEL_ENDPOINT_MAP = [
        'cc'      => '/direct/v2/cancel',
        'va'      => '/api/v1.0/transfer-va/delete-va',
        'qris'    => '/api/v1.0/qr/qr-mpm-refund',
        'ewallet' => '/api/v1.0/debit/refund',
        'cstore'  => '/direct/v2/cancel',
        'payloan' => '/direct/v2/cancel',
    ];

    /**
     * Build full request URL (base + endpoint).
     */
    private function build_full_url(string $endpoint): string
    {
        return rtrim($this->apiUrl, '/') . $endpoint;
    }
    public function __construct(private readonly mixed $credential = null)
    {
        if ($credential !== null && is_object($credential)) {
            $this->merchantId   = $credential->merchant_id;
            $this->merchantKey  = $credential->merchant_key;
            $this->privateKey   = (string) ($credential->private_key ?? '');
            // client_key (Client Secret) untuk signature service SNAP
            $this->snapSecretClient = (string) ($credential->client_key ?? '');
            // CHANNEL-ID SNAP adalah credential terpisah dari NICEPay.
            // Jika tidak di-set di credential manager, fallback ke pola umum X-CLIENT-KEY + "01".
            $this->channelId = (string) (($credential->channel_id ?? '') !== '' ? $credential->channel_id : ($this->merchantId . '01'));
            $this->environment  = $credential->environment;
        } else {
            // Fallback ke global settings
            $this->merchantId   = NicePayCancelAdminSettings::get_option('merchant_id', '');
            $this->merchantKey  = NicePayCancelAdminSettings::get_option('merchant_key', '');
            $this->privateKey   = '';
            $this->snapSecretClient = '';
            $this->channelId = (string) ($this->merchantId . '01');
            $this->environment  = NicePayCancelAdminSettings::get_option('environment', 'dev');
        }

        // Tentukan base URL API berdasarkan environment
        $this->apiUrl = $this->get_api_url();
    }

    /**
     * Helper: format amount ke integer string tanpa desimal (sesuai spesifikasi NICEPay)
     */
    private function formatAmount(mixed $amount): string
    {
        // WooCommerce terkadang mengembalikan total sebagai string.
        // Pastikan tetap bisa diproses untuk kebutuhan signature/token NICEPay.
        if (is_string($amount)) {
            // Normalisasi: hapus spasi dan pemisah ribuan jika ada
            $amount = trim($amount);
            $amount = str_replace([',', ' '], ['', ''], $amount);
        }

        $amount_float = (float) $amount;

        return number_format($amount_float, 0, '', '');
    }

    /**
     * Timestamp SNAP ISO 8601 (Asia/Jakarta) untuk header X-TIMESTAMP.
     * Contoh: 2025-02-05T10:29:40+07:00
     */
    private function generate_snap_timestamp_iso(): string
    {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    /**
     * Format amount untuk refund SNAP (2 desimal).
     */
    private function formatAmountSnapRefundValue(mixed $amount): string
    {
        if (is_string($amount)) {
            $amount = trim($amount);
            $amount = str_replace([',', ' '], ['', ''], $amount);
        }
        return number_format((float) $amount, 2, '.', '');
    }

    /**
     * Normalisasi private key menjadi PEM yang bisa dibaca OpenSSL.
     */
    private function to_pem_private_key(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }
        if (str_contains($raw, 'BEGIN')) {
            return $raw;
        }
        // Diasumsikan format tanpa header.
        return "-----BEGIN RSA PRIVATE KEY-----\r\n" . $raw . "\r\n-----END RSA PRIVATE KEY-----";
    }

    /**
     * Helper: response error standar
     */
    private function error_response(string $message): array
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }

    /**
     * Helper wrapper ke fungsi lama generate_merchant_token
     */
    private function generateMerchantToken(string $timestamp, string $transaction_id, string $amount): string
    {
        return $this->generate_merchant_token($timestamp, $transaction_id, $amount);
    }

    /**
     * Helper wrapper ke fungsi lama send_api_request
     */
    private function sendApiRequest(string $endpoint, array $data)
    {
        return $this->send_api_request($endpoint, $data);
    }

    /**
     * Helper wrapper ke fungsi lama get_server_ip
     */
    private function getServerIp(): string
    {
        return $this->get_server_ip();
    }

    /**
     * Helper wrapper ke fungsi lama get_client_ip
     */
    private function getClientIp(): string
    {
        return $this->get_client_ip();
    }

    /**
     * Helper wrapper ke fungsi lama get_user_info
     */
    private function getUserInfo(): string
    {
        return $this->get_user_info();
    }

    /**
     * Helper wrapper ke fungsi lama sanitize_log_data
     */
    private function sanitizeLogData(array $data): array
    {
        return $this->sanitize_log_data($data);
    }

    /**
     * Helper wrapper ke fungsi lama log_activity
     */
    private function logActivity(string $action, array $data): void
    {
        $this->log_activity($action, $data);
    }

    /**
     * Get API URL berdasarkan environment
     * 
     * @return string
     */
    private function get_api_url() {
        $urls = array(
            'dev' => 'https://dev.nicepay.co.id/nicepay',
            'prod' => 'https://www.nicepay.co.id/nicepay'
        );
        
        return isset($urls[$this->environment]) ? $urls[$this->environment] : $urls['dev'];
    }
    
    /**
     * Cancel transaksi NICEPay
     * 
     * @param string $transaction_id Transaction ID dari NICEPay (tXid)
     * @param WC_Order $order WooCommerce order object
     * @param string $cancel_reason Alasan cancel
     * @param string $cancel_type Cancel type (1=partial, 2=full)
     * @return array Result array with success status and message
     */
    public function cancel_transaction(
        string $transaction_id,
        object $order,
        string $cancel_reason   = '',
        string $cancel_type     = '2',
        string $payment_method  = 'cc',
    ): array {
        // --- Validasi dasar ---
        if (empty($transaction_id)) {
            return $this->error_response(__('Transaction ID tidak boleh kosong', 'nicepay-cancel'));
        }

        if (empty($this->merchantId)) {
            return $this->error_response(__('API credentials belum dikonfigurasi (X-CLIENT-KEY/Merchant ID kosong)', 'nicepay-cancel'));
        }

        // --- Validasi payment method ---
        if (!array_key_exists($payment_method, self::PAY_METHOD_MAP)) {
            return $this->error_response(
                sprintf(__('Payment method tidak dikenali: %s', 'nicepay-cancel'), $payment_method)
            );
        }

        // --- SNAP methods (tidak pakai merchantToken versi direct) ---
        if ($payment_method === 'qris') {
            return $this->cancel_qris_snap($transaction_id, $order, $cancel_reason, $cancel_type);
        }
        if ($payment_method === 'va') {
            return $this->cancel_va_snap($transaction_id, $order, $cancel_reason, $cancel_type);
        }
        if ($payment_method === 'ewallet') {
            return $this->cancel_ewallet_snap($transaction_id, $order, $cancel_reason, $cancel_type);
        }

        // Direct V2 methods require merchant_key
        if (empty($this->merchantKey)) {
            return $this->error_response(__('API credentials belum dikonfigurasi (Merchant Key kosong)', 'nicepay-cancel'));
        }

        // --- Resolve nilai-nilai request ---
        if (empty($cancel_reason)) {
            $cancel_reason = NicePayCancelAdminSettings::get_option(
                'cancel_reason',
                'Cancellation Of Transaction by Admin'
            );
        }

        $timestamp  = date('YmdHis');
        $amount     = $this->formatAmount($order->get_total());
        $pay_method = self::PAY_METHOD_MAP[$payment_method];
        $endpoint   = self::CANCEL_ENDPOINT_MAP[$payment_method];
        $full_url   = $this->build_full_url($endpoint);

        // --- Generate merchant token ---
        // Formula: SHA256(timeStamp + iMid + tXid + amt + merchantKey)
        $merchant_token = $this->generateMerchantToken($timestamp, $transaction_id, $amount);

        // --- Build request payload ---
        $request_data = [
            'timeStamp'       => $timestamp,
            'tXid'            => $transaction_id,
            'iMid'            => $this->merchantId,
            'payMethod'       => $pay_method,
            'cancelType'      => '1',
            'cancelMsg'       => $cancel_reason,
            'merchantToken'   => $merchant_token,
            'referenceNo'     => $order->get_order_number(),
            'amt'             => $amount,
            'preauthToken'    => '',
            'cancelServerIp'  => '',
            'cancelUserId'    => 'Admin',
            'cancelUserIp'    => '',
            'cancelUserInfo'  => '',
            'cancelRetryCnt'  => '',
            'worker'          => '',
        ];

        // --- Log request ---
        $this->logActivity('cancel_request', [
            'transaction_id' => $transaction_id,
            'order_id'       => $order->get_id(),
            'payment_method' => $payment_method,
            'api_base_url'   => $this->apiUrl,
            'endpoint'       => $endpoint,
            'full_url'       => $full_url,
            'merchant_token_formula' => 'SHA256(timeStamp + iMid + tXid + amt + merchantKey)',
            'merchant_token_components' => [
                'timeStamp' => $timestamp,
                'iMid'      => $this->merchantId,
                'tXid'      => $transaction_id,
                'amt'       => $amount,
                // merchantKey sengaja tidak dilog (sangat sensitif)
            ],
            // Simpan payload lengkap yang dikirim ke NICEPay,
            // termasuk merchantToken (jangan dibagikan ke pihak lain).
            'request_data'        => $request_data,
        ]);

        // --- Kirim ke API NICEPay ---
        $started_at = microtime(true);
        $response = $this->sendApiRequest($endpoint, $request_data);
        $elapsed_ms = (int) round((microtime(true) - $started_at) * 1000);

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();

            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => $payment_method,
                'full_url'       => $full_url,
                'elapsed_ms'     => $elapsed_ms,
                'error'          => $error_message,
            ]);

            return $this->error_response(
                sprintf(__('API Error: %s', 'nicepay-cancel'), $error_message)
            );
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        // --- Log response ---
        $this->logActivity('cancel_response', [
            'transaction_id' => $transaction_id,
            'payment_method' => $payment_method,
            'full_url'       => $full_url,
            'response_code'  => $response_code,
            'elapsed_ms'     => $elapsed_ms,
            'response_body'  => $response_body,
        ]);

        if ($response_code !== 200) {
            return $this->error_response(
                sprintf(__('HTTP Error: %d', 'nicepay-cancel'), $response_code)
            );
        }

        // --- Parse response ---
        $data = json_decode($response_body, associative: true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logActivity('cancel_parse_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => $payment_method,
                'full_url'       => $full_url,
                'response_code'  => $response_code,
                'elapsed_ms'     => $elapsed_ms,
                'error'          => json_last_error_msg(),
                'response_body'  => $response_body,
            ]);
            return $this->error_response(__('Invalid JSON response from API', 'nicepay-cancel'));
        }

        // --- Cek result code NICEPay ---
        $result_code = $data['resultCd'] ?? 'unknown';
        $result_msg  = $data['resultMsg'] ?? __('Unknown error from NICEPay API', 'nicepay-cancel');

        if ($result_code === '0000') {
            $this->logActivity('cancel_success', [
                'transaction_id' => $transaction_id,
                'order_id'       => $order->get_id(),
                'payment_method' => $payment_method,
                'full_url'       => $full_url,
                'elapsed_ms'     => $elapsed_ms,
                'response'       => $data,
            ]);

            // Update status order (best-effort). Jika gagal, cancel tetap dianggap sukses,
            // tapi kita simpan log error agar mudah debugging.
            try {
                $this->updateOrderAfterCancel($order, $data, $payment_method);
            } catch (\Throwable $e) {
                $this->logActivity('cancel_order_update_error', [
                    'transaction_id' => $transaction_id,
                    'order_id'       => method_exists($order, 'get_id') ? $order->get_id() : null,
                    'payment_method' => $payment_method,
                    'error'          => $e->getMessage(),
                    'file'           => $e->getFile(),
                    'line'           => $e->getLine(),
                ]);
            }

            return [
                'success' => true,
                'message' => $result_msg,
                'data'    => $data,
            ];
        }

        // --- Cancel gagal ---
        $this->logActivity('cancel_failed', [
            'transaction_id' => $transaction_id,
            'error_code'     => $result_code,
            'error_message'  => $result_msg,
            'payment_method' => $payment_method,
            'full_url'       => $full_url,
            'elapsed_ms'     => $elapsed_ms,
        ]);

        return [
            'success'    => false,
            'message'    => $result_msg,
            'error_code' => $result_code,
        ];
    }

    /**
     * Create accessToken untuk SNAP (client_credentials).
     */
    private function get_snap_access_token(): string
    {
        if (trim($this->privateKey) === '') {
            throw new \Exception(__('private_key SNAP tidak dikonfigurasi', 'nicepay-cancel'));
        }
        if (trim($this->merchantId) === '') {
            throw new \Exception(__('X-CLIENT-KEY tidak dikonfigurasi', 'nicepay-cancel'));
        }

        $xClientKey = $this->merchantId;
        $timestamp  = $this->generate_snap_timestamp_iso();
        $stringToSign = $xClientKey . '|' . $timestamp;

        $privatePem = $this->to_pem_private_key($this->privateKey);
        if (trim($privatePem) === '') {
            throw new \Exception(__('Private key PEM kosong', 'nicepay-cancel'));
        }

        $pKey = openssl_pkey_get_private($privatePem);
        if ($pKey === false) {
            throw new \Exception(__('Invalid private key untuk SNAP', 'nicepay-cancel'));
        }

        $binary_signature = '';
        $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        if ($sign_result === false) {
            throw new \Exception(__('Gagal sign request accessToken SNAP', 'nicepay-cancel'));
        }

        $signature = base64_encode($binary_signature);

        $jsonData = [
            'grantType' => 'client_credentials',
        ];
        $requestTokenUrl = rtrim($this->apiUrl, '/') . '/v1.0/access-token/b2b';

        $args = [
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-SIGNATURE'  => $signature,
                'X-CLIENT-KEY' => $xClientKey,
                'X-TIMESTAMP'  => $timestamp,
            ],
            // JSON body access token
            'body' => wp_json_encode($jsonData),
        ];

        $response = wp_remote_post($requestTokenUrl, $args);
        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message());
        }

        $body_raw = wp_remote_retrieve_body($response);
        $body = json_decode($body_raw);

        if (!is_object($body) || empty($body->accessToken)) {
            throw new \Exception(__('Invalid response accessToken SNAP', 'nicepay-cancel') . ': ' . $body_raw);
        }

        return (string) $body->accessToken;
    }

    /**
     * SNAP QRIS cancel/refund via /api/v1.0/qr/qr-mpm-refund
     *
     * Mengikuti sample Postman user:
     * - originalReferenceNo/originalPartnerReferenceNo dari meta order
     * - partnerRefundNo = originalReferenceNo
     * - refundAmount 2 desimal
     * - additionalInfo.cancelType = "1"
     */
    private function cancel_qris_snap(
        string $transaction_id,
        object $order,
        string $cancel_reason,
        string $cancel_type
    ): array {
        $endpoint = self::CANCEL_ENDPOINT_MAP['qris'];
        $full_url = $this->build_full_url($endpoint);

        $originalReferenceNo = (string) ($order->get_meta('_nicepay_tXid') ?: $transaction_id);
        $originalPartnerReferenceNo = (string) ($order->get_meta('_nicepay_reference_no') ?: '');

        if ($originalPartnerReferenceNo === '') {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'qris',
                'reason'          => 'SNAP meta missing: _nicepay_reference_no is empty',
            ]);
            return $this->error_response(__('originalPartnerReferenceNo tidak ditemukan dari meta order', 'nicepay-cancel'));
        }

        $partnerRefundNo = $originalReferenceNo;

        $refundValue = $this->formatAmountSnapRefundValue($order->get_total());
        $refundCurrency = (string) ($order->get_currency() ?: 'IDR');

        $reason = trim($cancel_reason) !== '' ? $cancel_reason : 'Refund Trans';

        $requestBody = [
            'originalReferenceNo' => $originalReferenceNo,
            'originalPartnerReferenceNo' => $originalPartnerReferenceNo,
            'partnerRefundNo' => $partnerRefundNo,
            'merchantId' => $this->merchantId,
            'externalStoreId' => 'NICEPAY',
            'refundAmount' => [
                'value' => $refundValue,
                'currency' => $refundCurrency,
            ],
            'reason' => $reason,
            'additionalInfo' => [
                // Untuk saat ini hardcode sesuai sample user
                'cancelType' => '1',
            ],
        ];

        $stringBody = json_encode($requestBody, JSON_UNESCAPED_SLASHES);
        $hashbody = strtolower(hash('sha256', $stringBody));
        $X_TIMESTAMP = $this->generate_snap_timestamp_iso();

        try {
            $accessToken = $this->get_snap_access_token();
        } catch (\Throwable $e) {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'qris',
                'full_url'       => $full_url,
                'error'          => $e->getMessage(),
            ]);
            return $this->error_response(__('Failed to get SNAP access token', 'nicepay-cancel') . ': ' . $e->getMessage());
        }

        $secretClient = $this->snapSecretClient;
        if (trim($secretClient) === '') {
            return $this->error_response(__('SNAP SecretClient (client_key) tidak dikonfigurasi', 'nicepay-cancel'));
        }

        // Signature service:
        // POST:/api/v1.0/qr/qr-mpm-refund:{accessToken}:{sha256(body)}:{X_TIMESTAMP}
        $strigSign = 'POST:/api/v1.0/qr/qr-mpm-refund:' . $accessToken . ':' . $hashbody . ':' . $X_TIMESTAMP;
        $bodyHasing = hash_hmac('sha512', $strigSign, $secretClient, true);
        $signature = base64_encode($bodyHasing);

        $xExternalId = (string) (date('YmdHis') . rand(1000, 9999));
        $channelId = $this->channelId !== '' ? $this->channelId : $this->merchantId;

        $request_headers = [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $accessToken,
            'X-TIMESTAMP'   => $X_TIMESTAMP,
            'X-SIGNATURE'   => $signature,
            'X-PARTNER-ID'  => $this->merchantId,
            'CHANNEL-ID'    => $channelId,
            'X-EXTERNAL-ID' => $xExternalId,
            'X-CLIENT-KEY'  => $this->merchantId,
        ];

        // Log request (full body)
        $this->logActivity('cancel_request', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'qris',
            'full_url'       => $full_url,
            'endpoint'       => $endpoint,
            'request_headers' => [
                'Content-Type'  => $request_headers['Content-Type'],
                'Authorization' => 'Bearer ' . (strlen($accessToken) > 10 ? substr($accessToken, 0, 10) . '...' : $accessToken),
                'X-TIMESTAMP'   => $request_headers['X-TIMESTAMP'],
                'X-PARTNER-ID'  => $request_headers['X-PARTNER-ID'],
                'CHANNEL-ID'    => $request_headers['CHANNEL-ID'],
                'X-EXTERNAL-ID' => $request_headers['X-EXTERNAL-ID'],
                'X-SIGNATURE'   => strlen($signature) > 10 ? substr($signature, 0, 10) . '...' : $signature,
                'X-CLIENT-KEY'  => $request_headers['X-CLIENT-KEY'],
            ],
            'request_body' => $requestBody,
        ]);

        $started_at = microtime(true);

        $args = [
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => $request_headers,
            'body'    => $stringBody,
        ];

        $response = wp_remote_post($full_url, $args);
        $elapsed_ms = (int) round((microtime(true) - $started_at) * 1000);

        if (is_wp_error($response)) {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'qris',
                'full_url'       => $full_url,
                'elapsed_ms'    => $elapsed_ms,
                'error'          => $response->get_error_message(),
            ]);
            return $this->error_response(sprintf(__('API Error: %s', 'nicepay-cancel'), $response->get_error_message()));
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body_raw = wp_remote_retrieve_body($response);
        $response_body = json_decode($response_body_raw, true);

        $this->logActivity('cancel_response', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'qris',
            'full_url'       => $full_url,
            'http_code'      => $response_code,
            'elapsed_ms'    => $elapsed_ms,
            'response_body'  => $response_body_raw,
        ]);

        if (!is_array($response_body)) {
            return $this->error_response(__('Invalid JSON response dari QRIS SNAP', 'nicepay-cancel') . ': ' . $response_body_raw);
        }

        $respCode = (string) ($response_body['responseCode'] ?? '');
        $respMsg  = (string) ($response_body['responseMessage'] ?? '');

        if ($respCode === '2007800') {
            $this->logActivity('cancel_success', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'qris',
                'full_url'       => $full_url,
                'response'       => $response_body,
            ]);

            // Bentuk payload untuk update order wrapper yang sudah ada
            $updatePayload = [
                'tXid' => $response_body['originalReferenceNo'] ?? $originalReferenceNo,
                'referenceNo' => $response_body['referenceNo'] ?? $originalPartnerReferenceNo,
            ];

            try {
                $this->update_order_after_cancel($order, $updatePayload);
            } catch (\Throwable $e) {
                $this->logActivity('cancel_order_update_error', [
                    'transaction_id' => $transaction_id,
                    'payment_method' => 'qris',
                    'error'          => $e->getMessage(),
                ]);
            }

            return [
                'success' => true,
                'message' => $respMsg !== '' ? $respMsg : __('QRIS SNAP refund success', 'nicepay-cancel'),
                'data'    => $response_body,
            ];
        }

        $this->logActivity('cancel_failed', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'qris',
            'full_url'       => $full_url,
            'responseCode'  => $respCode,
            'responseMessage' => $respMsg,
            'response'       => $response_body,
        ]);

        return [
            'success' => false,
            'message' => $respMsg !== '' ? $respMsg : __('QRIS SNAP refund failed', 'nicepay-cancel'),
            'error_code' => $respCode,
            'data' => $response_body,
        ];
    }

    /**
     * SNAP VA cancel/delete via /api/v1.0/transfer-va/delete-va
     * Body mengikuti sample Postman user.
     */
    private function cancel_va_snap(
        string $transaction_id,
        object $order,
        string $cancel_reason,
        string $cancel_type
    ): array {
        $endpoint = self::CANCEL_ENDPOINT_MAP['va'];
        $full_url = $this->build_full_url($endpoint);

        // Required SNAP creds
        if (trim($this->privateKey) === '' || trim($this->snapSecretClient) === '') {
            return $this->error_response(__('SNAP credential belum lengkap (private_key / client secret kosong)', 'nicepay-cancel'));
        }
        if (trim($this->channelId) === '') {
            return $this->error_response(__('SNAP credential belum lengkap (CHANNEL-ID kosong)', 'nicepay-cancel'));
        }

        $virtualAccountNo = (string) ($order->get_meta('_nicepay_va_number') ?: '');
        $trxId = (string) ($order->get_meta('_nicepay_reference_no') ?: (string) $order->get_id());
        // di gateway VA SNAP, _nicepay_tXid berisi tXidVA
        $tXidVA = (string) ($order->get_meta('_nicepay_tXid') ?: $transaction_id);

        if ($virtualAccountNo === '') {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'va',
                'reason' => 'SNAP meta missing: _nicepay_va_number is empty',
            ]);
            return $this->error_response(__('virtualAccountNo tidak ditemukan dari meta order', 'nicepay-cancel'));
        }

        $reason = trim($cancel_reason) !== '' ? $cancel_reason : 'Cancel Virtual Account';

        $refundValue = $this->formatAmountSnapRefundValue($order->get_total());
        $currency = (string) ($order->get_currency() ?: 'IDR');

        $requestBody = [
            'partnerServiceId' => '',
            'customerNo' => '',
            'virtualAccountNo' => $virtualAccountNo,
            'trxId' => $trxId,
            'additionalInfo' => [
                'totalAmount' => [
                    'value' => $refundValue,
                    'currency' => $currency,
                ],
                'tXidVA' => $tXidVA,
                'cancelMessage' => $reason,
            ],
        ];

        $stringBody = json_encode($requestBody, JSON_UNESCAPED_SLASHES);
        $hashbody = strtolower(hash('sha256', $stringBody));
        $X_TIMESTAMP = $this->generate_snap_timestamp_iso();

        try {
            $accessToken = $this->get_snap_access_token();
        } catch (\Throwable $e) {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'va',
                'full_url'       => $full_url,
                'error'          => $e->getMessage(),
            ]);
            return $this->error_response(__('Failed to get SNAP access token', 'nicepay-cancel') . ': ' . $e->getMessage());
        }

        $secretClient = $this->snapSecretClient;
        $strigSign = 'POST:/api/v1.0/transfer-va/delete-va:' . $accessToken . ':' . $hashbody . ':' . $X_TIMESTAMP;
        $bodyHasing = hash_hmac('sha512', $strigSign, $secretClient, true);
        $signature = base64_encode($bodyHasing);

        $xExternalId = (string) (date('YmdHis') . rand(1000, 9999));

        $request_headers = [
            'Content-Type'  => 'application/json',
            'X-SIGNATURE'   => $signature,
            'X-CLIENT-KEY'  => $this->merchantId,
            'X-TIMESTAMP'   => $X_TIMESTAMP,
            'Authorization' => 'Bearer ' . $accessToken,
            'CHANNEL-ID'    => $this->channelId,
            'X-EXTERNAL-ID' => $xExternalId,
            'X-PARTNER-ID'  => $this->merchantId,
        ];

        $this->logActivity('cancel_request', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'va',
            'full_url'       => $full_url,
            'endpoint'       => $endpoint,
            'request_headers' => [
                'Content-Type'  => $request_headers['Content-Type'],
                'Authorization' => 'Bearer ' . (strlen($accessToken) > 10 ? substr($accessToken, 0, 10) . '...' : $accessToken),
                'X-TIMESTAMP'   => $request_headers['X-TIMESTAMP'],
                'X-CLIENT-KEY'  => $request_headers['X-CLIENT-KEY'],
                'X-PARTNER-ID'  => $request_headers['X-PARTNER-ID'],
                'CHANNEL-ID'    => $request_headers['CHANNEL-ID'],
                'X-EXTERNAL-ID' => $request_headers['X-EXTERNAL-ID'],
                'X-SIGNATURE'   => strlen($signature) > 10 ? substr($signature, 0, 10) . '...' : $signature,
            ],
            'request_body' => $requestBody,
        ]);

        $started_at = microtime(true);
        $response = wp_remote_post($full_url, [
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => $request_headers,
            'body'    => $stringBody,
        ]);
        $elapsed_ms = (int) round((microtime(true) - $started_at) * 1000);

        if (is_wp_error($response)) {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'va',
                'full_url'       => $full_url,
                'elapsed_ms'    => $elapsed_ms,
                'error'          => $response->get_error_message(),
            ]);
            return $this->error_response(sprintf(__('API Error: %s', 'nicepay-cancel'), $response->get_error_message()));
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $response_body_raw = wp_remote_retrieve_body($response);
        $response_body = json_decode($response_body_raw, true);

        $this->logActivity('cancel_response', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'va',
            'full_url'       => $full_url,
            'http_code'      => $http_code,
            'elapsed_ms'    => $elapsed_ms,
            'response_body'  => $response_body_raw,
        ]);

        if (!is_array($response_body)) {
            return $this->error_response(__('Invalid JSON response dari VA SNAP', 'nicepay-cancel') . ': ' . $response_body_raw);
        }

        $respCode = (string) ($response_body['responseCode'] ?? '');
        $respMsg  = (string) ($response_body['responseMessage'] ?? '');

        // Sukses VA SNAP biasanya 200xx00; kita anggap success jika responseCode diawali "200"
        if ($respCode !== '' && str_starts_with($respCode, '200')) {
            $this->logActivity('cancel_success', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'va',
                'full_url'       => $full_url,
                'response'       => $response_body,
            ]);

            // Update order status best-effort
            try {
                $this->update_order_after_cancel($order, [
                    'tXid' => $transaction_id,
                    'referenceNo' => $trxId,
                ]);
            } catch (\Throwable $e) {
                $this->logActivity('cancel_order_update_error', [
                    'transaction_id' => $transaction_id,
                    'payment_method' => 'va',
                    'error'          => $e->getMessage(),
                ]);
            }

            return [
                'success' => true,
                'message' => $respMsg !== '' ? $respMsg : __('VA SNAP delete success', 'nicepay-cancel'),
                'data'    => $response_body,
            ];
        }

        $this->logActivity('cancel_failed', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'va',
            'full_url'       => $full_url,
            'responseCode'  => $respCode,
            'responseMessage' => $respMsg,
            'response'       => $response_body,
        ]);

        return [
            'success' => false,
            'message' => $respMsg !== '' ? $respMsg : __('VA SNAP delete failed', 'nicepay-cancel'),
            'error_code' => $respCode,
            'data' => $response_body,
        ];
    }

    /**
     * SNAP E-Wallet cancel/refund via /api/v1.0/debit/refund
     */
    private function cancel_ewallet_snap(
        string $transaction_id,
        object $order,
        string $cancel_reason,
        string $cancel_type
    ): array {
        $endpoint = self::CANCEL_ENDPOINT_MAP['ewallet'];
        $full_url = $this->build_full_url($endpoint);

        if (trim($this->privateKey) === '' || trim($this->snapSecretClient) === '') {
            return $this->error_response(__('SNAP credential belum lengkap (private_key / client secret kosong)', 'nicepay-cancel'));
        }
        if (trim($this->channelId) === '') {
            return $this->error_response(__('SNAP credential belum lengkap (CHANNEL-ID kosong)', 'nicepay-cancel'));
        }

        $originalReferenceNo = (string) ($order->get_meta('_nicepay_tXid') ?: $transaction_id);
        $originalPartnerReferenceNo = (string) ($order->get_meta('_nicepay_reference_no') ?: (string) $order->get_id());
        $partnerRefundNo = $originalReferenceNo;

        $refundValue = $this->formatAmountSnapRefundValue($order->get_total());
        $refundCurrency = (string) ($order->get_currency() ?: 'IDR');
        $reason = trim($cancel_reason) !== '' ? $cancel_reason : 'Refund EWallet';

        // Body mengikuti pola refund SNAP (mirip QRIS, endpoint ewallet refund)
        $requestBody = [
            'merchantId' => $this->merchantId,
            'subMerchantId' => '',
            'originalPartnerReferenceNo' => $originalPartnerReferenceNo,
            'originalReferenceNo' => $originalReferenceNo,
            'partnerRefundNo' => $partnerRefundNo,
            'externalStoreId' => '',
            'refundAmount' => [
                'value' => $refundValue,
                'currency' => $refundCurrency,
            ],
            'reason' => $reason,
            'additionalInfo' => [
                'refundType' => '1',
            ],
        ];

        $stringBody = json_encode($requestBody, JSON_UNESCAPED_SLASHES);
        $hashbody = strtolower(hash('sha256', $stringBody));
        $X_TIMESTAMP = $this->generate_snap_timestamp_iso();

        try {
            $accessToken = $this->get_snap_access_token();
        } catch (\Throwable $e) {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'ewallet',
                'full_url'       => $full_url,
                'error'          => $e->getMessage(),
            ]);
            return $this->error_response(__('Failed to get SNAP access token', 'nicepay-cancel') . ': ' . $e->getMessage());
        }

        $strigSign = 'POST:/api/v1.0/debit/refund:' . $accessToken . ':' . $hashbody . ':' . $X_TIMESTAMP;
        $bodyHasing = hash_hmac('sha512', $strigSign, $this->snapSecretClient, true);
        $signature = base64_encode($bodyHasing);
        $xExternalId = (string) (date('YmdHis') . rand(1000, 9999));

        $request_headers = [
            'Content-Type'  => 'application/json',
            'X-SIGNATURE'   => $signature,
            'X-CLIENT-KEY'  => $this->merchantId,
            'X-TIMESTAMP'   => $X_TIMESTAMP,
            'Authorization' => 'Bearer ' . $accessToken,
            'CHANNEL-ID'    => $this->channelId,
            'X-EXTERNAL-ID' => $xExternalId,
            'X-PARTNER-ID'  => $this->merchantId,
        ];

        $this->logActivity('cancel_request', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'ewallet',
            'full_url'       => $full_url,
            'endpoint'       => $endpoint,
            'request_headers' => [
                'Content-Type'  => $request_headers['Content-Type'],
                'Authorization' => 'Bearer ' . (strlen($accessToken) > 10 ? substr($accessToken, 0, 10) . '...' : $accessToken),
                'X-TIMESTAMP'   => $request_headers['X-TIMESTAMP'],
                'X-CLIENT-KEY'  => $request_headers['X-CLIENT-KEY'],
                'X-PARTNER-ID'  => $request_headers['X-PARTNER-ID'],
                'CHANNEL-ID'    => $request_headers['CHANNEL-ID'],
                'X-EXTERNAL-ID' => $request_headers['X-EXTERNAL-ID'],
                'X-SIGNATURE'   => strlen($signature) > 10 ? substr($signature, 0, 10) . '...' : $signature,
            ],
            'request_body' => $requestBody,
        ]);

        $started_at = microtime(true);
        $response = wp_remote_post($full_url, [
            'method' => 'POST',
            'timeout' => 45,
            'headers' => $request_headers,
            'body' => $stringBody,
        ]);
        $elapsed_ms = (int) round((microtime(true) - $started_at) * 1000);

        if (is_wp_error($response)) {
            $this->logActivity('cancel_error', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'ewallet',
                'full_url'       => $full_url,
                'elapsed_ms'    => $elapsed_ms,
                'error'          => $response->get_error_message(),
            ]);
            return $this->error_response(sprintf(__('API Error: %s', 'nicepay-cancel'), $response->get_error_message()));
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $response_body_raw = wp_remote_retrieve_body($response);
        $response_body = json_decode($response_body_raw, true);

        $this->logActivity('cancel_response', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'ewallet',
            'full_url'       => $full_url,
            'http_code'      => $http_code,
            'elapsed_ms'    => $elapsed_ms,
            'response_body'  => $response_body_raw,
        ]);

        if (!is_array($response_body)) {
            return $this->error_response(__('Invalid JSON response dari E-Wallet SNAP', 'nicepay-cancel') . ': ' . $response_body_raw);
        }

        $respCode = (string) ($response_body['responseCode'] ?? '');
        $respMsg  = (string) ($response_body['responseMessage'] ?? '');

        if ($respCode !== '' && str_starts_with($respCode, '200')) {
            $this->logActivity('cancel_success', [
                'transaction_id' => $transaction_id,
                'payment_method' => 'ewallet',
                'full_url'       => $full_url,
                'response'       => $response_body,
            ]);

            try {
                $this->update_order_after_cancel($order, [
                    'tXid' => $originalReferenceNo,
                    'referenceNo' => $originalPartnerReferenceNo,
                ]);
            } catch (\Throwable $e) {
                $this->logActivity('cancel_order_update_error', [
                    'transaction_id' => $transaction_id,
                    'payment_method' => 'ewallet',
                    'error'          => $e->getMessage(),
                ]);
            }

            return [
                'success' => true,
                'message' => $respMsg !== '' ? $respMsg : __('E-Wallet SNAP refund success', 'nicepay-cancel'),
                'data' => $response_body,
            ];
        }

        $this->logActivity('cancel_failed', [
            'transaction_id' => $transaction_id,
            'payment_method' => 'ewallet',
            'full_url'       => $full_url,
            'responseCode'  => $respCode,
            'responseMessage' => $respMsg,
            'response'       => $response_body,
        ]);

        return [
            'success' => false,
            'message' => $respMsg !== '' ? $respMsg : __('E-Wallet SNAP refund failed', 'nicepay-cancel'),
            'error_code' => $respCode,
            'data' => $response_body,
        ];
    }

    /**
     * Update order setelah cancel berhasil (wrapper untuk kompatibilitas).
     *
     * @param object $order
     * @param array $response_data
     * @param string $payment_method
     */
    private function updateOrderAfterCancel(object $order, array $response_data, string $payment_method): void
    {
        // Untuk saat ini, logic update order sama untuk semua method.
        // Jika nanti ada perbedaan per payment method, bisa di-handle di sini.
        $this->update_order_after_cancel($order, $response_data);
    }
    
    /**
     * Update order setelah cancel berhasil
     * 
     * @param WC_Order $order
     * @param array $response_data
     */
    private function update_order_after_cancel($order, $response_data) {
        // Update order status ke cancelled
        $order->update_status('cancelled', __('Transaction cancelled via NICEPay API', 'nicepay-cancel'));
        
        // Add order note
        $note = sprintf(
            __('NICEPay transaction cancelled successfully. Transaction ID: %s, Reference: %s', 'nicepay-cancel'),
            isset($response_data['tXid'])
                ? $response_data['tXid']
                : (isset($response_data['originalReferenceNo']) ? $response_data['originalReferenceNo'] : 'N/A'),
            isset($response_data['referenceNo'])
                ? $response_data['referenceNo']
                : (isset($response_data['originalPartnerReferenceNo']) ? $response_data['originalPartnerReferenceNo'] : 'N/A')
        );
        $order->add_order_note($note);
        
        // Save order
        $order->save();
    }
    
    /**
     * Test API connection
     * 
     * @return array Result with success status and message
     */
    public function test_connection() {
        if (empty($this->merchantId) || empty($this->merchantKey)) {
            return array(
                'success' => false,
                'message' => __('API credentials belum dikonfigurasi', 'nicepay-cancel')
            );
        }
        
        // Test dengan request sederhana ke check merchant ID
        $timestamp = date('YmdHis');
        $test_data = array(
            'timeStamp'     => $timestamp,
            'iMid'          => $this->merchantId,
            'merchantToken' => hash('sha256', $timestamp . $this->merchantId . 'TEST' . '0' . $this->merchantKey),
        );
        
        $response = $this->sendApiRequest('/direct/v2/checkMid', $test_data);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => sprintf(__('Connection failed: %s', 'nicepay-cancel'), $response->get_error_message())
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code === 200) {
            $data = json_decode($response_body, true);
            
            // Cek response dari NICEPay
            if (isset($data['resultCd'])) {
                if ($data['resultCd'] === '0000') {
                    return array(
                        'success' => true,
                        'message' => __('Connection successful! Merchant ID is valid.', 'nicepay-cancel')
                    );
                } else {
                    return array(
                        'success' => false,
                        'message' => sprintf(__('API Error: %s (Code: %s)', 'nicepay-cancel'), 
                                   isset($data['resultMsg']) ? $data['resultMsg'] : 'Unknown error',
                                   $data['resultCd'])
                    );
                }
            }
            
            return array(
                'success' => true,
                'message' => __('Connection successful!', 'nicepay-cancel')
            );
        } else {
            return array(
                'success' => false,
                'message' => sprintf(__('Connection failed with HTTP code: %d', 'nicepay-cancel'), $response_code)
            );
        }
    }
    
    /**
     * Generate merchant token untuk autentikasi
     * Format: SHA256(timeStamp+iMid+tXid+amt+merchantKey)
     * 
     * @param string $timestamp
     * @param string $transaction_id
     * @param string $amount
     * @return string
     */
    private function generate_merchant_token($timestamp, $transaction_id, $amount) {
        $string_to_hash = $timestamp . $this->merchantId . $transaction_id . $amount . $this->merchantKey;
        return hash('sha256', $string_to_hash);
    }
    
    /**
     * Send API request ke NICEPay
     * 
     * @param string $endpoint
     * @param array $data
     * @return array|WP_Error
     */
    private function send_api_request($endpoint, $data) {
        $url = rtrim($this->apiUrl, '/') . $endpoint;
        $timeout = 30;
        
        $args = array(
            'body' => wp_json_encode($data),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'timeout' => $timeout,
            'method' => 'POST',
            'sslverify' => true
        );
        
        return wp_remote_request($url, $args);
    }
    
    /**
     * Get server IP address
     * 
     * @return string
     */
    private function get_server_ip() {
        $server_ip = '';
        
        if (isset($_SERVER['SERVER_ADDR'])) {
            $server_ip = $_SERVER['SERVER_ADDR'];
        } elseif (isset($_SERVER['LOCAL_ADDR'])) {
            $server_ip = $_SERVER['LOCAL_ADDR'];
        } else {
            // Fallback: get external IP
            $server_ip = $this->get_external_ip();
        }
        
        return $server_ip ?: '127.0.0.1';
    }
    
    /**
     * Get external IP address
     * 
     * @return string
     */
    private function get_external_ip() {
        $external_ip = '';
        
        $ip_services = array(
            'https://api.ipify.org',
            'https://ifconfig.me/ip',
            'https://icanhazip.com'
        );
        
        foreach ($ip_services as $service) {
            $response = wp_remote_get($service, array('timeout' => 5));
            
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $external_ip = trim(wp_remote_retrieve_body($response));
                if (filter_var($external_ip, FILTER_VALIDATE_IP)) {
                    break;
                }
            }
        }
        
        return $external_ip;
    }
    
    /**
     * Get user info untuk logging
     * 
     * @return string
     */
    private function get_user_info() {
        $current_user = wp_get_current_user();
        
        if ($current_user->ID) {
            return sprintf('%s (%s)', $current_user->display_name, $current_user->user_email);
        }
        
        return 'Unknown User';
    }
    
    /**
     * Sanitize log data untuk menghilangkan sensitive information
     * 
     * @param array $data
     * @return array
     */
    private function sanitize_log_data($data) {
        $sanitized = $data;
        
        // Hide sensitive information
        if (isset($sanitized['merchantToken'])) {
            $sanitized['merchantToken'] = substr($sanitized['merchantToken'], 0, 8) . '...';
        }
        
        if (isset($sanitized['iMid'])) {
            $sanitized['iMid'] = substr($sanitized['iMid'], 0, 4) . '***';
        }
        
        return $sanitized;
    }
    
    /**
     * Log activity untuk debugging dan audit
     * 
     * @param string $action
     * @param array $data
     */
    private function log_activity($action, $data) {
        // Cek apakah logging diaktifkan
        if (!NicePayCancelAdminSettings::get_option('enable_logging', '1')) {
            return;
        }
        
        $log_entry = array(
            'date' => current_time('mysql'),
            'action' => $action,
            'data' => $data,
            'user_id' => get_current_user_id(),
            'ip_address' => $this->get_client_ip()
        );
        
        // Save ke database atau file log
        $this->save_log_entry($log_entry);
    }
    
    /**
     * Save log entry ke database
     * 
     * @param array $log_entry
     */
    private function save_log_entry($log_entry) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'nicepay_cancel_logs';
        
        // Create table jika belum ada
        $this->maybe_create_log_table();
        
        $wpdb->insert(
            $table_name,
            array(
                'date_created' => $log_entry['date'],
                'action' => $log_entry['action'],
                'data' => json_encode($log_entry['data']),
                'user_id' => $log_entry['user_id'],
                'ip_address' => $log_entry['ip_address']
            ),
            array('%s', '%s', '%s', '%d', '%s')
        );
    }
    
    /**
     * Create log table jika belum ada
     */
    private function maybe_create_log_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'nicepay_cancel_logs';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            date_created datetime DEFAULT CURRENT_TIMESTAMP,
            action varchar(100) NOT NULL,
            data longtext,
            user_id int(11) DEFAULT 0,
            ip_address varchar(45),
            PRIMARY KEY (id),
            KEY action (action),
            KEY date_created (date_created)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Get client IP address
     * 
     * @return string
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    }
    
    /**
     * Get logs untuk reporting
     * 
     * @param array $args
     * @return array
     */
    public static function get_logs($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'limit' => 50,
            'offset' => 0,
            'action' => '',
            'date_from' => '',
            'date_to' => '',
            'order' => 'DESC'
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $table_name = $wpdb->prefix . 'nicepay_cancel_logs';
        
        $where_clauses = array();
        $where_values = array();
        
        if (!empty($args['action'])) {
            $where_clauses[] = 'action = %s';
            $where_values[] = $args['action'];
        }
        
        if (!empty($args['date_from'])) {
            $where_clauses[] = 'date_created >= %s';
            $where_values[] = $args['date_from'];
        }
        
        if (!empty($args['date_to'])) {
            $where_clauses[] = 'date_created <= %s';
            $where_values[] = $args['date_to'];
        }
        
        $where_sql = '';
        if (!empty($where_clauses)) {
            $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
        }
        
        $order_sql = 'ORDER BY date_created ' . ($args['order'] === 'ASC' ? 'ASC' : 'DESC');
        $limit_sql = 'LIMIT %d OFFSET %d';
        
        $sql = "SELECT * FROM $table_name $where_sql $order_sql $limit_sql";
        
        $where_values[] = intval($args['limit']);
        $where_values[] = intval($args['offset']);
        
        if (!empty($where_values)) {
            $sql = $wpdb->prepare($sql, $where_values);
        }
        
        return $wpdb->get_results($sql, ARRAY_A);
    }
    
    /**
     * Delete old logs untuk maintenance
     * 
     * @param int $days_old
     * @return int Number of deleted records
     */
    public static function cleanup_old_logs($days_old = 30) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'nicepay_cancel_logs';
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days_old} days"));
        
        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $table_name WHERE date_created < %s",
                $cutoff_date
            )
        );
    }
    
    /**
     * Get transaction info by order ID untuk validasi
     * 
     * @param int $order_id
     * @return array|false
     */
    public function get_transaction_info($order_id) {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return false;
        }
        
        // Get NICEPay transaction ID dari order meta
        $transaction_id = $order->get_meta('_nicepay_transaction_id');
        
        if (empty($transaction_id)) {
            return false;
        }
        
        return array(
            'transaction_id' => $transaction_id,
            'order_id' => $order_id,
            'order_number' => $order->get_order_number(),
            'total' => $order->get_total(),
            'status' => $order->get_status(),
            'payment_method' => $order->get_payment_method()
        );
    }
}