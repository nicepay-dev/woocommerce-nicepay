<?php
/**
 * Filename: includes/class-credential-manager-core.php
 * NICEPay Credential Manager Class
 * Manages multiple MID credentials for different payment methods
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class NicePayCredentialManager {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'nicepay_credentials';
        
       add_action('admin_menu', array($this, 'add_credential_menu'));
        add_action('wp_ajax_nicepay_save_credential', array($this, 'handle_save_credential'));
        add_action('wp_ajax_nicepay_delete_credential', array($this, 'handle_delete_credential'));
        add_action('wp_ajax_nicepay_test_credential', array($this, 'handle_test_credential'));
        add_action('wp_ajax_nicepay_set_default_credential', array($this, 'handle_set_default'));
        add_action('wp_ajax_nicepay_create_credential_table', array($this, 'handle_create_table'));
    }
    
    /**
     * Add credential management menu
     */
    public function add_credential_menu() {
        add_submenu_page(
            'nicepay-cancel',
            __('Credential Manager', 'nicepay-cancel'),
            __('Credentials', 'nicepay-cancel'),
            'manage_options',
            'nicepay-credentials',
            array($this, 'credential_page_callback')
        );
    }
    
    /**
     * Credential management page
     */
    public function credential_page_callback() {
        $credentials = $this->get_all_credentials();
        ?>
        <div class="wrap">
            <h1><?php _e('NICEPay Credential Manager', 'nicepay-cancel'); ?></h1>
            <p class="description">
                <?php _e('Kelola multiple credential NICEPay untuk berbagai payment method atau environment. Berguna untuk merchant yang menggunakan lebih dari satu MID.', 'nicepay-cancel'); ?>
            </p>
            
            <!-- Add New Credential -->
             <div class="postbox">
                <h2 class="hndle"><?php _e('Add New Credential', 'nicepay-cancel'); ?></h2>
                <div class="inside" style="padding: 20px;">
                    <form id="add-credential-form">
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="credential_name"><?php _e('Credential Name', 'nicepay-cancel'); ?> <span class="required">*</span></label>
                                </th>
                                <td>
                                    <input type="text" id="credential_name" name="credential_name" class="regular-text" required 
                                           placeholder="<?php _e('e.g., Production CC, Dev VA, etc.', 'nicepay-cancel'); ?>" />
                                    <p class="description"><?php _e('Nama untuk mengidentifikasi credential ini', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="environment"><?php _e('Environment', 'nicepay-cancel'); ?> <span class="required">*</span></label>
                                </th>
                                <td>
                                    <select id="environment" name="environment" required>
                                        <option value="dev"><?php _e('Development', 'nicepay-cancel'); ?></option>
                                        <option value="prod"><?php _e('Production', 'nicepay-cancel'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="merchant_id"><?php _e('Merchant ID (iMid)', 'nicepay-cancel'); ?> <span class="required">*</span></label>
                                </th>
                                <td>
                                    <input type="text" id="merchant_id" name="merchant_id" class="regular-text" required 
                                           placeholder="IONPAYTEST" />
                                    <p class="description"><?php _e('Merchant ID dari NICEPay', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="merchant_key"><?php _e('Merchant Key', 'nicepay-cancel'); ?> <span class="required">*</span></label>
                                </th>
                                <td>
                                    <input type="password" id="merchant_key" name="merchant_key" class="regular-text" required />
                                    <button type="button" class="button" onclick="togglePassword('merchant_key')"><?php _e('Show/Hide', 'nicepay-cancel'); ?></button>
                                    <p class="description"><?php _e('Merchant Key untuk generate signature', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="client_key"><?php _e('Client Key', 'nicepay-cancel'); ?></label>
                                </th>
                                <td>
                                    <input type="password" id="client_key" name="client_key" class="regular-text" />
                                    <button type="button" class="button" onclick="togglePassword('client_key')"><?php _e('Show/Hide', 'nicepay-cancel'); ?></button>
                                    <p class="description"><?php _e('Client Secret (SNAP) / Client Key (sesuai credential dari NICEPay). Untuk SNAP dipakai sebagai SecretClient (HMAC signature).', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="channel_id"><?php _e('CHANNEL-ID', 'nicepay-cancel'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="channel_id" name="channel_id" class="regular-text" />
                                    <p class="description"><?php _e('CHANNEL-ID untuk SNAP (nilai khusus dari NICEPay, berbeda dengan X-CLIENT-KEY).', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="private_key"><?php _e('Private Key', 'nicepay-cancel'); ?></label>
                                </th>
                                <td>
                                    <textarea id="private_key" name="private_key" rows="4" class="large-text" 
                                              placeholder="-----BEGIN PRIVATE KEY-----"></textarea>
                                    <p class="description"><?php _e('Private Key (opsional, untuk enkripsi tambahan)', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="payment_methods"><?php _e('Payment Methods', 'nicepay-cancel'); ?></label>
                                </th>
                                <td>
                                    <fieldset>
                                        <label><input type="checkbox" name="payment_methods[]" value="credit_card" checked> <?php _e('Credit Card', 'nicepay-cancel'); ?></label><br>
                                        <label><input type="checkbox" name="payment_methods[]" value="virtual_account"> <?php _e('Virtual Account', 'nicepay-cancel'); ?></label><br>
                                        <label><input type="checkbox" name="payment_methods[]" value="qris"> <?php _e('QRIS', 'nicepay-cancel'); ?></label><br>
                                        <label><input type="checkbox" name="payment_methods[]" value="ewallet"> <?php _e('E-Wallet', 'nicepay-cancel'); ?></label><br>
                                        <label><input type="checkbox" name="payment_methods[]" value="convenience_store"> <?php _e('Convenience Store', 'nicepay-cancel'); ?></label><br>
                                        <label><input type="checkbox" name="payment_methods[]" value="Payloan"> <?php _e('Payloan', 'nicepay-cancel'); ?></label><br>
                                    </fieldset>
                                    <p class="description"><?php _e('Payment method yang didukung oleh credential ini', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="is_default"><?php _e('Set as Default', 'nicepay-cancel'); ?></label>
                                </th>
                                <td>
                                    <input type="checkbox" id="is_default" name="is_default" value="1" />
                                    <label for="is_default"><?php _e('Gunakan sebagai credential default', 'nicepay-cancel'); ?></label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="description"><?php _e('Description', 'nicepay-cancel'); ?></label>
                                </th>
                                <td>
                                    <textarea id="description" name="description" rows="3" class="large-text" 
                                              placeholder="<?php _e('Deskripsi penggunaan credential ini...', 'nicepay-cancel'); ?>"></textarea>
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary">
                                <?php _e('Save Credential', 'nicepay-cancel'); ?>
                            </button>
                            <button type="button" id="test-new-credential" class="button button-secondary">
                                <?php _e('Test Connection', 'nicepay-cancel'); ?>
                            </button>
                        </p>
                    </form>
                </div>
            </div>
            
            <!-- Existing Credentials -->
            <div class="postbox">
                <h2 class="hndle"><?php _e('Existing Credentials', 'nicepay-cancel'); ?></h2>
                <div class="inside">
                    <?php if (empty($credentials)): ?>
                        <p style="padding: 20px;">
                            <?php _e('Belum ada credential yang tersimpan. Silakan tambahkan credential pertama Anda.', 'nicepay-cancel'); ?>
                        </p>
                    <?php else: ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Name', 'nicepay-cancel'); ?></th>
                                    <th><?php _e('Environment', 'nicepay-cancel'); ?></th>
                                    <th><?php _e('Merchant ID', 'nicepay-cancel'); ?></th>
                                    <th><?php _e('Payment Methods', 'nicepay-cancel'); ?></th>
                                    <th><?php _e('Status', 'nicepay-cancel'); ?></th>
                                    <th><?php _e('Actions', 'nicepay-cancel'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($credentials as $credential): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo esc_html($credential->credential_name); ?></strong>
                                            <?php if ($credential->is_default): ?>
                                                <span class="default-badge"><?php _e('DEFAULT', 'nicepay-cancel'); ?></span>
                                            <?php endif; ?>
                                            <?php if ($credential->description): ?>
                                                <br><span class="description"><?php echo esc_html($credential->description); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="env-badge env-<?php echo $credential->environment; ?>">
                                                <?php echo $credential->environment === 'prod' ? 'PRODUCTION' : 'DEVELOPMENT'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <code><?php echo esc_html($this->mask_sensitive_data($credential->merchant_id)); ?></code>
                                        </td>
                                        <td>
                                            <?php 
                                            $methods = json_decode($credential->payment_methods, true) ?: [];
                                            echo esc_html(implode(', ', array_map('ucwords', str_replace('_', ' ', $methods))));
                                            ?>
                                        </td>
                                        <td>
                                            <span class="connection-status" data-credential-id="<?php echo $credential->id; ?>">
                                                <span class="status-unknown"><?php _e('Unknown', 'nicepay-cancel'); ?></span>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="button button-small test-credential" 
                                                    data-credential-id="<?php echo $credential->id; ?>">
                                                <?php _e('Test', 'nicepay-cancel'); ?>
                                            </button>
                                            
                                            <?php if (!$credential->is_default): ?>
                                                <button type="button" class="button button-small set-default" 
                                                        data-credential-id="<?php echo $credential->id; ?>">
                                                    <?php _e('Set Default', 'nicepay-cancel'); ?>
                                                </button>
                                            <?php endif; ?>
                                            
                                            <button type="button" class="button button-small edit-credential" 
                                                    data-credential-id="<?php echo $credential->id; ?>">
                                                <?php _e('Edit', 'nicepay-cancel'); ?>
                                            </button>
                                            
                                            <button type="button" class="button button-small button-link-delete delete-credential" 
                                                    data-credential-id="<?php echo $credential->id; ?>"
                                                    data-credential-name="<?php echo esc_attr($credential->credential_name); ?>">
                                                <?php _e('Delete', 'nicepay-cancel'); ?>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Credential Usage Guide -->
            <div class="postbox">
                <h2 class="hndle"><?php _e('Usage Guide', 'nicepay-cancel'); ?></h2>
                <div class="inside" style="padding: 20px;">
                    <h4><?php _e('How to Use Multiple Credentials:', 'nicepay-cancel'); ?></h4>
                    <ol>
                        <li><?php _e('Tambahkan credential untuk setiap MID/environment yang Anda miliki', 'nicepay-cancel'); ?></li>
                        <li><?php _e('Set satu credential sebagai default untuk digunakan secara otomatis', 'nicepay-cancel'); ?></li>
                        <li><?php _e('Saat melakukan cancel, Anda dapat memilih credential mana yang akan digunakan', 'nicepay-cancel'); ?></li>
                        <li><?php _e('Test connection secara berkala untuk memastikan credential masih valid', 'nicepay-cancel'); ?></li>
                    </ol>
                    
                    <h4><?php _e('Best Practices:', 'nicepay-cancel'); ?></h4>
                    <ul>
                        <li><?php _e('Gunakan nama yang deskriptif untuk credential (e.g., "Prod CC Main", "Dev Testing")', 'nicepay-cancel'); ?></li>
                        <li><?php _e('Pisahkan credential production dan development', 'nicepay-cancel'); ?></li>
                        <li><?php _e('Backup credential Anda secara berkala', 'nicepay-cancel'); ?></li>
                        <li><?php _e('Hapus credential yang sudah tidak digunakan', 'nicepay-cancel'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Edit Credential Modal -->
        <div id="edit-credential-modal" class="credential-modal" style="display: none;">
            <div class="credential-modal-content">
                <span class="credential-modal-close">&times;</span>
                <h2><?php _e('Edit Credential', 'nicepay-cancel'); ?></h2>
                <form id="edit-credential-form">
                    <input type="hidden" id="edit_credential_id" name="credential_id" />
                    <!-- Form fields will be populated dynamically -->
                    <div id="edit-form-fields"></div>
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <?php _e('Update Credential', 'nicepay-cancel'); ?>
                        </button>
                        <button type="button" class="button cancel-edit">
                            <?php _e('Cancel', 'nicepay-cancel'); ?>
                        </button>
                    </p>
                </form>
            </div>
        </div>
        
        <style>
        .required { color: #dc3232; font-weight: bold; }
        
        .default-badge {
            background: #00a32a;
            color: white;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            margin-left: 5px;
        }
        
        .env-badge {
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: bold;
        }
        .env-dev { background: #ffb900; color: white; }
        .env-prod { background: #dc3232; color: white; }
        
        .connection-status .status-unknown { color: #999; }
        .connection-status .status-success { color: #00a32a; font-weight: bold; }
        .connection-status .status-error { color: #dc3232; font-weight: bold; }
        
        .credential-modal {
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .credential-modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border-radius: 5px;
            width: 80%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .credential-modal-close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .credential-modal-close:hover { color: #000; }
        
        fieldset label {
            display: block;
            margin: 5px 0;
        }
        
        #add-credential-form .form-table th {
            width: 200px;
        }
        </style>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            
            // Toggle password visibility
            window.togglePassword = function(fieldId) {
                var field = document.getElementById(fieldId);
                if (field.type === 'password') {
                    field.type = 'text';
                } else {
                    field.type = 'password';
                }
            };
            
            // Save credential
            $('#add-credential-form').on('submit', function(e) {
                e.preventDefault();
                
                var formData = new FormData(this);
                formData.append('action', 'nicepay_save_credential');
                formData.append('nonce', '<?php echo wp_create_nonce('nicepay_credential_nonce'); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert('<?php _e('Credential saved successfully!', 'nicepay-cancel'); ?>');
                            location.reload();
                        } else {
                            alert('Error: ' + response.data.message);
                        }
                    },
                    error: function() {
                        alert('<?php _e('Failed to save credential', 'nicepay-cancel'); ?>');
                    }
                });
            });
            
            // Test credential
            $(document).on('click', '.test-credential, #test-new-credential', function() {
                var $button = $(this);
                var credentialId = $button.data('credential-id');
                var isNewCredential = $button.attr('id') === 'test-new-credential';
                
                $button.prop('disabled', true).text('<?php _e('Testing...', 'nicepay-cancel'); ?>');
                
                var data = {
                    action: 'nicepay_test_credential',
                    nonce: '<?php echo wp_create_nonce('nicepay_credential_nonce'); ?>'
                };
                
                if (isNewCredential) {
                    // Get data from form
                    data.merchant_id = $('#merchant_id').val();
                    data.merchant_key = $('#merchant_key').val();
                    data.environment = $('#environment').val();
                } else {
                    data.credential_id = credentialId;
                }
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: data,
                    success: function(response) {
                        var status = response.success ? 'success' : 'error';
                        var message = response.data.message;
                        
                        if (!isNewCredential) {
                            var $statusSpan = $('.connection-status[data-credential-id="' + credentialId + '"] span');
                            $statusSpan.removeClass('status-unknown status-success status-error')
                                      .addClass('status-' + status)
                                      .text(status === 'success' ? '<?php _e('Connected', 'nicepay-cancel'); ?>' : '<?php _e('Failed', 'nicepay-cancel'); ?>');
                        }
                        
                        alert((status === 'success' ? '✓ ' : '✗ ') + message);
                    },
                    error: function() {
                        alert('<?php _e('Test failed', 'nicepay-cancel'); ?>');
                    },
                    complete: function() {
                        $button.prop('disabled', false).text('<?php _e('Test', 'nicepay-cancel'); ?>');
                        if (isNewCredential) {
                            $button.text('<?php _e('Test Connection', 'nicepay-cancel'); ?>');
                        }
                    }
                });
            });
            
            // Set default credential
            $(document).on('click', '.set-default', function() {
                var credentialId = $(this).data('credential-id');
                
                if (confirm('<?php _e('Set this credential as default?', 'nicepay-cancel'); ?>')) {
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'nicepay_set_default_credential',
                            credential_id: credentialId,
                            nonce: '<?php echo wp_create_nonce('nicepay_credential_nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload();
                            } else {
                                alert('Error: ' + response.data.message);
                            }
                        }
                    });
                }
            });
            
            // Delete credential
            $(document).on('click', '.delete-credential', function() {
                var credentialId = $(this).data('credential-id');
                var credentialName = $(this).data('credential-name');
                
                if (confirm('<?php _e('Delete credential', 'nicepay-cancel'); ?> "' + credentialName + '"?\n\n<?php _e('This action cannot be undone.', 'nicepay-cancel'); ?>')) {
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'nicepay_delete_credential',
                            credential_id: credentialId,
                            nonce: '<?php echo wp_create_nonce('nicepay_credential_nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload();
                            } else {
                                alert('Error: ' + response.data.message);
                            }
                        }
                    });
                }
            });
            
            // Modal functionality (for edit - simplified for now)
            $('.credential-modal-close, .cancel-edit').on('click', function() {
                $('#edit-credential-modal').hide();
            });
            
            $(window).on('click', function(e) {
                if ($(e.target).hasClass('credential-modal')) {
                    $('.credential-modal').hide();
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Handle save credential AJAX
     */
    public function handle_save_credential() {
         if (!wp_verify_nonce($_POST['nonce'], 'nicepay_credential_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'nicepay-cancel')));
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'nicepay-cancel')));
        }
        
        // Validate required fields
        $required_fields = ['credential_name', 'environment', 'merchant_id', 'merchant_key'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                wp_send_json_error(array('message' => sprintf(__('Field %s is required', 'nicepay-cancel'), $field)));
            }
        }
         // Check for duplicate credential name
        global $wpdb;
        $this->maybe_create_table();
        
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table_name} WHERE credential_name = %s",
                sanitize_text_field($_POST['credential_name'])
            )
        );
        
        if ($existing > 0) {
            wp_send_json_error(array('message' => __('Credential name already exists. Please choose a different name.', 'nicepay-cancel')));
        }
        
        $credential_data = array(
             'credential_name' => sanitize_text_field($_POST['credential_name']),
            'environment' => sanitize_text_field($_POST['environment']),
            'merchant_id' => sanitize_text_field($_POST['merchant_id']),
            'merchant_key' => sanitize_text_field($_POST['merchant_key']),
            'client_key' => sanitize_text_field($_POST['client_key']),
            'channel_id' => sanitize_text_field($_POST['channel_id'] ?? ''),
            'private_key' => sanitize_textarea_field($_POST['private_key']),
            'payment_methods' => json_encode($_POST['payment_methods'] ?? array('credit_card')),
            'is_default' => isset($_POST['is_default']) ? 1 : 0,
            'description' => sanitize_textarea_field($_POST['description'])
        );
        
        $result = $this->save_credential($credential_data);
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Credential saved successfully', 'nicepay-cancel'),
                'credential_id' => $wpdb->insert_id
            ));
        } else {
            $error_msg = !empty($wpdb->last_error) ? $wpdb->last_error : __('Failed to save credential', 'nicepay-cancel');
            wp_send_json_error(array('message' => $error_msg));
        }
    }
    
    /**
     * Handle test credential AJAX
     */
    public function handle_test_credential() {
        if (!wp_verify_nonce($_POST['nonce'], 'nicepay_credential_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'nicepay-cancel')));
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'nicepay-cancel')));
        }
        
        $credential_id = intval($_POST['credential_id'] ?? 0);
        
        if ($credential_id > 0) {
            $credential = $this->get_credential($credential_id);
            if (!$credential) {
                wp_send_json_error(array('message' => __('Credential not found', 'nicepay-cancel')));
            }
        } else {
            // Test new credential from form
            $credential = (object) array(
                'merchant_id' => sanitize_text_field($_POST['merchant_id']),
                'merchant_key' => sanitize_text_field($_POST['merchant_key']),
                'environment' => sanitize_text_field($_POST['environment'])
            );
        }
        
        $result = $this->test_credential_connection($credential);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * Handle set default credential
     */
    public function handle_set_default() {
        if (!wp_verify_nonce($_POST['nonce'], 'nicepay_credential_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'nicepay-cancel')));
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'nicepay-cancel')));
        }
        
        $credential_id = intval($_POST['credential_id']);
        $result = $this->set_default_credential($credential_id);
        
        if ($result) {
            wp_send_json_success(array('message' => __('Default credential updated', 'nicepay-cancel')));
        } else {
            wp_send_json_error(array('message' => __('Failed to update default credential', 'nicepay-cancel')));
        }
    }
    
    /**
     * Handle delete credential
     */
    public function handle_delete_credential() {
        if (!wp_verify_nonce($_POST['nonce'], 'nicepay_credential_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'nicepay-cancel')));
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'nicepay-cancel')));
        }
        
        $credential_id = intval($_POST['credential_id']);
        $result = $this->delete_credential($credential_id);
        
        if ($result) {
            wp_send_json_success(array('message' => __('Credential deleted successfully', 'nicepay-cancel')));
        } else {
            wp_send_json_error(array('message' => __('Failed to delete credential', 'nicepay-cancel')));
        }
    }

    /**
     * Handle create table AJAX
     */
    public function handle_create_table() {
        if (!wp_verify_nonce($_POST['nonce'], 'nicepay_credential_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'nicepay-cancel')));
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'nicepay-cancel')));
        }
        
        $result = self::create_table();
        
        if ($result) {
            wp_send_json_success(array('message' => __('Credential table created successfully', 'nicepay-cancel')));
        } else {
            wp_send_json_error(array('message' => __('Failed to create credential table', 'nicepay-cancel')));
        }
    }
        
    
    
    /**
     * Save credential to database
     */
    private function save_credential($data) {
        global $wpdb;
        $this->maybe_create_table();
        
        // If setting as default, unset other defaults first
        if ($data['is_default']) {
            $wpdb->update(
                $this->table_name,
                array('is_default' => 0),
                array('1' => '1'),
                array('%d'),
                array('%s')
            );
        }
        
        $data['created_at'] = current_time('mysql');
        $data['updated_at'] = current_time('mysql');
        
        $result = $wpdb->insert($this->table_name, $data);
        
        if ($result === false) {
            error_log('NICEPay Credential Save Error: ' . $wpdb->last_error);
        }
        
        return $result;
    }
    private function maybe_create_table() {
        global $wpdb;
        
        $table_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $this->table_name
            )
        );
        
        if (!$table_exists) {
            $this->create_table_now();
            return;
        }

        // Backward compatibility:
        // Jika tabel sudah ada dari versi lama, pastikan kolom baru tetap dibuat.
        $this->maybe_add_missing_columns();
    }

    /**
     * Add missing columns for existing installations.
     */
    private function maybe_add_missing_columns(): void
    {
        global $wpdb;

        $columns = $wpdb->get_col("SHOW COLUMNS FROM {$this->table_name}", 0);
        if (!is_array($columns)) {
            return;
        }

        if (!in_array('channel_id', $columns, true)) {
            $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN channel_id text DEFAULT NULL AFTER client_key");
            if (!empty($wpdb->last_error)) {
                error_log('NICEPay Migration Error (channel_id): ' . $wpdb->last_error);
            }
        }
    }
     private function create_table_now() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE {$this->table_name} (
            id int(11) NOT NULL AUTO_INCREMENT,
            credential_name varchar(255) NOT NULL,
            environment enum('dev','prod') NOT NULL DEFAULT 'dev',
            merchant_id varchar(100) NOT NULL,
            merchant_key text NOT NULL,
            client_key text DEFAULT NULL,
            channel_id text DEFAULT NULL,
            private_key longtext DEFAULT NULL,
            payment_methods longtext DEFAULT NULL,
            is_default tinyint(1) DEFAULT 0,
            description text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_name (credential_name),
            KEY environment (environment),
            KEY is_default (is_default)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $result = dbDelta($sql);
        
        if (!empty($wpdb->last_error)) {
            error_log('NICEPay Table Creation Error: ' . $wpdb->last_error);
        }
        
        return $result;
    }
    
    /**
     * Get all credentials
     */
    public function get_all_credentials() {
        global $wpdb;
        
        // Ensure table exists
        $this->maybe_create_table();
        
        return $wpdb->get_results(
            "SELECT * FROM {$this->table_name} ORDER BY is_default DESC, credential_name ASC"
        );
    }
    
    /**
     * Get single credential
     */
    public function get_credential($credential_id) {
        global $wpdb;
        
        // Ensure table exists
        $this->maybe_create_table();
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $credential_id)
        );
    }
    
    /**
     * Get default credential
     */
     public function get_default_credential() {
        global $wpdb;
        
        // Ensure table exists
        $this->maybe_create_table();
        
        return $wpdb->get_row(
            "SELECT * FROM {$this->table_name} WHERE is_default = 1 LIMIT 1"
        );
    }
    /**
     * Get credentials by payment method
     */
    public function get_credentials_by_payment_method($payment_method) {
        global $wpdb;
        
        // Ensure table exists
        $this->maybe_create_table();
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->table_name} WHERE payment_methods LIKE %s ORDER BY is_default DESC",
                '%' . $payment_method . '%'
            )
        );
    }
    
    /**
     * Set default credential
     */
    public function set_default_credential($credential_id) {
        global $wpdb;
        
        // Ensure table exists
        $this->maybe_create_table();
        
        // First, unset all defaults with safe WHERE clause
        $wpdb->update(
            $this->table_name,
            array('is_default' => 0),
            array('1' => '1'), // Safe WHERE clause to update all rows
            array('%d'),
            array('%s')
        );
        
        // Then set the new default
        return $wpdb->update(
            $this->table_name,
            array('is_default' => 1, 'updated_at' => current_time('mysql')),
            array('id' => $credential_id),
            array('%d', '%s'),
            array('%d')
        );
    }
    
    /**
     * Delete credential
     */
    public function delete_credential($credential_id) {
        global $wpdb;
        
        // Ensure table exists
        $this->maybe_create_table();
        
        return $wpdb->delete(
            $this->table_name,
            array('id' => $credential_id),
            array('%d')
        );
    }
    
    /**
     * Test credential connection
     */
    private function test_credential_connection($credential) {
        $api_url = $credential->environment === 'prod' 
            ? 'https://www.nicepay.co.id/nicepay' 
            : 'https://dev.nicepay.co.id/nicepay';
        
        $timestamp = date('YmdHis');
        $test_data = array(
            'timeStamp' => $timestamp,
            'iMid' => $credential->merchant_id,
            'merchantToken' => hash('sha256', $timestamp . $credential->merchant_id . 'TEST' . '0' . $credential->merchant_key)
        );
        
        $response = wp_remote_post($api_url . '/direct/v2/checkMid', array(
            'body' => json_encode($test_data),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => sprintf(__('Connection failed: %s', 'nicepay-cancel'), $response->get_error_message())
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code === 200) {
            $data = json_decode($response_body, true);
            
            if (isset($data['resultCd'])) {
                if ($data['resultCd'] === '0000') {
                    return array(
                        'success' => true,
                        'message' => __('Connection successful! Credentials are valid.', 'nicepay-cancel')
                    );
                } else {
                    return array(
                        'success' => false,
                        'message' => sprintf(__('API Error: %s (Code: %s)', 'nicepay-cancel'), 
                                   isset($data['resultMsg']) ? $data['resultMsg'] : 'Unknown error',
                                   $data['resultCd'])
                    );
                }
            }
            
            return array(
                'success' => true,
                'message' => __('Connection successful!', 'nicepay-cancel')
            );
        } else {
            return array(
                'success' => false,
                'message' => sprintf(__('HTTP Error: %d', 'nicepay-cancel'), $response_code)
            );
        }
    }
    
    /**
     * Mask sensitive data for display
     */
    private function mask_sensitive_data($data, $visible_chars = 4) {
        if (strlen($data) <= $visible_chars) {
            return $data;
        }
        
        return substr($data, 0, $visible_chars) . str_repeat('*', strlen($data) - $visible_chars);
    }
    
    /**
     * Create credentials table
     */
     public static function create_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'nicepay_credentials';
        
        // Check if table already exists
        $table_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $table_name
            )
        );
        
        if ($table_exists) {
            return true; // Table already exists
        }
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            credential_name varchar(255) NOT NULL,
            environment enum('dev','prod') NOT NULL DEFAULT 'dev',
            merchant_id varchar(100) NOT NULL,
            merchant_key text NOT NULL,
            client_key text DEFAULT NULL,
            channel_id text DEFAULT NULL,
            private_key longtext DEFAULT NULL,
            payment_methods longtext DEFAULT NULL,
            is_default tinyint(1) DEFAULT 0,
            description text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_name (credential_name),
            KEY environment (environment),
            KEY is_default (is_default)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $result = dbDelta($sql);
        
        // Log any errors
        if (!empty($wpdb->last_error)) {
            error_log('NICEPay Credential Table Creation Error: ' . $wpdb->last_error);
            return false;
        }
        
        return true;
    }
    
    /**
     * Get credential options for select dropdown
     */
    public function get_credential_options($payment_method = '') {
        $credentials = empty($payment_method) 
            ? $this->get_all_credentials() 
            : $this->get_credentials_by_payment_method($payment_method);
        
        $options = array();
        foreach ($credentials as $credential) {
            $label = $credential->credential_name;
            if ($credential->is_default) {
                $label .= ' (Default)';
            }
            $label .= ' - ' . strtoupper($credential->environment);
            
            $options[$credential->id] = $label;
        }
        
        return $options;
    }
    
    /**
     * Export credentials (for backup)
     */
    public function export_credentials($include_sensitive = false) {
        $credentials = $this->get_all_credentials();
        
        $export_data = array();
        foreach ($credentials as $credential) {
            $data = array(
                'credential_name' => $credential->credential_name,
                'environment' => $credential->environment,
                'merchant_id' => $credential->merchant_id,
                'payment_methods' => $credential->payment_methods,
                'description' => $credential->description,
                'is_default' => $credential->is_default
            );
            
            if ($include_sensitive) {
                $data['merchant_key'] = $credential->merchant_key;
                $data['client_key'] = $credential->client_key;
                $data['channel_id'] = $credential->channel_id ?? '';
                $data['private_key'] = $credential->private_key;
            }
            
            $export_data[] = $data;
        }
        
        return $export_data;
    }
    
    /**
     * Import credentials (from backup)
     */
    public function import_credentials($import_data) {
        $imported = 0;
        $errors = array();
        
        foreach ($import_data as $data) {
            if (empty($data['credential_name']) || empty($data['merchant_id'])) {
                $errors[] = 'Invalid credential data: missing required fields';
                continue;
            }
            
            // Check if credential name already exists
            global $wpdb;
            $existing = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table_name} WHERE credential_name = %s",
                    $data['credential_name']
                )
            );
            
            if ($existing > 0) {
                $errors[] = 'Credential "' . $data['credential_name'] . '" already exists';
                continue;
            }
            
            if ($this->save_credential($data)) {
                $imported++;
            } else {
                $errors[] = 'Failed to import credential "' . $data['credential_name'] . '"';
            }
        }
        
        return array(
            'imported' => $imported,
            'errors' => $errors
        );
    }
}