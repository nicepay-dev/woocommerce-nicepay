<?php
/**
 * Filename: includes/class-credential-manager.php
 * NICEPay Credential Manager Class Loader
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Load the core credential manager
$core_file = NICEPAY_CANCEL_PLUGIN_PATH . 'includes/class-credential-manager-core.php';
if (file_exists($core_file)) {
    require_once $core_file;
    
    // Initialize the credential manager
    if (class_exists('NicePayCredentialManager')) {
        // Create table on class load
        add_action('init', function() {
            if (is_admin()) {
                NicePayCredentialManager::create_table();
            }
        });
        
        // Initialize the class
        new NicePayCredentialManager();
    } else {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>NICEPay Cancel:</strong> Failed to load NicePayCredentialManager class.</p></div>';
        });
    }
} else {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>NICEPay Cancel:</strong> Credential manager core file not found.</p></div>';
    });
}