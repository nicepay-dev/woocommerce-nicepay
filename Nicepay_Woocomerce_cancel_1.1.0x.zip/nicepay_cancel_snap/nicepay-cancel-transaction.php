<?php
/**
 * Plugin Name: NICEPay Cancel Transaction
 * Plugin URI: https://www.nicepay.co.id/
 * Description: Plugin untuk melakukan cancel transaksi NICEPay
 * Version: 1.1.0
 * Author: NICEPay Integration
 * License: GPL v2 or SNAP
 * Text Domain: nicepay-cancel
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 8.2
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// PHP version compatibility check
if (version_compare(PHP_VERSION, '8.2', '<')) {
    add_action('admin_notices', static function (): void {
        echo '<div class="notice notice-error"><p><strong>NICEPay Cancel</strong> requires PHP 8.2 or higher. Current version: ' . PHP_VERSION . '</p></div>';
    });
    return;
}

// Check if WooCommerce is active
add_action('plugins_loaded', static function (): void {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', static function (): void {
            echo '<div class="notice notice-error"><p><strong>NICEPay Cancel Transaction</strong> requires WooCommerce to be installed and active.</p></div>';
        });
        return;
    }

    // Initialize plugin only if WooCommerce is active
    NicePayCancelPlugin::get_instance();
});

// Define plugin constants
define('NICEPAY_CANCEL_VERSION', '1.1.0');
define('NICEPAY_CANCEL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NICEPAY_CANCEL_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NICEPAY_CANCEL_PLUGIN_BASENAME', plugin_basename(__FILE__));

enum NicePayPaymentMethod: string
{
    case CreditCard        = 'cc';
    case VirtualAccount    = 'va';
    case QRIS              = 'qris';
    case EWallet           = 'ewallet';
    case ConvenienceStore  = 'cstore';
    case PayLoan           = 'payloan';

    /**
     * Label human-readable untuk setiap payment method
     */
    public function label(): string
    {
        return match($this) {
            self::CreditCard       => 'Credit Card',
            self::VirtualAccount   => 'Virtual Account',
            self::QRIS             => 'QRIS',
            self::EWallet          => 'E-Wallet',
            self::ConvenienceStore => 'Convenience Store',
            self::PayLoan          => 'PayLoan',
        };
    }

    /**
     * Icon untuk setiap payment method
     */
    public function icon(): string
    {
        return match($this) {
            self::CreditCard       => '💳',
            self::VirtualAccount   => '🏦',
            self::QRIS             => '📱',
            self::EWallet          => '👛',
            self::ConvenienceStore => '🏪',
            self::PayLoan          => '📄',
        };
    }
}

readonly class CancelResult
{
    public function __construct(
        public bool   $success,
        public string $message,
        public array  $data = [],
    ) {}

    /**
     * Named constructor untuk hasil sukses
     */
    public static function success(string $message, array $data = []): self
    {
        return new self(success: true, message: $message, data: $data);
    }

    /**
     * Named constructor untuk hasil error
     */
    public static function error(string $message, array $data = []): self
    {
        return new self(success: false, message: $message, data: $data);
    }

    public function toArray(): array
    {
        return [
            'success' => $this->success,
            'message' => $this->message,
            'data'    => $this->data,
        ];
    }
}
final class NicePayDummyOrder
{
    private readonly string $resolvedReferenceNo;

    public function __construct(
        private readonly string $transactionId,
        private readonly float  $amount,
        private readonly string $referenceNo = '',
    ) {
        $this->resolvedReferenceNo = $referenceNo !== ''
            ? $referenceNo
            : 'MANUAL_CANCEL_' . time();
    }

    public function get_id(): int
    {
        return 0;
    }

    public function get_total(): float
    {
        return $this->amount;
    }

    public function get_order_number(): string
    {
        return $this->resolvedReferenceNo;
    }

    public function get_status(): string
    {
        return 'manual-cancel';
    }

    public function update_status(string $status, string $note = ''): bool
    {
        return true;
    }

    public function add_order_note(string $note): bool
    {
        return true;
    }

    public function save(): bool
    {
        return true;
    }

    public function get_meta(string $key): string
    {
        return match($key) {
            '_nicepay_transaction_id' => $this->transactionId,
            default                   => '',
        };
    }
}
final class NicePayCancelPlugin
{
    /**
     * Single instance — menggunakan typed static property (PHP 8.0+)
     */
    private static ?self $instance = null;

    /**
     * Constructor — private untuk Singleton pattern
     */
    private function __construct()
    {
        $this->init_hooks();
    }

    /**
     * Get single instance (Singleton)
     */
    public static function get_instance(): static
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void
    {
        add_action('init', $this->init(...));
        add_action('admin_menu', $this->add_admin_menu(...));
        add_action('admin_enqueue_scripts', $this->enqueue_admin_scripts(...));
        add_action('admin_post_nicepay_clear_logs', $this->handle_clear_logs(...));

        // AJAX handlers
        add_action('wp_ajax_nicepay_cancel_transaction', $this->handle_cancel_transaction(...));
        add_action('wp_ajax_nicepay_search_transaction', $this->handle_search_transaction(...));
        add_action('wp_ajax_nicepay_get_credentials', $this->handle_get_credentials(...));

        // Order management
        add_filter('manage_edit-shop_order_columns', $this->add_order_column(...));
        add_action('manage_shop_order_posts_custom_column', $this->populate_order_column(...), 10, 2);
        add_action('woocommerce_order_details_after_order_table', $this->add_cancel_button_to_order(...));

        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, $this->activate(...));
        register_deactivation_hook(__FILE__, $this->deactivate(...));
    }

    /**
     * Initialize plugin
     */
    public function init(): void
    {
        load_plugin_textdomain(
            'nicepay-cancel',
            false,
            dirname(NICEPAY_CANCEL_PLUGIN_BASENAME) . '/languages'
        );

        $this->load_dependencies();
    }

    /**
     * Load required files safely
     */
    private function load_dependencies(): void
    {
        $files = [
            'includes/class-admin-setting.php',
            'includes/class-nicepay-api.php',
            'includes/class-credential-manager.php',
        ];

        foreach ($files as $file) {
            $file_path = NICEPAY_CANCEL_PLUGIN_PATH . $file;

            if (file_exists($file_path) && is_readable($file_path)) {
                require_once $file_path;
            } else {
                add_action('admin_notices', static function () use ($file): void {
                    echo '<div class="notice notice-warning"><p><strong>NICEPay Cancel:</strong> Missing file: ' . esc_html($file) . '</p></div>';
                });
            }
        }
    }

    
    /**
     * Add admin menu
     */
    public function add_admin_menu(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        add_submenu_page(
            parent_slug: 'woocommerce',
            page_title:  __('NICEPay Cancel', 'nicepay-cancel'),
            menu_title:  __('NICEPay Cancel', 'nicepay-cancel'),
            capability:  'manage_woocommerce',
            menu_slug:   'nicepay-cancel',
            callback:    $this->admin_page_callback(...),
        );

        add_submenu_page(
            parent_slug: 'woocommerce',
            page_title:  __('Cancel Logs', 'nicepay-cancel'),
            menu_title:  __('Cancel Logs', 'nicepay-cancel'),
            capability:  'manage_woocommerce',
            menu_slug:   'nicepay-cancel-logs',
            callback:    $this->log_page_callback(...),
        );
    }

    /**
     * Log Cancel page — tampilkan riwayat log cancel untuk debugging
     */
    public function log_page_callback(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $action_filter = isset($_GET['log_action']) ? sanitize_text_field($_GET['log_action']) : '';
        $date_from     = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        $date_to       = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';
        $limit         = isset($_GET['limit']) ? min(200, max(10, (int) $_GET['limit'])) : 100;

        $args = [
            'limit'     => $limit,
            'offset'    => 0,
            'action'    => $action_filter,
            'date_from' => $date_from,
            'date_to'   => $date_to,
            'order'     => 'DESC',
        ];

        $logs = [];
        if (class_exists('NicePayAPI')) {
            $logs = NicePayAPI::get_logs($args);
        }

        $base_url = admin_url('admin.php?page=nicepay-cancel-logs');
        $logs_cleared = isset($_GET['nicepay_logs_cleared']) && $_GET['nicepay_logs_cleared'] === '1';
        ?>
        <div class="wrap">
            <h1><?php _e('NICEPay Cancel Logs', 'nicepay-cancel'); ?></h1>
            <p class="description">
                <?php _e('Riwayat request/response cancel transaksi. Gunakan untuk debugging saat cancel gagal.', 'nicepay-cancel'); ?>
            </p>

            <?php if ($logs_cleared): ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php _e('Cancel logs berhasil dihapus.', 'nicepay-cancel'); ?></p>
                </div>
            <?php endif; ?>

            <form method="get" action="" class="nicepay-log-filter" style="margin-bottom: 10px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
                <input type="hidden" name="page" value="nicepay-cancel-logs" />
                <label>
                    <?php _e('Action', 'nicepay-cancel'); ?>
                    <select name="log_action">
                        <option value=""><?php _e('Semua', 'nicepay-cancel'); ?></option>
                        <option value="cancel_request"  <?php selected($action_filter, 'cancel_request'); ?>><?php _e('Request', 'nicepay-cancel'); ?></option>
                        <option value="cancel_response" <?php selected($action_filter, 'cancel_response'); ?>><?php _e('Response', 'nicepay-cancel'); ?></option>
                        <option value="cancel_success"  <?php selected($action_filter, 'cancel_success'); ?>><?php _e('Success', 'nicepay-cancel'); ?></option>
                        <option value="cancel_failed"   <?php selected($action_filter, 'cancel_failed'); ?>><?php _e('Failed', 'nicepay-cancel'); ?></option>
                        <option value="cancel_error"    <?php selected($action_filter, 'cancel_error'); ?>><?php _e('Error', 'nicepay-cancel'); ?></option>
                    </select>
                </label>
                <label style="margin-left: 15px;">
                    <?php _e('Dari tanggal', 'nicepay-cancel'); ?>
                    <input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>" />
                </label>
                <label style="margin-left: 15px;">
                    <?php _e('Sampai tanggal', 'nicepay-cancel'); ?>
                    <input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>" />
                </label>
                <label style="margin-left: 15px;">
                    <?php _e('Limit', 'nicepay-cancel'); ?>
                    <input type="number" name="limit" value="<?php echo esc_attr($limit); ?>" min="10" max="200" step="10" style="width: 70px;" />
                </label>
                <button type="submit" class="button button-primary" style="margin-left: 15px;"><?php _e('Filter', 'nicepay-cancel'); ?></button>
                <a href="<?php echo esc_url($base_url); ?>" class="button" style="margin-left: 5px;"><?php _e('Reset', 'nicepay-cancel'); ?></a>
            </form>

            <?php if (!empty($logs)): ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom: 20px;">
                    <?php wp_nonce_field('nicepay_clear_logs', 'nicepay_clear_logs_nonce'); ?>
                    <input type="hidden" name="action" value="nicepay_clear_logs" />
                    <button type="submit"
                            class="button button-secondary"
                            onclick="return confirm('<?php echo esc_js(__('Yakin ingin menghapus semua cancel logs? Tindakan ini tidak dapat dibatalkan.', 'nicepay-cancel')); ?>');">
                        <?php _e('Hapus Semua Cancel Logs', 'nicepay-cancel'); ?>
                    </button>
                </form>
            <?php endif; ?>

            <?php if (empty($logs)): ?>
                <p><?php _e('Belum ada log cancel.', 'nicepay-cancel'); ?></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 140px;"><?php _e('Waktu', 'nicepay-cancel'); ?></th>
                            <th style="width: 120px;"><?php _e('Action', 'nicepay-cancel'); ?></th>
                            <th><?php _e('Data', 'nicepay-cancel'); ?></th>
                            <th style="width: 80px;"><?php _e('User', 'nicepay-cancel'); ?></th>
                            <th style="width: 110px;"><?php _e('IP', 'nicepay-cancel'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $row): ?>
                            <?php
                            $data = isset($row['data']) ? json_decode($row['data'], true) : [];
                            $data_preview = $this->format_log_data_preview($row['action'], $data);
                            $data_json    = $row['data'] ?? '';
                            ?>
                            <tr>
                                <td><?php echo esc_html($row['date_created'] ?? '-'); ?></td>
                                <td>
                                    <span class="log-action log-action-<?php echo esc_attr($row['action'] ?? ''); ?>">
                                        <?php echo esc_html($row['action'] ?? '-'); ?>
                                    </span>
                                </td>
                                <td>
                                    <details>
                                        <summary style="cursor: pointer; color: #0073aa;"><?php echo esc_html($data_preview); ?></summary>
                                        <pre style="margin: 8px 0 0 0; padding: 10px; background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; max-height: 300px; overflow: auto;"><?php echo esc_html($data_json); ?></pre>
                                    </details>
                                </td>
                                <td><?php echo esc_html($row['user_id'] ?? '-'); ?></td>
                                <td><code><?php echo esc_html($row['ip_address'] ?? '-'); ?></code></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <style>
            .log-action-cancel_success { color: #00a32a; font-weight: 600; }
            .log-action-cancel_failed, .log-action-cancel_error { color: #d63638; font-weight: 600; }
            .log-action-cancel_request { color: #0073aa; }
            .log-action-cancel_response { color: #646970; }
        </style>
        <?php
    }

    /**
     * Handle clear logs action (hapus semua log cancel)
     */
    public function handle_clear_logs(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('Insufficient permissions', 'nicepay-cancel'));
        }

        if (!isset($_POST['nicepay_clear_logs_nonce']) || !wp_verify_nonce($_POST['nicepay_clear_logs_nonce'], 'nicepay_clear_logs')) {
            wp_die(__('Security check failed', 'nicepay-cancel'));
        }

        if (!class_exists('NicePayAPI')) {
            wp_safe_redirect(admin_url('admin.php?page=nicepay-cancel-logs'));
            exit;
        }

        // Hapus semua log (older than 0 days => semua)
        NicePayAPI::cleanup_old_logs(0);

        wp_safe_redirect(
            add_query_arg(
                ['page' => 'nicepay-cancel-logs', 'nicepay_logs_cleared' => '1'],
                admin_url('admin.php')
            )
        );
        exit;
    }

    /**
     * Ringkasan singkat isi log untuk kolom Data (summary)
     */
    private function format_log_data_preview(string $action, array $data): string
    {
        if (empty($data)) {
            return '-';
        }
        switch ($action) {
            case 'cancel_request':
                $tx = $data['transaction_id'] ?? $data['tXid'] ?? '';
                $pm = $data['payment_method'] ?? '';
                return $tx ? sprintf('tXid: %s%s', $tx, $pm ? ' | ' . $pm : '') : wp_json_encode($data);
            case 'cancel_response':
                $code = $data['response_code'] ?? '';
                $body = $data['response_body'] ?? '';
                if ($body !== '') {
                    $decoded = json_decode($body, true);
                    $rc = $decoded['resultCd'] ?? $code;
                    $rm = $decoded['resultMsg'] ?? '';
                    return $rc ? sprintf('[%s] %s', $rc, $rm ?: substr($body, 0, 80)) : substr($body, 0, 120);
                }
                return $code ? "HTTP {$code}" : substr($body, 0, 80);
            case 'cancel_success':
                return $data['transaction_id'] ?? ($data['tXid'] ?? wp_json_encode($data));
            case 'cancel_failed':
            case 'cancel_error':
                return $data['error_message'] ?? $data['error'] ?? wp_json_encode($data);
            default:
                return wp_json_encode($data);
        }
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts(string $hook): void
    {
        $allowed_hooks = ['woocommerce_page_nicepay-cancel', 'woocommerce_page_nicepay-cancel-logs', 'post.php', 'edit.php'];

        if (!in_array($hook, $allowed_hooks, strict: true)) {
            return;
        }

        wp_enqueue_script('jquery');

        $js_file = NICEPAY_CANCEL_PLUGIN_PATH . 'assets/admin.js';

        if (file_exists($js_file)) {
            wp_enqueue_script(
                'nicepay-cancel-admin',
                NICEPAY_CANCEL_PLUGIN_URL . 'assets/admin.js',
                ['jquery'],
                NICEPAY_CANCEL_VERSION,
                true,
            );

            wp_localize_script('nicepay-cancel-admin', 'nicepay_ajax', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('nicepay_cancel_nonce'),
                'messages' => [
                    'confirm_cancel' => __('Apakah Anda yakin ingin membatalkan transaksi ini? Tindakan ini tidak dapat dibatalkan.', 'nicepay-cancel'),
                    'processing'     => __('Memproses...', 'nicepay-cancel'),
                    'success'        => __('Transaksi berhasil dibatalkan', 'nicepay-cancel'),
                    'error'          => __('Terjadi kesalahan saat membatalkan transaksi', 'nicepay-cancel'),
                    'search_required'=> __('Mohon masukkan nilai pencarian', 'nicepay-cancel'),
                ],
            ]);
        }

        $css_file = NICEPAY_CANCEL_PLUGIN_PATH . 'assets/admin.css';

        if (file_exists($css_file)) {
            wp_enqueue_style(
                'nicepay-cancel-admin',
                NICEPAY_CANCEL_PLUGIN_URL . 'assets/admin.css',
                [],
                NICEPAY_CANCEL_VERSION,
            );
        }
    }

    
    /**
     * Admin page callback
     */
    public function admin_page_callback(): void
    {
        $is_configured = class_exists('NicePayCancelAdminSettings')
            && NicePayCancelAdminSettings::is_configured();

        ?>
        <div class="wrap">
            <h1><?php _e('NICEPay Cancel Transaction', 'nicepay-cancel'); ?></h1>

            <?php if (!$is_configured): ?>
                <div class="notice notice-warning">
                    <p><strong><?php _e('Configuration Required!', 'nicepay-cancel'); ?></strong></p>
                    <p><?php _e('Plugin belum dikonfigurasi. Silakan lengkapi Merchant ID dan Merchant Key terlebih dahulu.', 'nicepay-cancel'); ?></p>
                    <p><a href="<?php echo admin_url('admin.php?page=nicepay-cancel-settings'); ?>" class="button button-primary"><?php _e('Go to Settings', 'nicepay-cancel'); ?></a></p>
                </div>
            <?php else: ?>
                <div class="notice notice-success">
                    <p><strong><?php _e('Plugin Ready!', 'nicepay-cancel'); ?></strong></p>
                    <p><?php _e('Plugin sudah dikonfigurasi dan siap digunakan untuk cancel transaksi NICEPay.', 'nicepay-cancel'); ?></p>
                </div>
            <?php endif; ?>

            <!-- Manual Cancel Section -->
            <div class="postbox">
                <h2 class="hndle"><?php _e('Manual Cancel Transaction', 'nicepay-cancel'); ?></h2>
                <div class="inside" style="padding: 20px;">

                    <!-- Credential Selector -->
                    <?php
                    $credential_options = [];
                    if (class_exists('NicePayCredentialManager')) {
                        $credential_manager = new NicePayCredentialManager();
                        // Tampilkan semua credential agar bisa dipakai lintas payment method (CC/VA/QRIS/EWallet/CVS/PayLoan).
                        // Filtering per payment method bisa ditambahkan nanti jika diperlukan.
                        $credential_options = $credential_manager->get_credential_options('');
                    }
                    ?>
                    <?php if (!empty($credential_options)): ?>
                    <div class="credential-selector-section" style="margin-bottom: 25px; padding: 15px; background: #f0f8ff; border: 1px solid #0073aa; border-radius: 4px;">
                        <h4 style="margin: 0 0 10px 0; color: #0073aa;">
                            🔐 <?php _e('Select Credential to Use', 'nicepay-cancel'); ?>
                        </h4>
                        <table class="form-table" style="margin: 0;">
                            <tr>
                                <th scope="row" style="width: 150px;">
                                    <label for="selected_credential"><?php _e('Credential', 'nicepay-cancel'); ?> <span class="required">*</span></label>
                                </th>
                                <td>
                                    <select id="selected_credential" name="selected_credential" class="regular-text" required>
                                        <option value=""><?php _e('-- Select Credential --', 'nicepay-cancel'); ?></option>
                                        <?php foreach ($credential_options as $id => $label): ?>
                                            <option value="<?php echo esc_attr((string) $id); ?>"><?php echo esc_html($label); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=nicepay-credentials')); ?>"
                                       class="button button-secondary"
                                       style="margin-left: 10px; vertical-align: middle;">
                                        <?php _e('Manage Credentials', 'nicepay-cancel'); ?>
                                    </a>
                                    <p class="description"><?php _e('Pilih credential (MID) yang akan digunakan untuk cancel transaksi ini', 'nicepay-cancel'); ?></p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php else: ?>
                    <div style="margin-bottom: 25px; padding: 15px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px;">
                        <p style="margin: 0; color: #856404;">
                            <?php _e('No credentials configured!', 'nicepay-cancel'); ?>
                            <a href="<?php echo admin_url('admin.php?page=nicepay-credentials'); ?>" class="button button-small" style="margin-left: 10px;">
                                <?php _e('Add Credential', 'nicepay-cancel'); ?>
                            </a>
                        </p>
                    </div>
                    <?php endif; ?>

                    <!-- Payment Method Tabs -->
                    <div class="nicepay-tabs">
                        <nav class="nicepay-tab-nav">
                            <?php foreach (NicePayPaymentMethod::cases() as $index => $method): ?>
                                <button type="button"
                                        class="nicepay-tab-btn <?php echo $index === 0 ? 'active' : ''; ?>"
                                        data-tab="tab-<?php echo esc_attr($method->value); ?>">
                                    <?php echo $method->icon(); ?> <?php echo esc_html($method->label()); ?>
                                </button>
                            <?php endforeach; ?>
                        </nav>

                        <?php foreach (NicePayPaymentMethod::cases() as $index => $method): ?>
                            <div id="tab-<?php echo esc_attr($method->value); ?>"
                                 class="nicepay-tab-content <?php echo $index === 0 ? 'active' : ''; ?>">
                                <?php $this->render_cancel_form($method); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                </div>
            </div>

        </div>

        <style>
        /* Tab Navigation */
        .nicepay-tabs { margin-top: 10px; }
        .nicepay-tab-nav {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            border-bottom: 2px solid #0073aa;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .nicepay-tab-btn {
            padding: 8px 16px;
            border: 1px solid #ccc;
            border-bottom: none;
            background: #f1f1f1;
            cursor: pointer;
            border-radius: 4px 4px 0 0;
            font-size: 13px;
            color: #555;
            transition: background 0.2s;
        }
        .nicepay-tab-btn:hover { background: #e0e0e0; }
        .nicepay-tab-btn.active {
            background: #fff;
            border-color: #0073aa;
            color: #0073aa;
            font-weight: 600;
            border-bottom: 2px solid #fff;
            margin-bottom: -2px;
        }
        .nicepay-tab-content {
            display: none;
            border: 1px solid #0073aa;
            border-top: none;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 0 0 4px 4px;
        }
        .nicepay-tab-content.active { display: block; }

        /* Form Styles */
        .payment-method-section h3 { margin-top: 0; color: #0073aa; }
        .cancel-btn {
            background: #dc3232 !important;
            border-color: #dc3232 !important;
            color: white !important;
        }
        .cancel-btn:hover:not(:disabled) {
            background: #a02622 !important;
            border-color: #a02622 !important;
        }
        .cancel-btn:disabled {
            background: #ccc !important;
            border-color: #ccc !important;
            cursor: not-allowed !important;
        }

        /* Search */
        .nicepay-search-section {
            border-bottom: 1px solid #ddd;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        #search-results {
            border: 1px solid #ccc;
            padding: 15px;
            background: white;
            border-radius: 4px;
        }
        .required { color: #dc3232; }
        </style>

        <script>
        jQuery(function($) {
            // Tab switching logic
            $('.nicepay-tab-btn').on('click', function() {
                const tabId = $(this).data('tab');
                $('.nicepay-tab-btn').removeClass('active');
                $('.nicepay-tab-content').removeClass('active');
                $(this).addClass('active');
                $('#' + tabId).addClass('active');
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render cancel form untuk setiap payment method
     * Menggunakan match expression PHP 8.0+
     */
    private function render_cancel_form(NicePayPaymentMethod $method): void
    {
        // Tidak ada extra field di UI (Mitra/Store/Bank code disembunyikan
        // agar form lebih sederhana dan tidak membingungkan user).
        $extra_fields = [];

        $is_configured = class_exists('NicePayCancelAdminSettings')
            && NicePayCancelAdminSettings::is_configured();
        ?>
        <div class="payment-method-section">
            <h3><?php echo $method->icon(); ?> <?php echo esc_html($method->label()); ?> <?php _e('Transaction Cancel', 'nicepay-cancel'); ?></h3>
            <p class="description">
                <?php
                printf(
                    __('Cancel transaksi %s dengan memasukkan Transaction ID dan Amount secara manual.', 'nicepay-cancel'),
                    esc_html($method->label())
                );

                // Catatan khusus per payment method
                if (in_array($method, [NicePayPaymentMethod::VirtualAccount, NicePayPaymentMethod::ConvenienceStore], true)) {
                    echo '<br><strong>' . esc_html__('Catatan:', 'nicepay-cancel') . '</strong> ';
                    echo esc_html__('Cancel hanya bisa dilakukan jika customer BELUM melakukan pembayaran (status belum dibayar di sistem NICEPay).', 'nicepay-cancel');
                }
                ?>
            </p>

            <form class="cancel-form" data-method="<?php echo esc_attr($method->value); ?>">
                <input type="hidden" name="payment_method" value="<?php echo esc_attr($method->value); ?>" />

                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Transaction ID', 'nicepay-cancel'); ?> <span class="required">*</span></th>
                        <td>
                            <input type="text" name="tXid"
                                   placeholder="IONPAYTEST01202212141146401456"
                                   class="regular-text" required />
                            <p class="description"><?php _e('Transaction ID yang diterima dari NICEPay saat pembayaran berhasil', 'nicepay-cancel'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Amount (IDR)', 'nicepay-cancel'); ?> <span class="required">*</span></th>
                        <td>
                            <input type="number" name="amt"
                                   placeholder="10000"
                                   class="regular-text" min="1" step="1" required />
                            <p class="description"><?php _e('Jumlah yang akan di-cancel (dalam Rupiah, tanpa desimal)', 'nicepay-cancel'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Reference Number', 'nicepay-cancel'); ?></th>
                        <td>
                            <input type="text" name="referenceNo"
                                   placeholder="ordNo20221214111208"
                                   class="regular-text" />
                            <p class="description"><?php _e('Reference number / Order number (opsional)', 'nicepay-cancel'); ?></p>
                        </td>
                    </tr>

                    <?php if ($method === NicePayPaymentMethod::CreditCard): ?>
                        <?php
                        // Cancel type untuk Credit Card sekarang di-hardcode di sisi server (API),
                        // sehingga field pilihan Cancel Type tidak perlu ditampilkan di form.
                        ?>
                    <?php endif; ?>

                    <?php foreach ($extra_fields as $field): ?>
                    <tr>
                        <th scope="row">
                            <?php echo esc_html($field['label']); ?>
                            <?php if ($field['required']): ?><span class="required">*</span><?php endif; ?>
                        </th>
                        <td>
                            <input type="<?php echo esc_attr($field['type']); ?>"
                                   name="<?php echo esc_attr($field['name']); ?>"
                                   placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                                   class="regular-text"
                                   <?php echo $field['required'] ? 'required' : ''; ?> />
                            <p class="description"><?php echo esc_html($field['description']); ?></p>
                        </td>
                    </tr>
                    <?php endforeach; ?>

                    <tr>
                        <th scope="row"><?php _e('Cancel Message', 'nicepay-cancel'); ?></th>
                        <td>
                            <input type="text" name="cancelMsg"
                                   value="<?php printf(
                                       esc_attr__('Cancellation Of Transaction %s by Admin', 'nicepay-cancel'),
                                       esc_attr($method->label())
                                   ); ?>"
                                   class="large-text" />
                            <p class="description"><?php _e('Pesan alasan cancel', 'nicepay-cancel'); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary cancel-btn">
                        <?php printf(
                            __('Cancel %s Transaction', 'nicepay-cancel'),
                            esc_html($method->label())
                        ); ?>
                    </button>
                    <span class="description" style="margin-left: 10px;">
                        <?php _e('* Pastikan data sudah benar sebelum melakukan cancel', 'nicepay-cancel'); ?>
                    </span>
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Display recent NICEPay transactions
     */
    private function display_recent_transactions(): void
    {
        $args = [
            'post_type'   => 'shop_order',
            'post_status' => ['wc-processing', 'wc-on-hold', 'wc-pending', 'wc-completed'],
            'posts_per_page' => 10,
            'meta_query'  => [
                [
                    'key'     => '_nicepay_transaction_id',
                    'compare' => 'EXISTS',
                ],
            ],
            'orderby' => 'date',
            'order'   => 'DESC',
        ];

        $orders = get_posts($args);

        if (empty($orders)) {
            echo '<p style="padding: 20px;">' . __('No NICEPay transactions found. Transactions will appear here after payments are made through NICEPay gateway.', 'nicepay-cancel') . '</p>';
            return;
        }

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>';
        echo '<th>' . __('Order ID', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Date', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Customer', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Amount', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Status', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Payment Method', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Transaction ID', 'nicepay-cancel') . '</th>';
        echo '<th>' . __('Action', 'nicepay-cancel') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($orders as $order_post) {
            $order          = wc_get_order($order_post->ID);
            $transaction_id = $order->get_meta('_nicepay_transaction_id');
            $payment_method = $order->get_payment_method_title();
            $can_cancel     = !empty($transaction_id)
                && in_array($order->get_status(), ['processing', 'on-hold', 'pending'], strict: true);

            echo '<tr>';
            echo '<td><a href="' . admin_url('post.php?post=' . $order->get_id() . '&action=edit') . '" target="_blank">#' . $order->get_order_number() . '</a></td>';
            echo '<td>' . $order->get_date_created()->format('Y-m-d H:i') . '</td>';
            echo '<td>' . esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) . '</td>';
            echo '<td>' . $order->get_formatted_order_total() . '</td>';
            echo '<td><span class="order-status status-' . $order->get_status() . '">' . wc_get_order_status_name($order->get_status()) . '</span></td>';
            echo '<td>' . esc_html($payment_method) . '</td>';
            echo '<td>' . ($transaction_id ? '<code>' . esc_html($transaction_id) . '</code>' : '-') . '</td>';
            echo '<td>';

            if ($can_cancel) {
                echo '<button type="button" class="button button-small quick-cancel"'
                    . ' data-order-id="' . $order->get_id() . '"'
                    . ' data-transaction-id="' . esc_attr($transaction_id) . '"'
                    . ' data-amount="' . $order->get_total() . '">'
                    . __('Quick Cancel', 'nicepay-cancel')
                    . '</button>';
            } else {
                $reason = match(true) {
                    empty($transaction_id) => __('No Transaction ID', 'nicepay-cancel'),
                    default                => __('Invalid Status', 'nicepay-cancel'),
                };
                echo '<span class="description">' . $reason . '</span>';
            }

            echo '</td></tr>';
        }

        echo '</tbody></table>';
    }

    
    /**
     * Display file status for debugging
     */
    private function display_file_status(): void
    {
        $files = [
            'assets/admin.js'                      => 'JavaScript Admin',
            'assets/admin.css'                     => 'CSS Admin',
            'includes/class-admin-setting.php'     => 'Settings Class',
            'includes/class-nicepay-api.php'       => 'API Class',
            'includes/class-credential-manager.php'=> 'Credential Manager',
        ];

        echo '<table class="form-table">';

        foreach ($files as $file => $description) {
            $file_path = NICEPAY_CANCEL_PLUGIN_PATH . $file;
            $exists    = file_exists($file_path);
            $status    = $exists ? '✅ ' . __('Found', 'nicepay-cancel') : '❌ ' . __('Missing', 'nicepay-cancel');
            $color     = $exists ? 'green' : 'red';

            echo '<tr>';
            echo '<th scope="row">' . esc_html($description) . '</th>';
            echo '<td>';
            echo '<span style="color: ' . $color . ';">' . $status . '</span> ';
            echo '<code>' . esc_html($file) . '</code>';

            if ($exists) {
                echo ' <span class="description">(' . size_format(filesize($file_path)) . ')</span>';
            }

            echo '</td></tr>';
        }

        echo '</table>';
    }
    
    /**
     * Handle search transaction AJAX
     */
    public function handle_search_transaction(): void
    {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'nicepay_cancel_nonce')) {
            wp_send_json_error(['message' => __('Security check failed', 'nicepay-cancel')]);
        }

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'nicepay-cancel')]);
        }

        $search_type  = sanitize_text_field($_POST['search_type'] ?? '');
        $search_value = sanitize_text_field($_POST['search_value'] ?? '');

        if (empty($search_value)) {
            wp_send_json_error(['message' => __('Search value is required', 'nicepay-cancel')]);
        }

        $orders = $this->search_orders($search_type, $search_value);

        if (empty($orders)) {
            wp_send_json_error(['message' => __('No transactions found matching your search criteria', 'nicepay-cancel')]);
        }

        wp_send_json_success([
            'orders'  => $orders,
            'message' => sprintf(__('%d transaction(s) found', 'nicepay-cancel'), count($orders)),
        ]);
    }
    
    /**
     * Handle cancel transaction AJAX
     */
     public function handle_cancel_transaction(): void
    {
        try {
            if (!wp_verify_nonce($_POST['nonce'] ?? '', 'nicepay_cancel_nonce')) {
                wp_send_json_error(CancelResult::error(__('Security check failed', 'nicepay-cancel'))->toArray());
            }

            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(CancelResult::error(__('Insufficient permissions', 'nicepay-cancel'))->toArray());
            }

            if (!class_exists('NicePayAPI')) {
                wp_send_json_error(CancelResult::error(__('NicePayAPI class not found', 'nicepay-cancel'))->toArray());
            }

            // Resolve credential
            $selected_credential_id = (int) ($_POST['selected_credential'] ?? 0);
            $credential             = null;

            if ($selected_credential_id > 0 && class_exists('NicePayCredentialManager')) {
                $credential_manager = new NicePayCredentialManager();
                $credential         = $credential_manager->get_credential($selected_credential_id);

                if (!$credential) {
                    wp_send_json_error(CancelResult::error(__('Selected credential not found', 'nicepay-cancel'))->toArray());
                }
            }

            // Collect & sanitize form data
            $transaction_id = sanitize_text_field($_POST['tXid'] ?? $_POST['transaction_id'] ?? '');
            $amount         = (float) ($_POST['amt'] ?? $_POST['amount'] ?? 0);
            $order_id       = (int) ($_POST['order_id'] ?? 0);
            $cancel_type    = sanitize_text_field($_POST['cancelType'] ?? $_POST['cancel_type'] ?? '2');
            $cancel_msg     = sanitize_text_field($_POST['cancelMsg'] ?? $_POST['cancel_reason'] ?? '');
            $reference_no   = sanitize_text_field($_POST['referenceNo'] ?? '');
            $payment_method = sanitize_text_field($_POST['payment_method'] ?? NicePayPaymentMethod::CreditCard->value);

            // Validate payment method via Enum
            $method_enum = NicePayPaymentMethod::tryFrom($payment_method);
            if ($method_enum === null) {
                wp_send_json_error(CancelResult::error(__('Invalid payment method', 'nicepay-cancel'))->toArray());
            }

            // Validation
            if (empty($transaction_id)) {
                wp_send_json_error(CancelResult::error(__('Transaction ID is required', 'nicepay-cancel'))->toArray());
            }

            if ($amount <= 0) {
                wp_send_json_error(CancelResult::error(__('Amount must be greater than 0', 'nicepay-cancel'))->toArray());
            }

            // Resolve WC Order
            $order = null;

            if ($order_id > 0) {
                $order = wc_get_order($order_id);
            }

            if (!$order) {
                $found_orders = $this->search_orders('transaction_id', $transaction_id);
                if (!empty($found_orders)) {
                    $order = wc_get_order($found_orders[0]['id']);
                }
            }

            // Fallback 2: cari berdasarkan reference number (jika diinput)
            if (!$order && $reference_no !== '') {
                $found_orders = $this->search_orders('reference_no', $reference_no);
                if (!empty($found_orders)) {
                    $order = wc_get_order($found_orders[0]['id']);
                }

                // Jika referenceNo berupa angka, coba sebagai order_id juga
                if (!$order && ctype_digit($reference_no)) {
                    $order = wc_get_order((int) $reference_no);
                }

                // Jika referenceNo berformat "231-xxxx" ambil angka depannya sebagai order_id
                if (
                    !$order
                    && preg_match('/^\s*(\d+)/', $reference_no, $m) === 1
                    && isset($m[1])
                    && ctype_digit($m[1])
                ) {
                    $order = wc_get_order((int) $m[1]);
                }
            }

            // SNAP QRIS: cari berdasarkan meta SNAP (lebih akurat)
            if (
                !$order
                && $method_enum !== null
                && $method_enum === NicePayPaymentMethod::QRIS
            ) {
                $posts = get_posts([
                    'post_type'      => 'shop_order',
                    'post_status'    => ['wc-processing', 'wc-on-hold', 'wc-pending', 'wc-completed', 'wc-cancelled'],
                    'posts_per_page' => 1,
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'fields'         => 'ids',
                    'meta_query'     => [
                        [
                            'key'     => '_nicepay_tXid',
                            'value'   => $transaction_id,
                            'compare' => '=',
                        ],
                    ],
                ]);

                if (!empty($posts)) {
                    $order = wc_get_order((int) $posts[0]);
                }

                // Alternatif: kalau user isi referenceNo = originalPartnerReferenceNo
                if (!$order && $reference_no !== '') {
                    $posts = get_posts([
                        'post_type'      => 'shop_order',
                        'post_status'    => ['wc-processing', 'wc-on-hold', 'wc-pending', 'wc-completed', 'wc-cancelled'],
                        'posts_per_page' => 1,
                        'orderby'        => 'date',
                        'order'          => 'DESC',
                        'fields'         => 'ids',
                        'meta_query'     => [
                            [
                                'key'     => '_nicepay_reference_no',
                                'value'   => $reference_no,
                                'compare' => '=',
                            ],
                        ],
                    ]);

                    if (!empty($posts)) {
                        $order = wc_get_order((int) $posts[0]);
                    }
                }
            }

            // Fallback: dummy order
            if (!$order) {
                $order = new NicePayDummyOrder(
                    transactionId: $transaction_id,
                    amount:        $amount,
                    referenceNo:   $reference_no,
                );
            }

            // Perform cancellation via API
            $api    = new NicePayAPI($credential);
            $result = $api->cancel_transaction(
                $transaction_id,
                $order,
                $cancel_msg,
                $cancel_type,
                $method_enum->value,
            );

            if ($result['success']) {
                if ($credential) {
                    $result['credential_used'] = [
                        'name'        => $credential->credential_name,
                        'merchant_id' => $this->mask_sensitive_data($credential->merchant_id),
                        'environment' => $credential->environment,
                    ];
                }

                $result['payment_method'] = $method_enum->label();
                wp_send_json_success($result);
            } else {
                wp_send_json_error($result);
            }
        } catch (\Throwable $e) {
            error_log('[NICEPay Cancel] Fatal error in handle_cancel_transaction: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

            wp_send_json_error([
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: error message */
                    __('Internal error when processing cancel: %s', 'nicepay-cancel'),
                    $e->getMessage()
                ),
            ]);
        }
    }
    public function handle_get_credentials(): void
    {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'nicepay_cancel_nonce')) {
            wp_send_json_error(['message' => __('Security check failed', 'nicepay-cancel')]);
        }

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'nicepay-cancel')]);
        }

        if (!class_exists('NicePayCredentialManager')) {
            wp_send_json_error(['message' => __('Credential manager not available', 'nicepay-cancel')]);
        }

        $credential_manager = new NicePayCredentialManager();
        $payment_method     = sanitize_text_field($_POST['payment_method'] ?? '');
        $credentials        = $credential_manager->get_credential_options($payment_method);

        wp_send_json_success(['credentials' => $credentials]);
    }
    /**
     * Create dummy order for manual cancellation
     */
    private function create_dummy_order($transaction_id, $amount, $reference_no) {
        // Create a simple object that mimics WC_Order for API purposes
        return new class($transaction_id, $amount, $reference_no) {
            private $transaction_id;
            private $amount;
            private $reference_no;
            
            public function __construct($transaction_id, $amount, $reference_no) {
                $this->transaction_id = $transaction_id;
                $this->amount = $amount;
                $this->reference_no = $reference_no ?: 'MANUAL_CANCEL_' . time();
            }
            
            public function get_id() {
                return 0; // Dummy ID
            }
            
            public function get_total() {
                return $this->amount;
            }
            
            public function get_order_number() {
                return $this->reference_no;
            }
            
            public function get_status() {
                return 'manual-cancel';
            }
            
            public function update_status($status, $note = '') {
                // Do nothing for dummy order
                return true;
            }
            
            public function add_order_note($note) {
                // Do nothing for dummy order
                return true;
            }
            
            public function save() {
                // Do nothing for dummy order
                return true;
            }
            
            public function get_meta($key) {
                if ($key === '_nicepay_transaction_id') {
                    return $this->transaction_id;
                }
                return '';
            }
        };
    }
    
    /**
     * Search orders based on criteria
     */
     private function search_orders(string $search_type, string $search_value): array
    {
        $args = [
            'post_type'      => 'shop_order',
            'post_status'    => ['wc-processing', 'wc-on-hold', 'wc-pending', 'wc-completed', 'wc-cancelled'],
            'posts_per_page' => 20,
            'meta_query'     => [],
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        match($search_type) {
            'order_id'      => $args['post__in'] = [(int) $search_value],
            'transaction_id'=> $args['meta_query'][] = [
                'key'     => '_nicepay_transaction_id',
                'value'   => $search_value,
                'compare' => '=',
            ],
            'reference_no'  => $args['meta_query'][] = [
                'relation' => 'OR',
                [
                    'key'     => '_nicepay_reference_no',
                    'value'   => $search_value,
                    'compare' => '=',
                ],
                [
                    'key'     => '_order_number',
                    'value'   => $search_value,
                    'compare' => '=',
                ],
            ],
            default => null,
        };

        $posts       = get_posts($args);
        $orders_data = [];

        foreach ($posts as $post) {
            $order          = wc_get_order($post->ID);
            $transaction_id = $order->get_meta('_nicepay_transaction_id');

            $orders_data[] = [
                'id'             => $order->get_id(),
                'order_number'   => $order->get_order_number(),
                'date'           => $order->get_date_created()->format('Y-m-d H:i:s'),
                'customer'       => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'total'          => $order->get_formatted_order_total(),
                'amount'         => $order->get_total(),
                'status'         => $order->get_status(),
                'status_text'    => wc_get_order_status_name($order->get_status()),
                'transaction_id' => $transaction_id,
                'payment_method' => $order->get_payment_method_title(),
                'can_cancel'     => !empty($transaction_id)
                    && in_array($order->get_status(), ['processing', 'on-hold', 'pending'], strict: true),
                'edit_url'       => admin_url('post.php?post=' . $order->get_id() . '&action=edit'),
            ];
        }

        return $orders_data;
    }
    
    /**
     * Add NICEPay column to orders list
     */
    public function add_order_column(array $columns): array
    {
        $new_columns = [];

        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;

            if ($key === 'order_status') {
                $new_columns['nicepay_transaction'] = __('NICEPay', 'nicepay-cancel');
            }
        }

        return $new_columns;
    }
    
    /**
     * Populate NICEPay column content
     */
    public function populate_order_column(string $column, int $post_id): void
    {
        if ($column !== 'nicepay_transaction') {
            return;
        }

        $order          = wc_get_order($post_id);
        $transaction_id = $order->get_meta('_nicepay_transaction_id');

        if (!$transaction_id) {
            echo '<span class="description">-</span>';
            return;
        }

        echo '<strong style="color: #0073aa;">' . esc_html($transaction_id) . '</strong><br>';

        $can_cancel = in_array($order->get_status(), ['processing', 'on-hold', 'pending'], strict: true);

        if ($can_cancel) {
            echo '<a href="' . admin_url('admin.php?page=nicepay-cancel&auto_search=' . urlencode($transaction_id)) . '" class="button button-small" style="margin-top: 3px;">';
            echo __('Cancel', 'nicepay-cancel');
            echo '</a>';
        } else {
            echo '<span class="description">' . __('Cannot Cancel', 'nicepay-cancel') . '</span>';
        }
    }
    
    /**
     * Add cancel button to order details page
     */
    public function add_cancel_button_to_order(\WC_Order $order): void
    {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $transaction_id = $order->get_meta('_nicepay_transaction_id');

        if (!$transaction_id || !in_array($order->get_status(), ['processing', 'on-hold', 'pending'], strict: true)) {
            return;
        }

        ?>
        <div class="nicepay-cancel-section" style="margin-top: 20px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd;">
            <h3><?php _e('NICEPay Transaction Control', 'nicepay-cancel'); ?></h3>
            <p>
                <strong><?php _e('Transaction ID:', 'nicepay-cancel'); ?></strong>
                <code><?php echo esc_html($transaction_id); ?></code>
            </p>
            <p>
                <a href="<?php echo admin_url('admin.php?page=nicepay-cancel&auto_search=' . urlencode($transaction_id)); ?>"
                   class="button button-secondary">
                    <?php _e('Cancel This Transaction', 'nicepay-cancel'); ?>
                </a>
                <span class="description" style="margin-left: 10px;">
                    <?php _e('Cancel transaksi ini melalui NICEPay API', 'nicepay-cancel'); ?>
                </span>
            </p>
        </div>
        <?php
    }
    
   /**
     * Plugin activation
     */
    public function activate(): void
    {
        add_option('nicepay_cancel_version', NICEPAY_CANCEL_VERSION);

        $this->create_log_table();

        $default_options = [
            'environment'       => 'dev',
            'cancel_reason'     => 'Cancellation Of Transaction by Admin',
            'enable_logging'    => '1',
            'auto_update_order' => '1',
        ];

        $existing_options = get_option('nicepay_cancel_options', []);
        $options          = [...$default_options, ...$existing_options]; // PHP 8.1+ spread operator for arrays

        update_option('nicepay_cancel_options', $options);

        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate(): void
    {
        flush_rewrite_rules();
    }

    /**
     * Create log table for activity tracking
     */
    private function create_log_table(): void
    {
        global $wpdb;

        $table_name      = $wpdb->prefix . 'nicepay_cancel_logs';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id            int(11)      NOT NULL AUTO_INCREMENT,
            date_created  datetime     DEFAULT CURRENT_TIMESTAMP,
            action        varchar(100) NOT NULL,
            data          longtext,
            user_id       int(11)      DEFAULT 0,
            ip_address    varchar(45),
            PRIMARY KEY  (id),
            KEY action       (action),
            KEY date_created (date_created),
            KEY user_id      (user_id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Mask sensitive data — e.g., merchant ID
     */
    private function mask_sensitive_data(string $data, int $visible_chars = 4): string
    {
        if (strlen($data) <= $visible_chars) {
            return $data;
        }

        return substr($data, 0, $visible_chars) . str_repeat('*', strlen($data) - $visible_chars);
    }

    /**
     * Get client IP address
     */
    private function get_client_ip(): string
    {
        $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];

        foreach ($ip_keys as $key) {
            if (!array_key_exists($key, $_SERVER)) {
                continue;
            }

            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }

        return $_SERVER['REMOTE_ADDR'] ?? '';
    }
}