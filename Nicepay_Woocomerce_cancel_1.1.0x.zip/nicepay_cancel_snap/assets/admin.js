// admin.js
jQuery(document).ready(function($) {
    
    // Handle search transaction
    $('#search-transaction').on('click', function() {
        var searchType = $('#search_type').val();
        var searchValue = $('#search_value').val().trim();
        
        if (!searchValue) {
            alert('Mohon masukkan nilai pencarian');
            return;
        }
        
        var $button = $(this);
        var originalText = $button.text();
        
        $button.text(nicepay_ajax.messages.processing).prop('disabled', true);
        
        $.ajax({
            url: nicepay_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'nicepay_search_transaction',
                search_type: searchType,
                search_value: searchValue,
                nonce: nicepay_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    displaySearchResults(response.data.orders);
                    showNotice(response.data.message, 'success');
                } else {
                    showNotice(response.data || 'Tidak ditemukan transaksi', 'error');
                    $('#search-results').hide();
                }
                $button.text(originalText).prop('disabled', false);
            },
            error: function() {
                showNotice('Error mencari transaksi', 'error');
                $button.text(originalText).prop('disabled', false);
            }
        });
    });
    
    // Handle cancel transaction buttons
    $(document).on('click', '.quick-cancel', function() {
        var $button = $(this);
        var orderId = $button.data('order-id');
        var transactionId = $button.data('transaction-id');
        var amount = $button.data('amount');
        
        if (!confirm(nicepay_ajax.messages.confirm_cancel)) {
            return;
        }
        
        var payload = {
            order_id: orderId,
            transaction_id: transactionId,
            amount: amount,
            cancel_type: '1', // Full cancel
            cancel_reason: 'Quick cancel by admin',
            payment_method: 'cc'
        };

        var $credentialSelect = $('#selected_credential');
        if ($credentialSelect.length) {
            var credentialId = ($credentialSelect.val() || '').toString().trim();
            if (!credentialId) {
                showNotice('Silakan pilih Credential (MID) terlebih dahulu', 'error');
                return;
            }
            payload.selected_credential = credentialId;
        }

        performCancel($button, payload);
    });
    // Handle manual cancel forms
    $('.cancel-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $button = $form.find('.cancel-btn');
        var method = $form.data('method');
        
        if (!confirm(nicepay_ajax.messages.confirm_cancel)) {
            return;
        }
        
        // Collect form data
        var formData = {
            payment_method: method,
            cancel_type: '1' // Full cancel for credit card
        };
        
        $form.find('input, select').each(function() {
            var $input = $(this);
            formData[$input.attr('name')] = $input.val();
        });
        
        // Validate required fields
        if (!formData.tXid || !formData.amt) {
            showNotice('Transaction ID dan Amount wajib diisi', 'error');
            return;
        }

        // Jika ada selector credential global, wajib dipilih dan ikut dikirim
        var $credentialSelect = $('#selected_credential');
        if ($credentialSelect.length) {
            var credentialId = ($credentialSelect.val() || '').toString().trim();
            if (!credentialId) {
                showNotice('Silakan pilih Credential (MID) terlebih dahulu', 'error');
                return;
            }
            formData.selected_credential = credentialId;
        }
        
        performCancel($button, formData);
    });
    
     // Handle search result cancel buttons
    $(document).on('click', '.cancel-transaction', function() {
        var $button = $(this);
        var orderId = $button.data('order-id');
        var transactionId = $button.data('transaction-id');
        var amount = $button.data('amount');
        
        if (!confirm(nicepay_ajax.messages.confirm_cancel)) {
            return;
        }
        
        var payload = {
            order_id: orderId,
            transaction_id: transactionId,
            amount: amount,
            cancel_type: '1',
            cancel_reason: 'Cancelled by admin from search results',
            payment_method: 'cc'
        };

        var $credentialSelect = $('#selected_credential');
        if ($credentialSelect.length) {
            var credentialId = ($credentialSelect.val() || '').toString().trim();
            if (!credentialId) {
                showNotice('Silakan pilih Credential (MID) terlebih dahulu', 'error');
                return;
            }
            payload.selected_credential = credentialId;
        }

        performCancel($button, payload);
    });
    
    
    // Handle Enter key in search input
    $('#search_value').on('keypress', function(e) {
        if (e.which === 13) {
            $('#search-transaction').click();
        }
    });
    
     function performCancel($button, data) {
        var originalText = $button.text();
        $button.text(nicepay_ajax.messages.processing).prop('disabled', true);
        
        // Show loading overlay for form cancels
        if (data.payment_method !== 'quick') {
            showLoadingOverlay();
        }
        
        $.ajax({
            url: nicepay_ajax.ajax_url,
            type: 'POST',
            data: $.extend({
                action: 'nicepay_cancel_transaction',
                nonce: nicepay_ajax.nonce
            }, data),
            success: function(response) {
                hideLoadingOverlay();
                
                if (response.success) {
                    var nicepayData = response.data && response.data.data ? response.data.data : null;
                    var resultCd = nicepayData && nicepayData.resultCd ? nicepayData.resultCd : null;
                    var resultMsg = nicepayData && nicepayData.resultMsg ? nicepayData.resultMsg : null;
                    var successMessage = resultCd && resultMsg
                        ? ('[' + resultCd + '] ' + resultMsg)
                        : (response.data && response.data.message ? response.data.message : nicepay_ajax.messages.success);

                    showNotice(successMessage, (resultCd && resultCd !== '0000') ? 'error' : 'success');
                    
                    // Update button status
                    $button.text('Cancelled')
                           .removeClass('button-secondary cancel-btn')
                           .addClass('button-disabled')
                           .prop('disabled', true);
                    
                    // Update row status if in table
                    var $row = $button.closest('tr');
                    if ($row.length) {
                        $row.find('.order-status')
                            .removeClass()
                            .addClass('order-status status-cancelled')
                            .text('Cancelled');
                    }
                    
                    // Clear form if manual cancel
                    var $form = $button.closest('.cancel-form');
                    if ($form.length) {
                        $form[0].reset();
                    }
                    
                    // Show transaction details if available
                    if (response.data.data) {
                        showTransactionResult(response.data.data);
                    }
                    
                } else {
                    var errorMessage = nicepay_ajax.messages.error;
                    if (response && response.data) {
                        if (typeof response.data === 'string') {
                            errorMessage = response.data;
                        } else if (response.data.message) {
                            errorMessage = response.data.message;
                        }
                    }
                    showNotice(errorMessage, 'error');
                    $button.text(originalText).prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                hideLoadingOverlay();
                
                var errorMessage = nicepay_ajax.messages.error;
                if (xhr.responseJSON) {
                    if (xhr.responseJSON.data) {
                        if (typeof xhr.responseJSON.data === 'string') {
                            errorMessage = xhr.responseJSON.data;
                        } else if (xhr.responseJSON.data.message) {
                            errorMessage = xhr.responseJSON.data.message;
                        }
                    } else if (xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }
                }
                
                showNotice(errorMessage, 'error');
                $button.text(originalText).prop('disabled', false);
            }
        });
    }
    
    // Function to display search results
    function displaySearchResults(orders) {
        var $resultsContainer = $('#search-results');
        var $detailsContainer = $('#transaction-details');
        
        if (orders && orders.length > 0) {
            var html = '<table class="wp-list-table widefat fixed striped">';
            html += '<thead>';
            html += '<tr>';
            html += '<th>Order ID</th>';
            html += '<th>Tanggal</th>';
            html += '<th>Customer</th>';
            html += '<th>Total</th>';
            html += '<th>Status</th>';
            html += '<th>Transaction ID</th>';
            html += '<th>Aksi</th>';
            html += '</tr>';
            html += '</thead>';
            html += '<tbody>';
            
            orders.forEach(function(order) {
                html += '<tr>';
                html += '<td><a href="' + order.edit_url + '" target="_blank">#' + order.order_number + '</a></td>';
                html += '<td>' + order.date + '</td>';
                html += '<td>' + order.customer + '</td>';
                html += '<td>' + order.total + '</td>';
                html += '<td><span class="order-status status-' + order.status + '">' + order.status_text + '</span></td>';
                html += '<td><code>' + (order.transaction_id || '-') + '</code></td>';
                html += '<td>';
                if (order.can_cancel) {
                    html += '<button type="button" class="button button-secondary cancel-transaction" ';
                    html += 'data-order-id="' + order.id + '" ';
                    html += 'data-transaction-id="' + order.transaction_id + '" ';
                    html += 'data-amount="' + order.amount + '">';
                    html += 'Cancel</button>';
                } else {
                    html += '<span class="description">Cannot Cancel</span>';
                }
                html += '</td>';
                html += '</tr>';
            });
            
            html += '</tbody>';
            html += '</table>';
            
            $detailsContainer.html(html);
            $resultsContainer.show();
            
            // Scroll to results
            $('html, body').animate({
                scrollTop: $resultsContainer.offset().top - 50
            }, 500);
        } else {
            $detailsContainer.html('<p class="description">Tidak ditemukan transaksi dengan kriteria pencarian tersebut.</p>');
            $resultsContainer.show();
        }
    }
    
    // Function to show transaction result details
    function showTransactionResult(data) {
        var html = '<div class="transaction-result-details" style="margin-top: 15px; padding: 15px; background: #f0f8ff; border: 1px solid #0073aa; border-radius: 4px;">';
        html += '<h4 style="margin-top: 0;">Transaction Cancel Details:</h4>';
        html += '<table class="form-table">';
        
        if (data.tXid) {
            html += '<tr><th>Transaction ID:</th><td><code>' + data.tXid + '</code></td></tr>';
        } else if (data.originalReferenceNo) {
            html += '<tr><th>Transaction ID:</th><td><code>' + data.originalReferenceNo + '</code></td></tr>';
        }
        if (data.referenceNo) {
            html += '<tr><th>Reference No:</th><td><code>' + data.referenceNo + '</code></td></tr>';
        } else if (data.originalPartnerReferenceNo) {
            html += '<tr><th>Reference No:</th><td><code>' + data.originalPartnerReferenceNo + '</code></td></tr>';
        }
        if (data.resultCd) {
            html += '<tr><th>Result Code:</th><td><span style="color: ' + (data.resultCd === '0000' ? 'green' : 'red') + ';">' + data.resultCd + '</span></td></tr>';
        } else if (data.responseCode) {
            html += '<tr><th>Response Code:</th><td><span style="color: ' + (data.responseCode === '2007800' ? 'green' : 'red') + ';">' + data.responseCode + '</span></td></tr>';
        }
        if (data.resultMsg) {
            html += '<tr><th>Result Message:</th><td>' + data.resultMsg + '</td></tr>';
        } else if (data.responseMessage) {
            html += '<tr><th>Response Message:</th><td>' + data.responseMessage + '</td></tr>';
        }
        if (data.refundAmount && data.refundAmount.value) {
            var refundVal = data.refundAmount.value;
            var refundNum = parseFloat(refundVal);
            html += '<tr><th>Amount:</th><td>IDR ' + (isNaN(refundNum) ? refundVal : refundNum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })) + '</td></tr>';
        }
        if (data.transDt) {
            html += '<tr><th>Transaction Date:</th><td><code>' + data.transDt + '</code></td></tr>';
        }
        if (data.transTm) {
            html += '<tr><th>Transaction Time:</th><td><code>' + data.transTm + '</code></td></tr>';
        }
        if (data.description) {
            html += '<tr><th>Description:</th><td>' + data.description + '</td></tr>';
        }
        if (data.amt) {
            var amtInt = parseInt(data.amt, 10);
            html += '<tr><th>Amount:</th><td>IDR ' + (isNaN(amtInt) ? data.amt : amtInt.toLocaleString()) + '</td></tr>';
        }
        
        html += '</table>';
        html += '</div>';
        
        // Find the best place to show details
        var $target = $('.transaction-result-details').length ? $('.transaction-result-details') : $('.wrap h1');
        if ($('.transaction-result-details').length) {
            $('.transaction-result-details').replaceWith(html);
        } else {
            $target.after(html);
        }
    }
    
    // Function to show admin notices
    function showNotice(message, type) {
        type = type || 'info';
        var noticeClass = 'notice-' + type;
        var icon = type === 'success' ? '✓' : (type === 'error' ? '✗' : 'ℹ');
        
        var $notice = $('<div class="notice ' + noticeClass + ' is-dismissible" style="position: relative; z-index: 9999;">' +
            '<p><strong>' + icon + '</strong> ' + message + '</p>' +
            '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>' +
            '</div>');
        
        // Remove existing notices of same type
        $('.notice.' + noticeClass).remove();
        
        $('.wrap h1').after($notice);
        
        // Auto dismiss after 5 seconds for success messages
        if (type === 'success') {
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $notice.remove();
                });
            }, 5000);
        }
        
        // Handle dismiss button
        $notice.on('click', '.notice-dismiss', function() {
            $notice.fadeOut(function() {
                $notice.remove();
            });
        });
        
        // Scroll to notice
        $('html, body').animate({
            scrollTop: $notice.offset().top - 50
        }, 300);
    }
    
    // Add loading overlay functions
    function showLoadingOverlay() {
        if ($('.nicepay-loading-overlay').length === 0) {
            var overlay = '<div class="nicepay-loading-overlay" style="' +
                'position: fixed; top: 0; left: 0; width: 100%; height: 100%; ' +
                'background: rgba(0,0,0,0.5); z-index: 99999; display: flex; ' +
                'align-items: center; justify-content: center;">' +
                '<div class="nicepay-spinner" style="' +
                'border: 4px solid #f3f3f3; border-radius: 50%; ' +
                'border-top: 4px solid #0073aa; width: 60px; height: 60px; ' +
                'animation: spin 1s linear infinite;">' +
                '</div></div>';
            
            $('body').append(overlay);
            
            // Add CSS animation if not exists
            if (!$('#nicepay-spinner-css').length) {
                $('head').append('<style id="nicepay-spinner-css">@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>');
            }
        }
    }
      function hideLoadingOverlay() {
        $('.nicepay-loading-overlay').remove();
    }
    
});