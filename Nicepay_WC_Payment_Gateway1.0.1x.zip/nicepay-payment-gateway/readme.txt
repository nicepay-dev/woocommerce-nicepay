=== NICEPay Payment Gateway for WooCommerce ===
Contributors: nicepay
Tags: woocommerce, payment, ewallet, virtual-account, qris
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4 ++
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Seamlessly integrate NICEPay payment options into WooCommerce including VA, QRIS, E-Wallets, Credit Card, Paylater, & Convenience Stores—all within checkout.

== Description ==

The official NICEPay Payment Gateway for WooCommerce enables merchants to offer a variety of payment methods—all processed securely through NICEPay. Customers stay on your checkout page from start to finish:

• Virtual Account (BCA, BNI, Mandiri, etc.)  
• QRIS  
• E-Wallets (OVO, DANA, LinkAja, ShopeePay)  
• Credit Card (Full Payment, One-Click)  
• Paylater / Payloan (Akulaku, Kredivo, Indodana)  
• Convenience Stores (Indomaret, Alfamart)

Supports WooCommerce Blocks and offers smooth admin configuration under WooCommerce → Settings → Payments.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/nicepay-payment-gateway-for-woocommerce`.
2. Activate the plugin via the **Plugins** screen in WordPress.
3. Navigate to **WooCommerce → Settings → Payments**.
4. Enable **NICEPay Payment Gateway** and enter your NICEPay credentials (iMid, Merchant Key, API URL).
5. Choose the payment methods you’d like to display at checkout.
6. Save settings and run test payments using NICEPay Sandbox before going live.

== Frequently Asked Questions ==

= How do I get my Merchant ID and keys? =
Register at the NICEPay Merchant Dashboard and request your iMid and API credentials.

= Does the plugin support WooCommerce Blocks? =
Yes, it is compatible with standard and block-based checkout flows.

= Can I offer installment or paylater options? =
Yes. Simply enable Paylater in settings. Available options include Akulaku, Kredivo, and Indodana.

= Where can I report bugs or request new features? =
Contact us at **integration@nicepay.co.id** or raise an issue on the GitHub repo.

== Screenshots ==
1. NICEPay setup page in WooCommerce admin.
2. Checkout view showing payment options.
3. QRIS checkout interface.

== Changelog ==
= 1.0.0 =
* Initial stable release with full payment method and feature support.
= 1.0.1 =
* fixing checkstatus for CC

== Upgrade Notice ==
= 1.0.0 =
First official release! Set your merchant account and go live.