(function() {
    console.log("Loading NICEPay Payout Blocks");

    const wpElement = window.wp.element;
    const { createElement, useState } = wpElement;

    // ✅ Global variable to pass selected bank to payment data
    let selectedBank = '';

    // ✅ Define bank list (extend this if needed)
    const banks = [
        { code: 'BMRI', name: 'Bank Mandiri' },
        { code: 'BNIN', name: 'Bank BNI' },
        { code: 'BRIN', name: 'Bank BRI' },
        { code: 'BBBA', name: 'Bank Permata' },
        { code: 'CENA', name: 'Bank BCA' },
        { code: 'IBBK', name: 'Maybank' },
        { code: 'BBBB', name: 'Bank Permata Syariah' },
        { code: 'HNBN', name: 'Bank KEB Hana Indonesia' },
        { code: 'BNIA', name: 'Bank CIMB' },
        { code: 'BDIN', name: 'Bank Bank Danamon' },
        { code: 'PDJB', name: 'Bank BJB' },
        { code: 'YUDB', name: 'Bank Neo Commerce (BNC)' },
        { code: 'BDKI', name: 'Bank DKI' },
    ];

    // ✅ Save selected bank to WooCommerce session via AJAX
    const saveBankSelection = (selectedBankCode) => {
        console.log('Attempting to save payout bank selection:', selectedBankCode);

        if (typeof jQuery !== 'undefined' && typeof nicepayPayoutBlocksData !== 'undefined') {
            jQuery.ajax({
                url: nicepayPayoutBlocksData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_payout_bank',
                    bank_code: selectedBankCode,
                    security: nicepayPayoutBlocksData.nonce || ''
                },
                success: function(response) {
                },
                error: function(error) {
                    console.error('Error saving payout bank selection:', error);
                }
            });
        } else {
            console.error('jQuery or nicepayPayoutBlocksData is not available');
        }
    };

    // ✅ React component for selecting bank
    const NicepayPayoutComponent = () => {
        const [localSelectedBank, setLocalSelectedBank] = useState('');

        const handleBankChange = (e) => {
            const selected = e.target.value;
            console.log('Payout bank selected:', selected);

            selectedBank = selected;
            setLocalSelectedBank(selected);
            saveBankSelection(selected);
        };

        return createElement('div', { className: 'nicepay-payout-container' }, [
            createElement('div', { className: 'nicepay-payout-header' }, [
                createElement('img', {
                    src: nicepayPayoutBlocksData.pluginUrl + 'assets/images/logo-bank.png',
                    alt: 'Bank Icon',
                    className: 'nicepay-payout-bank-icon'
                }),
            ]),
            createElement('div', { className: 'nicepay-payout-bank-select' }, [
                createElement('label', { htmlFor: 'nicepay-payout-bank-select' }, 'Pilih Bank:'),
                createElement('select',
                    {
                        name: 'nicepay_payout_bank',
                        id: 'nicepay-payout-bank-select',
                        onChange: handleBankChange,
                        value: localSelectedBank
                    },
                    [
                        createElement('option', { value: '' }, 'Pilih Bank'),
                        ...banks.map(bank =>
                            createElement('option', { value: bank.code, key: bank.code }, bank.name)
                        )
                    ]
                )
            ]),
            createElement('p', { className: 'nicepay-payout-instruction' }, 'Silakan pilih bank untuk pembayaran Payout Anda.')
        ]);
    };

    // ✅ Register payment method with WooCommerce Blocks
    const safelyRegisterPayoutPaymentMethod = function() {
        console.log("Attempting to register NICEPay Payout Payment Method");

        if (!window.wc || !window.wc.wcBlocksRegistry) {
            console.error('WooCommerce Blocks registry not available for Payout');
            setTimeout(safelyRegisterPayoutPaymentMethod, 300);
            return;
        }

        try {
            if (window.nicepay_payout_registered === true) {
                console.log("Payout already registered, skipping");
                return;
            }

            const { registerPaymentMethod } = window.wc.wcBlocksRegistry;

            registerPaymentMethod({
                name: "nicepay_payout",
                label: "NICEPay Payout",
                content: createElement(NicepayPayoutComponent),
                edit: createElement(NicepayPayoutComponent),
                canMakePayment: () => true,
                ariaLabel: "NICEPay Payout payment method",
                paymentMethodId: "nicepay_payout",
                supports: {
                    features: ['products'],
                },
                paymentMethodData: {
                    getPaymentData: () => {
                        console.log("getPaymentData triggered, selectedBank:", selectedBank);
                        return {
                            nicepay_payout_bank: selectedBank
                        };
                    }
                }
            });

            window.nicepay_payout_registered = true;
            console.log("NICEPay Payout Payment Method successfully registered");
        } catch (error) {
            console.error("Error registering NICEPay Payout Payment Method:", error);
            setTimeout(safelyRegisterPayoutPaymentMethod, 500);
        }
    };

    // ✅ Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', safelyRegisterPayoutPaymentMethod);
    } else {
        safelyRegisterPayoutPaymentMethod();
    }
})();