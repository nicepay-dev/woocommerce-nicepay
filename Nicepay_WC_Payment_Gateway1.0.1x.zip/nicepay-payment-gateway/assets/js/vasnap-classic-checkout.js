jQuery(document).ready(function ($) {
    console.log("NICEPay VA Classic Checkout Loaded");

    // Hanya jalankan jika metode NICEPay VA aktif
    function isNicepayVASelected() {
        return $('#payment_method_nicepay_va_snap').is(':checked');
    }

    // Tambahkan dropdown bank
    function renderBankSelector() {
        const container = $('#nicepay-va-bank-container');

        if (container.length > 0) return;

        const html = `
            <div id="nicepay-va-bank-container" style="margin-top: 15px;">
                <label for="nicepay_va_bank">Pilih Bank Virtual Account:</label>
                <select name="nicepay_va_bank" id="nicepay_va_bank" required>
                    <option value="">-- Pilih Bank --</option>
                    <option value="BMRI">Bank Mandiri</option>
                    <option value="BNIN">Bank BNI</option>
                    <option value="BRIN">Bank BRI</option>
                    <option value="BBBA">Bank Permata</option>
                    <option value="CENA">Bank BCA</option>
                    <option value="IBBK">Maybank</option>
                    <option value="BBBB">Permata Syariah</option>
                    <option value="HNBN">KEB Hana</option>
                    <option value="BNIA">Bank CIMB</option>
                    <option value="BDIN">Bank Danamon</option>
                    <option value="PDJB">Bank BJB</option>
                    <option value="YUDB">Bank Neo Commerce</option>
                    <option value="BDKI">Bank DKI</option>
                </select>
                <p class="form-row form-row-wide">Silakan pilih bank untuk Virtual Account Anda.</p>
            </div>
        `;

        $('#payment_method_nicepay_va_snap').closest('.payment_box').append(html);
    }

    // Hapus dropdown jika metode tidak dipilih
    function removeBankSelector() {
        $('#nicepay-va-bank-container').remove();
    }

    // Pantau perubahan metode pembayaran
    $('form.checkout').on('change', 'input[name="payment_method"]', function () {
        if (isNicepayVASelected()) {
            renderBankSelector();
        } else {
            removeBankSelector();
        }
    });

    // Trigger awal kalau page diload dan VA udah terpilih
    if (isNicepayVASelected()) {
        renderBankSelector();
    }
});