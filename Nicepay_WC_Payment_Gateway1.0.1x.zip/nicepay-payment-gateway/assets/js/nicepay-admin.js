jQuery(function($){
    $('#nicepay-admin-form').on('submit', function(e){
        e.preventDefault();
        var data = $(this).serialize();
        $('#nicepay-admin-response').html('<em>Processing...</em>');

        $.post(nicepayAdmin.ajax_url, data + '&security=' + nicepayAdmin.nonce, function(response){
            $('#nicepay-admin-response').html('<pre>' + JSON.stringify(response, null, 2) + '</pre>');
        });
    });
});