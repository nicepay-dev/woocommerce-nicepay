console.log("Loading NICEPay Payloan Plugin");

document.addEventListener('DOMContentLoaded', function () {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log("Initializing Payloan Payment Method");
        initNicepayPayloan();
    } else {
        console.error('Required dependencies not available for Payloan');
    }
});

function initNicepayPayloan() {
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment, useState } = window.wp.element;

    const NicepayPayloanComponent = () => {
        const [selectedMitra, setSelectedMitra] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const mitra = window.nicepaypayloanData?.enabled_mitra || [];

        console.log('Available mitra (Payloan):', mitra);

        const handleMitraChange = (e) => {
            const mitraCode = e.target.value;
            console.log('Mitra selected:', mitraCode);
            setSelectedMitra(mitraCode);
            saveMitraSelection(mitraCode);
        };

        const saveMitraSelection = (mitraCode) => {
            if (typeof jQuery === 'undefined' || !window.nicepaypayloanData) {
                console.warn('jQuery or nicepaypayloanData not available');
                return;
            }
            if (!nicepaypayloanData.ajax_url || !nicepaypayloanData.nonce) {
                console.warn('Required AJAX data missing');
                return;
            }
            setIsLoading(true);
            jQuery.ajax({
                url: nicepaypayloanData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_payloan_mitra',
                    mitra_code: mitraCode,
                    nonce: nicepaypayloanData.nonce
                },
                timeout: 10000,
                success: function (response) {
                    setIsLoading(false);
                },
                error: function (xhr, status, error) {
                    console.error('Error saving mitra selection:', error);
                    setIsLoading(false);
                }
            });
        };

        if (!Array.isArray(mitra) || mitra.length === 0) {
            return createElement('div', { className: 'nicepay-payloan-container' },
                createElement('p', null, 'Tidak ada payloan yang tersedia saat ini.')
            );
        }

        return createElement(Fragment, null,
            createElement('div', { className: 'nicepay-payloan-container' },
                createElement('div', { className: 'nicepay-payloan-header' },
                    createElement('img', {
                        src: (nicepaypayloanData?.pluginUrl || '') + '/assets/images/paylater-logo.png',
                        alt: 'Payloan Options',
                        className: 'nicepay-payloan-image',
                        onError: (e) => { e.target.style.display = 'none'; }
                    })
                ),
                createElement('div', { className: 'nicepay-payloan-select' },
                    createElement('label', { htmlFor: 'nicepay-payloan-select' }, 'Pilih Payloan:'),
                    createElement('select', {
                        name: 'nicepay_mitra',
                        id: 'nicepay-payloan-select',
                        onChange: handleMitraChange,
                        value: selectedMitra,
                        disabled: isLoading,
                        required: true
                    },
                        [
                            createElement('option', { value: '' }, 'Pilih Payloan'),
                            ...mitra.map(m =>
                                createElement('option', {
                                    value: m.value || m.code,
                                    key: m.value || m.code
                                }, m.label || m.name)
                            )
                        ]
                    ),
                    isLoading && createElement('span', { className: 'nicepay-loading' }, 'Menyimpan...')
                ),
                createElement('p', { className: 'nicepay-payloan-instruction' }, 'Silakan pilih Payloan untuk pembayaran Anda.'),
                createElement('input', { type: 'hidden', name: 'nicepay_selected_payloan_mitra', value: selectedMitra })
            )
        );
    };

    registerPaymentMethod({
        name: "nicepay_payloan",
        label: "NICEPay Payloan",
        content: createElement(NicepayPayloanComponent),
        edit: createElement(NicepayPayloanComponent),
        canMakePayment: () => true,
        ariaLabel: "NICEPay Payloan payment method",
        supports: { features: ['products'] }
    });

    console.log("Payloan Payment Method successfully registered");
}