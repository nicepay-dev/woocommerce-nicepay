jQuery(function($) {
    console.log('NICEPay CC classic checkout initialized');

    function handlePaymentMethodDisplay() {
        console.log('handlePaymentMethodDisplay called');
        $('.nicepay-ccv2-container, .nicepay-vasnap-container, .nicepay_ewallet_snap').hide();
        const selectedMethod = $('input[name="payment_method"]:checked').val();
        console.log('Selected payment method:', selectedMethod);
        if (selectedMethod === 'nicepay_ccv2') {
            $('.nicepay-ccv2-container').show();
        } else if (selectedMethod === 'nicepay_va_snap') {
            $('.nicepay-vasnap-container').show();
            console.log('VA container should be visible');
        } else if (selectedMethod === 'nicepay_ewallet') {
            $('.nicepay_ewallet_snap').show();
            console.log('Ewallet container should be visible');
        }
        
        console.log('CC container exists:', $('.nicepay-ccv2-container').length);
        console.log('VA container exists:', $('.nicepay-vasnap-container').length);
        console.log('Ewallet container exists:', $('.nicepay_ewallet_snap').length);
    }

    function initNicepayCC() {
        const paymentMethod = $('input[name="payment_method"][value="nicepay_ccv2"]');
        if (paymentMethod.length) {
            if (!paymentMethod.closest('li').find('.nicepay-ccv2-container').length) {
                const cardInput = createCardInput();
                paymentMethod.closest('li').append(cardInput);
            }
        }
    }

    function createCardInput() {
        if (!nicepayData) {
            console.error('NICEPay configuration is missing');
            return $('<div>').text('Payment configuration is not available');
        }

        const container = $('<div/>', {
            class: 'nicepay-ccv2-container'
        });

        
        const header = $('<div/>', {
            class: 'nicepay-ccv2-header'
        }).append(
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/card.png',
                alt: 'CC Logo',
                class: 'nicepay-ccv2-icon'
            })
        );

        // Credit card logos
        const cardLogos = $('<div/>', {
            class: 'nicepay-ccv2-logos'
        }).append(
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/visa.png',
                alt: 'Visa',
                class: 'card-logo'
            }),
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/mastercard.png',
                alt: 'Mastercard',
                class: 'card-logo'
            }),
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/jcb.png',
                alt: 'JCB',
                class: 'card-logo'
            }),
            $('<img/>', {
                src: nicepayData.pluginUrl + '/images/american.png',
                alt: 'AmericanExpress',
                class: 'card-logo'
            })
        );

        container.append(header, cardLogos);
        return container;
    }
    $('form.checkout').on('checkout_place_order_nicepay_ccv2', function() {
        return true;
    });

    initNicepayCC();
    handlePaymentMethodDisplay();

    $(document.body).on('updated_checkout', function() {
        console.log('updated_checkout event triggered');
        initNicepayCC();
        handlePaymentMethodDisplay();
    });

    $(document.body).on('change', 'input[name="payment_method"]', function() {
        console.log('Payment method changed to:', $(this).val());
        handlePaymentMethodDisplay();
    });
});