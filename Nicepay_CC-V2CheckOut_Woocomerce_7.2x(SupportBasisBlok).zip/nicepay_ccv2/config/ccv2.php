<?php
class WC_Gateway_NICEPay_CCV2 extends WC_Payment_Gateway {
    public function __construct() {

        if (ob_get_level() == 0) {
            ob_start();
        }

        cc_error_log('Initializing CC Payment Gateway', 'init');
        // plugin id
        $this->id = 'nicepay_ccv2';
        // Payment Gateway title
        $this->method_title = 'NICEPay CC Payment Gateway';
        // true only in case of direct payment method, false in our case
        $this->has_fields = false;

        remove_action('woocommerce_thankyou', 'wc_order_details_table', 10);
        remove_action('woocommerce_thankyou', 'woocommerce_order_details_table', 10);
        remove_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));

        // redirect URL
        $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'WC_Gateway_NICEPay_CCV2', home_url('/')));
        $this->method_description = __('Allows payments using NICEPay Credit Card.', 'nicepay-cc-snap-gateway');

        //Load settings
        $this->init_form_fields(); 
        $this->init_settings();
        $this->environment  = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();

        add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));

        if ($this->get_option('enable_blocks') === 'classic') {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_classic_mode'));
        } else {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_blocks_mode'));
        }

        if ($this->environment === 'sandbox') {
            @ini_set('display_errors', 1);
            @ini_set('display_startup_errors', 1);
            @error_reporting(E_ALL);
        }

        // Define user set variables
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->iMid = $this->get_option('iMid');
        $this->mKey = $this->get_option('mKey');
        $this->Instmount1 = $this->get_option('instmntMon1');
        $this->Instmount3 = $this->get_option('instmntMon3');
        $this->Instmount6 = $this->get_option('instmntMon6');
        $this->Instmount12 = $this->get_option('instmntMon12');
        //---------------------------------------------//
        $this->reduceStock   = $this->get_option( 'reduceStock' );
        //---------------------------------------------//

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_nicepay_return', array($this, 'handle_return_url'));
        add_action('woocommerce_settings_save_' . $this->id, array($this, 'update_api_endpoints'));
        add_action('woocommerce_api_wc_gateway_nicepay_ccv2', array($this, 'handle_notification'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'), 1);
    }
    public function enqueue_classic_mode() {
        if (!is_checkout()) {
            return;
        }
    
        ?>
        <style>
            .nicepay-ccv2-container {
                margin: 15px 0;
                padding: 15px;
                background: #f8f8f8;
                border-radius: 4px;
            }
            .nicepay-ccv2-header {
                margin-bottom: 15px;
                text-align: center;
                padding: 10px 0;
            }
            .nicepay-ccv2-icon {
                max-height: 150px;
                width: auto;
                display: inline-block;
                margin: 10px 0;
            }
            .nicepay-ccv2-select {
                margin: 10px 0;
            }
            .nicepay-ccv2-select label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .nicepay-ccv2-logos {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px; /* Spacing antar logo */
            margin-bottom: 20px;
            }
            .nicepay-ccv2-logos img {
            height: 30px; /* Ukuran untuk logo individu */
            width: auto;
            }
            .nicepay-ccv2-select select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
        </style>
        <?php
    
        // Enqueue JS
        wp_enqueue_script(
            'nicepay-classic-checkout',
            plugins_url('config/classic-checkout.js', dirname(__FILE__)),
            array('jquery'),
            '1.0.0',
            true
        );
    
        // Localize script
        wp_localize_script(
            'nicepay-classic-checkout',
            'nicepayData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'pluginUrl' => plugins_url('', dirname(__FILE__)),
                // 'enabled_mitra' => $this->get_ewallet_options(),
                'nonce' => wp_create_nonce('nicepay-ccv2-snap-nonce')
            )
        );
    }
    public function enqueue_blocks_mode() {
        // Enqueue CSS
        wp_enqueue_style(
            'nicepay-cc-style',
            plugins_url('config/ccv2.css', dirname(__FILE__))
        );
    
        $blocks_js_path = plugin_dir_path(dirname(__FILE__)) . 'config/blocks-integration.js';
        $blocks_js_url = plugins_url('config/blocks-integration.js', dirname(__FILE__));
        if (file_exists($blocks_js_path)) {
            // Register blocks script
            wp_register_script(
                'nicepay-blocks-integration',
                $blocks_js_url,
                array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry', 'jquery'),
                filemtime($blocks_js_path),
                true
            );
            
            // Localize script
            wp_localize_script(
                'nicepay-blocks-integration',
                'nicepayData',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('nicepay-ccv2-snap-nonce'),
                    'pluginUrl' => plugins_url('', dirname(__FILE__))
                )
            );
            
            // Enqueue blocks script
            wp_enqueue_script('nicepay-blocks-integration');
        } else {
            // Log pesan error jika file tidak ditemukan
            error_log('NICEPay CCV2: blocks-integration.js file not found at ' . $blocks_js_path);
        }
    }

    public function update_api_endpoints() {
        $this->environment = $this->get_option('environment', 'sandbox');
        $this->api_endpoints = $this->get_api_endpoints();
    }
    private function get_api_endpoints() {
        $environment = $this->get_option('environment', 'sandbox');
        error_log ("Current environment setting: " . $environment);
    
        $base_url = ($environment === 'production')  
                ? 'https://www.nicepay.co.id'
                : 'https://dev.nicepay.co.id';
        
            return [
                'registration'     => $base_url . '/nicepay/redirect/v2/registration',
                'check_status_url' => $base_url . '/nicepay/direct/v2/inquiry',
            ];
        }
    function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Enable/Disable',
                'label' => 'Enable NICEPay',
                'type' => 'checkbox',
                'description' => '',
                'default' => 'yes',
            ),
            'title' => array(
                'title' =>'Title',
                'type' => 'text',
                'description' => '',
                'default' => 'Pembayaran dengan Kartu Kredit',
            ),
            'description' => array(
                'title' => 'Description',
                'type' => 'textarea',
                'description' => '',
                'default' => 'Sistem pembayaran menggunakan Kartu Kredit.',
            ),
            'enable_blocks' => array(
            'title'       => __('Checkout Mode', 'woocommerce'),
            'type'        => 'select',
            'description' => __('Select checkout mode. Block checkout is for modern WooCommerce checkout, while Classic is for traditional checkout.', 'woocommerce'),
            'default'     => 'classic',
            'options'     => array(
            'classic' => __('Classic Checkout / Element Checkout (Non-Blocks)', 'woocommerce'),
            'blocks'  => __('Block Checkout', 'woocommerce')
            )
            ),
            'environment' => array(
            'title'       => __('Environment', 'woocommerce'),
            'type'        => 'select',
            'desc_tip'    => true,
            'description' => __('Select the NICEPay environment.', 'woocommerce'),
            'default'     => 'sandbox',
            'options'     => array(
                'sandbox'    => __('Sandbox / Development', 'woocommerce'),
                'production' => __('Production', 'woocommerce'),
            ),
        ),
            'iMid' => array(
                'title' => 'Merchant ID',
                'type' => 'text',
                'description' => '<small>Isikan dengan Merchant ID dari NICEPay</small>.',
                'default' => 'IONPAYTEST',
            ),
            
            'mKey' => array(
                'title' => 'Merchant Key',
                'type' => 'text',
                'description' =>'<small>Isikan dengan Merchant Key dari NICEPay</small>.',
                'default' => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            ),

            'reduceStock' => array(
                'title' => __('Reduce stock', 'woocommerce'),
                'type' => 'checkbox',
                'description' => __('<small>Check to enable.</small>', 'woocommerce'),
                'default' => 'no',
            ),
            'instmntMon1' => array(
            'title' => __('Fullpayment', 'woocommerce'),
            'type' => 'checkbox',
            'description' => __('<small>Check to enable. Please confirm to NICEPay before enabled this Installment.</small>', 'woocommerce'),
            'default' => 'yes',
             ),
            'instmntMon3' => array(
            'title' => __('Installment 3 Month', 'woocommerce'),
            'type' => 'checkbox',
            'description' => __('<small>Check to enable. Please confirm to NICEPay before enabled this Installment.</small>', 'woocommerce'),
            'default' => 'no',
            ),
            'instmntMon6' => array(
            'title' => __('Installment 6 Month', 'woocommerce'),
            'type' => 'checkbox',
            'description' => __('<small>Check to enable. Please confirm to NICEPay before enabled this Installment.</small>', 'woocommerce'),
            'default' => 'no',
            ),
            'instmntMon12' => array(
            'title' => __('Installment 12 Month', 'woocommerce'),
            'type' => 'checkbox',
            'description' => __('<small>Check to enable. Please confirm to NICEPay before enabled this Installment.</small>', 'woocommerce'),
            'default' => 'no',
          ),
        );
    }
    public function handle_return_url() {
        try {
            // Clear any output buffer to prevent "headers already sent" error
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            $order_id = isset($_GET['order_id']) ? sanitize_text_field($_GET['order_id']) : '';
            $key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
    
            cc_error_log("Return URL accessed - Order ID: {$order_id}", 'debug');
    
            if (!$order_id || !$key) {
                cc_error_log("Missing required parameters in return URL", 'error');
                wp_redirect(home_url());
                exit;
            }
    
            $order = wc_get_order($order_id);
            if (!$order || $order->get_order_key() !== $key) {
                cc_error_log("Invalid order or key", 'error');
                wp_redirect(home_url());
                exit;
            }
            
            // Get the Thank You page URL
            $redirect_url = $order->get_checkout_order_received_url();
            cc_error_log("Redirecting to: " . $redirect_url, 'debug');
            
            wp_redirect($redirect_url);
            exit;
        } catch (Exception $e) {
            cc_error_log("Return URL error: " . $e->getMessage(), 'error');
            wp_redirect(home_url());
            exit;
        }
    }

    // what this function for?
    public function admin_options() {
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';
    }

    public function process_payment($order_id) {
        try {
            while (ob_get_level()) {
                ob_end_clean();
            }
            $order = wc_get_order($order_id);
            cc_error_log("Starting payment process for order ID: " . $order_id, 'debug');
            
            if (!$order) {
                throw new Exception('Order not found');
            }
            // Siapkan data registrasi
            $registration_data = $this->prepare_registration_data($order);
            cc_error_log("Prepared registration data: " . print_r($registration_data, true), 'debug');
    
            // Kirim request registrasi
            $response = $this->send_registration_request($registration_data);

            if (!$response) {
                throw new Exception('Empty response from registration request');
            }
            cc_error_log("Registration response: " . print_r($response, true), 'debug');
            if (!isset($response->tXid)) {
                throw new Exception('Transaction ID not found in response');
            }
            if (!isset($response->paymentURL)) {
                throw new Exception('Payment URL not found in response');
            }
    
            $order->update_meta_data('_nicepay_txid', $response->tXid);
            $order->update_meta_data('_nicepay_response', json_encode($response));

            $registration_note = "Payment Registration:\n";
            $registration_note .= "- Transaction ID: " . $response->tXid . "\n";
            $registration_note .= "- Amount: Rp" . number_format($response->amt, 0, ',', '.');
            $order->add_order_note($registration_note);
            
            WC()->session->set('nicepay_thank_you_url', $order->get_checkout_order_received_url());

                $order->save();
                
            $payment_url = $response->paymentURL . '?tXid=' . $response->tXid;
            cc_error_log("Payment registration successful. Redirecting to: " . $payment_url, 'info');
    
                return array(
                    'result' => 'success',
                    'redirect' => $payment_url
                );
            } catch (Exception $e) {
                cc_error_log("Payment processing failed: " . $e->getMessage(), 'error');
                wc_add_notice('Payment error: ' . $e->getMessage(), 'error');
                return array('result' => 'fail');
            }
        }
    
        private function prepare_registration_data($order) {
            cc_error_log("Preparing registration data for order: " . $order->get_id(), 'debug');
        
            // Format timestamp sesuai dengan format yang diminta
            $timestamp = date('YmdHis');
            
            // Siapkan cart data
            $cart_data = $this->prepare_cart_data($order);
            $thank_you_url = $order->get_checkout_order_received_url();
            $return_url = add_query_arg(array(
                'wc-api' => 'nicepay_return',
                'order_id' => $order->get_id(),
                'key' => $order->get_order_key()
            ), home_url('/'));
            cc_error_log("Thank you page URL: " . $return_url, 'debug');
        
            $data = array(
                'timeStamp' => $timestamp,
                'iMid' => $this->iMid,
                'payMethod' => '00', 
                'bankCd' => '',
                'currency' => 'IDR',
                'amt' => number_format($order->get_total(), 0, '', ''),
                'referenceNo' => $order->get_id(),
                'callBackUrl' => $return_url,
                'dbProcessUrl' => add_query_arg('wc-api', 'WC_Gateway_NICEPay_CCV2', home_url('/')),
                'goodsNm' => 'Order' . $order->get_id(),
                'vacctValidDt' => '',
                'vacctValidTm' => '',
                'description' => 'Payment for order #' . $order->get_id(),
                'billingNm' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'billingPhone' => $order->get_billing_phone(),
                'billingEmail' => $order->get_billing_email(),
                'billingAddr' => $order->get_billing_address_1(),
                'billingCity' => $order->get_billing_city(),
                'billingState' => $order->get_billing_state(),
                'billingPostCd' => $order->get_billing_postcode(),
                'billingCountry' => $order->get_billing_country(),
                'userIP' => '127.0.0.1',
                'mitraCd' => '',
                'instmntType' => '2',
                'instmntMon' => '1',
                'recurrOpt' => '',
                'cartData' => $cart_data,
                'deliveryNm' => '',
                'deliveryPhone' => '',
                'deliveryAddr' => '',
                'deliveryCity' => '',
                'deliveryState' => '',
                'deliveryPostCd' => '',
                'deliveryCountry' => '',
                'vat' => '',
                'fee' => '',
                'notaxAmt' => '',
                'reqDt' => '',
                'reqTm' => '',
                'reqDomain' => '',
                'reqServerIP' => '',
                'reqClientVer' => '',
                'userSessionID' => '',
                'userAgent' => '',
                'userLanguage' => ''
            );
            cc_error_log("Order total: " . $order->get_total(), 'debug');
            cc_error_log("Order subtotal: " . $order->get_subtotal(), 'debug');
            cc_error_log("Order tax: " . $order->get_total_tax(), 'debug');
            cc_error_log("Order shipping: " . $order->get_shipping_total(), 'debug');
            // Generate merchant token
            $data['merchantToken'] = $this->generate_merchant_token($data);
            cc_error_log("Callback URL set to: " . $thank_you_url, 'debug');
            cc_error_log("Complete registration data prepared: " . print_r($data, true), 'debug');
            
            return $data;
        }


private function prepare_cart_data($order) {
    $items = $order->get_items();
    $cart_items = array();
    $calculated_total = 0;
    $order_total = intval(number_format($order->get_total(), 0, '', ''));

    foreach ($items as $item) {
        $product = $item->get_product();
        $unit_price = intval(number_format($item->get_total() / $item->get_quantity(), 0, '', '')); 
        
        $cart_items[] = array(
            'goods_id' => $product->get_sku() ?: $product->get_id(),
            'goods_detail' => substr(strip_tags($product->get_description()), 0, 50),
            'goods_name' => $item->get_name(),
            'goods_amt' => (string)$unit_price, 
            'goods_type' => $product->get_type(),
            'goods_url' => get_permalink($product->get_id()),
            'goods_quantity' => $item->get_quantity(),
            'goods_sellers_id' => 'STORE',
            'goods_sellers_name' => get_bloginfo('name')
        );
        $calculated_total += ($unit_price * $item->get_quantity());
        cc_error_log("Item: {$item->get_name()}, Unit Price: {$unit_price}, Qty: {$item->get_quantity()}, Subtotal: " . ($unit_price * $item->get_quantity()), 'debug');
    }
    if ($order->get_shipping_total() > 0) {
        $shipping_amount = intval(number_format($order->get_shipping_total(), 0, '', ''));
        $cart_items[] = array(
            'goods_id' => 'SHIPPING',
            'goods_detail' => 'Delivery Fee',
            'goods_name' => 'Shipping Cost',
            'goods_amt' => (string)$shipping_amount,
            'goods_type' => 'shipping',
            'goods_url' => '',
            'goods_quantity' => 1,
            'goods_sellers_id' => 'STORE',
            'goods_sellers_name' => get_bloginfo('name')
        );
        $calculated_total += $shipping_amount;
        cc_error_log("Shipping: {$shipping_amount}", 'debug');
    }
    $tax_difference = $order_total - $calculated_total;
    
    cc_error_log("Calculated total before tax: {$calculated_total}", 'debug');
    cc_error_log("Order total: {$order_total}", 'debug');
    cc_error_log("Difference (tax): {$tax_difference}", 'debug');
    if ($tax_difference > 0) {
        $cart_items[] = array(
            'goods_id' => 'TAX',
            'goods_detail' => 'Tax',
            'goods_name' => 'Tax',
            'goods_amt' => (string)$tax_difference,
            'goods_type' => 'tax',
            'goods_url' => '',
            'goods_quantity' => 1,
            'goods_sellers_id' => 'STORE',
            'goods_sellers_name' => get_bloginfo('name')
        );
        $calculated_total += $tax_difference;
        cc_error_log("Tax added: {$tax_difference}", 'debug');
    }
    cc_error_log("Final calculated total: {$calculated_total}", 'debug');
    
    $cart_data = array(
        'count' => count($cart_items),
        'item' => $cart_items
    );
    cc_error_log("Cart items count: " . count($cart_items), 'debug');
    return json_encode($cart_data);
}
private function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = '127.0.0.1';
    return $ipaddress;
}
private function generate_merchant_token($data) {
    // Memastikan format amt tanpa desimal dan tanda pemisah
    $amt = number_format($data['amt'], 0, '', '');
    
    // Membuat raw data sesuai format
    $raw_data = $data['timeStamp'] . $data['iMid'] . $data['referenceNo'] . $amt . $this->mKey;
    
    // Log untuk debugging
    cc_error_log("Generating merchant token with components:", 'debug');
    cc_error_log("- timeStamp: " . $data['timeStamp'], 'debug');
    cc_error_log("- iMid: " . $data['iMid'], 'debug');
    cc_error_log("- referenceNo: " . $data['referenceNo'], 'debug');
    cc_error_log("- amt: " . $amt, 'debug');
    cc_error_log("- merchantKey: " . $this->mKey, 'debug');
    cc_error_log("Raw data before hash: " . $raw_data, 'debug');
    
    // Generate SHA256 hash
    $token = hash('sha256', $raw_data);
    cc_error_log("Generated merchant token: " . $token, 'debug');
    
    return $token;
}
        
    
    private function send_registration_request($data) {
        try {
            // Clear any output buffer
            while (ob_get_level()) {
                ob_end_clean();
            }
        cc_error_log("Sending registration request to: " . $this->api_endpoints['registration'], 'debug');
        
        if (empty($this->api_endpoints['registration'])) {
            throw new Exception('Registration endpoint not configured');
        }
        $request_body = json_encode($data);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Failed to encode request data: ' . json_last_error_msg());
        }
        cc_error_log("Request body: " . json_encode($data), 'debug');
        $response = wp_remote_post($this->api_endpoints['registration'], array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($data),
            'timeout' => 30
        ));
    
        if (is_wp_error($response)) {
            throw new Exception('Registration request failed: ' . $response->get_error_message());
        }
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            throw new Exception('Invalid response code: ' . $response_code);
        }
    
        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            throw new Exception('Empty response body');
        }

        cc_error_log("Raw response body: " . $body, 'debug');
        
        $decoded_response = json_decode($body);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Failed to decode response: ' . json_last_error_msg());
        }
        
        // Check result code
        if (isset($decoded_response->resultCd) && $decoded_response->resultCd !== '0000') {
            throw new Exception('Error response from gateway: ' . 
                (isset($decoded_response->resultMsg) ? $decoded_response->resultMsg : 'Unknown error'));
        }
    
        return $decoded_response;

    } catch (Exception $e) {
        cc_error_log("Registration request error: " . $e->getMessage(), 'error');
        throw $e;
    }
}

    
    public function handle_notification() {
        try {
            // Log raw notification data
            cc_error_log("========= START NOTIFICATION HANDLER =========", 'debug');
            cc_error_log("Raw POST data: " . print_r($_POST, true), 'debug');
            
            // Cek parameter wajib
            if (!isset($_POST['referenceNo']) || !isset($_POST['tXid']) || !isset($_POST['status'])) {
                cc_error_log("Missing required parameters", 'error');
                throw new Exception('Missing required parameters');
            }
            
            $reference_no = sanitize_text_field($_POST['referenceNo']);
            $txid = sanitize_text_field($_POST['tXid']);
            $status = sanitize_text_field($_POST['status']);
            
            cc_error_log("Processing notification - Order ID: {$reference_no}, tXid: {$txid}, Status: {$status}", 'debug');
            // Get order
            $order = wc_get_order($reference_no);
            if (!$order) {
                cc_error_log("Order not found: {$reference_no}", 'error');
                throw new Exception('Order not found');
            }
            
            $stored_txid = $order->get_meta('_nicepay_txid');
            if ($stored_txid !== $txid) {
                cc_error_log("tXid mismatch - Stored: {$stored_txid}, Received: {$txid}", 'error');
                throw new Exception('Invalid transaction ID');
            }
            if ($status === '0') {
                cc_error_log("Success status received, executing check_payment_status", 'debug');
                
                $check_result = $this->check_payment_status($reference_no);
                if ($check_result) {
                    cc_error_log("Status check response: " . print_r($check_result, true), 'debug');
                    $status_note = $this->get_status_message($check_result);
                    
                    switch($check_result->status) {
                        case '0':
                            $order->payment_complete($txid);
                            $order->add_order_note($status_note, 1);
                            cc_error_log("Order marked as complete", 'info');
                            break;
                        case '8':
                            $order->update_status('failed');
                            $order->add_order_note($status_note, 1);
                            cc_error_log("Order marked as failed", 'info');
                            break;
                        default:
                            $order->update_status('pending');
                            $order->add_order_note($status_note, 1);
                            cc_error_log("Order status unchanged", 'info');
                            break;
                    }
                }
            } else {
                cc_error_log("Non-success status received: {$status}", 'info');
            }
            
            cc_error_log("========= END NOTIFICATION HANDLER =========", 'debug');
            echo "OK";
            
        } catch (Exception $e) {
            cc_error_log("Notification handler error: " . $e->getMessage(), 'error');
            echo "ERROR: " . $e->getMessage();
        }
        exit;
    }
    private function get_status_message($status_check) {
        $status_messages = array(
            '0' => 'Success - Payment completed successfully',
            '1' => 'Void - Payment has been voided',
            '2' => 'Refund - Payment has been refunded',
            '8' => 'Failed - Payment transaction failed',
            '9' => 'Initialization - Payment is being initialized'
        );
        
        $status = isset($status_check->status) ? $status_check->status : '';
        $txid = isset($status_check->tXid) ? $status_check->tXid : '';
        $amount = isset($status_check->amt) ? $status_check->amt : '0';
        $result_msg = isset($status_check->resultMsg) ? $status_check->resultMsg : '';
        cc_error_log("Preparing note with values:", 'debug');
        cc_error_log("Status: " . $status, 'debug');
        cc_error_log("TxID: " . $txid, 'debug');
        cc_error_log("Amount: " . $amount, 'debug');
        cc_error_log("Result Message: " . $result_msg, 'debug');

        $status_message = isset($status_messages[$status]) 
        ? $status_messages[$status] 
        : 'Unknown status';
    
         $note_parts = array(
        'Payment Status Information:',
        '- Status: ' . $status_message . ' (' . $status . ')',
        '- Transaction ID: ' . $txid,
        '- Amount: Rp' . number_format($amount, 0, ',', '.'),
        '- Response Message: ' . $result_msg
        );
    
        if (!empty($status_check->cardNo)) {
            $note_parts[] = '- Card Number: ' . $status_check->cardNo;
        }
        if (!empty($status_check->acquBankNm)) {
            $note_parts[] = '- Bank: ' . $status_check->acquBankNm;
        }
    
        $final_note = implode("\n", $note_parts);
        cc_error_log("Final note: " . $final_note, 'debug');
    
        return $final_note;
    }
    
    private function update_order_status($order, $notification) {
        switch ($notification->status) {
            case '0':
                $order->payment_complete($notification->tXid);
                $order->add_order_note('Payment successful. Transaction ID: ' . $notification->tXid);
                break;
                
            case '1':
                $order->update_status('failed');
                $order->add_order_note('Payment failed. Reason: ' . $notification->failureMsg);
                break;
                
            default:
                $order->update_status('on-hold');
                $order->add_order_note('Payment status unclear. Status: ' . $notification->status);
        }
    }

    public function check_payment_status($order_id) {
        try {
            $order = wc_get_order($order_id);
            if (!$order) {
            throw new Exception("Order not found: {$order_id}");
            }
            
            $txid = $order->get_meta('_nicepay_txid');
        if (!$txid) {
            throw new Exception('Transaction ID not found in order meta');
        }
    
        cc_error_log("Checking payment status for order: {$order_id}, tXid: {$txid}", 'debug');
            
            // Format data sesuai dokumentasi
            $amount = number_format($order->get_total(), 0, '', '');
            $timestamp = date('YmdHis');
            
            $request_data = array(
                'timeStamp' => $timestamp,
                'tXid' => $txid,
                'iMid' => $this->iMid,
                'referenceNo' => $order_id,
                'amt' => $amount
            );
            
            // Generate merchant token
            $raw_data = $request_data['timeStamp'] . 
                       $request_data['iMid'] . 
                       $request_data['referenceNo'] . 
                       $request_data['amt'] . 
                       $this->mKey;
                       
            $request_data['merchantToken'] = hash('sha256', $raw_data);
            
            cc_error_log("Check status request data: " . print_r($request_data, true), 'debug');
            cc_error_log("Raw data for token: " . $raw_data, 'debug');
            cc_error_log("Generated merchant token: " . $request_data['merchantToken'], 'debug');
            
            $response = wp_remote_post($this->api_endpoints['check_status_url'], array(
                'headers' => array(
                    'Content-Type' => 'application/json'
                ),
                'body' => json_encode($request_data),
                'timeout' => 30
            ));
            
            if (is_wp_error($response)) {
                throw new Exception('Status check request failed: ' . $response->get_error_message());
            }
            
            $body = wp_remote_retrieve_body($response);
            cc_error_log("Status check raw response: " . $body, 'debug');
            
            $decoded_response = json_decode($body);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid response format: ' . json_last_error_msg());
            }
            
            return $decoded_response;
            
        } catch (Exception $e) {
            cc_error_log("Status check failed: " . $e->getMessage(), 'error');
            return false;
        }
    }

    public function thankyou_page($order_id) {
        try {

            if (ob_get_level()) {
                ob_end_clean();
            }
            $order = wc_get_order($order_id);
            
            if (!$order || $order->get_payment_method() !== $this->id) {
                return;
            }
            
           
            ob_clean();
            // $status_check = $this->check_payment_status($order_id);
            // remove_action('woocommerce_thankyou', 'woocommerce_order_details_table', 10);
            // Inline styles
            echo '<style>
            .nicepay-status-message {
                text-align: center;
                padding: 15px;
                margin: 20px 0;
                border-radius: 4px;
                font-weight: bold;
                display: block;
            }
            .status-success {
                background-color: #f0f9f0;
                color: #2e7d32;
                border: 1px solid #a5d6a7;
            }
            .status-failed {
                background-color: #fef2f2;
                color: #b71c1c;
                border: 1px solid #ef9a9a;
            }
            .status-pending {
                background-color: #fff8e1;
                color: #f57f17;
                border: 1px solid #ffe082;
            }
        </style>';

        $order_status = $order->get_status();
        
        echo '<div class="nicepay-status-message ';
        
        // Show appropriate message based on order status
        if ($order_status === 'completed' || $order_status === 'processing') {
            echo 'status-success">Payment has been successfully completed.';
        } elseif ($order_status === 'failed') {
            echo 'status-failed">Payment failed. Please try again or contact administrator.';
        } else {
            echo 'status-pending">Your payment is being processed. Please wait for confirmation and refresh page if you already payment for update status';
        }
        echo '</div>';
        
    } catch (Exception $e) {
        cc_error_log("Thankyou page error: " . $e->getMessage(), 'error');
    }
}
    
    private function verify_notification($notification) {
        try {
            // Membuat token untuk verifikasi
            $raw_data = $notification['transDt'] . 
                       $this->iMid . 
                       $notification['referenceNo'] . 
                       $notification['amt'] . 
                       $this->mKey;
            
            $expected_token = hash('sha256', $raw_data);
            
            // Log verification process
            cc_error_log("Verifying notification token:", 'debug');
            cc_error_log("- Raw data: " . $raw_data, 'debug');
            cc_error_log("- Expected token: " . $expected_token, 'debug');
            cc_error_log("- Received token: " . $notification['merchantToken'], 'debug');
            
            return $notification['merchantToken'] === $expected_token;
        } catch (Exception $e) {
            cc_error_log("Token verification failed: " . $e->getMessage(), 'error');
            return false;
        }
    }
}

?>