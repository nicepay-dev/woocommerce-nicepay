<?php
if (!defined('ABSPATH')) exit;

class NICEPay_Log_Manager {
    private static $instances = array();
    private $log_dir;
    private $channel;

    private function __construct($channel = 'va') {
        $this->channel = $channel;
        $upload_dir    = wp_upload_dir();
        $this->log_dir = trailingslashit($upload_dir['basedir']) . 'nicepay-logs/' . $channel . '/';
        
        if (!file_exists($this->log_dir)) {
            wp_mkdir_p($this->log_dir);
        }
    }

    public static function instance($channel = 'va') {
        if (!isset(self::$instances[$channel])) {
            self::$instances[$channel] = new self($channel);
        }
        return self::$instances[$channel];
    }

    public function log($message, $type = 'info') {
        $time     = current_time('mysql');
        $filename = $this->log_dir . $this->get_today_log_filename();
        $entry    = "[$time][$type] $message" . PHP_EOL;
        file_put_contents($filename, $entry, FILE_APPEND);
    }

    public function get_today_log_filename() {
        $date = current_time('Y-m-d');
        return $date . '.log';
    }

    public function get_log_files() {
        $files = glob($this->log_dir . '*.log');
        if (!$files) return [];
        // urutkan desc terbaru ke lama
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        return array_map('basename', $files);
    }

    public function get_logs() {
        $filename = $this->log_dir . $this->get_today_log_filename();
        if (!file_exists($filename)) {
            return [];
        }

        $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $logs  = [];

        foreach ($lines as $line) {
            if (preg_match('/\[(.*?)\]\[(.*?)\] (.*)/', $line, $matches)) {
                $logs[] = [
                    'time'    => $matches[1],
                    'type'    => $matches[2],
                    'message' => $matches[3]
                ];
            }
        }

        return $logs;
    }

    public function get_log_file_url($filename = null) {
        $upload_dir = wp_upload_dir();
        if (!$filename) {
            $filename = $this->get_today_log_filename();
        }
        return trailingslashit($upload_dir['baseurl']) . 'nicepay-logs/' . $this->channel . '/' . $filename;
    }

    public function clear_logs() {
        $filename = $this->log_dir . $this->get_today_log_filename();
        if (file_exists($filename)) {
            unlink($filename);
        }
    }
}