(function() {
    console.log("Loading NICEPay VA Plugin");

    const wpElement = window.wp.element;
    const { createElement, useState } = wpElement;

    // global var buat getPaymentData
    let selectedBank = '';

    const NicepayVASNAPComponent = () => {
        const [localSelectedBank, setLocalSelectedBank] = useState('');
        const banks = nicepayVAData.banks || [];
        // const banks = [
        //     { code: 'BMRI', name: 'Bank Mandiri' },
        //     { code: 'BNIN', name: 'Bank BNI' },
        //     { code: 'BRIN', name: 'Bank BRI' },
        //     { code: 'BBBA', name: 'Bank Permata' },
        //     { code: 'CENA', name: 'Bank BCA' },
        //     { code: 'IBBK', name: 'Maybank' },
        //     { code: 'BBBB', name: 'Bank Permata Syariah' },
        //     { code: 'HNBN', name: 'Bank KEB Hana Indonesia' },
        //     { code: 'BNIA', name: 'Bank CIMB' },
        //     { code: 'BDIN', name: 'Bank Bank Danamon' },
        //     { code: 'PDJB', name: 'Bank BJB' },
        //     { code: 'YUDB', name: 'Bank Neo Commerce (BNC)' },
        //     { code: 'BDKI', name: 'Bank DKI' },
        // ];

        const handleBankChange = (e) => {
            const selectedBankCode = e.target.value;
            console.log('Bank selected:', selectedBankCode);
            selectedBank = selectedBankCode;
            setLocalSelectedBank(selectedBankCode);
            saveBankSelection(selectedBankCode);
        };

        const saveBankSelection = (selectedBankCode) => {
            if (typeof jQuery !== 'undefined' && typeof nicepayVAData !== 'undefined') {
                jQuery.ajax({
                    url: nicepayVAData.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'set_nicepay_bank',
                        bank_code: selectedBankCode,
                        security: nicepayVAData.nonce || '' 
                    },
                    success: function(response) {
                    },
                    error: function(error) {
                        console.error('Error saving bank selection:', error);
                    }
                });
            } else {
                console.error('jQuery or nicepayVAData is not available');
            }
        };

        return createElement('div', { className: 'nicepay-vasnap-container' }, [
            createElement('div', { className: 'nicepay-vasnap-header' }, [
                createElement('img', {
                    src: nicepayVAData.pluginUrl + '/assets/images/logo-bank.png',
                    alt: 'Bank Icon',
                    className: 'nicepay-vasnap-bank-icon'
                }),
            ]),
            createElement('div', { className: 'nicepay-vasnap-bank-select' }, [
                createElement('label', { htmlFor: 'nicepay-bank-select' }, 'Pilih Bank:'),
                createElement('select',
                    {
                        name: 'nicepay_bank',
                        id: 'nicepay-bank-select',
                        onChange: handleBankChange,
                        value: localSelectedBank
                    },
                    [
                        createElement('option', { value: '' }, 'Pilih Bank'),
                        ...banks.map(bank =>
                            createElement('option', { value: bank.code, key: bank.code }, bank.name)
                        )
                    ]
                )
            ]),
            createElement('p', { className: 'nicepay-vasnap-instruction' }, 'Silakan pilih bank untuk pembayaran Virtual Account Anda.')
        ]);
    };

    const safelyRegisterVAPaymentMethod = function() {
        console.log("Attempting to register VA Payment Method");

        if (!window.wc || !window.wc.wcBlocksRegistry) {
            console.error('WooCommerce Blocks registry tidak tersedia untuk VA');
            setTimeout(safelyRegisterVAPaymentMethod, 300);
            return;
        }

        try {
            if (window.nicepay_va_registered === true) {
                console.log("VA already registered, skipping");
                return;
            }

            const { registerPaymentMethod } = window.wc.wcBlocksRegistry;

            registerPaymentMethod({
                name: "nicepay_va_snap",
                label: "NICEPay Virtual Account",
                content: createElement(NicepayVASNAPComponent),
                edit: createElement(NicepayVASNAPComponent),
                canMakePayment: () => true,
                ariaLabel: "NICEPay Virtual Account payment method",
                paymentMethodId: "nicepay_va_snap",
                supports: {
                    features: ['products'],
                },
                paymentMethodData: {
                    getPaymentData: () => {
                        console.log("getPaymentData triggered, selectedBank:", selectedBank);
                        return {
                            nicepay_bank: selectedBank
                        };
                    }
                }
            });

            window.nicepay_va_registered = true;
            console.log("VA Payment Method successfully registered");
        } catch (error) {
            console.error("Error registering VA Payment Method:", error);
            setTimeout(safelyRegisterVAPaymentMethod, 500);
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', safelyRegisterVAPaymentMethod);
    } else {
        safelyRegisterVAPaymentMethod();
    }
})();