(function () {
    console.log("Loading NICEPay CC Plugin");

    document.addEventListener('DOMContentLoaded', function () {
        if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
            console.log('Initializing Credit Card payment method');
            initNicepayCC();
        } else {
            console.error('Required dependencies not available for CC');
        }
    });

    function initNicepayCC() {
        const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
        const { createElement, Fragment } = window.wp.element;

        const NicepayCCComponent = () => {
            return createElement(Fragment, null,
                createElement('div', { className: 'nicepay-cc-container' },
                    createElement('div', { className: 'nicepay-cc-header' },
                        createElement('img', {
                            src: (nicepayCCData?.pluginUrl || '') + '/assets/images/credit-card-logo.png',
                            alt: 'Credit Card Payment',
                            className: 'nicepay-cc-image',
                            onError: e => e.target.style.display = 'none'
                        })
                    ),
                    createElement('p', null, 'You will be redirected to NICEPay to complete your payment securely.')
                )
            );
        };

        registerPaymentMethod({
            name: 'nicepay_cc',
            label: 'NICEPay Credit Card',
            content: createElement(NicepayCCComponent),
            edit: createElement(NicepayCCComponent),
            canMakePayment: () => true,
            ariaLabel: 'NICEPay Credit Card payment method',
            supports: { features: ['products'] }
        });

        console.log('CC Payment Method registered');
    }
})();