console.log("Loading NICEPay Ewallet Plugin");

document.addEventListener('DOMContentLoaded', function () {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log("Initializing E-wallet Payment Method");
        initNicepayEwallet();
    } else {
        console.error('Required dependencies not available for E-wallet');
    }
});

function initNicepayEwallet() {
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment, useState, useEffect } = window.wp.element;

    const NicepayEwalletComponent = () => {
        const [selectedMitra, setSelectedMitra] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const mitra = window.nicepayEwalletData?.enabled_mitra || [];

        console.log('Available mitra (Ewallet):', mitra);

        // Reset default setiap load
        useEffect(() => {
            setSelectedMitra('');
            if (mitra.length === 1) {
                const defaultMitra = mitra[0].value || mitra[0].code;
                setSelectedMitra(defaultMitra);
            }
        }, [mitra]);

        const handleMitraChange = (e) => {
            const mitraCode = e.target.value;
            console.log('Mitra selected:', mitraCode);
            setSelectedMitra(mitraCode);
            saveMitraSelection(mitraCode);
        };

        const saveMitraSelection = (mitraCode) => {
            if (typeof jQuery === 'undefined' || !window.nicepayEwalletData) {
                console.warn('jQuery or nicepayEwalletData not available');
                return;
            }
            if (!nicepayEwalletData.ajax_url || !nicepayEwalletData.nonce) {
                console.warn('Required AJAX data missing');
                return;
            }
            setIsLoading(true);
            jQuery.ajax({
                url: nicepayEwalletData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_mitra',
                    mitra_code: mitraCode,
                    nonce: nicepayEwalletData.nonce
                },
                timeout: 10000,
                success: function (response) {
                    setIsLoading(false);
                },
                error: function (xhr, status, error) {
                    console.error('Error saving mitra selection:', error);
                    setIsLoading(false);
                }
            });
        };

        if (!Array.isArray(mitra) || mitra.length === 0) {
            return createElement('div', { className: 'nicepay-ewallet-container' },
                createElement('p', null, 'Tidak ada e-wallet yang tersedia saat ini.')
            );
        }

        return createElement(Fragment, null,
            createElement('div', { className: 'nicepay-ewallet-container' },
                createElement('div', { className: 'nicepay-ewallet-header' },
                    createElement('img', {
                        src: (nicepayEwalletData?.pluginUrl || '') + '/assets/images/ewallet-logo.png',
                        alt: 'E-wallet Options',
                        className: 'nicepay-ewallet-image',
                        onError: (e) => { e.target.style.display = 'none'; }
                    })
                ),
                createElement('div', { className: 'nicepay-ewallet-select' },
                    createElement('label', { htmlFor: 'nicepay-ewallet-select' }, 'Pilih E-wallet:'),
                    createElement('select', {
                        name: 'nicepay_mitra',
                        id: 'nicepay-ewallet-select',
                        onChange: handleMitraChange,
                        value: selectedMitra,
                        disabled: isLoading,
                        required: true
                    },
                        [
                            createElement('option', { value: '' }, 'Pilih E-wallet'),
                            ...mitra.map(m =>
                                createElement('option', {
                                    value: m.value || m.code,
                                    key: m.value || m.code
                                }, m.label || m.name)
                            )
                        ]
                    ),
                    isLoading && createElement('span', { className: 'nicepay-loading' }, 'Menyimpan...')
                ),
                createElement('p', { className: 'nicepay-ewallet-instruction' }, 'Silakan pilih e-wallet untuk pembayaran Anda.'),
                createElement('input', { type: 'hidden', name: 'nicepay_selected_mitra', value: selectedMitra })
            )
        );
    };

    registerPaymentMethod({
        name: "nicepay_ewallet",
        label: "NICEPay E-wallet",
        content: createElement(NicepayEwalletComponent),
        edit: createElement(NicepayEwalletComponent),
        canMakePayment: () => true,
        ariaLabel: "NICEPay E-wallet payment method",
        supports: { features: ['products'] }
    });

    console.log("Ewallet Payment Method successfully registered");
}