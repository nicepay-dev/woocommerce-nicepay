console.log("Loading NICEPay CVS Plugin");

document.addEventListener('DOMContentLoaded', function () {
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log('Initializing CVS payment method');
        initNicepayCvs();
    } else {
        console.error('Required dependencies not available for CVS');
    }
});

function initNicepayCvs() {
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, Fragment, useState } = window.wp.element;
    const mitraList = window.nicepayCvsData?.enabled_mitra || [];

    const NicepayCvsComponent = () => {
        const [selectedMitra, setSelectedMitra] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        

        const handleMitraChange = (e) => {
            const mitraCode = e.target.value;
            console.log('Mitra selected:', mitraCode);
            setSelectedMitra(mitraCode);
            saveMitraSelection(mitraCode);
        };

        const saveMitraSelection = (mitraCode) => {
            if (!nicepayCvsData?.ajax_url || !nicepayCvsData?.nonce) {
                console.warn('Required AJAX data missing for CVS');
                return;
            }

            setIsLoading(true);
            jQuery.post(nicepayCvsData.ajax_url, {
                action: 'set_nicepay_cvs_mitra',
                mitra_code: mitraCode,
                nonce: nicepayCvsData.nonce
            }).always(() => {
                setIsLoading(false);
            });
        };

        if (mitraList.length === 0) {
            return createElement('div', { className: 'nicepay-cvs-container' },
                createElement('p', null, 'Tidak ada CVS yang tersedia saat ini.')
            );
        }

        return createElement(Fragment, null,
            createElement('div', { className: 'nicepay-cvs-container' },
                createElement('div', { className: 'nicepay-cvs-header' },
                    createElement('img', {
                        src: (nicepayCvsData?.pluginUrl || '') + '/assets/images/cvs-logo.png',
                        alt: 'CVS Options',
                        className: 'nicepay-cvs-image',
                        onError: e => { e.target.style.display = 'none'; }
                    })
                ),
                createElement('div', { className: 'nicepay-cvs-select' },
                    createElement('label', { htmlFor: 'nicepay-cvs-select' }, 'Pilih CVS:'),
                    createElement('select', {
                        name: 'nicepay_mitra',
                        id: 'nicepay-cvs-select',
                        onChange: handleMitraChange,
                        value: selectedMitra,
                        disabled: isLoading,
                        required: true
                    }, [
                        createElement('option', { value: '' }, 'Pilih CVS'),
                        ...mitraList.map(m => createElement('option', { value: m.value || m.code }, m.label || m.name))
                    ]),
                    isLoading && createElement('span', { className: 'nicepay-loading' }, 'Menyimpan...')
                ),
                createElement('p', { className: 'nicepay-cvs-instruction' }, 'Silakan pilih CVS untuk pembayaran Anda.'),
                createElement('input', { type: 'hidden', name: 'nicepay_selected_cvs_mitra', value: selectedMitra })
            )
        );
    };

    registerPaymentMethod({
        name: 'nicepay_cvs',
        label: 'NICEPay CVS',
        content: createElement(NicepayCvsComponent),
        edit: createElement(NicepayCvsComponent),
        canMakePayment: () => mitraList.length > 0,
        ariaLabel: 'NICEPay CVS payment method',
        paymentMethodId: 'nicepay_cvs',
        supports: {
            features: ['products']
        }
    });
}