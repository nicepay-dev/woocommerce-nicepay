jQuery(function ($) {
    console.log('NICEPay Cvs classic checkout initialized');

    function createCvsSelector() {
        if (!nicepayData || !Array.isArray(nicepayData.enabled_mitra) || nicepayData.enabled_mitra.length === 0) {
            console.error('NICEPay configuration is missing or no mitra available');
            return $('<div>').text('Cvs belum tersedia saat ini.');
        }

        const container = $('<div/>', {
            class: 'nicepay-cvs-container'
        });

        const header = $('<div/>', { class: 'nicepay-cvs-header' }).append(
            $('<img/>', {
                src: nicepayData.pluginUrl + '/assets/images/cvs-logo.png',
                alt: 'Cvs Logo',
                class: 'nicepay-cvs-icon'
            })
        );

        const cvsSelect = $('<div/>', { class: 'nicepay-cvs-select' }).append(
            $('<label/>', {
                for: 'nicepay-cvs-select',
                text: 'Pilih Cvs:'
            }),
            $('<select/>', {
                name: 'nicepay_mitra',
                id: 'nicepay-cvs-select'
            }).append(
                $('<option/>', { value: '', text: 'Pilih Cvs' }),
                nicepayData.enabled_mitra.map(mitra =>
                    $('<option/>', { value: mitra.value, text: mitra.label })
                )
            )
        );

        const errorContainer = $('<div/>', {
            class: 'nicepay-cvs-error',
            style: 'display: none; color: red; margin-top: 10px;'
        });

        container.append(header, cvsSelect, errorContainer);
        return container;
    }

    function showError(message, container) {
        const errorDiv = container.find('.nicepay-cvs-error');
        errorDiv.text(message).show();
        setTimeout(() => errorDiv.fadeOut(), 5000);
    }

    function saveMitraSelection(selectedMitra, container) {
        if (!selectedMitra) {
            return;
        }

        const select = container.find('#nicepay-cvs-select');
        select.prop('disabled', true);

        $.ajax({
            url: nicepayData.ajax_url,
            type: 'POST',
            data: {
                action: 'set_nicepay_cvs_mitra',
                mitra_code: selectedMitra,
                nonce: nicepayData.nonce
            },
            success: function (response) {
                if (response.success) {
                    console.log('Mitra selection saved:', response.data);
                    sessionStorage.setItem('nicepay_selected_cvs_mitra', selectedMitra);
                } else {
                    showError(response.data || 'Failed to save selection', container);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error saving mitra selection:', error);
                showError('Failed to save Cvs selection', container);
            },
            complete: function () {
                select.prop('disabled', false);
            }
        });
    }

    function initNicepayClassic() {
        const paymentMethod = $('input[name="payment_method"][value="nicepay_cvs_snap"]');

        if (paymentMethod.length) {
            // Remove existing container biar gak dobel
            paymentMethod.closest('li').find('.nicepay-cvs-container').remove();

            const cvsSelector = createCvsSelector();
            paymentMethod.closest('li').append(cvsSelector);

            // Restore selection kalau ada
            const savedMitra = sessionStorage.getItem('nicepay_selected_cvs_mitra');
            if (savedMitra) {
                $('#nicepay-cvs-select').val(savedMitra);
            }

            // Handle selection
            $('#nicepay-cvs-select').on('change', function () {
                const selectedMitra = $(this).val();
                if (selectedMitra) {
                    sessionStorage.setItem('nicepay_selected_cvs_mitra', selectedMitra);
                    saveMitraSelection(selectedMitra, cvsSelector);
                } else {
                    sessionStorage.removeItem('nicepay_selected_cvs_mitra');
                }
            });
        }
    }

    // Validasi pas form submit
    $('form.checkout').on('checkout_place_order_nicepay_cvs_snap', function () {
        const selectedMitra = $('#nicepay-cvs-select').val();
        if (!selectedMitra) {
            showError('Silakan pilih Cvs untuk pembayaran', $('.nicepay-cvs-container'));
            return false;
        }

        // Bersihkan input hidden sebelumnya
        $('input[name="nicepay_mitra"]').remove();

        // Tambahkan hidden input ke form
        $('<input>').attr({
            type: 'hidden',
            name: 'nicepay_mitra',
            value: selectedMitra
        }).appendTo('form.checkout');

        return true;
    });

    // Init saat halaman ready
    initNicepayClassic();

    // Reinit tiap checkout di-refresh / payment method diganti
    $(document.body).on('updated_checkout payment_method_selected', function () {
        initNicepayClassic();
    });
});