jQuery(function ($) {
    console.log('NICEPay Payloan classic checkout initialized');

    const config = {
        containerClass: 'nicepay-payloan-container',
        headerClass: 'nicepay-payloan-header',
        selectClass: 'nicepay-payloan-select',
        errorClass: 'nicepay-payloan-error',
        storageKey: 'nicepay_selected_payloan_mitra',
        action: 'set_nicepay_payloan_mitra',
        paymentMethod: 'nicepay_payloan_snap',
        label: 'Pilih Payloan:',
        placeholder: 'Pilih Payloan',
        emptyMessage: 'Payloan belum tersedia saat ini.',
        image: '/assets/images/paylater-logo.png'
    };

    function createSelector() {
        if (!nicepayData || !Array.isArray(nicepayData.enabled_mitra) || nicepayData.enabled_mitra.length === 0) {
            return $('<div>').text(config.emptyMessage);
        }

        const container = $('<div/>', { class: config.containerClass });

        container.append(
            $('<div/>', { class: config.headerClass }).append(
                $('<img/>', {
                    src: nicepayData.pluginUrl + config.image,
                    alt: 'Payloan Logo',
                    class: 'nicepay-payloan-icon',
                    onerror: function () { $(this).hide(); }
                })
            ),
            $('<div/>', { class: config.selectClass }).append(
                $('<label/>', { for: 'nicepay-payloan-select', text: config.label }),
                $('<select/>', { id: 'nicepay-payloan-select', name: 'nicepay_mitra' }).append(
                    $('<option/>', { value: '', text: config.placeholder }),
                    nicepayData.enabled_mitra.map(m => $('<option/>', { value: m.value, text: m.label }))
                )
            ),
            $('<div/>', { class: config.errorClass, style: 'display:none;color:red;margin-top:10px;' })
        );

        return container;
    }

    function showError(message) {
        const errorDiv = $('.' + config.errorClass);
        errorDiv.text(message).show();
        setTimeout(() => errorDiv.fadeOut(), 5000);
    }

    function saveMitra(selectedMitra) {
        if (!selectedMitra) return;
        const select = $('#nicepay-payloan-select').prop('disabled', true);

        $.post(nicepayData.ajax_url, {
            action: config.action,
            mitra_code: selectedMitra,
            nonce: nicepayData.nonce
        })
        .done(res => {
            if (res.success) {
                sessionStorage.setItem(config.storageKey, selectedMitra);
                console.log('Mitra saved:', res.data);
            } else {
                showError(res.data || 'Failed to save selection');
            }
        })
        .fail(() => showError('Failed to save Payloan selection'))
        .always(() => select.prop('disabled', false));
    }

    function initClassic() {
        const methodInput = $(`input[name="payment_method"][value="${config.paymentMethod}"]`);
        if (!methodInput.length) return;

        methodInput.closest('li').find('.' + config.containerClass).remove();
        const selector = createSelector();
        methodInput.closest('li').append(selector);

        const saved = sessionStorage.getItem(config.storageKey);
        if (saved) $('#nicepay-payloan-select').val(saved);

        $('#nicepay-payloan-select').off('change').on('change', function () {
            const val = $(this).val();
            if (val) saveMitra(val);
            else sessionStorage.removeItem(config.storageKey);
        });
    }

    $('form.checkout').on('checkout_place_order_' + config.paymentMethod, function () {
        const selected = $('#nicepay-payloan-select').val();
        if (!selected) {
            showError('Silakan pilih Payloan untuk pembayaran');
            return false;
        }
        $('input[name="nicepay_mitra"]').remove();
        $('<input>', { type: 'hidden', name: 'nicepay_mitra', value: selected }).appendTo('form.checkout');
        return true;
    });

    initClassic();
    $(document.body).on('updated_checkout payment_method_selected', initClassic);
});
