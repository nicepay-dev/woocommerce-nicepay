jQuery(function($) {
    console.log('NICEPay Payout classic checkout loaded');

    $(document).on('change', '#nicepay-payout-bank-select', function() {
        var selectedBank = $(this).val();
        console.log('Selected bank:', selectedBank);

        if (selectedBank) {
            $.ajax({
                url: nicepayPayoutData.ajax_url,
                type: 'POST',
                data: {
                    action: 'set_nicepay_payout_bank',
                    bank_code: selectedBank,
                    security: nicepayPayoutData.nonce || ''
                },
                success: function(response) {
                },
                error: function(error) {
                    console.error('Error saving bank:', error);
                }
            });
        }
    });

    $('form.checkout').on('submit', function(e) {
        var paymentMethod = $('input[name="payment_method"]:checked').val();

        if (paymentMethod === 'nicepay_payout') {
            var selectedBank = $('#nicepay-payout-bank-select').val();
            if (!selectedBank) {
                e.preventDefault();
                if ($('.nicepay-error-message').length === 0) {
                    $('#nicepay-payout-bank-select').after('<div class="nicepay-error-message" style="color: red;">Please select a bank for payout</div>');
                }
                $('html, body').animate({ scrollTop: $('#nicepay-payout-bank-select').offset().top - 100 }, 500);
                return false;
            } else {
                $('.nicepay-error-message').remove();
                if (!$('input[name="nicepay_payout_bank"]').length) {
                    $(this).append('<input type="hidden" name="nicepay_payout_bank" value="' + selectedBank + '">');
                } else {
                    $('input[name="nicepay_payout_bank"]').val(selectedBank);
                }
            }
        }
    });
});