<?php
/**
 * Plugin Name: NICEPay Payment Gateway for WooCommerce
 * Plugin URI: https://github.com/yourusername/nicepay-woocommerce
 * Description: WooCommerce payment gateway integration with NICEPay (Virtual Account, QRIS, E-Wallet, Credit Card, Payloan, CVS).
 * Version: 1.0.1
 * Author: Nicepay
 * Author URI: https://github.com/yourusername
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: nicepay-wc
 * Domain Path: /languages
 * Requires at least: 5.8
 * Tested up to: 6.6
 * WC requires at least: 5.0
 * WC tested up to: 9.2
 */

if (!defined('ABSPATH')) exit;
if ( ! defined( 'NICEPAY_PLUGIN_URL' ) ) {
    define( 'NICEPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
define('NICEPAY_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Load Admin Actions Class
//require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-payout';
//require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-nicepay-transaction.php';
require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-wc-admin-nicepay.php';
        
require_once NICEPAY_PLUGIN_PATH  . 'includes/class-nicepay-log-manager.php';

// Include Log Manager

// Global helper log function
function nicepay_log($message, $type = 'info', $channel = 'va') {
    if (class_exists('NICEPay_Log_Manager')) {
        NICEPay_Log_Manager::instance($channel)->log($message, $type);
    } else {
        error_log("NICEPay {$channel} {$type}: {$message}");
    }
}

// Load gateway class setelah WooCommerce ready
// add_action('admin_menu', ['NICEPay_Admin_Page', 'init']);
add_action('plugins_loaded', 'nicepay_register_payment_gateways', 0);

function nicepay_register_payment_gateways() {
    // Pastikan WooCommerce aktif
    if (!class_exists('WooCommerce')) {
        error_log('[NICEPay] WooCommerce not activated.');
        return;
    }

    // Load gateway classes
    include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-qris.php';
    include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-va.php';
    include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-ewallet.php';
    include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-cvs.php';
    include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-payloan.php';
    include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-cc.php';
    //include_once plugin_dir_path(__FILE__) . 'includes/gateways/class-wc-gateway-nicepay-payout.php';

    // Daftarkan gateway ke WooCommerce
    add_filter('woocommerce_payment_gateways', function($methods) {
        $methods[] = 'WC_Gateway_Nicepay_QRIS';     
        $methods[] = 'WC_Gateway_Nicepay_VA';   
        $methods[] = 'WC_Gateway_Nicepay_Ewallet'; 
        $methods[] = 'WC_Gateway_Nicepay_Cvs'; 
        $methods[] = 'WC_Gateway_Nicepay_Payloan'; 
        $methods[] = 'WC_Gateway_Nicepay_CC'; 
        //$methods[] = 'WC_Gateway_Nicepay_Payout'; 
        return $methods;
    });

    $gatewayVA = new WC_Gateway_Nicepay_VA();
    add_action('wp_ajax_set_nicepay_bank', array($gatewayVA, 'set_nicepay_bank'));
    add_action('wp_ajax_nopriv_set_nicepay_bank', array($gatewayVA, 'set_nicepay_bank'));

    $gatewayEwallet = new WC_Gateway_Nicepay_Ewallet();
    add_action('wp_ajax_set_nicepay_mitra', array($gatewayEwallet, 'set_nicepay_mitra'));
    add_action('wp_ajax_nopriv_set_nicepay_mitra', array($gatewayEwallet, 'set_nicepay_mitra'));

    $gatewayCvs = new WC_Gateway_Nicepay_Cvs();
    add_action('wp_ajax_set_nicepay_cvs_mitra', array($gatewayCvs, 'set_nicepay_cvs_mitra'));
    add_action('wp_ajax_nopriv_set_nicepay_cvs_mitra', array($gatewayCvs, 'set_nicepay_cvs_mitra'));
    
    $gatewayPayloan = new WC_Gateway_Nicepay_Payloan();
    add_action('wp_ajax_set_nicepay_payloan_mitra', array($gatewayPayloan, 'set_nicepay_payloan_mitra'));
    add_action('wp_ajax_nopriv_set_nicepay_payloan_mitra', array($gatewayPayloan, 'set_nicepay_payloan_mitra'));

    $gatewayCC = new WC_Gateway_Nicepay_CC();
    add_action('wp_ajax_set_nicepay_CC_CardNo', array($gatewayCC, 'set_nicepay_CC_CardNo'));
    add_action('wp_ajax_nopriv_set_nicepay_CC_CardNo', array($gatewayCC, 'set_nicepay_CC_CardNo'));

    // $gatewayPayout = new WC_Gateway_Nicepay_Payout();
    // add_action('wp_ajax_set_nicepay_payout_bank', array($gatewayPayout, 'set_nicepay_payout_bank'));
    // add_action('wp_ajax_nopriv_set_nicepay_payout_bank', array($gatewayPayout, 'set_nicepay_payout_bank'));

    // Load asset ke frontend saat checkout
    add_action('wp_enqueue_scripts', 'enqueue_nicepay_payment_assets');
}

function enqueue_nicepay_payment_assets() {
    if (!is_checkout()) return;

    // === QRIS ASSETS ===
    if (class_exists('WC_Gateway_Nicepay_QRIS')) {
        $qris_gateway = new WC_Gateway_Nicepay_QRIS();
        $qris_mode    = $qris_gateway->get_option('enable_blocks', 'classic');

        // QRIS Style
        $file_qris_css = plugin_dir_path(__FILE__) . 'assets/css/qris.css';
        wp_enqueue_style(
            'nicepay-qris-style',
            plugin_dir_url(__FILE__) . 'assets/css/qris.css',
            [],
            filemtime($file_qris_css)
        );

        // QRIS Script
        if ($qris_mode === 'classic') {
            $file_qris_js = plugin_dir_path(__FILE__) . 'assets/js/qris-classic-checkout.js';
            wp_enqueue_script(
                'nicepay-qris-classic',
                plugin_dir_url(__FILE__) . 'assets/js/qris-classic-checkout.js',
                ['jquery'],
                filemtime($file_qris_js),
                true
            );
            $qris_script_handle = 'nicepay-qris-classic';
        } else {
            $file_qris_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/qris-block-integration.js';
            wp_enqueue_script(
                'nicepay-qris-blocks',
                plugin_dir_url(__FILE__) . 'assets/js/qris-block-integration.js',
                ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
                filemtime($file_qris_blocks_js),
                true
            );
            $qris_script_handle = 'nicepay-qris-blocks';
        }

        // QRIS Localized Data
        $data_qris = [
            'ajax_url'   => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('nicepay-qris-nonce'),
            'pluginUrl'  => plugins_url('', __FILE__),
            'merchantId' => $qris_gateway->get_option('iMid'),
            'shopId'     => $qris_gateway->get_option('shopId'),
            'mode'       => $qris_mode
        ];
        wp_localize_script($qris_script_handle, 'qrisData', $data_qris);
    }

    // === VA SNAP ASSETS ===
    if (class_exists('WC_Gateway_Nicepay_VA')) {
        $vasnap_gateway = new WC_Gateway_Nicepay_VA();
        $vasnap_mode    = $vasnap_gateway->get_option('enable_blocks', 'classic');

        // VA Style
        $file_va_css = plugin_dir_path(__FILE__) . 'assets/css/vasnap.css';
        wp_enqueue_style(
            'nicepay-vasnap-style',
            plugin_dir_url(__FILE__) . 'assets/css/vasnap.css',
            [],
            filemtime($file_va_css)
        );

        // VA Script
        if ($vasnap_mode === 'classic') {
            $file_va_js = plugin_dir_path(__FILE__) . 'assets/js/vasnap-classic-checkout.js';
            wp_enqueue_script(
                'nicepay-vasnap-classic',
                plugin_dir_url(__FILE__) . 'assets/js/vasnap-classic-checkout.js',
                ['jquery'],
                filemtime($file_va_js),
                true
            );
            $vasnap_script_handle = 'nicepay-vasnap-classic';
        } else {
            $file_va_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/vasnap-block-integration.js';
            wp_enqueue_script(
                'nicepay-vasnap-blocks',
                plugin_dir_url(__FILE__) . 'assets/js/vasnap-block-integration.js',
                ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
                filemtime($file_va_blocks_js),
                true
            );
            $vasnap_script_handle = 'nicepay-vasnap-blocks';
        }

        // VA Localized Data
        $data_va = [
            'banks'     => $vasnap_gateway->get_active_bank_list(),
            'ajax_url'  => admin_url('admin-ajax.php'),
            'pluginUrl' => plugins_url('', __FILE__),
            'isVA'      => true,
            'nonce'     => wp_create_nonce('nicepay-bank-selection')
        ];
        wp_localize_script($vasnap_script_handle, 'nicepayVAData', $data_va);
    }

    // === Ewallet ASSETS ===
    if (class_exists('WC_Gateway_Nicepay_Ewallet')) {
        $ewallet_gateway = new WC_Gateway_Nicepay_Ewallet();
        $ewallet_mode    = $ewallet_gateway->get_option('enable_blocks', 'classic');

        // ewallet Style
        $file_ewallet_css = plugin_dir_path(__FILE__) . 'assets/css/ewallet.css';
        wp_enqueue_style(
            'nicepay-ewallet-style',
            plugin_dir_url(__FILE__) . 'assets/css/ewallet.css',
            [],
            filemtime($file_ewallet_css)
        );

        // ewallet Script
        if ($ewallet_mode === 'classic') {
            $file_ewallet_js = plugin_dir_path(__FILE__) . 'assets/js/ewallet-classic-checkout.js';
            wp_enqueue_script(
                'nicepay-ewallet-classic',
                plugin_dir_url(__FILE__) . 'assets/js/ewallet-classic-checkout.js',
                ['jquery'],
                filemtime($file_ewallet_js),
                true
            );
            $ewallet_script_handle = 'nicepay-ewallet-classic';
        } else {
            $file_ewallet_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/ewallet-block-integration.js';
            wp_enqueue_script(
                'nicepay-ewallet-blocks',
                plugin_dir_url(__FILE__) . 'assets/js/ewallet-block-integration.js',
                ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
                filemtime($file_ewallet_blocks_js),
                true
            );
            $ewallet_script_handle = 'nicepay-ewallet-blocks';
        }

        // ewallet Localized Data
        $data_ewallet = [
            'ajax_url'   => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('nicepay-ewallet-nonce'),
            'pluginUrl'  => plugins_url('', __FILE__),
            'isEwallet'  => true
        ];
        wp_localize_script($ewallet_script_handle, 'ewalletData', $data_ewallet);
    }

    // === cvs ASSETS ===
    if (class_exists('WC_Gateway_Nicepay_Cvs')) {
        $cvs_gateway = new WC_Gateway_Nicepay_Cvs();
        $cvs_mode    = $cvs_gateway->get_option('enable_blocks', 'classic');

        // cvs Style
        $file_cvs_css = plugin_dir_path(__FILE__) . 'assets/css/cvs.css';
        wp_enqueue_style(
            'nicepay-cvs-style',
            plugin_dir_url(__FILE__) . 'assets/css/cvs.css',
            [],
            filemtime($file_cvs_css)
        );

        // cvs Script
        if ($cvs_mode === 'classic') {
            $file_cvs_js = plugin_dir_path(__FILE__) . 'assets/js/cvs-classic-checkout.js';
            wp_enqueue_script(
                'nicepay-cvs-classic',
                plugin_dir_url(__FILE__) . 'assets/js/cvs-classic-checkout.js',
                ['jquery'],
                filemtime($file_cvs_js),
                true
            );
            $cvs_script_handle = 'nicepay-cvs-classic';
        } else {
            $file_cvs_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/cvs-block-integration.js';
            wp_enqueue_script(
                'nicepay-cvs-blocks',
                plugin_dir_url(__FILE__) . 'assets/js/cvs-block-integration.js',
                ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
                filemtime($file_cvs_blocks_js),
                true
            );
            $cvs_script_handle = 'nicepay-cvs-blocks';
        }

        // cvs Localized Data
        $data_cvs = [
            'ajax_url'   => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('nicepay-cvs-nonce'),
            'pluginUrl'  => plugins_url('', __FILE__),
            'iscvs'  => true
        ];
        wp_localize_script($cvs_script_handle, 'cvsData', $data_cvs);
    }

    // === Payloan ASSETS ===
    if (class_exists('WC_Gateway_Nicepay_Payloan')) {
        $payloan_gateway = new WC_Gateway_Nicepay_Payloan();
        $payloan_mode    = $payloan_gateway->get_option('enable_blocks', 'classic');

        // payloan Style
        $file_payloan_css = plugin_dir_path(__FILE__) . 'assets/css/payloan.css';
        wp_enqueue_style(
            'nicepay-payloan-style',
            plugin_dir_url(__FILE__) . 'assets/css/payloan.css',
            [],
            filemtime($file_payloan_css)
        );

        // payloan Script
        if ($payloan_mode === 'classic') {
            $file_payloan_js = plugin_dir_path(__FILE__) . 'assets/js/payloan-classic-checkout.js';
            wp_enqueue_script(
                'nicepay-payloan-classic',
                plugin_dir_url(__FILE__) . 'assets/js/payloan-classic-checkout.js',
                ['jquery'],
                filemtime($file_payloan_js),
                true
            );
            $payloan_script_handle = 'nicepay-payloan-classic';
        } else {
            $file_payloan_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/payloan-block-integration.js';
            wp_enqueue_script(
                'nicepay-payloan-blocks',
                plugin_dir_url(__FILE__) . 'assets/js/payloan-block-integration.js',
                ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
                filemtime($file_payloan_blocks_js),
                true
            );
            $payloan_script_handle = 'nicepay-payloan-blocks';
        }

        // payloan Localized Data
        $data_payloan = [
            'ajax_url'   => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('nicepay-payloan-nonce'),
            'pluginUrl'  => plugins_url('', __FILE__),
            'ispayloan'  => true
        ];
        wp_localize_script($payloan_script_handle, 'payloanData', $data_payloan);
    }

    // === Credit Card ASSETS ===
    if (class_exists('WC_Gateway_Nicepay_CC')) {
        $cc_gateway = new WC_Gateway_Nicepay_CC();
        $cc_mode    = $cc_gateway->get_option('enable_blocks', 'classic');

        // Credit Card Style
        $file_cc_css = plugin_dir_path(__FILE__) . 'assets/css/cc.css';
        wp_enqueue_style(
            'nicepay-cc-style',
            plugin_dir_url(__FILE__) . 'assets/css/cc.css',
            [],
            filemtime($file_cc_css)
        );

        // Credit Card Script
        if ($cc_mode === 'classic') {
            $file_cc_js = plugin_dir_path(__FILE__) . 'assets/js/cc-classic-checkout.js';
            wp_enqueue_script(
                'nicepay-cc-classic',
                plugin_dir_url(__FILE__) . 'assets/js/cc-classic-checkout.js',
                ['jquery'],
                filemtime($file_cc_js),
                true
            );
            $cc_script_handle = 'nicepay-cc-classic';
        } else {
            $file_cc_blocks_js = plugin_dir_path(__FILE__) . 'assets/js/cc-block-integration.js';
            wp_enqueue_script(
                'nicepay-cc-blocks',
                plugin_dir_url(__FILE__) . 'assets/js/cc-block-integration.js',
                ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
                filemtime($file_cc_blocks_js),
                true
            );
            $cc_script_handle = 'nicepay-cc-blocks';
        }

        // Credit Card Localized Data
        $data_cc = [
            'ajax_url'  => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('nicepay-cc-nonce'),
            'pluginUrl' => plugins_url('', __FILE__),
            'isCC'      => true
        ];
        wp_localize_script($cc_script_handle, 'ccData', $data_cc);
    }

    // === Payout ASSETS ===
    // if (class_exists('WC_Gateway_Nicepay_Payout')) {
    //     $payout_gateway = new WC_Gateway_Nicepay_Payout();
    //     $payout_mode    = $payout_gateway->get_option('enable_blocks', 'classic');

    //     // Payout Style
    //     $file_payout_css = plugin_dir_path(__FILE__) . 'assets/css/payout.css';
    //     if (file_exists($file_payout_css)) {
    //         wp_enqueue_style(
    //             'nicepay-payout-style',
    //             plugin_dir_url(__FILE__) . 'assets/css/payout.css',
    //             [],
    //             filemtime($file_payout_css)
    //         );
    //     }

    //     // Payout Script
    //     if ($payout_mode === 'classic') {
    //         $file_payout_js = plugin_dir_path(__FILE__) . 'assets/js/payout-classic-checkout.js';
    //         wp_enqueue_script(
    //             'nicepay-payout-classic',
    //             plugin_dir_url(__FILE__) . 'assets/js/payout-classic-checkout.js',
    //             ['jquery'],
    //             filemtime($file_payout_js),
    //             true
    //         );
    //         $payout_script_handle = 'nicepay-payout-classic';
    //     } else {
    //         $file_payout_js = plugin_dir_path(__FILE__) . 'assets/js/payout-block-integration.js';
    //         wp_enqueue_script(
    //             'nicepay-payout-blocks',
    //             plugin_dir_url(__FILE__) . 'assets/js/payout-block-integration.js',
    //             ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'],
    //             filemtime($file_payout_js),
    //             true
    //         );
    //         $payout_script_handle = 'nicepay-payout-blocks';
    //     }

    //     // VA Localized Data
    //     $data_payout = [
    //         'ajax_url'  => admin_url('admin-ajax.php'),
    //         'pluginUrl' => plugins_url('', __FILE__),
    //         'isPayout'  => true,
    //         'nonce'     => wp_create_nonce('nicepay-bank-payout-selection')
    //     ];
    //     wp_localize_script($payout_script_handle, 'nicepayPayoutData', $data_payout);
    // }
}

// /**
//  * === Admin Menu ===
//  */
// add_action('admin_menu', 'nicepay_register_admin_menu');
// function nicepay_register_admin_menu() {
//     add_menu_page(
//         'NICEPay Admin Actions',
//         'NICEPay Admin Actions',
//         'manage_options',
//         'nicepay-admin-actions',
//         'nicepay_admin_actions_page',
//         'dashicons-admin-generic',
//         56
//     );
// }

// function nicepay_admin_actions_page() {
//     $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'va';

//     $tabs = [
//         'va'      => 'VA Cancel',
//         'qris'    => 'QRIS Cancel',
//         'ewallet' => 'eWallet Cancel'
//         //'payout'  => 'Payout Actions'
//     ];

//     echo '<div class="wrap">';
//     echo '<h1>NICEPay Admin Actions</h1>';

//     // Tabs
//     echo '<h2 class="nav-tab-wrapper">';
//     foreach ($tabs as $key => $label) {
//         $class = ($active_tab == $key) ? ' nav-tab-active' : '';
//         echo '<a href="?page=nicepay-admin-actions&tab=' . $key . '" class="nav-tab' . $class . '">' . esc_html($label) . '</a>';
//     }
//     echo '</h2>';

//     echo '<div id="nicepay-admin-container">';
//     echo '<form id="nicepay-admin-form">';
//     wp_nonce_field('nicepay_admin_action', 'nicepay_admin_nonce');
//     echo '<input type="hidden" name="action" value="nicepay_admin_process">';
//     echo '<input type="hidden" name="operation" value="' . esc_attr($active_tab) . '">';

//     // Render form per tab
//     if ($active_tab === 'va') {
//         echo '<h3>VA Cancel</h3>';
//         echo '<label>virtualAccountNo</label><input type="text" name="virtualAccountNo" required />';
//         echo '<label>trxId</label><input type="text" name="trxId" required />';
//     }

//     if ($active_tab === 'qris') {
//         echo '<h3>QRIS Cancel</h3>';
//         echo '<label>originalPartnerReferenceNo</label><input type="text" name="originalPartnerReferenceNo" required />';
//         echo '<label>originalReferenceNo</label><input type="text" name="originalReferenceNo" required />';
//         echo '<label>partnerRefundNo</label><input type="text" name="partnerRefundNo" required />';
//         echo '<label>merchantId</label><input type="text" name="merchantId" required />';
//     }

//     if ($active_tab === 'ewallet') {
//         echo '<h3>eWallet Cancel</h3>';
//         echo '<label>originalPartnerReferenceNo</label><input type="text" name="originalPartnerReferenceNo" required />';
//         echo '<label>originalReferenceNo</label><input type="text" name="originalReferenceNo" required />';
//         echo '<label>partnerRefundNo</label><input type="text" name="partnerRefundNo" required />';
//         echo '<label>merchantId</label><input type="text" name="merchantId" required />';
//     }

//     if ($active_tab === 'payout') {
//         echo '<h3>Payout Actions</h3>';
//         echo '<label>originalPartnerReferenceNo</label><input type="text" name="originalPartnerReferenceNo" required />';
//         echo '<label>originalReferenceNo</label><input type="text" name="originalReferenceNo" required />';
//         echo '<label>merchantId</label><input type="text" name="merchantId" required />';
//         echo '<label>Action</label>';
//         echo '<select name="payout_action" required>
//                 <option value="">Select</option>
//                 <option value="approve">Approve</option>
//                 <option value="reject">Reject</option>
//                 <option value="cancel">Cancel</option>
//               </select>';
//     }

//     echo '<button type="submit" class="button button-primary">Submit</button>';
//     echo '</form>';
//     echo '<div id="nicepay-admin-response"></div>';
//     echo '</div>';
//     echo '</div>';
// }

// // Enqueue admin JS + CSS
// add_action('admin_enqueue_scripts', function($hook) {
//     if ($hook !== 'toplevel_page_nicepay-admin-actions') return;
//     wp_enqueue_script('nicepay-admin-js', NICEPAY_PLUGIN_URL . 'assets/js/nicepay-admin.js', ['jquery'], '1.0', true);
//     wp_localize_script('nicepay-admin-js', 'nicepayAdmin', [
//         'ajax_url' => admin_url('admin-ajax.php'),
//         'nonce'    => wp_create_nonce('nicepay_admin_action')
//     ]);
//     wp_enqueue_style('nicepay-admin-css', NICEPAY_PLUGIN_URL . 'assets/css/nicepay-admin.css');
// });

// // Handle AJAX
// add_action('wp_ajax_nicepay_admin_process', function() {
//     check_ajax_referer('nicepay_admin_action', 'security');

//     $operation = sanitize_text_field($_POST['operation']);
//     $params    = $_POST;

//     unset($params['action'], $params['security'], $params['operation']);

//     require_once NICEPAY_PLUGIN_PATH . 'includes/admin/class-nicepay-admin-actions.php';
//     $result = NICEPay_Admin_Actions::process($operation, $params);

//     wp_send_json($result);
// });

// Tambah admin menu log page
add_action('admin_menu', 'nicepay_register_log_menu');
function nicepay_register_log_menu() {
    add_menu_page(
        'NICEPay Logs',
        'NICEPay Logs',
        'manage_options',
        'nicepay-logs',
        'nicepay_logs_main_page_callback',
        'dashicons-clipboard',
        56
    );
}

// Main admin log page callback
function nicepay_logs_main_page_callback() {
    $active_tab = isset($_GET['channel']) ? sanitize_text_field($_GET['channel']) : 'va';
    $channels = ['va' => 'VA', 'qris' => 'QRIS', 'ewallet' => 'eWallet', 'payout' => 'Payout', 'cvs' => 'Cvs', 'payloan' => 'Payloan', 'cc' => 'Credit Card'];

    echo '<div class="wrap"><h1>NICEPay Logs</h1>';

    // Tab navigation
    echo '<h2 class="nav-tab-wrapper">';
    foreach ($channels as $key => $label) {
        $active_class = ($active_tab === $key) ? ' nav-tab-active' : '';
        echo '<a href="?page=nicepay-logs&channel=' . esc_attr($key) . '" class="nav-tab' . $active_class . '">' . esc_html($label) . '</a>';
    }
    echo '</h2>';

    $log_manager = NICEPay_Log_Manager::instance($active_tab);

    // Action buttons
    echo '<p><a href="' . esc_url($log_manager->get_log_file_url()) . '" class="button button-primary" download>Download Log Hari Ini</a> ';
    echo '<a href="' . admin_url('admin.php?page=nicepay-logs&channel=' . $active_tab . '&clear=true') . '" class="button">Clear Log Hari Ini</a></p>';

    // Tampilkan log hari ini
    $logs = $log_manager->get_logs();
    if (empty($logs)) {
        echo '<p>Tidak ada log ditemukan.</p>';
    } else {
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Waktu</th><th>Tipe</th><th>Pesan</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            echo '<tr>';
            echo '<td>' . esc_html($log['time']) . '</td>';
            echo '<td>' . esc_html(ucfirst($log['type'])) . '</td>';
            echo '<td>' . esc_html($log['message']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    // Daftar file log lama
    $files = $log_manager->get_log_files();
    if (!empty($files)) {
        echo '<h3>Log Sebelumnya</h3><ul>';
        foreach ($files as $file) {
            if ($file === $log_manager->get_today_log_filename()) continue;
            $url = $log_manager->get_log_file_url($file);
            echo '<li><a href="' . esc_url($url) . '" download>' . esc_html($file) . '</a></li>';
        }
        echo '</ul>';
    }

    echo '</div>';
}

// Clear log dari URL param
add_action('admin_init', function() {
    if (isset($_GET['page'], $_GET['channel'], $_GET['clear']) && $_GET['page'] === 'nicepay-logs' && $_GET['clear'] === 'true') {
        $channel = sanitize_text_field($_GET['channel']);
        if (in_array($channel, ['va', 'qris', 'ewallet', 'payout', 'cvs', 'payloan', 'cc'])) {
            NICEPay_Log_Manager::instance($channel)->clear_logs();
            wp_safe_redirect(admin_url('admin.php?page=nicepay-logs&channel=' . $channel));
            exit;
        }
    }
});